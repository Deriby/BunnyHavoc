@tool
extends RefCounted
## Paleta e trilha pintada da Fase 1 em HTML; calculadas fora do render.
static var _material: StandardMaterial3D
static func material() -> StandardMaterial3D:
	if _material == null:
		_material = StandardMaterial3D.new()
		_material.vertex_color_use_as_albedo = true
		_material.vertex_color_is_srgb = false
		_material.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
		_material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
		_material.roughness = 1.0
	return _material
static func largura(z: float) -> float:
	for area in [[-56,-84],[-144,-172],[-232,-260],[-330,-380]]:
		if z<area[0] and z>area[1]:return 4+3*pow(sin(PI*(area[0]-z)/float(area[0]-area[1])),.6)
	return 4.0
static func _variar_luz(c: Color, delta: float) -> Color:
	var maior: float=maxf(c.r,maxf(c.g,c.b));var menor: float=minf(c.r,minf(c.g,c.b))
	var l: float=clampf((maior+menor)*.5+delta,0,1)
	var s: float=(maior-menor)/maxf(.00001,1-absf(maior+menor-1))
	var v: float=l+s*minf(l,1-l)
	return Color.from_hsv(c.h,2*(1-l/v) if v>0 else 0,v)
static func cor_piso(p: Vector3, circular: bool=false) -> Color:
	# A compressão dos vértices pode trazer a borda x=4 para 3,9998.
	# Mantém a mesma classificação do HTML e evita uma costura clara na margem.
	var dentro: bool=absf(p.x)<largura(p.z)-.01
	var verde: Color=Color("71bd55" if dentro else "347f45").srgb_to_linear()
	var c: Color=_variar_luz(verde,sin(p.x*.9+p.z*.7)*.025)
	var areia: Color=Color("cbb17b").srgb_to_linear()
	if dentro:
		var lane: float=absf(p.x-.36*sin(p.z*.029))
		c=c.lerp(areia,pow(maxf(0,1-lane/3.4),1.25)*.56)
		if lane>2.65:c=c.lerp(Color("4b9a56").srgb_to_linear(),.16)
	if circular:
		var d: float=Vector2(p.x,p.z+119).length()
		var centro: Color=_variar_luz(Color("71bd55").srgb_to_linear(),sin(p.x*.9+p.z*.7)*.025).lerp(areia,.56)
		c=centro.lerp(c,smoothstep(8.0,12.0,d))
	# Compatibility trabalha a cor final em sRGB; os GLBs traziam a cor linear.
	return c.linear_to_srgb()
