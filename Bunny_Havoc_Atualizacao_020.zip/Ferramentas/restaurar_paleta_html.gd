extends SceneTree
## Recolore os recursos compilados; preserva posições, faces, colisões e fontes.
const Paleta=preload("res://Fase1/Arena/paleta_bosque.gd")
const DESTINO: String="res://Recursos/Terreno020"
var mat: StandardMaterial3D
var mapeamento: Dictionary={}
var faces_originais: int=0
var faces_novas: int=0
func _initialize() -> void:gerar.call_deferred()
func converter(path: String) -> void:
	var source: ArrayMesh=load(path)
	var tool:=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES);tool.set_material(mat)
	for s in source.get_surface_count():
		var antigo: BaseMaterial3D=source.surface_get_material(s)
		var a: Array=source.surface_get_arrays(s).duplicate(true)
		var vertices: PackedVector3Array=a[Mesh.ARRAY_VERTEX]
		var cores: PackedColorArray=a[Mesh.ARRAY_COLOR]
		for i in vertices.size():
			if antigo.albedo_texture!=null:
				var p: Vector3=vertices[i]
				cores[i]=Paleta.cor_piso(p,Vector2(p.x,p.z+119).length()<12.1)
			else:cores[i]=cores[i].linear_to_srgb()
		a[Mesh.ARRAY_COLOR]=cores;a[Mesh.ARRAY_TEX_UV]=null;a[Mesh.ARRAY_TEX_UV2]=null;a[Mesh.ARRAY_TANGENT]=null
		var temp:=ArrayMesh.new();temp.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);temp.surface_set_material(0,mat)
		tool.append_from(temp,0,Transform3D.IDENTITY)
		faces_originais+=source.surface_get_array_index_len(s)/3
	tool.index();var mesh: ArrayMesh=tool.commit()
	faces_novas+=mesh.surface_get_array_index_len(0)/3
	var importer: Resource=ClassDB.instantiate("ImporterMesh")
	importer.add_surface(Mesh.PRIMITIVE_TRIANGLES,mesh.surface_get_arrays(0),[],{},mat)
	importer.generate_lods(25.0,60.0,[]);mesh=importer.get_mesh()
	mesh.set_meta("paleta_html020",true);mesh.set_meta("fonte_preservada",path)
	var novo: String=DESTINO+"/"+path.get_file()
	assert(ResourceSaver.save(mesh,novo,ResourceSaver.FLAG_COMPRESS)==OK)
	mapeamento[path]=novo
func gerar() -> void:
	DirAccess.make_dir_recursive_absolute(DESTINO)
	assert(ResourceSaver.save(Paleta.material(),DESTINO+"/paleta.tres")==OK)
	mat=load(DESTINO+"/paleta.tres")
	for name in DirAccess.get_files_at("res://Fase1/Estatico/Trechos"):
		if name.begins_with("terreno_") and name.ends_with(".res"):converter("res://Fase1/Estatico/Trechos/"+name)
	for name in DirAccess.get_files_at("res://Fase1/Estatico/Malhas"):
		if name.begins_with("longe_") and name.ends_with("_0.res"):converter("res://Fase1/Estatico/Malhas/"+name)
	var cenas: Array[String]=["res://Fase1/Estatico/CenarioTrechos.tscn"]
	for name in DirAccess.get_files_at("res://Fase1/Estatico/Trechos"):
		if name.ends_with(".tscn"):cenas.append("res://Fase1/Estatico/Trechos/"+name)
	for path in cenas:
		var texto: String=FileAccess.get_file_as_string(path)
		for antigo in mapeamento:texto=texto.replace(antigo,mapeamento[antigo])
		FileAccess.open(path,FileAccess.WRITE).store_string(texto)
	assert(faces_originais==faces_novas)
	print(JSON.stringify({"meshes":mapeamento.size(),"originalTriangles":faces_originais,"recoloredTriangles":faces_novas,"textureLookups":0}))
	quit()
