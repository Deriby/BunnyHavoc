extends SceneTree
const NOMES: Array[String]=["ArvoreCopaRedonda","Pinheiro","Arbusto","Rocha","Seixo","TufoGrama","FlorAzul","FlorRosa","FlorAmarela","FlorBranca","CogumeloRoxo","CogumeloVermelho","CogumeloAmarelo"]
var resultados: Dictionary={}
func _initialize() -> void:run.call_deferred()
func run() -> void:
 DirAccess.make_dir_recursive_absolute("res://Fase1/Estatico/Impostores")
 for nome in NOMES:
  var viewport:=SubViewport.new();viewport.size=Vector2i(192,192);viewport.transparent_bg=true;viewport.own_world_3d=true;viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(viewport)
  var world:=Node3D.new();viewport.add_child(world)
  var env:=WorldEnvironment.new();env.environment=Environment.new();env.environment.background_mode=Environment.BG_CLEAR_COLOR;env.environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.environment.ambient_light_color=Color(1,.953,.859);env.environment.ambient_light_energy=.5;world.add_child(env)
  var light:=DirectionalLight3D.new();light.rotation_degrees=Vector3(-53,-40,0);light.light_color=Color(1,.91,.69);light.light_energy=.95;world.add_child(light)
  var planta: Node3D=load("res://Cenas/Natureza/"+nome+".tscn").instantiate();world.add_child(planta)
  var box: AABB;var primeiro: bool=true
  for n: MeshInstance3D in planta.find_children("*","MeshInstance3D",true,false):
   if not n.is_visible_in_tree():continue
   for s in n.mesh.get_surface_count():
    var m: Material=n.get_active_material(s)
    if m is BaseMaterial3D:
     m=m.duplicate();m.vertex_color_use_as_albedo=true;m.shading_mode=BaseMaterial3D.SHADING_MODE_PER_VERTEX;m.specular_mode=BaseMaterial3D.SPECULAR_DISABLED;n.set_surface_override_material(s,m)
   var a: AABB=n.global_transform*n.mesh.get_aabb();box=a if primeiro else box.merge(a);primeiro=false
  var centro: Vector3=box.get_center();var tamanho: float=maxf(box.size.x,box.size.y)*1.04
  var camera:=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.size=tamanho;world.add_child(camera);camera.position=centro+Vector3(0,0,20);camera.look_at(centro);camera.current=true
  for i in 4:await process_frame
  await RenderingServer.frame_post_draw
  var img: Image=viewport.get_texture().get_image();var path: String="res://Fase1/Estatico/Impostores/"+nome+".res"
  img.generate_mipmaps();var tex:=ImageTexture.create_from_image(img);assert(ResourceSaver.save(tex,path,ResourceSaver.FLAG_COMPRESS)==OK)
  resultados[nome]={"texture":path,"size":tamanho,"center":centro}
  viewport.queue_free();await process_frame
 var output:=Node3D.new();output.name="NaturezaDistante"
 var mapping: Dictionary={"Cogumelo_9d74e4":"CogumeloRoxo","Cogumelo_e95364":"CogumeloVermelho","Cogumelo_ffc052":"CogumeloAmarelo","Flor_6ab0ff":"FlorAzul","Flor_ff5ac8":"FlorRosa","Flor_ffe14a":"FlorAmarela","Flor_ffffff":"FlorBranca"}
 var grupos: Dictionary={};var total: int=0
 for p in ["Fase1/natureza-layout.json","Fase1/Trecho2/natureza-layout.json","Fase1/Trecho4/natureza-layout.json","Fase1/Completa/natureza-layout.json"]:
  var registros: Array=JSON.parse_string(FileAccess.get_file_as_string("res://"+p))
  for d in registros:
   var pos:=Vector3(d.position[0],d.position[1],d.position[2])
   if Vector2(pos.x,pos.z+119).length()<15:continue
   var nome: String=mapping.get(d.name,d.name);var faixa: int=floori(pos.z/64)
   var key: String=str(faixa)+":"+nome
   if not grupos.has(key):grupos[key]={"faixa":faixa,"nome":nome,"transforms":[]}
   var t:=Transform3D(Basis.IDENTITY.scaled(Vector3.ONE*float(d.scale)),pos)
   grupos[key].transforms.append(t);total+=1
 var mats: Dictionary={};var malhas: Dictionary={}
 for g in grupos.values():
  var nome: String=g.nome;var info: Dictionary=resultados[nome]
  if not mats.has(nome):
   var mat:=StandardMaterial3D.new();mat.albedo_texture=load(info.texture);mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR;mat.alpha_scissor_threshold=.4;mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;mat.billboard_mode=BaseMaterial3D.BILLBOARD_FIXED_Y;mat.texture_filter=BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS;mat.cull_mode=BaseMaterial3D.CULL_DISABLED;mats[nome]=mat
   var quad:=QuadMesh.new();quad.size=Vector2.ONE*float(info.size);quad.center_offset=info.center;quad.material=mat;malhas[nome]=quad
  var n:=MultiMeshInstance3D.new();n.name="Plantas_%d_%s"%[g.faixa,nome];n.material_override=mats[nome];n.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
  var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.mesh=malhas[nome];mm.instance_count=g.transforms.size()
  var a: AABB;var primeiro: bool=true
  for i in mm.instance_count:
   mm.set_instance_transform(i,g.transforms[i]);var b: AABB=g.transforms[i]*mm.mesh.get_aabb();a=b if primeiro else a.merge(b);primeiro=false
  mm.custom_aabb=a.grow(2);n.multimesh=mm;n.layers=0;n.set_meta("faixa_z",(float(g.faixa)+.5)*64);output.add_child(n);n.owner=output
 output.set_meta("plantas",total);output.set_meta("grupos",grupos.size())
 var packed:=PackedScene.new();assert(packed.pack(output)==OK);assert(ResourceSaver.save(packed,"res://Fase1/Estatico/NaturezaDistante.tscn")==OK)
 print("IMPOSTORS ",total," plants, ",grupos.size()," groups")
 output.free();quit.call_deferred()
