extends CharacterBody3D
## Locomoção nativa com os impulsos aprovados e uma janela curta de entrada.

const AnimacaoBunnyck = preload("bunnyck_animacao.gd")
const ComboBunnyck = preload("bunnyck_combo.gd")

@export var velocidade_andar: float = 6.4
@export var velocidade_correr: float = 10.3
@export var gravidade: float = 24.0
@export var impulso_salto: float = 10.1
@export var impulso_salto_correndo: float = 12.8
@export var acompanhar_camera: bool = true
@export var voltar_ao_cair: bool = true

const ACELERACAO_CHAO: float = 10.0
const ACELERACAO_AR: float = 5.2
const TOLERANCIA_BORDA: float = 0.12
const ANTECIPACAO_SALTO: float = 0.12
const LIMIAR_SALTO_CORRENDO: float = 7.6

var _velocidade_antes_deslize: Vector3
var _quadro_colisao: int = -1
var _visual: Node3D
var _camera: Camera3D
var _inicio: Vector3
var _camera_inicio: Vector3
var _tolerancia_restante: float = 0.0
var _salto_pressionado: bool = false
var _salto_em_fila: float = 0.0
var _animacao: RefCounted = AnimacaoBunnyck.new()
var _combate: RefCounted = ComboBunnyck.new()

func _ready() -> void:
	_visual = get_node_or_null("Visual") as Node3D
	_camera = get_viewport().get_camera_3d()
	_inicio = global_position
	if _camera != null:
		_camera_inicio = _camera.global_position
	_animacao.configurar(_visual)
	_combate.configurar(self, _visual)

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var tecla: int = event.physical_keycode if event.physical_keycode != 0 else event.keycode
		if tecla == KEY_SPACE and is_physics_processing():
			_salto_em_fila = ANTECIPACAO_SALTO
			_salto_pressionado = true
		if tecla == KEY_J or tecla == KEY_SHIFT:
			if _combate.pressionar(_ler_direcao()):
				get_viewport().set_input_as_handled()

func _process(_delta: float) -> void:
	# Conversa, morte e cutscene não podem guardar um pulo para depois.
	if not is_physics_processing():
		_salto_em_fila = 0.0
		_tolerancia_restante = 0.0
		_salto_pressionado = Input.is_physical_key_pressed(KEY_SPACE)

func _physics_process(delta: float) -> void:
	var eixo: Vector2 = _ler_direcao()
	_combate.atualizar(delta, eixo)
	var correndo: bool = (
		Input.is_physical_key_pressed(KEY_K)
		or Input.is_physical_key_pressed(KEY_CTRL)
	) and eixo.length() > 0.1 and not _combate.atacando
	var velocidade_alvo: float = 7.0 if _combate.atacando else velocidade_correr if correndo else velocidade_andar
	var taxa: float = ACELERACAO_CHAO if is_on_floor() else ACELERACAO_AR
	var fator: float = minf(1.0, delta * taxa)
	velocity.x = lerpf(velocity.x, eixo.x * velocidade_alvo, fator)
	velocity.z = lerpf(velocity.z, eixo.y * velocidade_alvo, fator)

	if is_on_floor():
		_tolerancia_restante = TOLERANCIA_BORDA
	else:
		_tolerancia_restante = maxf(0.0, _tolerancia_restante - delta)

	var espaco: bool = Input.is_physical_key_pressed(KEY_SPACE)
	if espaco and not _salto_pressionado:
		_salto_em_fila = ANTECIPACAO_SALTO
	_salto_pressionado = espaco
	if _salto_em_fila > 0.0 and _tolerancia_restante > 0.0:
		var rapidez: float = Vector2(velocity.x, velocity.z).length()
		var impulso: float = impulso_salto_correndo if rapidez > LIMIAR_SALTO_CORRENDO else impulso_salto
		# A entrada antecipada não reduz o lançamento de uma caixa-mola.
		velocity.y = maxf(velocity.y, impulso)
		_tolerancia_restante = 0.0
		_salto_em_fila = 0.0
	_salto_em_fila = maxf(0.0, _salto_em_fila - delta)

	velocity.y -= gravidade * delta
	_velocidade_antes_deslize = velocity
	_quadro_colisao = Engine.get_physics_frames()
	move_and_slide()
	_animacao.atualizar(delta, velocity, is_on_floor(), correndo, eixo.length_squared() > 0.0, _combate.girando)
	_combate.aplicar_pose()

	# Recuperação desta plataforma de teste; ainda não é a regra de morte/vidas.
	if voltar_ao_cair and global_position.y < _inicio.y - 12.0:
		voltar_ao_inicio()
	_atualizar_camera()

func encostou_em(corpo: PhysicsBody3D) -> bool:
	if _quadro_colisao != Engine.get_physics_frames():return false
	for i in get_slide_collision_count():
		if get_slide_collision(i).get_collider() == corpo:return true
	# Um inimigo pode ter parado no jogador depois do movimento deste quadro.
	var direcao: Vector3 = corpo.global_position-global_position
	direcao.y = 0.0
	if direcao.length_squared() < 12.25 and direcao.length_squared() > 0.0001:
		var contato := KinematicCollision3D.new()
		if test_move(global_transform,direcao.normalized()*0.035,contato):
			for i in contato.get_collision_count():
				if contato.get_collider(i) == corpo:return true
	return false

func pisou_em(corpo: PhysicsBody3D) -> bool:
	# move_and_slide zera a queda: use a velocidade de entrada e a normal real.
	if _quadro_colisao != Engine.get_physics_frames() or _velocidade_antes_deslize.y >= -0.6:return false
	for i in get_slide_collision_count():
		var contato: KinematicCollision3D = get_slide_collision(i)
		if contato.get_collider() == corpo and contato.get_normal().y > 0.5:return true
	return false

func _ler_direcao() -> Vector2:
	var direita: bool = Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT)
	var esquerda: bool = Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT)
	var baixo: bool = Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN)
	var cima: bool = Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP)
	var eixo: Vector2 = Vector2(float(direita) - float(esquerda), float(baixo) - float(cima))
	return eixo.normalized() if eixo.length_squared() > 1.0 else eixo

func _atualizar_camera() -> void:
	if acompanhar_camera and is_instance_valid(_camera):
		# Mantém altura/rotação que o usuário configurou; acompanha só X/Z.
		var deslocamento: Vector3 = global_position - _inicio
		_camera.global_position = _camera_inicio + Vector3(deslocamento.x, 0.0, deslocamento.z)

func voltar_ao_inicio() -> void:
	global_position = _inicio
	velocity = Vector3.ZERO
	_tolerancia_restante = 0.0
	_salto_pressionado = Input.is_physical_key_pressed(KEY_SPACE)
	_salto_em_fila = 0.0
	_combate.limpar()
	_animacao.reiniciar()
	_atualizar_camera()
