extends Node
## Geometria próxima sob demanda; o fundo de cada faixa permanece até a troca.
var mundo: Node3D
var jogador: Node3D
var camera: Camera3D
var faixas: Array[Dictionary] = []
var modo: int = 1
var carregados: int = 0
var pedidos: int = 0
var liberados: int = 0
var _tempo: float = 0
var _natureza_completa: Node3D

func configurar(raiz: Node3D) -> void:
	mundo = raiz; jogador = mundo.get_parent().get_node("Jogador"); camera = mundo.get_parent().get_node("Camera3D")
	for key in mundo.get_meta("trechos"):
		var d: Dictionary = mundo.get_meta("trechos")[key]
		faixas.append({"id": int(key), "path": d.path, "z": float(d.z), "near": null, "far": mundo.get_node("Longe_%s_0" % key), "pedido": false})
	atualizar(true)

func qualidade(novo: int) -> void:
	modo = novo
	if modo == 2 and _natureza_completa == null:
		# Apenas o perfil Nítido solicita a vegetação 3D integral anterior.
		_natureza_completa = load("res://Fase1/Estatico/CenarioEstatico.tscn").instantiate()
		mundo.add_child(_natureza_completa)
		for n in _natureza_completa.get_children():
			if not String(n.name).begins_with("Bloco_") or not String(n.name).ends_with("_1"): n.queue_free()
			else: n.layers = 1
	elif modo != 2 and _natureza_completa != null:
		_natureza_completa.queue_free(); _natureza_completa = null
	atualizar(true)

func _process(dt: float) -> void:
	_tempo += dt
	if _tempo >= 0.10: atualizar()
	# Nunca bloqueia esperando uma leitura nem instancia várias faixas no mesmo quadro.
	for f in faixas:
		if not f.pedido: continue
		var status: int = ResourceLoader.load_threaded_get_status(f.path)
		if status == ResourceLoader.THREAD_LOAD_LOADED:
			var cena: PackedScene = ResourceLoader.load_threaded_get(f.path)
			f.pedido = false; pedidos -= 1
			f.near = cena.instantiate(); mundo.add_child(f.near); carregados += 1
			_exibir(f)
			break
		elif status == ResourceLoader.THREAD_LOAD_FAILED:
			f.pedido = false; pedidos -= 1; push_error("Não foi possível carregar " + f.path)

func _distancia(z: float) -> float:
	var filme: Node = mundo.get_parent().get("final")
	if filme != null and filme.ativo: return absf(camera.global_position.z - z)
	return minf(absf(jogador.global_position.z - z), absf(camera.global_position.z - z))

func _exibir(f: Dictionary) -> void:
	var perto: bool = f.near != null and _distancia(f.z) < (96.0 if modo != 1 else 80.0)
	if f.near != null:
		f.near.visible = perto
		# Mantém o relevo dos buracos e o chão sob os perigos, mesmo no perfil leve.
		for n in f.near.get_children(): n.lod_bias = 16.0
	f.far.layers = 0 if perto else 1

func atualizar(inicial: bool = false) -> void:
	_tempo = 0
	faixas.sort_custom(func(a, b): return _distancia(a.z) < _distancia(b.z))
	for f in faixas:
		var distancia: float = _distancia(f.z)
		if distancia < 144.0 and f.near == null and not f.pedido:
			if inicial and distancia < 80.0:
				f.near = load(f.path).instantiate(); mundo.add_child(f.near); carregados += 1
			elif pedidos < 2:
				var erro: int = ResourceLoader.load_threaded_request(f.path, "PackedScene", false)
				if erro == OK: f.pedido = true; pedidos += 1
		if distancia > 176.0 and f.near != null:
			f.far.layers = 1; f.near.queue_free(); f.near = null; carregados -= 1; liberados += 1
		_exibir(f)

func _exit_tree() -> void:
	# Consome pedidos pendentes para não deixar tarefas órfãs ao fechar a fase.
	for f in faixas:
		if f.pedido: ResourceLoader.load_threaded_get(f.path)
