extends CanvasLayer
const Distantes=preload("lotes_distantes.gd")
const Terreno=preload("lotes_terreno.gd")
const MODOS: Array[String]=["Leve","Mínimo","Completo"]
const RESOLUCOES: Array[float]=[168.0,240.0,360.0,540.0,0.0]
const CONFIG_IMAGEM: String="user://imagem_019.cfg"
var modo: int=1
var nitidez: int=2
var _aviso: Label
var _restante: float=0
var _fps: Label
var _viewport: Viewport
var terreno: Node3D
var detalhes: Node
var trechos: Node
func _ready() -> void:
	layer=80;_viewport=get_viewport()
	_aviso=Label.new();_aviso.position=Vector2(20,178)
	_aviso.mouse_filter=Control.MOUSE_FILTER_IGNORE
	_aviso.add_theme_font_size_override("font_size",16)
	_aviso.add_theme_color_override("font_color",Color("fff0dc"))
	_aviso.add_theme_color_override("font_outline_color",Color("241335"))
	_aviso.add_theme_constant_override("outline_size",4)
	add_child(_aviso);_aviso.visible=false
	_fps=Label.new();_fps.position=Vector2(20,204);_fps.visible=false;add_child(_fps)
	_viewport.size_changed.connect(_redimensionar)
	var config:=ConfigFile.new()
	if config.load(CONFIG_IMAGEM)==OK:nitidez=clampi(int(config.get_value("imagem","resolucao",2)),0,RESOLUCOES.size()-1)
	aplicar(1,false);_preparar.call_deferred()
	_mostrar_aviso("Imagem: "+_nome_resolucao()+" — F7 troca resolução; F3 detalhes")
func _preparar() -> void:
	terreno=Terreno.agrupar(get_parent()) if OS.get_environment("BH_BUILD_STATIC_WORLD")=="1" else get_parent().get_node("CenarioEstatico")
	detalhes=Distantes.new();detalhes.name="DetalhesDistantes";get_parent().add_child(detalhes);detalhes.configurar(get_parent());detalhes.qualidade(modo)
	var cenouras: Node3D=preload("res://Sistemas/Visual/lote_cenouras.gd").new();get_parent().add_child(cenouras);cenouras.configurar(get_parent())
	trechos=preload("res://Sistemas/Visual/trechos_ativos.gd").new();trechos.name="TrechosAtivos";get_parent().add_child(trechos);trechos.configurar(get_parent())
	var legiveis: Node=preload("objetos_legiveis.gd").new();legiveis.name="ObjetosLegiveis";get_parent().add_child(legiveis);legiveis.configurar(get_parent())
	var sombras: Node3D=preload("sombras_contato.gd").new();sombras.name="SombrasContato";get_parent().add_child(sombras);sombras.configurar(get_parent())
	var aquecimento: Node3D=preload("aquecimento.gd").new();get_parent().add_child(aquecimento)
func _redimensionar() -> void:aplicar(modo,false)
func aplicar(indice: int,avisar: bool=true) -> void:
	modo=clampi(indice,0,MODOS.size()-1)
	if detalhes!=null:detalhes.qualidade(modo)
	_viewport.scaling_3d_mode=Viewport.SCALING_3D_MODE_BILINEAR
	_atualizar_resolucao()
	_viewport.mesh_lod_threshold=[8.0,64.0,2.0][modo]
	var mundo: Node=get_parent().get_node_or_null("CenarioEstatico")
	if mundo!=null and mundo.has_method("configurar_qualidade"):mundo.configurar_qualidade(modo)
	if avisar:
		_mostrar_aviso("Detalhes: "+MODOS[modo]+" — F3 para trocar; imagem: "+_nome_resolucao())
func _nome_resolucao() -> String:
	return "nativa" if RESOLUCOES[nitidez]==0 else str(int(RESOLUCOES[nitidez]))+"p"
func _atualizar_resolucao() -> void:
	var altura: float=RESOLUCOES[nitidez]
	_viewport.scaling_3d_scale=clampf(altura/maxf(1.0,_viewport.get_texture().get_height()),0.1,1.0) if altura>0 else 1.0
func ajustar_nitidez(indice: int,salvar: bool=true) -> void:
	nitidez=clampi(indice,0,RESOLUCOES.size()-1)
	_atualizar_resolucao()
	if salvar:
		var config:=ConfigFile.new();config.set_value("imagem","resolucao",nitidez);config.save(CONFIG_IMAGEM)
	_mostrar_aviso("Imagem: "+_nome_resolucao()+" — F7 troca resolução; F3 detalhes")
func _mostrar_aviso(texto: String) -> void:
	_aviso.text=texto;_restante=5;_aviso.visible=true
func _process(dt: float) -> void:
	if _fps.visible:_fps.text="FPS: %d — %s — %s — %s" % [Engine.get_frames_per_second(),MODOS[modo],_nome_resolucao(),RenderingServer.get_video_adapter_name()]
	if _restante<=0:return
	_restante=maxf(0,_restante-dt);_aviso.visible=_restante>0
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F7 or event.keycode==KEY_F7):
		ajustar_nitidez((nitidez+1)%RESOLUCOES.size());get_viewport().set_input_as_handled()
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F4 or event.keycode==KEY_F4):
		_fps.visible=not _fps.visible;get_viewport().set_input_as_handled()
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F3 or event.keycode==KEY_F3):
		aplicar((modo+1)%MODOS.size());get_viewport().set_input_as_handled()
