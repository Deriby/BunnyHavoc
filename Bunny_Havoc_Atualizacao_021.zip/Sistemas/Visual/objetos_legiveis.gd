extends Node
## A simplificação da decoração não pode apagar perigos, plataformas ou itens.
var fase: Node3D
func configurar(raiz: Node3D) -> void:
	fase=raiz
	for n in fase.find_children("*","GeometryInstance3D",true,false):_proteger(n)
	get_tree().node_added.connect(_novo)
func _novo(n: Node) -> void:
	if n is GeometryInstance3D:_proteger.call_deferred(n)
func _proteger(n: Variant) -> void:
	if not is_instance_valid(n) or not fase.is_ancestor_of(n):return
	var pai: Node=n
	while pai!=fase:
		if pai.name in [&"CenarioEstatico",&"Bosque"]:return
		pai=pai.get_parent()
	if n is GeometryInstance3D:
		n.lod_bias=128.0
		n.visibility_range_begin=0.0;n.visibility_range_end=0.0
