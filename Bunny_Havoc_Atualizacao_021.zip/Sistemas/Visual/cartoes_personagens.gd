extends Node3D
## Mantém o controlador anterior, apresentando os atores como volumes 3D.
var grupos: Array=[]
var modo: int=0
func configurar(lista: Array) -> void:grupos=lista
func atualizar() -> void:
 for g in grupos:g.far.layers=1 if g.distante and g.ator.is_visible_in_tree() else 0
