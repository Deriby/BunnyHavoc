extends Node3D
## Sombras suaves em um lote, sem mapa de sombras ou textura adicional.
var fase: Node3D
var jogador: Node3D
var camera: Camera3D
var visual: MultiMeshInstance3D
var entradas: Array=[]
var _ids: Dictionary={}
var _tempo: float=0
var desenhadas: int=0
func configurar(raiz: Node3D) -> void:
	fase=raiz;jogador=fase.get_node("Jogador");camera=fase.get_node("Camera3D")
	process_physics_priority=28
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in 16:
		var a: float=i*TAU/16;var b: float=(i+1)*TAU/16
		for p in [Vector3.ZERO,Vector3(cos(b),0,sin(b)),Vector3(cos(a),0,sin(a))]:
			st.set_normal(Vector3.UP);st.set_color(Color(.06,.09,.04,.28) if p==Vector3.ZERO else Color(.06,.09,.04,0));st.add_vertex(p)
	var mat:=StandardMaterial3D.new();mat.vertex_color_use_as_albedo=true;mat.vertex_color_is_srgb=false
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.depth_draw_mode=BaseMaterial3D.DEPTH_DRAW_DISABLED;mat.cull_mode=BaseMaterial3D.CULL_DISABLED
	st.set_material(mat)
	visual=MultiMeshInstance3D.new();visual.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;visual.lod_bias=128
	var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_colors=true;mm.mesh=st.commit();mm.instance_count=96;mm.visible_instance_count=0
	mm.custom_aabb=AABB(Vector3(-150,-25,-450),Vector3(300,100,520));visual.multimesh=mm;add_child(visual)
	_registrar(jogador);_recolher()
func _registrar(n: Node3D) -> void:
	if _ids.has(n.get_instance_id()) or not fase.is_ancestor_of(n):return
	_ids[n.get_instance_id()]=true
	entradas.append({"node":n,"last":Vector3.INF,"chao":0.0,"valido":false,"idade":99.0,"raio":.8 if n.is_in_group("bh_caixas") else (.95 if n==fase.combate.urso else .65)})
func _recolher() -> void:
	for n in get_tree().get_nodes_in_group("bh_cidadaos")+get_tree().get_nodes_in_group("bunny_havoc_inimigos")+get_tree().get_nodes_in_group("bh_caixas"):_registrar(n)
func _physics_process(dt: float) -> void:
	if fase==null:return
	_tempo+=dt
	if _tempo>.5:_tempo=0;_recolher()
	var filme: Node=fase.get("final")
	visual.visible=filme==null or not filme.ativo
	if not visual.visible:return
	var count: int=0
	for item in entradas:
		if not is_instance_valid(item.node):continue
		var n: Node3D=item.node
		if not n.is_visible_in_tree() or n.global_position.distance_squared_to(jogador.global_position)>1600 or camera.is_position_behind(n.global_position):continue
		var screen: Vector2=camera.unproject_position(n.global_position)
		var size: Vector2=get_viewport().get_visible_rect().size
		if screen.x< -40 or screen.x>size.x+40 or screen.y< -40 or screen.y>size.y+40:continue
		item.idade+=dt
		var p: Vector3=n.global_position
		if item.idade>.2 or Vector2(p.x-item.last.x,p.z-item.last.z).length_squared()>.12:
			var query:=PhysicsRayQueryParameters3D.create(p+Vector3.UP*.7,p-Vector3.UP*5,1)
			var hit: Dictionary=get_world_3d().direct_space_state.intersect_ray(query)
			item.valido=not hit.is_empty();item.idade=0;item.last=p
			if item.valido:item.chao=hit.position.y+.05
		if not item.valido:continue
		var h: float=maxf(0,p.y-item.chao)
		var radius: float=item.raio*(1+h*.03)
		visual.multimesh.set_instance_transform(count,Transform3D(Basis.IDENTITY.scaled(Vector3(radius,1,radius*.62)),Vector3(p.x,item.chao,p.z)))
		visual.multimesh.set_instance_color(count,Color(1,1,1,clampf(1-h*.12,.25,1)))
		count+=1
		if count>=96:break
	visual.multimesh.visible_instance_count=count;desenhadas=count
