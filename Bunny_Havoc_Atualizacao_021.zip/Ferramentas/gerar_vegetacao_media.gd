extends SceneTree
## Malhas 3D intermediárias dos modelos aprovados; evita trocar volume por cartões.
const Malhas=preload("res://Sistemas/Visual/malhas_compartilhadas.gd")
const DESTINO: String="res://Recursos/VegetacaoMedia"
var texturas: Dictionary={}
func material_fixo(original: Material) -> Material:
	if not original is BaseMaterial3D or original.albedo_texture==null:return original
	var novo: BaseMaterial3D=original.duplicate()
	var img: Image=original.albedo_texture.get_image()
	var chave: String=img.get_data().hex_encode().sha256_text()
	if not texturas.has(chave):
		var path: String=DESTINO+"/textura_"+chave+".res"
		assert(ResourceSaver.save(ImageTexture.create_from_image(img),path,ResourceSaver.FLAG_COMPRESS)==OK)
		texturas[chave]=load(path)
	novo.albedo_texture=texturas[chave]
	return novo
func _initialize() -> void:gerar.call_deferred()
func localizar(dir: String,nome: String) -> String:
	if FileAccess.file_exists(dir+"/"+nome+".tscn"):return dir+"/"+nome+".tscn"
	for child in DirAccess.get_directories_at(dir):
		var path: String=localizar(dir+"/"+child,nome)
		if not path.is_empty():return path
	return ""
func gerar() -> void:
	DirAccess.make_dir_recursive_absolute(DESTINO)
	var referencia: Node3D=load("res://Fase1/Estatico/NaturezaInstanciada.tscn").instantiate()
	var nomes: Array=referencia.get_meta("species")
	var modelos: Array=[]
	for tipo in nomes.size():
		var caminho: String=localizar("res://Cenas/Natureza",str(nomes[tipo]))
		if caminho.is_empty():push_error("Modelo não encontrado: "+str(nomes[tipo]));quit(1);return
		var planta: Node3D=load(caminho).instantiate();root.add_child(planta)
		var pecas: Array[MeshInstance3D]=[]
		for n: MeshInstance3D in planta.find_children("*","MeshInstance3D",true,false):
			if n.mesh!=null and n.is_visible_in_tree():
				# Mesma correção de importação usada em Fase1/cores_vertices.gd.
				for s in n.mesh.get_surface_count():
					if n.mesh.surface_get_format(s)&Mesh.ARRAY_FORMAT_COLOR:
						var original: Material=n.get_active_material(s)
						if original is BaseMaterial3D and not original.vertex_color_use_as_albedo:
							var material: BaseMaterial3D=original.duplicate();material.vertex_color_use_as_albedo=true;n.set_surface_override_material(s,material)
				pecas.append(n)
		var original: ArrayMesh=Malhas.planta(planta,pecas)
		var importer: Resource=ClassDB.instantiate("ImporterMesh")
		for s in original.get_surface_count():importer.add_surface(Mesh.PRIMITIVE_TRIANGLES,original.surface_get_arrays(s),[],{},original.surface_get_material(s))
		importer.generate_lods(25.0,60.0,[])
		var leve:=ArrayMesh.new();var antes: int=0;var depois: int=0
		for s in original.get_surface_count():
			var a: Array=original.surface_get_arrays(s)
			var indices: PackedInt32Array=a[Mesh.ARRAY_INDEX];antes+=indices.size()/3
			for i in importer.get_surface_lod_count(s):
				var proposta: PackedInt32Array=importer.get_surface_lod_indices(s,i)
				if importer.get_surface_lod_size(s,i)<=.015*maxf(1,original.get_aabb().size.length()) and proposta.size()<indices.size():indices=proposta
			a[Mesh.ARRAY_INDEX]=indices;depois+=indices.size()/3
			leve.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,a);leve.surface_set_material(s,material_fixo(original.surface_get_material(s)))
		leve.set_meta("modelo_original",planta.scene_file_path)
		assert(ResourceSaver.save(leve,DESTINO+"/tipo_%d.res"%tipo,ResourceSaver.FLAG_COMPRESS)==OK)
		modelos.append({"name":nomes[tipo],"originalTriangles":antes,"mediumTriangles":depois})
		planta.free()
	FileAccess.open(DESTINO+"/modelos.json",FileAccess.WRITE).store_string(JSON.stringify(modelos,"\t"))
	print(JSON.stringify(modelos));referencia.free();quit()
