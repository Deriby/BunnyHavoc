extends RefCounted
## Nova morte: voo legível, queda de costas, impacto, acomodação e poeira curta.

var duracao_voo: float = 0.62
var duracao_total: float = 1.82
var impacto: bool = false
var menor_y: float = 0.0
var _animacao: RefCounted
var _inimigo: CharacterBody3D
var _meshes: Array[Node] = []
var _poeira: Node3D
var _puffs: Array[MeshInstance3D] = []
var _material: StandardMaterial3D

func configurar(inimigo: CharacterBody3D, visual: Node3D, animacao: RefCounted) -> void:
	_inimigo = inimigo
	_animacao = animacao
	_meshes = visual.find_children("UrsoPeca_*", "MeshInstance3D", true, false)
	_poeira = Node3D.new()
	_poeira.name = "PoeiraImpacto"
	_poeira.top_level = true
	inimigo.add_child(_poeira)
	var gradient := Gradient.new()
	gradient.set_color(0, Color(0.8, 0.71, 0.53, 0.55))
	gradient.set_color(1, Color(0.8, 0.71, 0.53, 0.0))
	var texture := GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill = GradientTexture2D.FILL_RADIAL
	texture.fill_from = Vector2(0.5, 0.5)
	texture.fill_to = Vector2(1.0, 0.5)
	_material = StandardMaterial3D.new()
	_material.albedo_texture = texture
	_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_material.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	_material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	var quad := QuadMesh.new()
	quad.size = Vector2.ONE
	for i in 6:
		var puff := MeshInstance3D.new()
		puff.mesh = quad
		puff.material_override = _material
		_poeira.add_child(puff)
		_puffs.append(puff)
	_poeira.visible = false

func iniciar(finalizador: bool) -> void:
	duracao_voo = 0.62 if finalizador else 0.30
	duracao_total = duracao_voo + 1.20
	impacto = false
	_poeira.visible = false
	_animacao.reiniciar()
	_assentar(0.0)

func _assentar(peso: float) -> void:
	menor_y = INF
	for node: MeshInstance3D in _meshes:
		var aabb: AABB = node.get_aabb()
		for i in 8:
			menor_y = minf(menor_y, (node.global_transform * aabb.get_endpoint(i)).y)
	var piso: float = _inimigo.chao_y + 0.025
	var ajuste: float = piso - menor_y
	if ajuste > 0.0 or peso > 0.0:
		_animacao.corpo.position.y += ajuste * (1.0 if ajuste > 0.0 else peso) / 1.15
		menor_y += ajuste * (1.0 if ajuste > 0.0 else peso)

func atualizar(idade: float) -> bool:
	var voo: float = clampf(idade / duracao_voo, 0.0, 1.0)
	var depois: float = maxf(0.0, idade - duracao_voo)
	var queda: float = clampf(depois / 0.18, 0.0, 1.0)
	var corpo: Node3D = _animacao.corpo
	_animacao.reiniciar()
	# A rotação vem do eixo de costas do modelo; nunca acumula voltas.
	var angulo: float = -0.12 - 0.58 * smoothstep(0.0, 1.0, voo) - 0.87 * queda * queda
	var acomoda: float = maxf(0.0, depois - 0.18)
	if acomoda > 0.0:
		angulo += sin(acomoda * 19.0) * 0.075 * exp(-acomoda * 9.0)
	corpo.rotation = Vector3(angulo, 0, sin(voo * PI) * 0.08)
	var squash: float = 0.0
	if acomoda > 0.0:
		squash = sin(minf(1.0, acomoda / 0.14) * PI) * 0.10
	corpo.scale = Vector3(1.0 + squash * 0.4, 1.0 - squash, 1.0 + squash * 0.25)
	var pivo := Vector3(0, 1.15, 0)
	corpo.position = pivo - corpo.basis * pivo
	for i in 2:
		_animacao.bracos[i].rotation = Vector3(-1.25 + queda * 0.35, 0, (-0.45 if i == 0 else 0.45) * (1.0 - 0.3 * queda))
		_animacao.antebracos[i].rotation.x = -0.4 - 0.25 * voo
		_animacao.pernas[i].rotation.x = -0.5 + queda * 0.7 + (0.18 if i else -0.12) * sin(voo * PI)
	_animacao.cabeca.rotation.x = -0.18 * (1.0 - queda)
	_animacao.mandibula.rotation.x = 0.26 * (1.0 - queda * 0.5)
	_assentar(smoothstep(0.0, 0.18, depois))
	if depois >= 0.18:
		impacto = true
		var poeira_t: float = clampf((depois - 0.18) / 0.48, 0.0, 1.0)
		_poeira.visible = poeira_t < 1.0
		_poeira.global_position = Vector3(_inimigo.global_position.x, _inimigo.chao_y + 0.09, _inimigo.global_position.z)
		_material.albedo_color.a = 1.0 - poeira_t
		for i in 6:
			var a: float = i * TAU / 6.0
			var largura: float = 0.45 + poeira_t * 0.9
			_puffs[i].position = Vector3(sin(a) * largura, 0.12 + sin(poeira_t * PI) * 0.25, cos(a) * largura)
			_puffs[i].scale = Vector3.ONE * (0.45 + poeira_t * 0.40)
	var sumindo: float = clampf((depois - 0.98) / 0.22, 0.0, 1.0)
	corpo.visible = sumindo < 1.0
	# Mantém a silhueta deitada por quase um segundo antes de recolher.
	if sumindo > 0.0:
		corpo.scale *= 1.0 - 0.30 * sumindo
		_assentar(1.0)
	return idade >= duracao_total

func reiniciar() -> void:
	impacto = false
	_poeira.visible = false
	_animacao.reiniciar()
