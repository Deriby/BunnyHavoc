extends RefCounted
## Poses de perseguição, preparação e garra adaptadas da Fase 2 original.

var corpo: Node3D
var torso: Node3D
var cabeca: Node3D
var mandibula: Node3D
var pernas: Array[Node3D] = []
var bracos: Array[Node3D] = []
var antebracos: Array[Node3D] = []
var ombros: Array[Node3D] = []
var _origens: Dictionary = {}
var _tempo: float = 0.0

func configurar(visual: Node3D) -> void:
	corpo = visual.find_child("CorpoUrso", true, false) as Node3D
	torso = visual.find_child("Torso", true, false) as Node3D
	cabeca = visual.find_child("Cabeca", true, false) as Node3D
	mandibula = visual.find_child("Mandibula", true, false) as Node3D
	for lado in ["E", "D"]:
		pernas.append(visual.find_child("Perna_" + lado, true, false) as Node3D)
		bracos.append(visual.find_child("Braco_" + lado, true, false) as Node3D)
		antebracos.append(visual.find_child("Antebraco_" + lado, true, false) as Node3D)
		ombros.append(visual.find_child("Ombro_" + lado, true, false) as Node3D)
	for node in [corpo, torso, cabeca, mandibula] + pernas + bracos + antebracos + ombros:
		node.rotation_order = EULER_ORDER_XYZ
		_origens[node] = node.transform

func reiniciar() -> void:
	for node: Node3D in _origens:
		node.transform = _origens[node]
	corpo.visible = true

func suavizar(node: Node3D, eixo: int, alvo: float, taxa: float, dt: float) -> void:
	var rot: Vector3 = node.rotation
	rot[eixo] = lerpf(rot[eixo], alvo, minf(1.0, taxa * dt))
	node.rotation = rot

func atualizar(dt: float, estado: String, idade: float, perseguindo: bool, movendo: bool) -> void:
	_tempo += dt
	var fase: float = _tempo * (9.0 if perseguindo else 5.0) + 4.0
	var taxa: float = 30.0 if estado == "swipe" else 14.0
	var tronco: float = 0.12 if perseguindo else 0.0
	var braco: float = 0.0
	var abertura: float = 0.0
	var antebraco: float = 0.0
	var head: float = 0.0
	var boca: float = 0.12 + sin(_tempo * 14.0) * 0.08 if perseguindo else 0.0
	if estado == "wind":
		var u: float = smoothstep(0.0, 0.5, idade)
		tronco = -0.55 * u
		braco = -2.7 * u
		abertura = 0.5 * u
		antebraco = -0.9 * u
		head = -0.4 * u
		boca = 0.7 * u
	elif estado == "swipe":
		var u: float = smoothstep(0.0, 0.22, idade)
		tronco = -0.55 + 0.9 * u
		braco = -2.7 + 3.2 * u
		abertura = 0.5 - 0.3 * u
		antebraco = -0.9 * (1.0 - u)
		head = -0.4 + 0.7 * u
		boca = 0.5
	elif estado == "recover":
		var u: float = smoothstep(0.0, 0.6, idade)
		tronco = 0.35 * (1.0 - u)
		braco = 0.5 * (1.0 - u)
		abertura = 0.2 * (1.0 - u)
		head = 0.3 * (1.0 - u)
		boca = 0.3 * (1.0 - u)
	else:
		braco = sin(fase + PI) * 0.35
		antebraco = -0.25 - sin(fase) * 0.2
		abertura = 0.08
	suavizar(torso, 0, tronco + sin(_tempo * 1.8 + 4.0) * 0.015, taxa, dt)
	suavizar(torso, 2, sin(fase) * 0.07 if estado == "walk" and movendo else 0.0, taxa, dt)
	for i in 2:
		suavizar(bracos[i], 0, braco * (1.0 if i else -1.0) if estado == "walk" else braco, taxa, dt)
		suavizar(bracos[i], 2, (1.0 if i else -1.0) * abertura, taxa, dt)
		suavizar(antebracos[i], 0, antebraco, taxa, dt)
		suavizar(pernas[i], 0, sin(fase + i * PI) * (0.65 if perseguindo else 0.4) if estado == "walk" and movendo else -0.15 if estado == "wind" else 0.0, taxa, dt)
	suavizar(cabeca, 0, head, taxa, dt)
	suavizar(mandibula, 0, boca, taxa, dt)
	corpo.position.y = (absf(sin(fase)) * 0.07 if estado == "walk" and movendo else 0.0) - (smoothstep(0.0, 0.5, idade) * 0.12 if estado == "wind" else 0.0)

func dano(idade: float, duracao: float, finalizador: bool) -> void:
	var u: float = clampf(idade / duracao, 0.0, 1.0)
	corpo.rotation.x = -0.12 * sin(u * PI)
	corpo.rotation.z = 0.12 * sin(u * PI)
	cabeca.rotation.x = -0.12 * sin(u * PI)
	for i in 2:
		bracos[i].rotation.x = -0.8 * sin(u * PI)
		bracos[i].rotation.z = (-1.0 if i == 0 else 1.0) * 0.25 * sin(u * PI)
		pernas[i].rotation.x = (-0.35 if i == 0 else 0.4) * sin(u * PI)
