# Migração gradual para Godot: projeto completo da etapa de combate

Estado atual: [project.godot](project.godot) abre a arena pronta com todos os
componentes já migrados. Instruções para importar e jogar: [LEIA-ME.txt](LEIA-ME.txt).
O histórico abaixo registra entregas menores; não é necessário montá-las
manualmente ao usar o pacote completo atual. As fases e a vila ainda estão
no projeto web preservado, fora desta arena de teste.

O usuário criou um projeto no Godot 4.7.2 no Windows e quer manter Windows e Web
como destinos. Já montou manualmente a cena `TesteFase1`, com chão CSG de
20 × 1 × 20 em Y=-0,5 e colisão, luz direcional e câmera em (0,7,10), rotação
(-30,0,0). A captura do usuário confirma o piso visível ao executar.

O primeiro pacote exportou **somente o modelo visual parado**, em
[Bunnyck/bunnyck.glb](Bunnyck/bunnyck.glb). As instruções para copiar e instanciar
no projeto estão em [LEIA-ME.txt](Bunnyck/LEIA-ME.txt). O usuário confirmou a
importação e montou Jogador com Visual e cápsula. Naquela etapa o projeto
existia somente no computador dele; agora a cena completa é distribuída aqui.

## Origem e reprodução

```sh
node tools/export_bunnyck_glb.cjs
```

O exportador executa o trecho literal de construção do Bunnyck de
`src/fase_1_logica_3d.js` em um contexto isolado. Não executa nem modifica fases,
controles ou demais sistemas. Usa Three.js r128 e seu GLTFExporter oficial,
com as dependências já existentes. O formato é glTF 2.0 binário, autocontido.

A escala local original 0,8, as 28 malhas e os pivôs de pernas/braços/orelhas/
cauda são preservados e recebem nomes para edição posterior. A rotação de
orientação do personagem durante o jogo não faz parte do modelo: na pose
neutra exportada ele olha para +Z, na direção da câmera do teste do usuário.
Os cinco tons sRGB originais são convertidos para fatores lineares do glTF;
os materiais PBR têm metalness=0 e roughness=1.

## Conferência

O GLB foi reaberto com GLTFLoader. Vértices em espaço global, pivôs, cores,
quantidade de malhas e apoio das solas em zero foram comparados. Cabeçalho,
versão, tamanho e ausência de recursos externos também foram verificados.
Relatório: [export-results.json](../validation/godot-bunnyck/export-results.json).

A prévia `validation/godot-bunnyck/preview-threejs.png` foi renderizada em
Three.js para inspeção da exportação, não no Godot. Posteriormente, o GLB
também foi importado no Godot 4.6.3 headless e conferido com 28 malhas.
As capturas do usuário no 4.7.2 confirmam o modelo visível no piso de teste.

## Movimento inicial — segundo pacote

[ControleInicial/jogador.gd](ControleInicial/jogador.gd) deve ser anexado ao
CharacterBody3D Jogador, sem substituir a cena. [Instruções](ControleInicial/LEIA-ME.txt).
WASD/setas movem, K/Ctrl corre e Espaço pula. Preserva os parâmetros da Fase 1:
6,4/10,3, gravidade 24, impulsos 10,1/12,8, aceleração, normalização diagonal e
tolerância de borda. Usa cápsula nativa e `move_and_slide`; o visual gira e a
câmera acompanha X/Z preservando altura/rotação configuradas. Queda abaixo de
12 unidades retorna ao início apenas nesta plataforma de teste.

```sh
python3 tools/test_godot_movement.py
```

O teste cria projeto temporário, importa o GLB e usa piso CSG/cápsula/câmera
equivalentes aos do usuário. Verifica 22 comportamentos no motor real, incluindo
teclas físicas, colisão com parede, saltos, aterrissagem, câmera e integração
com as animações. Evidências:
[results.json](../validation/godot-movement/results.json). Testado em 4.6.3
headless; ainda requer conferência pelo usuário no 4.7.2, Windows.

O usuário confirmou movimento no 4.7.2, após remover o script anexado por engano
ao Node3D TesteFase1. O script deve ficar somente em Jogador (CharacterBody3D).

## Animações de locomoção — terceiro pacote

[bunnyck_animacao.gd](ControleInicial/bunnyck_animacao.gd) adapta o animator da
Fase 1 como módulo visual separado. O controle o carrega por caminho relativo;
os dois `.gd` devem ficar juntos. Não exige AnimationPlayer, edição do GLB ou
recriação da cena. Atualização: substituir os dois scripts na pasta do controle
que o usuário já usa. Instruções completas em [LEIA-ME.txt](ControleInicial/LEIA-ME.txt).

Adapta passadas, sprint, frenagem, giro de orientação, subida/queda, aterrissagem,
respiração, orelhas, cauda e piscadas. Usa os mesmos pivôs, amplitudes, ritmos e
suavização. Mantém Euler XYZ do Three.js e escala importada. As duas pálpebras
são criadas uma vez, nas mesmas medidas/posições do animator original, com o
material roxo do GLB. Animação altera apenas Visual e seus descendentes; corpo
físico, cápsula e câmera continuam separados. Queda do piso reinicia a pose.

```sh
python3 tools/test_godot_animation.py
```

O oráculo executa o trecho literal original em Three.js (sem renderização),
ajustando apenas a direção inicial de PI para zero, pois o GLB exportado olha +Z.
Compara 980 quadros, sete estados, piscadas, transforms de pivôs e matrizes
globais das 28 peças com o porte rodando no Godot 4.6.3 headless. Maior erro
menor que 0,000001. Confere restauração de pose/escala e contagem estável de nós.
Evidências: [results.json](../validation/godot-animation/results.json).
Os 22 testes nativos também conferem animação acionada por teclado/física,
poses aéreas, retorno ao idle e cápsula intacta. Ainda requer teste visual
deste pacote no 4.7.2 do usuário; não houve validação de exportações Windows/Web.

O usuário confirmou que as animações funcionaram no 4.7.2. Pacotes anteriores
preservados nas branches `entrega-godot-controle-inicial` e `entrega-godot-animacoes`.

## Combo inicial — quarto pacote

[bunnyck_combo.gd](ControleInicial/bunnyck_combo.gd) adapta o estado do combo,
buffer de apertos, tolerância para encadear, direção, passos, alcance e poses
da fonte compartilhada `src/player_combat.js`. J/Shift inicia e apertos novos
encadeiam; eventos de repetição do sistema operacional são ignorados. Tempos
0,30/0,26/0,32 e passos 0,22/0,28 preservados. Locomoção durante ataque fica
limitada a 7, como na Fase 1. O salto e a cápsula continuam independentes.

Consultas físicas nativas substituem as listas de paredes e o campo de altura
do Three.js: passos são subdivididos, conferem piso contínuo em até 0,18 e
usam `test_move`; alcance usa uma caixa horizontal com margem de 0,58 para
respeitar obstáculos. No ar, o combo não acrescenta deslocamento horizontal.

[bunnyck_efeitos_combo.gd](ControleInicial/bunnyck_efeitos_combo.gd) cria as
mesmas 31 malhas fixas de punho curto, mangas, fitas, halo, riscos e impacto.
Compartilha as cores do GLB e usa Euler XYZ. Não altera o modelo importado.
O animator de locomoção agora também trata giro/cauda/piscadas, e o combo
aplica as poses finais após a locomoção, como na ordem do jogo original.

Cinco WAVs externos em `ControleInicial/audio/` renderizam os parâmetros dos
osciladores de `snd()` (ganho, frequências e duração), com harmônicos limitados.
Reprodução nativa por dois AudioStreamPlayer; a timbragem pode diferir um pouco
do oscilador WebAudio. Para regenerar: `python3 tools/build_godot_combo_audio.py`.

```sh
python3 tools/test_godot_combo.py
python3 tools/test_godot_movement.py
python3 tools/test_godot_animation.py
```

25 verificações de combo no motor real cobrem teclas/hold/repetição, direção,
buffer/tolerância, restauração, piso/borda/parede, alcance moderado e acerto.
O oráculo executa combate e animator literais do Three.js, comparando 390
quadros de estado/poses/visibilidade/matrizes das malhas visíveis. O passo do
oráculo é 1/64 exato para evitar arredondamento de JSON na fronteira dos golpes;
os testes nativos de teclado/física continuam em 60 Hz. Erros abaixo de 0,000001.
Evidências: [results.json](../validation/godot-combo/results.json). Regressão:
22 verificações de locomoção e 980 poses também passaram em Godot 4.6.3 headless.

A interface `pode_atingir`/`registrar_acerto`/`golpe_para` preserva um acerto por
golpe, dano 1/1/2, pausas de impacto e indicação de abertura/finalizador. O teste
usa Node3D sintético; não há inimigos, dano aplicado, arremesso, caixas ou HUD
de corações nesta cena ainda. A integração com inimigos é a próxima etapa.
Não houve conferência visual/auditiva deste pacote no 4.7.2 nem exportações.

Atualização do usuário: copiar todo o conteúdo de `ControleInicial`, incluindo
os quatro `.gd` e `audio/`, na pasta onde está o jogador.gd já anexado ao Jogador.
Não requer recriar a cena. Saúde, fases, cutscenes, saves e exportações seguem
pendentes. Fontes do jogo web, backups e GLB permanecem preservados.

## Passinhos — componente opcional

O usuário informou que nenhuma tecla respondia após o combo. O mesmo pacote
passou novamente nos testes; depois o usuário confirmou que havia ativado 3D
na janela incorporada, em vez de Entrada. O movimento voltou a funcionar;
não foi necessário alterar os controles.

O novo pedido usa o arquivo `Passinhos.wav` enviado pelo usuário. Original de
4 s, estéreo, 48 kHz/PCM16 preservado em `RecursosOriginais/Passinhos.wav`.
`tools/extract_godot_footsteps.py` recorta quatro batidas inteiras, mantendo
os bytes PCM, ganho, canais e frequência. Relatório e cortes em
[audio-extraction.json](../validation/godot-footsteps/audio-extraction.json).

[PassosBunnyck/Passos.tscn](PassosBunnyck/Passos.tscn) é um AudioStreamPlayer
com script e quatro WAVs externos. O usuário copia a pasta PassosBunnyck para
o projeto e arrasta essa cena sobre Jogador. Não substitui scripts do controle,
animação ou combo. Volume dB fica no Inspetor do próprio nó (inicial -6 dB).

O componente lê a fase das pernas do animator existente, somente para
reproduzir som nos contatos de caminhada/corrida. Confere movimento real,
chão e estado; não toca parado, no ar, em ataque ou empurrando parede. Atualiza
a fase observada mesmo quando silencioso, evitando passos acumulados. Alterna
as quatro amostras, sem loop, autoplay ou alteração de pitch.

```sh
python3 tools/extract_godot_footsteps.py
python3 tools/test_godot_footsteps.py
```

11 verificações passaram em Godot 4.6.3 headless com o componente instanciado
como filho do CharacterBody3D real: importação, movimento por teclado, cadência,
parada, corrida, salto, combo, parede e cápsula intacta. A reprodução foi
verificada por eventos no driver Dummy; conferência auditiva/visual no 4.7.2
do usuário ainda pendente. Evidências em
[results.json](../validation/godot-footsteps/results.json). Fontes do controle,
combo, animação, modelo e jogo web não foram alteradas nesta etapa.

O usuário confirmou os passos funcionando. Os problemas de instalação foram
um `passos.gd` anexado a CollisionShape3D, letras extras digitadas no editor e
a cena Passos instanciada dentro da colisão. Corrigir a primeira linha,
desanexar o script da colisão e mover Passos para filho direto de Jogador
resolveu. Amostras estavam preenchidas e a saída geral de áudio funcionava.

## Sons alternados de pulo

O usuário enviou Jump1.mp3, Jump2.mp3 e Jump3.mp3, três arquivos distintos
de aproximadamente 0,528 s. São copiados sem conversão nem edição para
`PulosBunnyck/audio/`. O original enviado é o próprio recurso distribuído.

[PulosBunnyck/Pulos.tscn](PulosBunnyck/Pulos.tscn) adiciona um AudioStreamPlayer
independente, com as três amostras já preenchidas e volume inicial -6 dB.
Instalar como filho direto de Jogador, ao lado de Passos e CollisionShape3D.
O script também aceita um ancestral CharacterBody3D intermediário e preenche
amostras vazias a partir dos três arquivos vizinhos, para tolerar erros simples
de montagem. Não precisa substituir scripts de controle ou dos passos.

Detecta a transição da velocidade vertical para subida fora do chão após a
atualização física do personagem. Alterna 1→2→3→1 em cada subida real, inclusive
salto correndo e dentro da tolerância de borda. Não reage à tecla sem salto,
a repetições no ar nem à queda de uma borda. A sequência continua após respawn.
O componente apenas reproduz som; não modifica velocidade, controles ou animação.

```sh
python3 tools/test_godot_jumps.py
```

14 verificações passaram em Godot 4.6.3 headless: importação, sequência de cinco
saltos, altura preservada, takeoff, tecla segurada, tentativa no ar, corrida,
queda de borda, tolerância de borda, combo, passos, montagem alternativa e cápsula.
Playback validado por eventos no driver Dummy; audição no 4.7.2 do usuário
permanece pendente. Evidências: [results.json](../validation/godot-jumps/results.json).

## Urso, corações e pasta completa — etapa atual

`ArenaCombate.tscn` conecta os componentes existentes sem editar o controlador,
combo, animações ou sons já entregues. `CombateBunnyck/combate.gd` resolve
contato, acertos, pisão, HUD, início do treino e reinício com R. A cena permanece
uma arena neutra: não substitui as fases aprovadas.

`tools/export_bear_glb.cjs` executa somente o construtor literal `spawnBear` da
Fase 2. Preserva 53 malhas, 636 triângulos, nove cores e escala 1,15; roundtrip
glTF confirma erro zero de vértices/cores. O GLB fica em `Urso/urso.glb` e uma
cópia idêntica junto da cena do inimigo. Os ombros ganham pivôs nomeados, sem
mudar a geometria. O deslocamento Visual Y=0,0805 apoia as solas no piso.

`urso.gd` mantém perseguição, preparo de 0,55 s, garra, alcance e recuperação
da fonte. O combo real aplica dano 1/1/2. Golpes iniciais recuam 0,26 e elevam
0,32; o finalizador desloca 2,15 e eleva 0,85. Enquanto reage, o urso não
avança causando dano. Subpassos, consultas ao piso e `test_move` impedem
arremessos através de paredes ou para fora do piso nesta arena.

`urso_morte.gd` é a alteração visual solicitada: voo curto, queda de costas,
impacto único, acomodação amortecida e seis manchas de poeira prealocadas.
Limites transformados das malhas garantem apoio acima do chão. O corpo fica
deitado antes de desaparecer; sem rotação acumulada ou flash como única reação.
A renderização real com Godot Compatibility/Mesa foi inspecionada em sequência
(`validation/godot-bear/contact-sheet.jpg` e `frame_*.png`).

`vida_bunnyck.gd` adiciona três corações, três vidas, imunidade de 1,25 s e
reação breve; reaparecimento restaura a arena. Buracos ignoram imunidade.
O player mantém sua reação original por contato/queda, e o HUD permite R no
fim de jogo. Não foram portadas as variantes de morte específicas de futuras
fases, campanha, recompensas ou persistência. Sete WAVs sintetizados externos
reproduzem os parâmetros originais, além de um impacto grave novo do urso.

```sh
node tools/export_bear_glb.cjs
python3 tools/build_godot_bear_audio.py
python3 tools/test_godot_bear.py
DISPLAY=:93 python3 tools/test_godot_bear.py --visual  # requer X11 disponível
python3 tools/package_godot.py
python3 tools/test_godot_bear.py --archive Bunny_Havoc_Godot_Combate.zip
```

25 verificações nativas cobrem combo real, recuo, voo, piso, colisão com parede,
borda, morte por golpe isolado, restauração, corações, imunidade, vidas, queda,
fim de jogo, R e estados da IA. A sequência gráfica cobre nove verificações
do mesmo combate. O teste do ZIP extrai para diretório novo, confere manifesto,
importa recursos, executa a cena principal configurada e repete os 25 casos.
Hashes protegem fontes web e recursos existentes. Engine usada: 4.6.3 Linux;
usuário ainda conferirá no 4.7.2 Windows. O driver de áudio Dummy permite
verificar reprodução, mas não substitui audição humana.

`tools/package_godot.py` inclui toda a pasta Godot e um manifesto SHA-256,
excluindo somente caches de importação/execução. O pacote abre diretamente
por `project.godot` com F5 e renderer Compatibility. As exportações Windows/Web
e o porte das fases completas/vila/cutscenes/saves continuam pendentes.
A versão web e suas entregas anteriores não foram alteradas.

## Refinamento do urso: quatro patas e impacto mais forte

Pedido seguinte do usuário: manter o modelo, andar sobre as quatro patas,
levantar somente para atacar e reforçar o impacto da morte. As 53 malhas,
a paleta, a escala e os dois GLBs permanecem byte a byte iguais à entrega
anterior. A alteração é de pose/animação, não uma remodelagem do personagem.

`urso_animacao.gd` inclina o torso, compensa a cabeça e os braços para manter
o olhar para a frente e apoia as quatro patas. A passada usa pares diagonais,
elevação na fase aérea e correção de contato pelo limite real da malha da pata.
Respiração e balanço são discretos; animação é suavizada ao iniciar/parar.
Preparo e garra mantêm seus tempos/IA e recebem transição até a pose ereta;
a recuperação abaixa o urso novamente. Reação a dano permanece quadrúpede
e não reaproveita a elevação do ataque por engano.

A morte captura a pose atual e mistura para a queda lateral, inclusive quando
o urso é atingido preparando a garra. Mantém o arremesso físico e o apoio
calculado das malhas. O impacto acontece após 0,12 s de queda final, com pausa
de pose de 0,065 s, compressão, ressalto de até 0,12, acomodação amortecida,
seis nuvens baixas e uma onda curta no chão. Tudo é prealocado. A câmera treme
brevemente com mais força só na pancada final. O WAV dessa pancada ganhou
transiente e grave; os demais áudios não mudaram.

32 verificações nativas incluem postura parada, perseguição real, passada
diagonal, elevação/apoio das patas, ataque ereto, retorno ao chão, reação a dano
sem levantar, pausa e ressalto no impacto, além dos 25 cenários anteriores.
Uma sequência renderizada no Godot real mostra caminhada/ataque/recuperação
e outra mostra combo/morte. Relatórios em `validation/godot-bear/`.
A repetição pelo ZIP inclui importação, boot da cena principal e os mesmos
32 casos; sem alteração do Bunnyck, controles, dano, corações ou arremesso.

A pasta completa atualizada continua gerada por `python3 tools/package_godot.py`.
Entrega: https://github.com/Deriby/BunnyHavoc/raw/refs/heads/entrega-godot-urso-quadrupede/Bunny_Havoc_Godot_Combate.zip
A entrega anterior continua na branch `entrega-godot-combate`.
