# Migração gradual para Godot: projeto completo da etapa de combate

**Etapa atual:** o bosque segue até Z −110, com o lagarto original em −103
e caixa normal em −109. O cenário já cobria esse intervalo; acrescentou-se
a colisão e as instâncias em `Fase1/Trecho3/`, preservando as regiões anteriores.
`Lagarto.tscn` tem dois pontos de vida, patrulha, perseguição, aviso/bote,
recuo físico, pisão e arremesso; recompensa de seis cenouras. A coleta conecta
o inimigo e suas recompensas, e a fase fornece altura/reset. Sem essa ligação
de terreno, o prefab usa a altura onde foi colocado em uma base plana.
Céu nativo mantido com energia 1.5. Restante da fase/campanha ainda em migração.

**Céu confirmado pelo usuário no Godot 4.4.1:** a cena principal usa
`Sky → ProceduralSkyMaterial`, com `Background/Energy Multiplier = 1.5`.
O ajuste substitui o shader de gradiente no ambiente principal; seus arquivos
históricos permanecem preservados. Manter essa configuração nas próximas entregas.

**Estado atual — bosque até o segundo checkpoint:** `Fase1Trecho.tscn` reúne
o primeiro trecho preservado e a extensão em `Fase1/Trecho2/`. Há quatro caixas
(incluindo TNT), 16 cenouras soltas, duas plataformas e dois checkpoints.
O urso de teste permanece; o novo trecho inclui o besouro original e Rufus,
com rotina e conversa por Enter. As árvores refinadas continuam nas mesmas
cenas compartilhadas. O restante da campanha ainda é web, não está neste Godot.

**Estado mais recente — biblioteca de cenas:** `Cenas/` contém os objetos
reutilizáveis e seus comportamentos; `Biblioteca/Modelos/` contém os GLBs.
`Fase1/Objetos.tscn`, `Vegetacao.tscn` e `Cenario.tscn` compõem o mesmo recorte
original. `ExemploNovaFase.tscn` demonstra o uso sem depender do script da Fase 1.
Guia: [COMO_CRIAR_FASES.md](COMO_CRIAR_FASES.md). F5 continua abrindo o bosque.
Os tópicos seguintes registram as entregas anteriores; o estado atual está
detalhado na última seção, sobre a continuação do bosque.


**Estado atual:** `project.godot` abre `Fase1Trecho.tscn`, o início original do
Bosque Verde até a primeira estátua-checkpoint. `ArenaCombate.tscn` continua
disponível para F6. O ZIP inclui toda a pasta Godot com ambos os cenários.
Ver [LEIA-ME.txt](LEIA-ME.txt) para abrir e jogar, sem montar nós manualmente.


Histórico anterior: [project.godot](project.godot) abria a arena pronta com todos os
componentes já migrados. Instruções para importar e jogar: [LEIA-ME.txt](LEIA-ME.txt).
O histórico abaixo registra entregas menores; não é necessário montá-las
manualmente ao usar o pacote completo atual. As fases e a vila ainda estão
no projeto web preservado, fora desta arena de teste.

O usuário criou um projeto no Godot 4.7.2 no Windows e quer manter Windows e Web
como destinos. Já montou manualmente a cena `TesteFase1`, com chão CSG de
20 × 1 × 20 em Y=-0,5 e colisão, luz direcional e câmera em (0,7,10), rotação
(-30,0,0). A captura do usuário confirma o piso visível ao executar.

O primeiro pacote exportou **somente o modelo visual parado**, em
[Bunnyck/bunnyck.glb](Bunnyck/bunnyck.glb). As instruções para copiar e instanciar
no projeto estão em [LEIA-ME.txt](Bunnyck/LEIA-ME.txt). O usuário confirmou a
importação e montou Jogador com Visual e cápsula. Naquela etapa o projeto
existia somente no computador dele; agora a cena completa é distribuída aqui.

## Origem e reprodução

```sh
node tools/export_bunnyck_glb.cjs
```

O exportador executa o trecho literal de construção do Bunnyck de
`src/fase_1_logica_3d.js` em um contexto isolado. Não executa nem modifica fases,
controles ou demais sistemas. Usa Three.js r128 e seu GLTFExporter oficial,
com as dependências já existentes. O formato é glTF 2.0 binário, autocontido.

A escala local original 0,8, as 28 malhas e os pivôs de pernas/braços/orelhas/
cauda são preservados e recebem nomes para edição posterior. A rotação de
orientação do personagem durante o jogo não faz parte do modelo: na pose
neutra exportada ele olha para +Z, na direção da câmera do teste do usuário.
Os cinco tons sRGB originais são convertidos para fatores lineares do glTF;
os materiais PBR têm metalness=0 e roughness=1.

## Conferência

O GLB foi reaberto com GLTFLoader. Vértices em espaço global, pivôs, cores,
quantidade de malhas e apoio das solas em zero foram comparados. Cabeçalho,
versão, tamanho e ausência de recursos externos também foram verificados.
Relatório: [export-results.json](../validation/godot-bunnyck/export-results.json).

A prévia `validation/godot-bunnyck/preview-threejs.png` foi renderizada em
Three.js para inspeção da exportação, não no Godot. Posteriormente, o GLB
também foi importado no Godot 4.6.3 headless e conferido com 28 malhas.
As capturas do usuário no 4.7.2 confirmam o modelo visível no piso de teste.

## Movimento inicial — segundo pacote

[ControleInicial/jogador.gd](ControleInicial/jogador.gd) deve ser anexado ao
CharacterBody3D Jogador, sem substituir a cena. [Instruções](ControleInicial/LEIA-ME.txt).
WASD/setas movem, K/Ctrl corre e Espaço pula. Preserva os parâmetros da Fase 1:
6,4/10,3, gravidade 24, impulsos 10,1/12,8, aceleração, normalização diagonal e
tolerância de borda. Usa cápsula nativa e `move_and_slide`; o visual gira e a
câmera acompanha X/Z preservando altura/rotação configuradas. Queda abaixo de
12 unidades retorna ao início apenas nesta plataforma de teste.

```sh
python3 tools/test_godot_movement.py
```

O teste cria projeto temporário, importa o GLB e usa piso CSG/cápsula/câmera
equivalentes aos do usuário. Verifica 22 comportamentos no motor real, incluindo
teclas físicas, colisão com parede, saltos, aterrissagem, câmera e integração
com as animações. Evidências:
[results.json](../validation/godot-movement/results.json). Testado em 4.6.3
headless; ainda requer conferência pelo usuário no 4.7.2, Windows.

O usuário confirmou movimento no 4.7.2, após remover o script anexado por engano
ao Node3D TesteFase1. O script deve ficar somente em Jogador (CharacterBody3D).

## Animações de locomoção — terceiro pacote

[bunnyck_animacao.gd](ControleInicial/bunnyck_animacao.gd) adapta o animator da
Fase 1 como módulo visual separado. O controle o carrega por caminho relativo;
os dois `.gd` devem ficar juntos. Não exige AnimationPlayer, edição do GLB ou
recriação da cena. Atualização: substituir os dois scripts na pasta do controle
que o usuário já usa. Instruções completas em [LEIA-ME.txt](ControleInicial/LEIA-ME.txt).

Adapta passadas, sprint, frenagem, giro de orientação, subida/queda, aterrissagem,
respiração, orelhas, cauda e piscadas. Usa os mesmos pivôs, amplitudes, ritmos e
suavização. Mantém Euler XYZ do Three.js e escala importada. As duas pálpebras
são criadas uma vez, nas mesmas medidas/posições do animator original, com o
material roxo do GLB. Animação altera apenas Visual e seus descendentes; corpo
físico, cápsula e câmera continuam separados. Queda do piso reinicia a pose.

```sh
python3 tools/test_godot_animation.py
```

O oráculo executa o trecho literal original em Three.js (sem renderização),
ajustando apenas a direção inicial de PI para zero, pois o GLB exportado olha +Z.
Compara 980 quadros, sete estados, piscadas, transforms de pivôs e matrizes
globais das 28 peças com o porte rodando no Godot 4.6.3 headless. Maior erro
menor que 0,000001. Confere restauração de pose/escala e contagem estável de nós.
Evidências: [results.json](../validation/godot-animation/results.json).
Os 22 testes nativos também conferem animação acionada por teclado/física,
poses aéreas, retorno ao idle e cápsula intacta. Ainda requer teste visual
deste pacote no 4.7.2 do usuário; não houve validação de exportações Windows/Web.

O usuário confirmou que as animações funcionaram no 4.7.2. Pacotes anteriores
preservados nas branches `entrega-godot-controle-inicial` e `entrega-godot-animacoes`.

## Combo inicial — quarto pacote

[bunnyck_combo.gd](ControleInicial/bunnyck_combo.gd) adapta o estado do combo,
buffer de apertos, tolerância para encadear, direção, passos, alcance e poses
da fonte compartilhada `src/player_combat.js`. J/Shift inicia e apertos novos
encadeiam; eventos de repetição do sistema operacional são ignorados. Tempos
0,30/0,26/0,32 e passos 0,22/0,28 preservados. Locomoção durante ataque fica
limitada a 7, como na Fase 1. O salto e a cápsula continuam independentes.

Consultas físicas nativas substituem as listas de paredes e o campo de altura
do Three.js: passos são subdivididos, conferem piso contínuo em até 0,18 e
usam `test_move`; alcance usa uma caixa horizontal com margem de 0,58 para
respeitar obstáculos. No ar, o combo não acrescenta deslocamento horizontal.

[bunnyck_efeitos_combo.gd](ControleInicial/bunnyck_efeitos_combo.gd) cria as
mesmas 31 malhas fixas de punho curto, mangas, fitas, halo, riscos e impacto.
Compartilha as cores do GLB e usa Euler XYZ. Não altera o modelo importado.
O animator de locomoção agora também trata giro/cauda/piscadas, e o combo
aplica as poses finais após a locomoção, como na ordem do jogo original.

Cinco WAVs externos em `ControleInicial/audio/` renderizam os parâmetros dos
osciladores de `snd()` (ganho, frequências e duração), com harmônicos limitados.
Reprodução nativa por dois AudioStreamPlayer; a timbragem pode diferir um pouco
do oscilador WebAudio. Para regenerar: `python3 tools/build_godot_combo_audio.py`.

```sh
python3 tools/test_godot_combo.py
python3 tools/test_godot_movement.py
python3 tools/test_godot_animation.py
```

25 verificações de combo no motor real cobrem teclas/hold/repetição, direção,
buffer/tolerância, restauração, piso/borda/parede, alcance moderado e acerto.
O oráculo executa combate e animator literais do Three.js, comparando 390
quadros de estado/poses/visibilidade/matrizes das malhas visíveis. O passo do
oráculo é 1/64 exato para evitar arredondamento de JSON na fronteira dos golpes;
os testes nativos de teclado/física continuam em 60 Hz. Erros abaixo de 0,000001.
Evidências: [results.json](../validation/godot-combo/results.json). Regressão:
22 verificações de locomoção e 980 poses também passaram em Godot 4.6.3 headless.

A interface `pode_atingir`/`registrar_acerto`/`golpe_para` preserva um acerto por
golpe, dano 1/1/2, pausas de impacto e indicação de abertura/finalizador. O teste
usa Node3D sintético; não há inimigos, dano aplicado, arremesso, caixas ou HUD
de corações nesta cena ainda. A integração com inimigos é a próxima etapa.
Não houve conferência visual/auditiva deste pacote no 4.7.2 nem exportações.

Atualização do usuário: copiar todo o conteúdo de `ControleInicial`, incluindo
os quatro `.gd` e `audio/`, na pasta onde está o jogador.gd já anexado ao Jogador.
Não requer recriar a cena. Saúde, fases, cutscenes, saves e exportações seguem
pendentes. Fontes do jogo web, backups e GLB permanecem preservados.

## Passinhos — componente opcional

O usuário informou que nenhuma tecla respondia após o combo. O mesmo pacote
passou novamente nos testes; depois o usuário confirmou que havia ativado 3D
na janela incorporada, em vez de Entrada. O movimento voltou a funcionar;
não foi necessário alterar os controles.

O novo pedido usa o arquivo `Passinhos.wav` enviado pelo usuário. Original de
4 s, estéreo, 48 kHz/PCM16 preservado em `RecursosOriginais/Passinhos.wav`.
`tools/extract_godot_footsteps.py` recorta quatro batidas inteiras, mantendo
os bytes PCM, ganho, canais e frequência. Relatório e cortes em
[audio-extraction.json](../validation/godot-footsteps/audio-extraction.json).

[PassosBunnyck/Passos.tscn](PassosBunnyck/Passos.tscn) é um AudioStreamPlayer
com script e quatro WAVs externos. O usuário copia a pasta PassosBunnyck para
o projeto e arrasta essa cena sobre Jogador. Não substitui scripts do controle,
animação ou combo. Volume dB fica no Inspetor do próprio nó (inicial -6 dB).

O componente lê a fase das pernas do animator existente, somente para
reproduzir som nos contatos de caminhada/corrida. Confere movimento real,
chão e estado; não toca parado, no ar, em ataque ou empurrando parede. Atualiza
a fase observada mesmo quando silencioso, evitando passos acumulados. Alterna
as quatro amostras, sem loop, autoplay ou alteração de pitch.

```sh
python3 tools/extract_godot_footsteps.py
python3 tools/test_godot_footsteps.py
```

11 verificações passaram em Godot 4.6.3 headless com o componente instanciado
como filho do CharacterBody3D real: importação, movimento por teclado, cadência,
parada, corrida, salto, combo, parede e cápsula intacta. A reprodução foi
verificada por eventos no driver Dummy; conferência auditiva/visual no 4.7.2
do usuário ainda pendente. Evidências em
[results.json](../validation/godot-footsteps/results.json). Fontes do controle,
combo, animação, modelo e jogo web não foram alteradas nesta etapa.

O usuário confirmou os passos funcionando. Os problemas de instalação foram
um `passos.gd` anexado a CollisionShape3D, letras extras digitadas no editor e
a cena Passos instanciada dentro da colisão. Corrigir a primeira linha,
desanexar o script da colisão e mover Passos para filho direto de Jogador
resolveu. Amostras estavam preenchidas e a saída geral de áudio funcionava.

## Sons alternados de pulo

O usuário enviou Jump1.mp3, Jump2.mp3 e Jump3.mp3, três arquivos distintos
de aproximadamente 0,528 s. São copiados sem conversão nem edição para
`PulosBunnyck/audio/`. O original enviado é o próprio recurso distribuído.

[PulosBunnyck/Pulos.tscn](PulosBunnyck/Pulos.tscn) adiciona um AudioStreamPlayer
independente, com as três amostras já preenchidas e volume inicial -6 dB.
Instalar como filho direto de Jogador, ao lado de Passos e CollisionShape3D.
O script também aceita um ancestral CharacterBody3D intermediário e preenche
amostras vazias a partir dos três arquivos vizinhos, para tolerar erros simples
de montagem. Não precisa substituir scripts de controle ou dos passos.

Detecta a transição da velocidade vertical para subida fora do chão após a
atualização física do personagem. Alterna 1→2→3→1 em cada subida real, inclusive
salto correndo e dentro da tolerância de borda. Não reage à tecla sem salto,
a repetições no ar nem à queda de uma borda. A sequência continua após respawn.
O componente apenas reproduz som; não modifica velocidade, controles ou animação.

```sh
python3 tools/test_godot_jumps.py
```

14 verificações passaram em Godot 4.6.3 headless: importação, sequência de cinco
saltos, altura preservada, takeoff, tecla segurada, tentativa no ar, corrida,
queda de borda, tolerância de borda, combo, passos, montagem alternativa e cápsula.
Playback validado por eventos no driver Dummy; audição no 4.7.2 do usuário
permanece pendente. Evidências: [results.json](../validation/godot-jumps/results.json).

## Urso, corações e pasta completa — etapa atual

`ArenaCombate.tscn` conecta os componentes existentes sem editar o controlador,
combo, animações ou sons já entregues. `CombateBunnyck/combate.gd` resolve
contato, acertos, pisão, HUD, início do treino e reinício com R. A cena permanece
uma arena neutra: não substitui as fases aprovadas.

`tools/export_bear_glb.cjs` executa somente o construtor literal `spawnBear` da
Fase 2. Preserva 53 malhas, 636 triângulos, nove cores e escala 1,15; roundtrip
glTF confirma erro zero de vértices/cores. O GLB fica em `Urso/urso.glb` e uma
cópia idêntica junto da cena do inimigo. Os ombros ganham pivôs nomeados, sem
mudar a geometria. O deslocamento Visual Y=0,0805 apoia as solas no piso.

`urso.gd` mantém perseguição, preparo de 0,55 s, garra, alcance e recuperação
da fonte. O combo real aplica dano 1/1/2. Golpes iniciais recuam 0,26 e elevam
0,32; o finalizador desloca 2,15 e eleva 0,85. Enquanto reage, o urso não
avança causando dano. Subpassos, consultas ao piso e `test_move` impedem
arremessos através de paredes ou para fora do piso nesta arena.

`urso_morte.gd` é a alteração visual solicitada: voo curto, queda de costas,
impacto único, acomodação amortecida e seis manchas de poeira prealocadas.
Limites transformados das malhas garantem apoio acima do chão. O corpo fica
deitado antes de desaparecer; sem rotação acumulada ou flash como única reação.
A renderização real com Godot Compatibility/Mesa foi inspecionada em sequência
(`validation/godot-bear/contact-sheet.jpg` e `frame_*.png`).

`vida_bunnyck.gd` adiciona três corações, três vidas, imunidade de 1,25 s e
reação breve; reaparecimento restaura a arena. Buracos ignoram imunidade.
O player mantém sua reação original por contato/queda, e o HUD permite R no
fim de jogo. Não foram portadas as variantes de morte específicas de futuras
fases, campanha, recompensas ou persistência. Sete WAVs sintetizados externos
reproduzem os parâmetros originais, além de um impacto grave novo do urso.

```sh
node tools/export_bear_glb.cjs
python3 tools/build_godot_bear_audio.py
python3 tools/test_godot_bear.py
DISPLAY=:93 python3 tools/test_godot_bear.py --visual  # requer X11 disponível
python3 tools/package_godot.py
python3 tools/test_godot_bear.py --archive Bunny_Havoc_Godot_Combate.zip
```

25 verificações nativas cobrem combo real, recuo, voo, piso, colisão com parede,
borda, morte por golpe isolado, restauração, corações, imunidade, vidas, queda,
fim de jogo, R e estados da IA. A sequência gráfica cobre nove verificações
do mesmo combate. O teste do ZIP extrai para diretório novo, confere manifesto,
importa recursos, executa a cena principal configurada e repete os 25 casos.
Hashes protegem fontes web e recursos existentes. Engine usada: 4.6.3 Linux;
usuário ainda conferirá no 4.7.2 Windows. O driver de áudio Dummy permite
verificar reprodução, mas não substitui audição humana.

`tools/package_godot.py` inclui toda a pasta Godot e um manifesto SHA-256,
excluindo somente caches de importação/execução. O pacote abre diretamente
por `project.godot` com F5 e renderer Compatibility. As exportações Windows/Web
e o porte das fases completas/vila/cutscenes/saves continuam pendentes.
A versão web e suas entregas anteriores não foram alteradas.

## Refinamento do urso: quatro patas e impacto mais forte

Pedido seguinte do usuário: manter o modelo, andar sobre as quatro patas,
levantar somente para atacar e reforçar o impacto da morte. As 53 malhas,
a paleta, a escala e os dois GLBs permanecem byte a byte iguais à entrega
anterior. A alteração é de pose/animação, não uma remodelagem do personagem.

`urso_animacao.gd` inclina o torso, compensa a cabeça e os braços para manter
o olhar para a frente e apoia as quatro patas. A passada usa pares diagonais,
elevação na fase aérea e correção de contato pelo limite real da malha da pata.
Respiração e balanço são discretos; animação é suavizada ao iniciar/parar.
Preparo e garra mantêm seus tempos/IA e recebem transição até a pose ereta;
a recuperação abaixa o urso novamente. Reação a dano permanece quadrúpede
e não reaproveita a elevação do ataque por engano.

A morte captura a pose atual e mistura para a queda lateral, inclusive quando
o urso é atingido preparando a garra. Mantém o arremesso físico e o apoio
calculado das malhas. O impacto acontece após 0,12 s de queda final, com pausa
de pose de 0,065 s, compressão, ressalto de até 0,12, acomodação amortecida,
seis nuvens baixas e uma onda curta no chão. Tudo é prealocado. A câmera treme
brevemente com mais força só na pancada final. O WAV dessa pancada ganhou
transiente e grave; os demais áudios não mudaram.

32 verificações nativas incluem postura parada, perseguição real, passada
diagonal, elevação/apoio das patas, ataque ereto, retorno ao chão, reação a dano
sem levantar, pausa e ressalto no impacto, além dos 25 cenários anteriores.
Uma sequência renderizada no Godot real mostra caminhada/ataque/recuperação
e outra mostra combo/morte. Relatórios em `validation/godot-bear/`.
A repetição pelo ZIP inclui importação, boot da cena principal e os mesmos
32 casos; sem alteração do Bunnyck, controles, dano, corações ou arremesso.

A pasta completa atualizada continua gerada por `python3 tools/package_godot.py`.
Entrega: https://github.com/Deriby/BunnyHavoc/raw/refs/heads/entrega-godot-urso-quadrupede/Bunny_Havoc_Godot_Combate.zip
A entrega anterior continua na branch `entrega-godot-combate`.

## Primeiro recorte do Bosque Verde

O usuário aprovou migrar um trecho da Fase 1 para validar cenário, câmera,
saltos, caixas, coleta, checkpoint e combate em contexto. O limite jogável
vai de Z=12 até -56, com spawn em 8 e checkpoint de reaparecimento em -54,5.
O urso foi colocado em (0,0,-36) como encontro de teste: ele pertence à Fase 2,
não substitui silenciosamente os inimigos originais da Fase 1. NPCs, besouro
e lagarto ainda não fazem parte deste recorte.

`tools/export_forest_glb.cjs` executa os construtores literais da fonte da
Fase 1 em Three.js r128, sem renderer/loop de jogo. Conserva a sequência
original do gerador aleatório; só depois recorta as malhas da região.
770 instâncias decorativas e demais peças são agrupadas por material em
26 lotes estáticos, preservando vértices, normais e cores convertidas para glTF.
`bosque.glb` e `objetos.glb` são reabertos com GLTFLoader e comparados com a
extração; erro zero de posições. O gradiente do céu e as duas texturas das
placas das caixas vêm dos canvases originais. Nenhuma arte nova substitui o
modelo do Bunnyck ou o cenário. A renderização nativa usa iluminação Godot;
não é uma promessa de igualdade pixel a pixel com o pós-processo WebGL.

`layout.json` traz posições/tipos das duas caixas, oito cenouras, plataforma,
espinhos, estátua e âncoras originais de câmera. Faces físicas vêm dos mesmos
vértices do chão, excluindo a parte sem apoio dos buracos. A ordem dos
vértices é adaptada ao motor e a colisão aceita as duas faces. Limites laterais
invisíveis preservam a largura jogável da fonte. A trajetória da plataforma
mantém seno de 1,1 rad/s e amplitude 2,1, com transporte pelo corpo nativo.

`itens.gd` usa a interface de acerto do combo existente. Mantém recompensa
imediata 5/15, coleta unitária, um acerto por golpe, pisão com impulso 8 e
separação das caixas equivalente ao original. As caixas usam layer 4 para
colisão com o urso; o jogador conserva a separação original e o combo ignora
caixas como paredes de cenário. Estilhaços usam um pool fixo de 24 peças.
Coleta persiste entre vidas da tentativa e R reinicia o recorte por inteiro.

`camera_fase.gd` adapta as âncoras e a antecipação do primeiro vão grande,
com suavização, enquadramento de corrida/salto e vibração sem acumulação.
`trecho.gd` compõe os sistemas sem editar o controlador, modelos, combo,
áudio do Bunnyck, urso ou saúde existentes. Ao alcançar o outro lado no chão,
a estátua muda para roxo e o spawn passa a -54,5. A regra de queda usa o
limiar local original de 1,5 abaixo do terreno. A música MP3 da Fase 1 foi
copiada sem conversão e toca em loop; três efeitos WAV usam os parâmetros
originais de coleta, quebra e checkpoint.

```sh
node tools/export_forest_glb.cjs
python3 tools/build_godot_forest_audio.py
python3 tools/test_godot_forest.py
DISPLAY=:93 python3 tools/test_godot_forest.py --visual  # requer X11
python3 tools/test_godot_bear.py
python3 tools/package_godot.py --forest
python3 tools/test_godot_forest.py --archive Bunny_Havoc_Godot_Bosque.zip
```

Os testes exercitam entrada por teclado, piso importado, coleta, recompensas
únicas, quebra por giro/pisão, combo real contra o urso no bosque, salto sobre
o vão pequeno, transporte pela plataforma, checkpoint, morte e reaparecimento,
persistência na tentativa, R, limite lateral, câmera e loop da música.
Importação/boot também são executados no ZIP extraído. Godot usado: 4.6.3 Linux;
usuário ainda fará conferência no 4.7.2 Windows. O driver Dummy não substitui
a conferência auditiva. Não há save entre sessões, fases completas, NPCs,
cutscenes ou exportações Windows/Web nesta etapa.

Entrega: https://github.com/Deriby/BunnyHavoc/raw/refs/heads/entrega-godot-bosque-inicial/Bunny_Havoc_Godot_Bosque.zip

Validação desta entrega: 20 verificações do recorte passaram, as 32 do
combate anterior também passaram, e cinco verificações com renderização
nativa registraram início, caixas, urso, plataforma e checkpoint. A luz
ambiente usa cor explícita para evitar iluminação duplicada pelo céu;
a névoa por profundidade mantém o intervalo original de 30 a 120.

## Biblioteca de cenas reutilizáveis

O usuário solicitou separar elementos para facilitar novas fases. Esta etapa
refatora a composição; não remodela os personagens nem acrescenta campanha.
A versão anterior está na tag `godot-bosque-primeiro-trecho` e na branch de
entrega `entrega-godot-bosque-inicial`. Fontes web e componentes anteriores de
Bunnyck, urso, controle, combo, saúde e áudio não foram alterados.

### Organização atual

- `Cenas/Natureza/`: 13 cenas de árvores/plantas/pedras e um conjunto de vegetação.
- `Cenas/Coletaveis/`: cenoura com flutuação, coleta e som.
- `Cenas/Caixas/`: base com script/colisão/som, mais duas variantes herdadas.
- `Cenas/Plataformas/`: plataforma com movimento configurável e colisão.
- `Cenas/Checkpoints/`: estátua, gatilho, marcador de reaparecimento e som.
- `Cenas/Obstaculos/`: espinhos com área e dano configuráveis.
- `Cenas/Personagens/`: composição do Bunnyck e referência ao urso existente.
- `Biblioteca/Modelos/`: 19 GLBs reutilizados pelas cenas, sem posições de fase.
- `Sistemas/Coleta/`: ligação com o jogador, contagem por sinais, áudio comum e
  pool de estilhaços. Não contém o layout da Fase 1.
- `Fase1/`: terreno e composição originais, limites, câmera e progresso.
- `ExemploNovaFase.tscn`: exemplo independente com os componentes prontos.

### Comportamentos e composição

Cada cenoura/caixa encapsula a interação, mantém a regra de um acerto/coleta
e emite um sinal. O agregador `ColetaFase` recebe as recompensas, conserva
um único canal de som como antes e reutiliza 24 estilhaços. Os parâmetros e
valores 1/5/15, alcance, separação e pisão foram mantidos. O checkpoint usa
seu marcador, respeita o chão e reinicia sua aparência sem alterar outras
instâncias. A plataforma oscila ao redor da posição em que foi colocada.
Espinhos não dependem do script de uma fase. O exemplo mostra coleta, caixas,
checkpoint e dano funcionando em uma cena sem `Fase1/trecho.gd`.

O bosque contém 394 instâncias naturais editáveis, distribuídas como antes.
`elemento_natural.gd` preserva offsets locais e o recorte de uma peça na borda
do trecho por propriedades privadas; o prefab padrão continua completo.
`vegetacao_lote.gd` só atua no jogo: mantém as cópias editáveis ocultas e cria
26 MultiMeshes, com 770 peças no total. Assim, editar uma árvore ou remover uma
instância não exige editar uma malha fundida nem sacrificar o agrupamento.
`ConjuntoVegetacao.tscn` oferece o mesmo mecanismo para novas fases.

O bloco antigo `bosque.glb`, o pacote `objetos.glb` e os scripts de objetos
específicos da Fase 1 foram substituídos por essa composição. O terreno
continua como recurso próprio da fase, separado das 13 cenas naturais.
Os três efeitos de coleta/quebra/checkpoint foram movidos sem alterar bytes
para `Sistemas/Coleta/audio/`; a música continua externa na Fase 1.

### Reprodução e validação

```sh
node tools/export_godot_catalog.cjs
python3 tools/build_godot_catalog.py
DISPLAY=:93 python3 tools/test_godot_catalog.py
python3 tools/test_godot_forest.py
DISPLAY=:93 python3 tools/test_godot_forest.py --visual
python3 tools/test_godot_bear.py
python3 tools/package_godot.py --catalog
python3 tools/test_godot_forest.py --archive Bunny_Havoc_Godot_Cenas_Reutilizaveis.zip
DISPLAY=:93 python3 tools/test_godot_catalog.py --archive Bunny_Havoc_Godot_Cenas_Reutilizaveis.zip
```

Os geradores acima são ferramentas da extração inicial e recriam a composição
original: não executá-los por cima de cenas editadas manualmente sem preservar
e comparar essas edições. Novas fases são montadas no editor com os prefabs.
O extrator antigo `export_forest_glb.cjs` é uma referência histórica; ele não
faz parte do fluxo atual de edição das cenas.

Na entrega `godot-cenas-reutilizaveis`, 19 modelos foram reabertos com GLTFLoader, com erro zero de vértices por modelo.
A comparação nativa usa a entrega anterior como referência: mantém os 152.454
vértices de triângulos da composição, com erro máximo de posição de cerca de
0,000191 unidade após importação. O teste usa tolerância de 0,001 para a
representação numérica do importador e desativa compressão apenas nos fixtures
de comparação. Entre a composição individual e o agrupamento, o erro é zero.
A paleta e as geometrias vêm dos mesmos construtores literais.

A verificação de MultiMesh exige renderização real: o renderer Dummy usado
por `--headless` retorna transforms identidade para esse recurso. Por isso,
`test_godot_catalog.py` exige DISPLAY e roda no Compatibility/OpenGL do Godot;
os testes de jogabilidade continuam headless. Não confundir essa limitação
do fixture com alteração de posição no jogo.

Dez verificações do catálogo cobrem composição, agrupamento e uso independente.
Os 20 cenários do bosque continuam passando. A regressão de combate e as
capturas no motor real também fazem parte da validação da entrega completa.
Relatórios em `validation/godot-catalog/`, `godot-forest/` e `godot-bear/`.
Engine de validação: 4.6.3 Linux. O usuário conferirá no 4.7.2 Windows.

Entrega: https://github.com/Deriby/BunnyHavoc/raw/refs/heads/entrega-godot-cenas-reutilizaveis/Bunny_Havoc_Godot_Cenas_Reutilizaveis.zip

## Árvores refinadas — etapa atual

Somente `Biblioteca/Modelos/ArvoreCopaRedonda.glb` e `Pinheiro.glb` mudam no
cenário executável. Permanecem as 64 árvores de copa redonda e os 36 pinheiros
nas mesmas posições/escalas; cenas, colisões, terreno, personagens e sistemas
não foram alterados. O visual aprovado anterior fica no tag
`godot-cenas-reutilizaveis` e no ZIP da entrega anterior.

A copa redonda agora tem tronco curvo, bifurcações, cinco raízes e cinco massas
de folhas com contorno irregular. O pinheiro tem raízes, ramos e três camadas
de folhagem com bordas recortadas. Um atlas de 128 × 128 px combina fibras e
nós de casca com pequenas manchas de folhas, sem transparência. Cada espécie
usa uma malha/superfície e compartilha seus recursos em MultiMesh. Os modelos
têm 868 e 696 triângulos, respectivamente; não acrescentam colisões.

Para reconstruir apenas esses dois modelos: `node tools/refine_godot_trees.cjs`.
Executar depois de uma eventual reextração com `export_godot_catalog.cjs`,
que extrai os modelos históricos simples. Não precisa executar nenhum
gerador para jogar ou criar fases no editor.

A comparação do catálogo agora preserva a geometria de tudo que não é árvore
contra o tag anterior e compara a cena inteira individual com MultiMesh.
A igualdade com a geometria antiga das árvores deixou de ser um requisito
porque o refinamento foi solicitado. Relatórios: `validation/godot-trees/`,
`godot-catalog/` e `godot-forest/`. Conferência nativa no Godot 4.6.3 Linux;
o Godot 4.7.2 Windows do usuário ainda precisa de conferência local.

Empacotar: `python3 tools/package_godot.py --trees`. O ZIP inclui o projeto
Godot atual inteiro, com o bosque e o exemplo independente. Vila e restante
da campanha web ainda não foram portados.

## Continuação do Bosque Verde — etapa atual

A extração aditiva em `Fase1/Trecho2/` acrescenta o percurso até Z −100,
incluindo a clareira e os vãos originais de Z −70 e −92. O primeiro terreno,
composição e modelos não são regravados. O terreno visual novo começa onde
terminava o recorte decorativo anterior; a colisão nova continua a superfície
anterior sem sobreposição. Os limites laterais seguem `wp(z)` na clareira.
O trilho lê os patamares de altura e os centros dos dois vãos da fonte.

`CaixaTNT.tscn` herda a base de caixas: golpe/pisão acende pavio de 1,1 s;
o raio 4,45 destrói caixas vizinhas sem recompensa e atinge inimigos/jogador.
A explosão pode tirar os três corações e usa áudio externo, anel e fragmentos
temporários sem colisão. `Besouro.tscn` conserva seu modelo, patrulha lateral,
bola rolante, dano de contato de um coração e derrota por golpe/pisão. A morte
faz o salto/inversão do casco, solta a bola e termina com poeira; a derrota
normal vale três cenouras e a explosão não dá recompensa. A coleta conecta
esse sinal automaticamente em fases compostas com os mesmos componentes.

`Rufus.tscn` conserva o modelo e falas originais, rotina de procurar objetos,
pequeno deslocamento, piscadas e objeto na mão. Enter conversa/avança; Esc
fecha. O personagem para durante o diálogo e retoma os controles ao terminar.
O segundo checkpoint fica em Z −98,5 / Y 5; a opção `Somente avanço` impede
regressão ao passar por checkpoints anteriores. R restaura os dois trechos.

Os exportadores executam os construtores originais em Three r128 e verificam
os GLBs reabertos com GLTFLoader. O extrator da extensão não reexporta nenhum
GLB anterior, inclusive as árvores refinadas. Para reconstruir só esta etapa:

```
node tools/export_godot_continuation.cjs
python3 tools/build_godot_continuation.py
python3 tools/build_godot_forest_audio.py
python3 tools/package_godot.py --continuation
python3 tools/test_godot_forest.py --archive Bunny_Havoc_Godot_Bosque_Continuacao.zip
DISPLAY=:93 python3 tools/test_godot_catalog.py --archive Bunny_Havoc_Godot_Bosque_Continuacao.zip
DISPLAY=:93 python3 tools/test_godot_forest.py --visual
```

Não executar os geradores sobre edições manuais sem preservá-las. Os testes
cobrem o percurso anterior, TNT/cadeia/dano, besouro, conversa e controles,
salto real no vão pequeno, plataforma, câmera, checkpoint, morte/retorno e R.
O catálogo também compara a geometria individual/agrupada da extensão.
Relatórios em `validation/godot-continuation/`, `godot-forest/` e `godot-catalog/`.
Validação em Godot 4.6.3 Linux/Compatibility; 4.7.2 Windows depende da conferência
do usuário. Sem benchmark de FPS nem exportação Windows/Web nesta etapa.

O pacote inclui toda a etapa Godot atual e preserva a arena e o exemplo.
Vixxo, Nina e outros NPCs da parte inicial, lagartos, restante da fase,
cutscenes, vila, campanha e persistência continuam pendentes de migração.
