extends Node3D
## Efeito limitado e sem colisões; os sons usam os parâmetros da versão web.
var idade: float = 0.0
var _partes: Array[MeshInstance3D] = []
var _anel: MeshInstance3D

func _ready() -> void:
	add_to_group("bh_efeitos_temporarios")
	var som := AudioStreamPlayer.new()
	som.stream = preload("res://Sistemas/Coleta/audio/explosao.wav")
	add_child(som)
	som.play()
	var malha := BoxMesh.new()
	malha.size = Vector3(0.18, 0.14, 0.2)
	for i in 16:
		var node := MeshInstance3D.new()
		node.mesh = malha
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color("ffa439").srgb_to_linear() if i % 3 else Color("514237").srgb_to_linear()
		node.material_override = mat
		add_child(node)
		_partes.append(node)
	_anel = MeshInstance3D.new()
	var malha_anel := TorusMesh.new()
	malha_anel.inner_radius = 4.1
	malha_anel.outer_radius = 4.45
	malha_anel.rings = 28
	malha_anel.ring_segments = 4
	_anel.mesh = malha_anel
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(1, 0.55, 0.16, 0.7)
	_anel.material_override = mat
	add_child(_anel)

func _process(dt: float) -> void:
	idade += dt
	for i in _partes.size():
		var a: float = i * 2.399
		_partes[i].position = Vector3(cos(a) * idade * 5.0, idade * (2.0 + i % 3) - 8.0 * idade * idade, sin(a) * idade * 5.0)
		_partes[i].rotation = Vector3(a, idade * 5.0, a * idade)
		_partes[i].scale = Vector3.ONE * maxf(0.0, 1.0 - idade / 0.65)
	_anel.scale = Vector3(1.0 + idade * 1.2, 0.08, 1.0 + idade * 1.2)
	(_anel.material_override as StandardMaterial3D).albedo_color.a = maxf(0.0, 0.75 - idade * 2.3)
	if idade > 0.7:
		queue_free()
