extends CharacterBody3D
## Besouro original: patrulha lateral, bola rolante e morte de casco para baixo.
signal recompensa_ganha(valor: int)
@export var amplitude: float = 1.4
@export var fase: float = 7.02624428972
@export var velocidade: float = 1.03048608235
var jogador: CharacterBody3D
var terreno: RefCounted
var hp: int = 1
var derrotado_agora: bool = false
var _inicio: Vector3
var _tempo: float = 0.0
var _idade: float = 0.0
var _direcao: float = 1.0
var _finalizador: bool = false
var _heading: float = 0.0
var _progresso: float = 0.0
var _chao: float
var _corpo: Node3D
var _pivo := Vector3.ZERO
var _bola: Node3D
var _bola_base: Transform3D
var _bola_solta: bool = false
var _pernas: Array[Node3D] = []
var _antenas: Array[Node3D] = []
var _poeira: Node3D
var _cubos: Array[MeshInstance3D] = []

func _ready() -> void:
	process_physics_priority = 15
	_inicio = global_position
	_chao = _inicio.y
	_corpo = $Visual.find_child("Corpo", true, false)
	_bola = $Visual.find_child("Bola", true, false)
	_bola_base = _bola.transform
	for i in 4:
		_pernas.append($Visual.find_child("Perna_" + str(i), true, false))
	for i in 2:
		_antenas.append($Visual.find_child("Antena_" + str(i), true, false))
	_poeira = Node3D.new()
	add_child(_poeira)
	var malha := BoxMesh.new()
	malha.size = Vector3.ONE * 0.2
	var mat := StandardMaterial3D.new()
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color("d9c9a5").srgb_to_linear()
	for i in 8:
		var cubo := MeshInstance3D.new()
		cubo.mesh = malha
		cubo.material_override = mat
		_poeira.add_child(cubo)
		_cubos.append(cubo)
	_poeira.visible = false
	add_to_group("bunny_havoc_inimigos")

func _altura(z: float) -> float:
	return terreno.altura(z) if terreno != null else _inicio.y

func _physics_process(dt: float) -> void:
	if jogador == null and get_tree().current_scene != null:
		jogador = get_tree().current_scene.find_child("Jogador", true, false) as CharacterBody3D
	if not visible or jogador == null:
		return
	var vida := jogador.get_node("Saude")
	if vida.morto or vida.encerrado or not jogador.is_physics_processing():
		return
	_tempo += dt
	if derrotado_agora:
		_animar_morte(dt)
		return
	var ph: float = _tempo * velocidade + fase
	position.x = _inicio.x + sin(ph) * amplitude
	position.z = _inicio.z
	position.y = _altura(position.z) + 0.04
	_direcao = 1.0 if cos(ph) >= 0 else -1.0
	_corpo.scale.x = _direcao
	_corpo.position.y = absf(sin(_tempo * 12 + fase)) * 0.05
	_bola.rotation.z -= dt * 5.0 * _direcao
	for i in _pernas.size():
		_pernas[i].rotation.z = sin(_tempo * 18 + i * 2.4) * 0.4
	for i in _antenas.size():
		_antenas[i].rotation.x = sin(_tempo * 7 + fase + i * 2) * 0.3
	var delta_pos: Vector3 = jogador.global_position - global_position
	var combo: RefCounted = jogador.get("_combate")
	if delta_pos.y < 1.4 and delta_pos.y > -0.6 and combo.pode_atingir(self, 1.45):
		combo.registrar_acerto(self)
		var golpe: Dictionary = combo.golpe_para(self)
		receber_golpe(golpe.damage, golpe.heading, golpe.finisher)
	elif absf(delta_pos.x) < 1.15 and absf(delta_pos.z) < 0.8 and delta_pos.y > -0.6 and delta_pos.y < 1.4:
		if jogador.velocity.y < -0.6 and delta_pos.y > 0.55:
			receber_golpe(1, atan2(-delta_pos.x, -delta_pos.z), false)
			jogador.velocity.y = 9.0
		else:
			vida.receber_dano(1, self)

func receber_golpe(dano: int, heading: float, finalizador: bool, premiar: bool = true) -> bool:
	if derrotado_agora or not visible:
		return false
	hp = maxi(0, hp - dano)
	if hp > 0:
		return true
	derrotado_agora = true
	collision_layer = 0
	_idade = 0.0
	_heading = heading
	_finalizador = finalizador
	_progresso = 0.0
	_chao = _altura(global_position.z) + 0.04
	_bola.reparent(get_parent(), true)
	_bola_solta = true
	_pivo = _corpo.to_local(_medir_caixa().get_center())
	if premiar:
		recompensa_ganha.emit(3)
	return true

func atingido_por_explosao() -> void:
	receber_golpe(99, 0.0, false, false)

func _medir_caixa() -> AABB:
	var caixa := AABB()
	var primeiro: bool = true
	for node: MeshInstance3D in _corpo.find_children("*", "MeshInstance3D", true, false):
		var atual: AABB = node.global_transform * node.get_aabb()
		caixa = atual if primeiro else caixa.merge(atual)
		primeiro = false
	return caixa

func _animar_morte(dt: float) -> void:
	_idade += dt
	var voo: float = 0.62 if _finalizador else 0.30
	var u: float = minf(1.0, _idade / voo)
	var progresso: float = 1.0 - (1.0 - u) * (1.0 - u)
	var distancia: float = (3.2 if _finalizador else 0.38) * (progresso - _progresso)
	_progresso = progresso
	var passo := Vector3(sin(_heading), 0, cos(_heading)) * distancia
	var alvo: Vector3 = global_position + passo
	var query := PhysicsRayQueryParameters3D.create(alvo + Vector3.UP * 0.5, alvo - Vector3.UP * 0.5, 1)
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and absf(hit.position.y - _chao) < 0.25 and not test_move(global_transform, passo):
		global_position += passo
		_chao = hit.position.y + 0.04
	global_position.y = _chao + (sin(u * PI) * 1.25 if _finalizador else 4 * u * (1-u) * 0.46)
	var land: float = clampf((_idade - voo) / 0.36, 0.0, 1.0)
	_corpo.rotation.z = _direcao * (PI * smoothstep(0.0, 1.0, u) + sin(land * 18) * 0.12 * (1-land))
	_corpo.rotation.x = sin(u * PI) * 0.12
	_corpo.position = _pivo * Vector3(_direcao, 1, 1) - _corpo.basis * _pivo
	for i in _pernas.size():
		var kick: float = sin(_idade * 24 + i * 1.7) * (1-land*0.7)
		_pernas[i].rotation.x = kick * 0.65
		_pernas[i].rotation.z = (-1.0 if i < 2 else 1.0) * (0.38 + kick * 0.2)
	for i in _antenas.size():
		_antenas[i].rotation.z = (1.0 if i else -1.0) * (0.42 + sin(_idade * 15) * 0.16) * (1-land*0.5)
	# Assentar o volume real após tombar, como em enemy_death.js.
	var correcao: float = _altura(global_position.z) + 0.025 - _medir_caixa().position.y
	if correcao > 0.0 or land > 0.0:
		_corpo.position.y += correcao if correcao > 0.0 else correcao * smoothstep(0.0, 0.65, land)
	_bola.global_position.x += _direcao * dt * 0.42
	_bola.global_position.y = _altura(_bola.global_position.z) + 0.58
	_bola.rotation.z = -_idade * 3.4
	var cauda: float = maxf(0.0, _idade - voo - 0.36)
	_corpo.visible = cauda == 0.0
	_bola.visible = cauda == 0.0
	_poeira.visible = land >= 0.1
	_poeira.global_position = Vector3(global_position.x, _chao, global_position.z)
	var dust: float = clampf((_idade - voo - 0.036) / 0.5, 0.0, 1.0)
	for i in _cubos.size():
		var a: float = i * PI / 4.0
		_cubos[i].position = Vector3(sin(a) * (0.25 + dust * 0.65), 0.12 + sin(dust * PI) * 0.35, cos(a) * (0.25 + dust * 0.65))
		(_cubos[i].material_override as StandardMaterial3D).albedo_color.a = 0.35 * (1-dust)
	if cauda >= 0.24:
		visible = false
		_bola.visible = false

func reiniciar() -> void:
	if _bola_solta:
		_bola.reparent(_corpo, false)
		_bola.transform = _bola_base
		_bola_solta = false
	_bola.visible = true
	global_position = _inicio
	hp = 1
	derrotado_agora = false
	visible = true
	collision_layer = 2
	_corpo.transform = Transform3D.IDENTITY
	_corpo.visible = true
	_poeira.visible = false
	for p in _pernas + _antenas:
		p.rotation = Vector3.ZERO
