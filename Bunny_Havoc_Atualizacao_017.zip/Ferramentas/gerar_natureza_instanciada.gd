extends SceneTree
const M=preload("res://Sistemas/Visual/malhas_compartilhadas.gd")
func _initialize() -> void:run.call_deferred()
func meshes(p: Node3D) -> Array[MeshInstance3D]:
 var out: Array[MeshInstance3D]=[]
 for n: MeshInstance3D in p.find_children("*","MeshInstance3D",true,false):
  if n.is_visible_in_tree() and n.mesh!=null:out.append(n)
 return out
func run() -> void:
 OS.set_environment("BH_BUILD_STATIC_WORLD","1")
 var dir: String="res://Fase1/Estatico/NaturezaInstanciada/";DirAccess.make_dir_recursive_absolute(dir)
 var autoria:=Node3D.new();autoria.set_script(load("res://Fase1/cores_vertices.gd"))
 for path in ["Fase1/Vegetacao.tscn","Fase1/Trecho2/Vegetacao.tscn","Fase1/Trecho4/Vegetacao.tscn","Fase1/Completa/Vegetacao.tscn"]:
  var v: Node3D=load("res://"+path).instantiate();v.otimizar_em_execucao=false;v.vento_ativo=false;autoria.add_child(v)
 var vida: Node3D=load("res://Fase1/Vida/VidaBosque.tscn").instantiate();vida.set_script(null);vida.get_node("Borboletas").free();vida.get_node("Detalhes/Vegetacao").otimizar_em_execucao=false;vida.get_node("Detalhes/Vegetacao").vento_ativo=false;autoria.add_child(vida);root.add_child(autoria);await process_frame
 var plantas: Array[Node3D]=[]
 for n: Node3D in autoria.find_children("*","Node3D",true,false):
  if n.scene_file_path.ends_with(".tscn") and n.scene_file_path.contains("Cenas/Natureza/"):plantas.append(n)
 var nomes: Array[String]=[];var infos: Dictionary={};var grupos: Dictionary={};var id: int=0
 var scene:=Node3D.new();scene.name="NaturezaInstanciada";var rows: Array=[]
 for p in plantas:
  var nome: String=p.scene_file_path.get_file().get_basename()
  var model: ArrayMesh=M.planta(p,meshes(p))
  if nome not in nomes:
   var i: int=nomes.size();nomes.append(nome);var box: AABB=model.get_aabb()
   infos[nome]={"size":maxf(box.size.x,box.size.y)*1.05,"center":box.get_center(),"uv":Vector2((i%5)*204+6,(i/5)*204+6)/1024.0}
  if Vector2(p.global_position.x,p.global_position.z+119).length()<15:continue
  var row: Dictionary={"id":id,"box":p.global_transform*model.get_aabb(),"parts":[]}
  for piece in meshes(p):
   for surface in piece.mesh.get_surface_count():
    var part: ArrayMesh=M.superficie(piece.mesh,surface,piece.get_active_material(surface))
    var signature: String=part.get_meta("bh_sha")
    if not grupos.has(signature):
     var idx: int=grupos.size();var path: String=dir+"peca_%d.res"%idx
     assert(ResourceSaver.save(part,path,ResourceSaver.FLAG_COMPRESS)==OK)
     grupos[signature]={"id":idx,"poses":[],"rows":[],"mesh":load(path)}
    var g: Dictionary=grupos[signature];g.poses.append(piece.global_transform)
    row.parts.append({"group":g.id,"pose":piece.global_transform})
  rows.append(row)
  var data: Dictionary=infos[nome];var scale: float=p.global_basis.get_scale().x;var center: Vector3=p.global_transform*data.center;var half: float=float(data.size)*scale*.5
  row.far={"center":center,"size":float(data.size)*scale,"type":nomes.find(nome)}
  id+=1
 for g in grupos.values():
  var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.mesh=g.mesh;mm.instance_count=g.poses.size();mm.visible_instance_count=0
  var box: AABB;var first: bool=true
  for t: Transform3D in g.poses:
   var b: AABB=t*mm.mesh.get_aabb();box=b if first else box.merge(b);first=false
  mm.custom_aabb=box
  var n:=MultiMeshInstance3D.new();n.name="Planta_%d"%int(g.id);n.multimesh=mm;n.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;scene.add_child(n);n.owner=scene;n.set_meta("group",g.id)
 scene.set_meta("plants",rows);scene.set_meta("species",nomes);var packed:=PackedScene.new();assert(packed.pack(scene)==OK);assert(ResourceSaver.save(packed,"res://Fase1/Estatico/NaturezaInstanciada.tscn")==OK)
 print(JSON.stringify({"plants":id,"groups":grupos.size(),"species":nomes.size()}));scene.free();autoria.free();quit.call_deferred()
