extends SceneTree
const M=preload("res://Sistemas/Visual/malhas_compartilhadas.gd")
var grupos: Dictionary={}
var info: Dictionary={}
var atlas: Image
var count: int=0
func _initialize() -> void:run.call_deferred()
func tipo(p: Node3D) -> String:return p.scene_file_path.get_file().get_basename()
func material_mundo(original: Material) -> Material:
 var mat: BaseMaterial3D=original.duplicate()
 if mat.albedo_texture!=null:
  var path: String="res://Fase1/Estatico/NaturezaInstanciada/folhas.res"
  if not FileAccess.file_exists(path):assert(ResourceSaver.save(ImageTexture.create_from_image(mat.albedo_texture.get_image()),path,ResourceSaver.FLAG_COMPRESS)==OK)
  mat.albedo_texture=load(path)
 var id: String=(str(mat.albedo_color)+str(mat.albedo_texture)+str(mat.vertex_color_use_as_albedo)+str(mat.shading_mode)).sha256_text()
 var path: String="res://Fase1/Estatico/NaturezaInstanciada/m_"+id+".res"
 if not FileAccess.file_exists(path):assert(ResourceSaver.save(mat,path,ResourceSaver.FLAG_COMPRESS)==OK)
 return load(path)
func run() -> void:
 OS.set_environment("BH_BUILD_STATIC_WORLD","1")
 # Keep each entire original plant in one cell: no cut crowns at the near/far boundary.
 var autoria:=Node3D.new();autoria.set_script(load("res://Fase1/cores_vertices.gd"))
 for path in ["Fase1/Vegetacao.tscn","Fase1/Trecho2/Vegetacao.tscn","Fase1/Trecho4/Vegetacao.tscn","Fase1/Completa/Vegetacao.tscn"]:
  var veg: Node3D=load("res://"+path).instantiate();veg.otimizar_em_execucao=false;veg.vento_ativo=false;autoria.add_child(veg)
 var vida: Node3D=load("res://Fase1/Vida/VidaBosque.tscn").instantiate();vida.set_script(null);vida.get_node("Borboletas").free()
 vida.get_node("Detalhes/Vegetacao").otimizar_em_execucao=false;vida.get_node("Detalhes/Vegetacao").vento_ativo=false;autoria.add_child(vida)
 root.add_child(autoria)
 await process_frame
 var plantas: Array[Node3D]=[]
 for n: Node3D in autoria.find_children("*","Node3D",true,false):
  if n.scene_file_path.ends_with(".tscn") and n.scene_file_path.contains("Cenas/Natureza/"):plantas.append(n)
 var nomes: Array[String]=[]
 for p in plantas:
  if tipo(p) not in nomes:nomes.append(tipo(p))
 atlas=Image.create_empty(1024,1024,false,Image.FORMAT_RGBA8);atlas.fill(Color.TRANSPARENT)
 for i in nomes.size():
  var nome: String=nomes[i]
  var exemplo: Node3D
  for p in plantas:
   if tipo(p)==nome:exemplo=p;break
  var model: ArrayMesh=M.planta(exemplo,_meshes(exemplo))
  var box: AABB=model.get_aabb();var size: float=maxf(box.size.x,box.size.y)*1.05
  var sv:=SubViewport.new();sv.size=Vector2i(192,192);sv.own_world_3d=true;sv.transparent_bg=true;sv.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(sv)
  var world:=Node3D.new();sv.add_child(world)
  var env:=WorldEnvironment.new();env.environment=Environment.new();env.environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.environment.ambient_light_color=Color(1,.953,.859);env.environment.ambient_light_energy=.5;world.add_child(env)
  var light:=DirectionalLight3D.new();light.rotation_degrees=Vector3(-53,-40,0);light.light_color=Color(1,.91,.69);light.light_energy=.95;world.add_child(light)
  var n:=MeshInstance3D.new();n.mesh=model;world.add_child(n)
  var camera:=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.size=size;world.add_child(camera);camera.position=box.get_center()+Vector3(0,0,20);camera.look_at(box.get_center());camera.current=true
  for j in 3:await process_frame
  await RenderingServer.frame_post_draw
  var img: Image=sv.get_texture().get_image();img.convert(Image.FORMAT_RGBA8)
  # 5 columns x 4 rows of 192 px cells, with a 4 px transparent gutter.
  var pixel:=Vector2i((i%5)*204+6,(i/5)*204+6)
  atlas.blit_rect(img,Rect2i(0,0,192,192),pixel)
  info[nome]={"size":size,"center":box.get_center(),"uv":Vector2(pixel)/1024.0}
  sv.queue_free();await process_frame
 atlas.generate_mipmaps();assert(ResourceSaver.save(ImageTexture.create_from_image(atlas),"res://Fase1/Estatico/NaturezaInstanciada/atlas.res",ResourceSaver.FLAG_COMPRESS)==OK)
 autoria.free();print("Atlas de 17 espécies gerado.");quit.call_deferred()
func _meshes(p: Node3D) -> Array[MeshInstance3D]:
 var out: Array[MeshInstance3D]=[]
 for n: MeshInstance3D in p.find_children("*","MeshInstance3D",true,false):
  if n.is_visible_in_tree() and n.mesh!=null:out.append(n)
 return out
