extends SceneTree
func _initialize() -> void:run.call_deferred()
func run() -> void:
 var scene: Node3D=load("res://Fase1Trecho.tscn").instantiate();root.add_child(scene);current_scene=scene
 for i in 6:await process_frame
 for n in scene.find_children("*","Node",true,false):n.set_process(false);n.set_physics_process(false)
 scene.set_process(false);scene.set_physics_process(false)
 var controller: Node=scene.get_node("Desempenho").detalhes
 var atlas:=Image.create_empty(2048,2048,false,Image.FORMAT_RGBA8);atlas.fill(Color.TRANSPARENT)
 var records: Dictionary={};var meshes: Dictionary={};var index: int=0
 DirAccess.make_dir_recursive_absolute("res://Recursos/PersonagensDistantes")
 for group in controller.atores:
  var actor: Node3D=group.ator;var path: String=actor.scene_file_path
  if records.has(path):continue
  var model: Mesh=group.far.mesh;var box: AABB=model.get_aabb();var size: float=maxf(maxf(box.size.x,box.size.y),box.size.z)*1.06
  for angle in 8:
   var sv:=SubViewport.new();sv.size=Vector2i(112,112);sv.own_world_3d=true;sv.transparent_bg=true;sv.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(sv)
   var world:=Node3D.new();sv.add_child(world)
   var env:=WorldEnvironment.new();env.environment=Environment.new();env.environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR;env.environment.ambient_light_color=Color(1,.953,.859);env.environment.ambient_light_energy=.5;world.add_child(env)
   var light:=DirectionalLight3D.new();light.rotation_degrees=Vector3(-53,-40,0);light.light_color=Color(1,.91,.69);light.light_energy=.95;world.add_child(light)
   var n:=MeshInstance3D.new();n.mesh=model;world.add_child(n)
   var a: float=angle*TAU/8
   var camera:=Camera3D.new();camera.projection=Camera3D.PROJECTION_ORTHOGONAL;camera.size=size;world.add_child(camera);camera.position=box.get_center()+Vector3(sin(a),0,cos(a))*20;camera.look_at(box.get_center());camera.current=true
   for k in 2:await process_frame
   await RenderingServer.frame_post_draw
   var img: Image=sv.get_texture().get_image();img.convert(Image.FORMAT_RGBA8)
   var tile: int=index*8+angle
   atlas.blit_rect(img,Rect2i(0,0,112,112),Vector2i((tile%16)*128+8,(tile/16)*128+8))
   sv.queue_free();await process_frame
  records[path]={"id":index,"size":size,"center":[box.get_center().x,box.get_center().y,box.get_center().z]};index+=1
 atlas.generate_mipmaps();assert(ResourceSaver.save(ImageTexture.create_from_image(atlas),"res://Recursos/PersonagensDistantes/atlas.res",ResourceSaver.FLAG_COMPRESS)==OK)
 var f:=FileAccess.open("res://Recursos/PersonagensDistantes/modelos.json",FileAccess.WRITE);f.store_string(JSON.stringify(records,"\t"))
 print("Actor cards ",index)
 for n in scene.find_children("*","Node",true,false):
  if n is AudioStreamPlayer or n is AudioStreamPlayer3D:n.stop();n.stream=null
 scene.queue_free();await process_frame;OS.delay_msec(100);quit.call_deferred()
