extends CharacterBody3D
## Urso original: perseguição, garra, resistência, pulinhos e arremesso.

const Animacao = preload("urso_animacao.gd")
const Morte = preload("urso_morte.gd")
const SONS: Array[AudioStream] = [preload("audio/urso_preparo.wav"), preload("audio/urso_garra.wav"), preload("audio/urso_dano.wav"), preload("audio/urso_impacto.wav")]

signal derrotado
signal pancada_no_chao
signal atingido(dano: int, finalizador: bool)

@export var ativo: bool = false
var hp: int = 3
var estado: String = "walk"
var alcance_ataque: float = 0.0
var chao_y: float = 0.0
var invulneravel: float = 0.0
var jogador: CharacterBody3D
var animacao: RefCounted = Animacao.new()
var morte: RefCounted = Morte.new()
var derrotado_agora: bool = false
var _inicio: Vector3
var _idade: float = 0.0
var _tempo: float = 0.0
var _cool: float = 0.0
var _voo: bool = false
var _voo_idade: float = 0.0
var _voo_duracao: float = 0.30
var _voo_distancia: float = 0.26
var _voo_altura: float = 0.32
var _voo_frente := Vector3.ZERO
var _voo_progresso: float = 0.0
var _voo_inicio_y: float = 0.0
var _voo_final: bool = false
var _morte_impactou: bool = false
var _parado_por_parede: bool = false
var _alertado: bool = false
var _frente_ataque := Vector3.FORWARD
var _som: AudioStreamPlayer

func _ready() -> void:
	_inicio = global_position
	chao_y = global_position.y
	animacao.configurar($Visual)
	morte.configurar(self, $Visual, animacao)
	_som = AudioStreamPlayer.new()
	_som.name = "SomUrso"
	add_child(_som)
	var aviso := Label3D.new()
	aviso.name = "AvisoGarra"
	aviso.text = "!"
	aviso.font_size = 128
	aviso.pixel_size = 0.006
	aviso.position.y = 4.5
	aviso.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	aviso.modulate = Color("ffdc68")
	aviso.outline_modulate = Color("562934")
	aviso.visible = false
	add_child(aviso)
	add_to_group("bunny_havoc_inimigos")
	var blocos: Node3D=preload("res://Sistemas/Visual/blocos_animados.gd").new();$Visual.add_child(blocos);blocos.configurar($Visual,"UrsoPeca_*")

func _mover_seguro(distancia: Vector3) -> void:
	if distancia.length() <= 0.000001 or _parado_por_parede:
		return
	var partes: int = maxi(1, ceili(distancia.length() / 0.16))
	var passo: Vector3 = distancia / partes
	var espaco: PhysicsDirectSpaceState3D = get_world_3d().direct_space_state
	for i in partes:
		var seguinte: Vector3 = global_position + passo
		var raio := PhysicsRayQueryParameters3D.create(Vector3(seguinte.x, chao_y + 0.5, seguinte.z), Vector3(seguinte.x, chao_y - 0.3, seguinte.z), 1, [get_rid()])
		var piso: Dictionary = espaco.intersect_ray(raio)
		if piso.is_empty() or absf(piso.position.y - chao_y) > 0.25:
			_parado_por_parede = true
			break
		if test_move(global_transform, passo):
			_parado_por_parede = true
			break
		global_position += passo
		chao_y = piso.position.y

func receber_golpe(dano: int, direcao: float, finalizador: bool) -> bool:
	if derrotado_agora or not visible or (_voo and _voo_final):
		return false
	hp = maxi(0, hp - dano)
	atingido.emit(dano, finalizador)
	invulneravel = 0.85
	alcance_ataque = 0.0
	_cool = 0.8
	estado = "hurt"
	_idade = 0.0
	_voo = true
	_voo_final = finalizador
	_voo_idade = 0.0
	_voo_duracao = 0.62 if finalizador else 0.30
	_voo_distancia = 2.15 if finalizador else 0.26
	_voo_altura = 0.85 if finalizador else 0.32
	_voo_frente = Vector3(sin(direcao), 0, cos(direcao))
	_voo_inicio_y = maxf(0.0, global_position.y - chao_y)
	_voo_progresso = 0.0
	_parado_por_parede = false
	_som.stream = SONS[2]
	_som.play()
	if hp <= 0:
		derrotado_agora = true
		collision_layer = 0
		_morte_impactou = false
		morte.iniciar(finalizador)
		derrotado.emit()
	return true

func pode_causar_dano() -> bool:
	return ativo and not derrotado_agora and not _voo and invulneravel <= 0.0 and estado in ["walk","swipe"]

var _passo_distante: float=0
func _physics_process(dt: float) -> void:
	if is_instance_valid(jogador) and jogador.is_physics_processing() and estado=="walk" and not derrotado_agora and not _voo and global_position.distance_to(jogador.global_position)>32:
		_passo_distante+=dt
		if _passo_distante<.10:return
		dt=_passo_distante;_passo_distante=0
	else:
		dt+=_passo_distante;_passo_distante=0
	_simular(dt)
func _simular(dt: float) -> void:
	if not visible:
		return
	_tempo += dt
	invulneravel = maxf(0.0, invulneravel - dt)
	alcance_ataque = 0.0
	$AvisoGarra.visible = estado == "wind" and ativo and not derrotado_agora
	if _voo:
		_voo_idade += dt
		var u: float = minf(1.0, _voo_idade / _voo_duracao)
		var progresso: float = 1.0 - (1.0 - u) * (1.0 - u)
		_mover_seguro(_voo_frente * (progresso - _voo_progresso) * _voo_distancia)
		_voo_progresso = progresso
		var arco: float = sin(u * PI) if _voo_final else 4.0 * u * (1.0 - u)
		global_position.y = chao_y + arco * _voo_altura + (1.0 - u) * _voo_inicio_y
		if derrotado_agora:
			estado = "death-air" if _voo_idade < _voo_duracao else "death-fall"
			var terminou: bool = morte.atualizar(_voo_idade)
			if morte.impacto and not _morte_impactou:
				_morte_impactou = true
				pancada_no_chao.emit()
				_som.stream = SONS[3]
				_som.play()
			if terminou:
				visible = false
				estado = "defeated"
			return
		animacao.dano(_voo_idade, _voo_duracao, _voo_final)
		if _voo_idade >= _voo_duracao + 0.16:
			_voo = false
			global_position.y = chao_y
			estado = "recover"
			_idade = 0.0
			animacao.retomar()
		return
	if not ativo or not is_instance_valid(jogador):
		animacao.atualizar(dt, "walk", 0, false, false)
		return
	_idade += dt
	_cool = maxf(0.0, _cool - dt)
	var diferenca: Vector3 = jogador.global_position - global_position
	var plano := Vector2(diferenca.x, diferenca.z)
	var distancia: float = plano.length()
	var perseguindo: bool = distancia < 13.0 and absf(jogador.global_position.z - _inicio.z) < 14.0 and absf(diferenca.y) < 3.6
	var movendo: bool = false
	if not perseguindo and estado=="walk":_alertado=false
	if perseguindo and not _alertado and estado=="walk":
		_alertado=true
		estado="sniff"
		_idade=0
	_parado_por_parede = false
	if estado == "walk":
		var alvo: Vector3 = jogador.global_position if perseguindo else _inicio + Vector3(sin(_tempo * 0.8 + 4.0) * 1.7, 0, sin(_tempo * 0.3 + 4.0) * 0.45)
		var delta_pos := Vector3(alvo.x - global_position.x, 0, alvo.z - global_position.z)
		if delta_pos.length() > 0.06:
			rotation.y = atan2(delta_pos.x, delta_pos.z)
			var rapidez: float = (4.4 if distancia < 3.5 else 3.8) if perseguindo else 1.05
			if invulneravel <= 0.05:
				_mover_seguro(delta_pos.normalized() * minf(delta_pos.length(), rapidez * dt))
				movendo = not _parado_por_parede
		if perseguindo and distancia < 3.3 and invulneravel <= 0.0 and _cool <= 0.0:
			estado = "wind"
			_idade = 0.0
			_som.stream = SONS[0]
			_som.play()
	elif estado == "sniff":
		rotation.y=lerp_angle(rotation.y,atan2(diferenca.x,diferenca.z),1-exp(-5*dt))
		if _idade>=0.65:
			estado="walk"
			_idade=0
	elif estado == "wind":
		if _idade<0.35:
			rotation.y = lerp_angle(rotation.y,atan2(diferenca.x,diferenca.z),1-exp(-12*dt))
		_frente_ataque=Vector3(sin(rotation.y),0,cos(rotation.y))
		if _idade > 0.55:
			estado = "swipe"
			_idade = 0.0
			_som.stream = SONS[1]
			_som.play()
	elif estado == "swipe":
		_mover_seguro(_frente_ataque * 5.0 * dt)
		if _idade > 0.05 and _idade < 0.26:
			alcance_ataque = 2.5
		if _idade > 0.30:
			estado = "recover"
			_idade = 0.0
	elif _idade > 0.7:
		estado = "walk"
		_cool = 1.3
	global_position.y = chao_y
	animacao.olhar_local=global_basis.inverse()*diferenca
	animacao.atualizar(dt, estado, _idade, perseguindo, movendo)

func reiniciar() -> void:
	_alertado=false
	_frente_ataque=Vector3.FORWARD
	_tempo=0
	global_position = _inicio
	chao_y = _inicio.y
	rotation = Vector3.ZERO
	hp = 3
	estado = "walk"
	alcance_ataque = 0.0
	invulneravel = 0.0
	derrotado_agora = false
	_voo = false
	_idade = 0.0
	_cool = 0.0
	_parado_por_parede = false
	collision_layer = 2
	visible = true
	morte.reiniciar()
	animacao.retomar()
