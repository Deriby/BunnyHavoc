# Bunny Havoc — terra e arena do bosque

Projeto nativo completo para Godot 4.7.2 Compatibility. Importe project.godot
em pasta nova e F5. F3 alterna qualidade; F4 exibe FPS. Sem filtro PS1 ou fog.

A trilha tem terra texturizada, com transição para grama. A nova clareira da
Luna abriga uma emboscada explicada por um vigia da patrulha de Bibibunn.
São dez lagartos humanoides em três ondas. Veja [a documentação da arena](Fase1/Arena/LEIA-ME.md).

A arena reaproveita combo, recuo, dano, colisões e recompensas existentes.
O bloqueio de socos considera obstáculos sólidos, mas não encurta o soco
por causa do próprio inimigo que deveria receber o golpe.

O cenário continua pré-agrupado em setores de 32 m com LOD/HLOD nativos.
A clareira remove vegetação que atravessaria o piso novo e cobre o vão curto
original desse trecho. O salto grande seguinte continua presente.
Os GLBs originais não foram alterados. NPCs, caixas, cenouras, plataformas,
checkpoints, herói e atores da cutscene continuam separados.
A vegetação é estática; aves, borboletas, poeira e folhas levantadas continuam.

As quatro cenas de floresta continuam como fontes de autoria no nó Bosque.
O runtime usa Fase1/Estatico/CenarioEstatico.tscn; não carrega os milhares de
nós decorativos. Ferramentas/gerar_cenario.gd está incluído para refazer o bake
fora do jogo. A edição do solo está em Fase1/Arena/solo_bosque.gd; mudanças no
solo/fontes exigem gerar novamente o cenário para atualizar a apresentação.

Inclui a Fase 1 atual, cinematográfica e com progresso salvo. Vila e Fase 2
ainda não migradas. Nenhuma garantia de FPS ou de hardware mínimo por RAM.

## Renderização em lotes — atualização 016

O perfil inicial é Mínimo, com 168 linhas internas. F3 alterna Mínimo,
Nítido e Leve (240 linhas). A interface mantém sua resolução. F4 mostra o
FPS e o dispositivo gráfico reais. A janela continua em 1152 × 648.

A vegetação próxima usa as peças, cores, texturas e transformações originais
em 21 grupos instanciados. A seleção considera cada planta inteira e o campo
de visão; evita enviar todas as plantas de um setor invisível. São 1819 plantas
de 17 tipos, incluindo detalhes do bosque. Leve mantém 3D a 24 m; Mínimo a 12 m,
com margem para evitar alternância na borda. A distância usa imagens dos modelos
originais. Nítido restaura o cenário 3D anterior. As representações distantes
perdem paralaxe e detalhes vistos por outros ângulos. Elementos menores que
0,8 pixel deixam de ser enviados; isso não limita o alcance do cenário.

NPCs e inimigos distantes usam imagens com oito vistas. Ao se aproximar,
receber dano ou morrer, voltam à apresentação animada. A patrulha distante
atualiza a 10 Hz com tempo acumulado; contato, ataques, recuo e morte próximos
continuam com a frequência original. O movimento ainda verifica chão e sólidos.

Bunnyck e urso continuam com seus nós e pivôs originais. Seus cuboides são
verificados e enviados em um lote, acompanhando as poses por quadro. Nenhum
GLB foi editado. Pálpebras e efeitos continuam independentes. Cenouras mantêm
seus nós de coleta; só sua apresentação é agrupada. Aves preservam as asas.

Geradores fora do jogo:
- Ferramentas/gerar_atlas_natureza.gd: captura o atlas (Compatibility, com janela).
- Ferramentas/gerar_natureza_instanciada.gd: prepara as peças e posições (headless).
- Ferramentas/gerar_personagens_distantes.gd: captura oito vistas (com janela).

Não é necessário executar geradores para jogar. Após editar modelos/posições,
refaça os recursos correspondentes. O atlas de natureza atual comporta 20 tipos.
Ao exportar, inclua também *.json e *.gz, usados pelos layouts e pela cutscene.

Os materiais das plantas e dos lotes animados são preparados em um viewport
minúsculo durante a carga inicial, com a simulação pausada. Isso antecipa a
compilação que poderia travar a primeira aproximação de uma árvore ou do urso.
Os nós-fonte dos lotes animados deixam de enviar transformações invisíveis ao
renderizador; suas poses continuam disponíveis para animação, colisões e morte.

As medições locais usam llvmpipe por software, sem aceleração gráfica. A entrega
registra jogo ativo em repouso, caminhada e combate; resultados pausados não
representam FPS jogável. Ainda há quedas abaixo de 60 FPS. Consulte as medições
entregues; não há garantia de 60 constantes ou de hardware mínimo só pela RAM.
