extends CharacterBody3D
const Lotes=preload("res://Sistemas/Visual/lotes_personagens.gd")
## Patrulha original, atenção e investida anunciada; mantém modelo e morte.
const Animacao=preload("animacao_besouro.gd")
var animacao: RefCounted=Animacao.new()
signal recompensa_ganha(valor: int)
@export var amplitude: float = 1.4
@export var fase: float = 7.02624428972
@export var velocidade: float = 1.03048608235
var estado: String = "patrol"
var _estado_idade: float = 0.0
var _cool: float = 0.0
var _frente: Vector3 = Vector3.RIGHT
var _aviso: Label3D
var jogador: CharacterBody3D
var terreno: RefCounted
var hp: int = 1
var derrotado_agora: bool = false
var _inicio: Vector3
var _tempo: float = 0.0
var _idade: float = 0.0
var _direcao: float = 1.0
var _finalizador: bool = false
var _heading: float = 0.0
var _progresso: float = 0.0
var _chao: float
var _corpo: Node3D
var _pivo := Vector3.ZERO
var _bola: Node3D
var _bola_base: Transform3D
var _bola_solta: bool = false
var _pernas: Array[Node3D] = []
var _antenas: Array[Node3D] = []
var _material_poeira: StandardMaterial3D
var _poeira: Node3D
var _cubos: Array[MeshInstance3D] = []
var _intervalo_animacao: float=0

func _ready() -> void:
	process_physics_priority = 15
	_inicio = global_position
	_chao = _inicio.y
	_corpo = $Visual.find_child("Corpo", true, false)
	_bola = $Visual.find_child("Bola", true, false)
	_bola_base = _bola.transform
	for i in 4:
		_pernas.append($Visual.find_child("Perna_" + str(i), true, false))
	for i in 2:
		_antenas.append($Visual.find_child("Antena_" + str(i), true, false))
	_poeira = Node3D.new()
	add_child(_poeira)
	var malha := BoxMesh.new()
	malha.size = Vector3.ONE * 0.2
	var mat := StandardMaterial3D.new()
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color("d9c9a5").srgb_to_linear()
	_material_poeira = mat
	for i in 8:
		var cubo := MeshInstance3D.new()
		cubo.mesh = malha
		cubo.material_override = mat
		_poeira.add_child(cubo)
		_cubos.append(cubo)
	_poeira.visible = false
	_aviso = Label3D.new()
	_aviso.text = "!"
	_aviso.font_size = 80
	_aviso.pixel_size = 0.004
	_aviso.position.y = 1.9
	_aviso.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_aviso.modulate = Color("ffdc68")
	_aviso.visible = false
	add_child(_aviso)
	animacao.configurar(_corpo,_pernas,_antenas,_bola,global_position)
	add_to_group("bunny_havoc_inimigos")
	Lotes.agrupar($Visual)

func _altura(z: float) -> float:
	return terreno.altura(z) if terreno != null else _inicio.y

var _passo_distante: float=0
func _physics_process(dt: float) -> void:
	if is_instance_valid(jogador) and jogador.is_physics_processing() and estado=="patrol" and not derrotado_agora and global_position.distance_to(jogador.global_position)>32:
		_passo_distante+=dt
		if _passo_distante<.10:return
		dt=_passo_distante;_passo_distante=0
	else:
		dt+=_passo_distante;_passo_distante=0
	_simular(dt)
func _simular(dt: float) -> void:
	if jogador == null and get_tree().current_scene != null:
		jogador = get_tree().current_scene.find_child("Jogador", true, false) as CharacterBody3D
	if not visible or jogador == null:
		return
	var vida := jogador.get_node("Saude")
	if vida.morto or vida.encerrado or not jogador.is_physics_processing():
		return
	_tempo += dt
	if derrotado_agora:
		_animar_morte(dt)
		return
	_atualizar_comportamento(dt)
	_intervalo_animacao+=dt
	var distancia: float=global_position.distance_to(jogador.global_position)
	if distancia<42.0 or _intervalo_animacao>=0.1 or estado!="patrol":
		animacao.atualizar(_intervalo_animacao,global_position,_direcao,distancia)
		animacao.intencao(estado,_estado_idade)
		_intervalo_animacao=0
	var delta_pos: Vector3 = jogador.global_position - global_position
	var combo: RefCounted = jogador.get("_combate")
	if delta_pos.y < 1.4 and delta_pos.y > -0.6 and combo.pode_atingir(self, 1.45):
		combo.registrar_acerto(self)
		var golpe: Dictionary = combo.golpe_para(self)
		receber_golpe(golpe.damage, golpe.heading, golpe.finisher)
	elif jogador.pisou_em(self):
		receber_golpe(1, atan2(-delta_pos.x, -delta_pos.z), false)
		jogador.velocity.y = 9.0
	elif jogador.encostou_em(self) and pode_causar_dano():
		vida.receber_dano(1, self)
	elif absf(delta_pos.x) < 1.15 and absf(delta_pos.z) < 0.8 and delta_pos.y > -0.6 and delta_pos.y < 1.4:
		if jogador.velocity.y < -0.6 and delta_pos.y > 0.55:
			receber_golpe(1, atan2(-delta_pos.x, -delta_pos.z), false)
			jogador.velocity.y = 9.0
		elif pode_causar_dano():
			vida.receber_dano(1, self)

func pode_causar_dano() -> bool:
	return not derrotado_agora and estado in ["patrol", "charge", "return"]

func _entrar(novo: String) -> void:
	if novo=="notice" and _direcao<0:
		rotation.y+=PI
		_direcao=1.0
	estado = novo
	_estado_idade = 0.0
	_aviso.visible = novo in ["notice", "windup"]

func _mover_seguro(passo: Vector3) -> bool:
	var partes: int = maxi(1,ceili(passo.length()/0.16))
	for i in partes:
		var p: Vector3 = global_position+passo/partes
		var ray := PhysicsRayQueryParameters3D.create(p+Vector3.UP*0.5,p-Vector3.UP*0.35,1,[get_rid()])
		var piso: Dictionary = get_world_3d().direct_space_state.intersect_ray(ray)
		if piso.is_empty() or absf(piso.position.y-global_position.y)>0.25 or test_move(global_transform,passo/partes):
			return false
		global_position = Vector3(p.x,piso.position.y+0.04,p.z)
	return true

func _atualizar_comportamento(dt: float) -> void:
	_estado_idade += dt
	_cool = maxf(0,_cool-dt)
	var delta: Vector3 = jogador.global_position-global_position
	var perto: bool = Vector2(delta.x,delta.z).length()<4.8 and absf(delta.y)<1.8
	if estado == "patrol":
		var ph: float = _tempo*velocidade+fase
		var alvo_patrulha := Vector3(_inicio.x+sin(ph)*amplitude,global_position.y,_inicio.z)
		var passo_patrulha: Vector3 = alvo_patrulha-global_position
		_mover_seguro(passo_patrulha.limit_length(maxf(0.04,amplitude*velocidade*dt)))
		rotation.y = 0
		_direcao = 1.0 if cos(ph)>=0 else -1.0
		if perto and _cool<=0:_entrar("notice")
	elif estado in ["notice","windup"]:
		# A bola foi modelada em +X; o root orienta o conjunto sem mudar a malha.
		if _estado_idade<0.28 or estado=="notice":
			_frente = Vector3(delta.x,0,delta.z).normalized()
			if _frente.length_squared()<0.1:_frente=Vector3.RIGHT
			rotation.y = lerp_angle(rotation.y,atan2(-_frente.z,_frente.x),1-exp(-12*dt))
			_direcao = 1.0
		if estado=="notice" and _estado_idade>=0.25:_entrar("windup")
		elif estado=="windup" and _estado_idade>=0.48:
			rotation.y=atan2(-_frente.z,_frente.x)
			_entrar("charge")
	elif estado=="charge":
		var livre: bool = _mover_seguro(_frente*5.6*dt)
		if not livre or _estado_idade>=0.48:
			_entrar("recover")
			_cool=2.0
	elif estado=="recover":
		if _estado_idade>=0.85:_entrar("return")
	elif estado=="return":
		var alvo := Vector3(_inicio.x+sin(_tempo*velocidade+fase)*amplitude,global_position.y,_inicio.z)
		var caminho: Vector3 = alvo-global_position
		_frente=caminho.normalized()
		if caminho.length()>0.08:
			rotation.y=lerp_angle(rotation.y,atan2(-_frente.z,_frente.x),1-exp(-8*dt))
			_direcao=1.0
			_mover_seguro(_frente*minf(caminho.length(),2.0*dt))
		else:_entrar("patrol")

func receber_golpe(dano: int, heading: float, finalizador: bool, premiar: bool = true) -> bool:
	if derrotado_agora or not visible:
		return false
	hp = maxi(0, hp - dano)
	if hp > 0:
		return true
	derrotado_agora = true
	_aviso.visible = false
	collision_layer = 0
	_idade = 0.0
	_heading = heading
	_finalizador = finalizador
	_progresso = 0.0
	_chao = _altura(global_position.z) + 0.04
	_bola.reparent(get_parent(), true)
	_bola_solta = true
	_pivo = _corpo.to_local(_medir_caixa().get_center())
	if premiar:
		recompensa_ganha.emit(3)
	return true

func atingido_por_explosao() -> void:
	receber_golpe(99, 0.0, false, false)

func _medir_caixa() -> AABB:
	var caixa := AABB()
	var primeiro: bool = true
	for node: MeshInstance3D in _corpo.find_children("*", "MeshInstance3D", true, false):
		var atual: AABB = node.global_transform * node.get_aabb()
		caixa = atual if primeiro else caixa.merge(atual)
		primeiro = false
	return caixa

func _animar_morte(dt: float) -> void:
	_idade += dt
	var voo: float = 0.62 if _finalizador else 0.30
	var u: float = minf(1.0, _idade / voo)
	var progresso: float = 1.0 - (1.0 - u) * (1.0 - u)
	var distancia: float = (3.2 if _finalizador else 0.38) * (progresso - _progresso)
	_progresso = progresso
	var passo := Vector3(sin(_heading), 0, cos(_heading)) * distancia
	var alvo: Vector3 = global_position + passo
	var query := PhysicsRayQueryParameters3D.create(alvo + Vector3.UP * 0.5, alvo - Vector3.UP * 0.5, 1)
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty() and absf(hit.position.y - _chao) < 0.25 and not test_move(global_transform, passo):
		global_position += passo
		_chao = hit.position.y + 0.04
	global_position.y = _chao + (sin(u * PI) * 1.25 if _finalizador else 4 * u * (1-u) * 0.46)
	var land: float = clampf((_idade - voo) / 0.36, 0.0, 1.0)
	_corpo.rotation.z = _direcao * (PI * smoothstep(0.0, 1.0, u) + sin(land * 18) * 0.12 * (1-land))
	_corpo.rotation.x = sin(u * PI) * 0.12
	_corpo.position = _pivo * Vector3(_direcao, 1, 1) - _corpo.basis * _pivo
	for i in _pernas.size():
		var kick: float = sin(_idade * 24 + i * 1.7) * (1-land*0.7)
		_pernas[i].rotation.x = kick * 0.65
		_pernas[i].rotation.z = (-1.0 if i < 2 else 1.0) * (0.38 + kick * 0.2)
	for i in _antenas.size():
		_antenas[i].rotation.z = (1.0 if i else -1.0) * (0.42 + sin(_idade * 15) * 0.16) * (1-land*0.5)
	# Assentar o volume real após tombar, como em enemy_death.js.
	var correcao: float = _altura(global_position.z) + 0.025 - _medir_caixa().position.y
	if correcao > 0.0 or land > 0.0:
		_corpo.position.y += correcao if correcao > 0.0 else correcao * smoothstep(0.0, 0.65, land)
	_bola.global_position.x += _direcao * dt * 0.42
	_bola.global_position.y = _altura(_bola.global_position.z) + 0.58
	_bola.rotation.z = -_idade * 3.4
	var cauda: float = maxf(0.0, _idade - voo - 0.36)
	_corpo.visible = cauda == 0.0
	_bola.visible = cauda == 0.0
	_poeira.visible = land >= 0.1
	_poeira.global_position = Vector3(global_position.x, _chao, global_position.z)
	var dust: float = clampf((_idade - voo - 0.036) / 0.5, 0.0, 1.0)
	for i in _cubos.size():
		var a: float = i * PI / 4.0
		_cubos[i].position = Vector3(sin(a) * (0.25 + dust * 0.65), 0.12 + sin(dust * PI) * 0.35, cos(a) * (0.25 + dust * 0.65))
		_material_poeira.albedo_color.a = 0.35 * (1-dust)
	if cauda >= 0.24:
		visible = false
		_bola.visible = false

func reiniciar() -> void:
	_intervalo_animacao=0
	_entrar("patrol")
	_cool=0
	_tempo=0
	rotation=Vector3.ZERO
	if _bola_solta:
		_bola.reparent(_corpo, false)
		_bola.transform = _bola_base
		_bola_solta = false
	_bola.visible = true
	global_position = _inicio
	hp = 1
	derrotado_agora = false
	visible = true
	collision_layer = 2
	_corpo.transform = Transform3D.IDENTITY
	animacao.reiniciar(global_position)
	_corpo.visible = true
	_poeira.visible = false
	for p in _pernas + _antenas:
		p.rotation = Vector3.ZERO
