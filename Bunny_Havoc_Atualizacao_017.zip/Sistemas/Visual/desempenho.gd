extends CanvasLayer
const Distantes=preload("lotes_distantes.gd")
const Terreno=preload("lotes_terreno.gd")
const MODOS: Array[String]=["Leve","Mínimo","Nítido"]
const ALTURAS: Array[float]=[240.0,168.0,0.0]
var modo: int=1
var _aviso: Label
var _restante: float=0
var _fps: Label
var _viewport: Viewport
var terreno: Node3D
var detalhes: Node
var trechos: Node
func _ready() -> void:
	layer=80;_viewport=get_viewport()
	_aviso=Label.new();_aviso.position=Vector2(20,178)
	_aviso.mouse_filter=Control.MOUSE_FILTER_IGNORE
	_aviso.add_theme_font_size_override("font_size",16)
	_aviso.add_theme_color_override("font_color",Color("fff0dc"))
	_aviso.add_theme_color_override("font_outline_color",Color("241335"))
	_aviso.add_theme_constant_override("outline_size",4)
	add_child(_aviso);_aviso.visible=false
	_fps=Label.new();_fps.position=Vector2(20,204);_fps.visible=false;add_child(_fps)
	_viewport.size_changed.connect(_redimensionar)
	aplicar(1,false);_preparar.call_deferred()
func _preparar() -> void:
	terreno=Terreno.agrupar(get_parent()) if OS.get_environment("BH_BUILD_STATIC_WORLD")=="1" else get_parent().get_node("CenarioEstatico")
	detalhes=Distantes.new();detalhes.name="DetalhesDistantes";get_parent().add_child(detalhes);detalhes.configurar(get_parent());detalhes.qualidade(modo)
	var cenouras: Node3D=preload("res://Sistemas/Visual/lote_cenouras.gd").new();get_parent().add_child(cenouras);cenouras.configurar(get_parent())
	trechos=preload("res://Sistemas/Visual/trechos_ativos.gd").new();trechos.name="TrechosAtivos";get_parent().add_child(trechos);trechos.configurar(get_parent())
	var aquecimento: Node3D=preload("aquecimento.gd").new();get_parent().add_child(aquecimento)
func _redimensionar() -> void:aplicar(modo,false)
func aplicar(indice: int,avisar: bool=true) -> void:
	modo=clampi(indice,0,MODOS.size()-1)
	if detalhes!=null:detalhes.qualidade(modo)
	_viewport.scaling_3d_mode=Viewport.SCALING_3D_MODE_BILINEAR
	_viewport.scaling_3d_scale=clampf(ALTURAS[modo]/maxf(1.0,_viewport.get_texture().get_height()),0.1,1.0) if ALTURAS[modo]>0 else 1.0
	_viewport.mesh_lod_threshold=[8.0,64.0,2.0][modo]
	var mundo: Node=get_parent().get_node_or_null("CenarioEstatico")
	if mundo!=null and mundo.has_method("configurar_qualidade"):mundo.configurar_qualidade(modo)
	if avisar:
		_aviso.text="Gráficos: "+MODOS[modo]+" — F3 para trocar"
		_restante=3;_aviso.visible=true
func _process(dt: float) -> void:
	if _fps.visible:_fps.text="FPS: %d — %s — %s" % [Engine.get_frames_per_second(),MODOS[modo],RenderingServer.get_video_adapter_name()]
	if _restante<=0:return
	_restante=maxf(0,_restante-dt);_aviso.visible=_restante>0
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F4 or event.keycode==KEY_F4):
		_fps.visible=not _fps.visible;get_viewport().set_input_as_handled()
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F3 or event.keycode==KEY_F3):
		aplicar((modo+1)%MODOS.size());get_viewport().set_input_as_handled()
