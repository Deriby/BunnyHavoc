extends Node3D
## Mesmas peças e transformações do cenário de autoria; só o envio ao render muda.
var plants: Array=[]
var groups: Array=[]
var far: MultiMeshInstance3D
var material: ShaderMaterial
var player: Node3D
var camera: Camera3D
var fase: Node3D
var ativo: bool=true
var raio: float=12
var trocas: int=0
var far_buffer:=PackedFloat32Array()
var _camera_anterior: Transform3D
var _focal_anterior: float=-1
var far_count: int=0
func _ready() -> void:
 plants=get_meta("plants")
 for p in plants:p.on=false
 for n in get_children():
  if n is MultiMeshInstance3D:groups.append({"node":n,"poses":[]})
 var shader:=Shader.new();shader.code="""shader_type spatial;
render_mode unshaded,cull_disabled,skip_vertex_transform;
uniform sampler2D atlas : source_color,filter_linear_mipmap,repeat_disable;
uniform float focal=120.0;
void vertex(){vec3 center=MODEL_MATRIX[3].xyz;float size=length(MODEL_MATRIX[0].xyz);vec3 vc=(VIEW_MATRIX*vec4(center,1.0)).xyz;if(INSTANCE_CUSTOM.g>0.5||size*focal/max(0.01,-vc.z)<0.8){VERTEX=vec3(0.0,0.0,10000.0);}else{vec3 right=normalize(vec3(INV_VIEW_MATRIX[0].x,0.0,INV_VIEW_MATRIX[0].z));vec3 world=center+right*VERTEX.x*size+vec3(0.0,VERTEX.y*size,0.0);VERTEX=(VIEW_MATRIX*vec4(world,1.0)).xyz;int tile=int(round(INSTANCE_CUSTOM.r*255.0));UV=(vec2(float(tile%5)*204.0,float(tile/5)*204.0)+vec2(6.0)+UV*192.0)/1024.0;}}
void fragment(){vec4 c=texture(atlas,UV);if(c.a<0.4){discard;}ALBEDO=c.rgb;}
"""
 material=ShaderMaterial.new();material.shader=shader;material.set_shader_parameter("atlas",load("res://Fase1/Estatico/NaturezaInstanciada/atlas.res"))
 far=MultiMeshInstance3D.new();far.material_override=material;far.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;add_child(far)
 var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_custom_data=true;mm.mesh=QuadMesh.new();mm.instance_count=plants.size();mm.custom_aabb=AABB(Vector3(-300,-80,-550),Vector3(600,250,750));far.multimesh=mm
 far_buffer.resize(plants.size()*16)
func configurar(raiz: Node3D,modo: int) -> void:
 fase=raiz;player=fase.get_node("Jogador");camera=fase.get_node("Camera3D");qualidade(modo)
func qualidade(modo: int) -> void:
 ativo=modo!=2;raio=24 if modo==0 else 12;visible=ativo
 for p in plants:p.on=false
 for g in groups:g.node.lod_bias=4 if modo==0 else 32
 atualizar(true)
func atualizar(forcar: bool=false) -> void:
 if not ativo or player==null:return
 var pos: Vector3=player.global_position
 var final: Node=fase.get("final")
 if final!=null and final.ativo:pos=camera.global_position
 material.set_shader_parameter("focal",get_viewport().get_texture().get_height()*get_viewport().scaling_3d_scale/(2.0*tan(deg_to_rad(camera.fov*.5))))
 var mudou: bool=forcar
 for p in plants:
  var b: AABB=p.box;var radius: float=raio+(2.0 if p.on else 0.0)
  var near: bool=pos.x>=b.position.x-radius and pos.x<=b.end.x+radius and pos.z>=b.position.z-radius and pos.z<=b.end.z+radius
  if near:
   var closest:=Vector3(clampf(pos.x,b.position.x,b.end.x),clampf(pos.y,b.position.y,b.end.y),clampf(pos.z,b.position.z,b.end.z))
   near=pos.distance_squared_to(closest)<radius*radius
  if forcar or near!=p.on:
   p.on=near;mudou=true;trocas+=1

 var camera_mudou: bool=not camera.global_transform.is_equal_approx(_camera_anterior)
 _atualizar_distantes(mudou)
 if not mudou and not camera_mudou:return
 for g in groups:g.poses.clear()
 var planes: Array[Plane]=camera.get_frustum()
 var box: AABB;var first: bool=true
 for p in plants:
  if not p.on:continue
  var outside: bool=false
  for plane: Plane in planes:
   var b: AABB=p.box
   var closest:=Vector3(b.position.x if plane.normal.x>=0 else b.end.x,b.position.y if plane.normal.y>=0 else b.end.y,b.position.z if plane.normal.z>=0 else b.end.z)
   if plane.distance_to(closest)>0:outside=true;break
  if outside:continue
  box=p.box if first else box.merge(p.box);first=false
  for part in p.parts:groups[int(part.group)].poses.append(part.pose)
 for g in groups:
  var mm: MultiMesh=g.node.multimesh;mm.visible_instance_count=g.poses.size()
  if not g.poses.is_empty():
   mm.custom_aabb=box
   for i in g.poses.size():mm.set_instance_transform(i,g.poses[i])


func _atualizar_distantes(forcar: bool) -> void:
 var view: Transform3D=camera.global_transform.affine_inverse()
 var height: float=get_viewport().get_texture().get_height()*get_viewport().scaling_3d_scale
 var focal: float=height/(2*tan(deg_to_rad(camera.fov*.5)))
 if not forcar and camera.global_transform.is_equal_approx(_camera_anterior) and is_equal_approx(focal,_focal_anterior):return
 _camera_anterior=camera.global_transform;_focal_anterior=focal
 var ty: float=tan(deg_to_rad(camera.fov*.5));var tx: float=ty*float(get_viewport().get_texture().get_width())/maxf(1.0,get_viewport().get_texture().get_height())
 var count: int=0
 for p in plants:
  if p.on:continue
  var data: Dictionary=p.far;var size: float=data.size;var center: Vector3=data.center;var v: Vector3=view*center;var z: float=-v.z;var half: float=size*.75
  if z< -half or size*focal/maxf(.01,z)<.8 or absf(v.x)>z*tx+half or absf(v.y)>z*ty+half:continue
  var o: int=count*16
  far_buffer[o]=size;far_buffer[o+1]=0;far_buffer[o+2]=0;far_buffer[o+3]=center.x
  far_buffer[o+4]=0;far_buffer[o+5]=size;far_buffer[o+6]=0;far_buffer[o+7]=center.y
  far_buffer[o+8]=0;far_buffer[o+9]=0;far_buffer[o+10]=size;far_buffer[o+11]=center.z
  far_buffer[o+12]=float(data.type)/255.0;far_buffer[o+13]=0;far_buffer[o+14]=0;far_buffer[o+15]=0;count+=1
 far.multimesh.visible_instance_count=count;far.multimesh.buffer=far_buffer;far_count=count
