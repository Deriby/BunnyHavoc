extends Node3D
var tipos: Dictionary
var visual: MultiMeshInstance3D
var grupos: Array=[]
var modo: int=0
func _ready() -> void:
 top_level=true;global_transform=Transform3D.IDENTITY
 tipos=JSON.parse_string(FileAccess.get_file_as_string("res://Recursos/PersonagensDistantes/modelos.json"))
 var shader:=Shader.new();shader.code="""shader_type spatial;
render_mode unshaded, cull_disabled, skip_vertex_transform;
uniform sampler2D atlas : source_color, filter_linear_mipmap, repeat_disable;
void vertex(){if(INSTANCE_CUSTOM.a<0.5){VERTEX=vec3(0.0,0.0,10000.0);}else{vec3 center=MODEL_MATRIX[3].xyz;float s=length(MODEL_MATRIX[0].xyz);vec3 right=normalize(vec3(INV_VIEW_MATRIX[0].x,0.0,INV_VIEW_MATRIX[0].z));vec3 world=center+right*VERTEX.x*s+vec3(0.0,VERTEX.y*s,0.0);float angle=atan(INV_VIEW_MATRIX[3].x-center.x,INV_VIEW_MATRIX[3].z-center.z)-INSTANCE_CUSTOM.g*6.283185307;int view=int(mod(floor(angle*1.273239545+0.5)+8.0,8.0));int type=int(round(INSTANCE_CUSTOM.r*255.0));int tile=type*8+view;UV=(vec2(float(tile%16)*128.0,float(tile/16)*128.0)+vec2(8.0)+UV*112.0)/2048.0;VERTEX=(VIEW_MATRIX*vec4(world,1.0)).xyz;}}
void fragment(){vec4 c=texture(atlas,UV);if(c.a<0.4){discard;}ALBEDO=c.rgb;}
"""
 var mat:=ShaderMaterial.new();mat.shader=shader;mat.set_shader_parameter("atlas",load("res://Recursos/PersonagensDistantes/atlas.res"))
 visual=MultiMeshInstance3D.new();visual.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;visual.material_override=mat;add_child(visual)
func configurar(lista: Array) -> void:
 grupos=lista
 var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_custom_data=true;mm.mesh=QuadMesh.new();mm.instance_count=grupos.size();mm.custom_aabb=AABB(Vector3(-100,-50,-500),Vector3(200,150,650));visual.multimesh=mm
 for i in grupos.size():mm.set_instance_custom_data(i,Color(0,0,0,0))
func atualizar() -> void:
 for i in grupos.size():
  var g: Dictionary=grupos[i];var actor: Node3D=g.ator;var info: Dictionary=tipos.get(actor.scene_file_path,{})
  var usar: bool=modo!=2 and g.distante and not info.is_empty() and actor.is_visible_in_tree()
  g.far.layers=0 if usar else (1 if g.distante else 0)
  if not usar:visual.multimesh.set_instance_custom_data(i,Color(0,0,0,0));continue
  var c: Array=info.center;var v: Node3D=actor.get_node("Visual")
  var center: Vector3=v.global_transform*Vector3(c[0],c[1],c[2])
  var s: float=float(info.size)*v.global_basis.get_scale().y
  visual.multimesh.set_instance_transform(i,Transform3D(Basis.IDENTITY.scaled(Vector3.ONE*s),center))
  visual.multimesh.set_instance_custom_data(i,Color(float(info.id)/255.0,fposmod(v.global_rotation.y,TAU)/TAU,0,1))
