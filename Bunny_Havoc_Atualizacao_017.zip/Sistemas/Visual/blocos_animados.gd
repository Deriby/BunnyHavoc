extends Node3D
## Envia os mesmos cuboides em um único lote, seguindo cada pivô original.
var sources: Array=[]
var dados:=PackedFloat32Array()
var visual: MultiMeshInstance3D
func configurar(root_visual: Node3D,pattern: String) -> bool:
 for n: MeshInstance3D in root_visual.find_children(pattern,"MeshInstance3D",true,false):
  if n.mesh==null or n.mesh.get_surface_count()!=1:return false
  var a: Array=n.mesh.surface_get_arrays(0);var box: AABB=n.mesh.get_aabb();var mat: Material=n.get_active_material(0)
  if not mat is BaseMaterial3D or mat.albedo_texture!=null or mat.transparency!=BaseMaterial3D.TRANSPARENCY_DISABLED or mat.emission_enabled:return false
  if a[Mesh.ARRAY_VERTEX].size()!=24:return false
  if mat.vertex_color_use_as_albedo and a[Mesh.ARRAY_COLOR]!=null and not a[Mesh.ARRAY_COLOR].is_empty():return false
  for v: Vector3 in a[Mesh.ARRAY_VERTEX]:
   if (absf(v.x-box.position.x)>.00001 and absf(v.x-box.end.x)>.00001) or (absf(v.y-box.position.y)>.00001 and absf(v.y-box.end.y)>.00001) or (absf(v.z-box.position.z)>.00001 and absf(v.z-box.end.z)>.00001):return false
  sources.append({"node":n,"local":Transform3D(Basis.IDENTITY.scaled(box.size),box.get_center()),"color":mat.albedo_color,"layer":n.layers})
 if sources.is_empty():return false
 visual=MultiMeshInstance3D.new();visual.name="BlocosAnimadosAgrupados";visual.cast_shadow=sources[0].node.cast_shadow;add_child(visual)
 var mat: BaseMaterial3D=sources[0].node.get_active_material(0).duplicate();mat.albedo_color=Color.WHITE;mat.vertex_color_use_as_albedo=true;mat.vertex_color_is_srgb=false
 var mesh:=BoxMesh.new();mesh.size=Vector3.ONE;mesh.material=mat
 var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_colors=true;mm.mesh=mesh;mm.instance_count=sources.size();mm.custom_aabb=AABB(Vector3(-10,-6,-10),Vector3(20,20,20));visual.multimesh=mm
 dados.resize(sources.size()*16)
 for i in sources.size():
  var c: Color=sources[i].color;var o: int=i*16
  dados[o+12]=c.r;dados[o+13]=c.g;dados[o+14]=c.b;dados[o+15]=c.a;sources[i].node.layers=0;sources[i].node.set_notify_transform(false)
 root_visual.set_meta("bh_blocos_animados",self);process_priority=100;_process(0);return true
func _process(_dt: float) -> void:
 if visual==null or visual.layers==0 or not visual.is_visible_in_tree():return
 var reference: Transform3D=global_transform.affine_inverse()
 for i in sources.size():
  var s: Dictionary=sources[i];var n: MeshInstance3D=s.node
  var pose: Transform3D=reference*n.global_transform*s.local
  if not n.is_visible_in_tree():pose.basis=Basis.IDENTITY.scaled(Vector3.ZERO)
  var b: Basis=pose.basis;var t: Vector3=pose.origin;var o: int=i*16
  dados[o]=b.x.x;dados[o+1]=b.y.x;dados[o+2]=b.z.x;dados[o+3]=t.x
  dados[o+4]=b.x.y;dados[o+5]=b.y.y;dados[o+6]=b.z.y;dados[o+7]=t.y
  dados[o+8]=b.x.z;dados[o+9]=b.y.z;dados[o+10]=b.z.z;dados[o+11]=t.z
 visual.multimesh.buffer=dados
