extends Node
## HLOD: troca peças por lotes equivalentes à distância, sem remover o cenário.
const Malhas=preload("malhas_compartilhadas.gd")
const Materiais=preload("materiais_compartilhados.gd")
var faixas: Array[Dictionary]=[]
var atores: Array[Dictionary]=[]
var fase: Node3D
var jogador: Node3D
var camera: Camera3D
var _tempo: float=0
var _cartoes: Node3D
var modo: int=0
func configurar(raiz: Node3D) -> void:
	fase=raiz;jogador=fase.get_node("Jogador");camera=fase.get_node("Camera3D")
	var zonas: Dictionary={}
	for v in get_tree().get_nodes_in_group("bh_vegetacao"):
		for node in v.get_children():
			if not node is MultiMeshInstance3D or not node.has_meta("bh_instancias"):continue
			var poses: Array=node.get_meta("bh_instancias")
			var zona: int=floori((node.global_transform*poses[0].origin).z/48.0)
			if not zonas.has(zona):zonas[zona]={"near":[],"tools":{},"far":[],"z":(zona+0.5)*48.0,"distante":false}
			var grupo: Dictionary=zonas[zona];grupo.near.append({"node":node,"layers":node.layers})
			for i in node.multimesh.mesh.get_surface_count():
				var mat: BaseMaterial3D=node.material_override if node.material_override!=null else node.multimesh.mesh.surface_get_material(i)
				mat=Materiais.equivalente(mat)
				var id: int=mat.get_instance_id()
				if not grupo.tools.has(id):
					var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES);st.set_material(mat);grupo.tools[id]=st
				for t: Transform3D in poses:grupo.tools[id].append_from(node.multimesh.mesh,i,node.global_transform*t)
	for grupo: Dictionary in zonas.values():
		for tool: SurfaceTool in grupo.tools.values():
			tool.index();var n:=MeshInstance3D.new();n.mesh=Malhas.com_lods(tool.commit());n.layers=0;add_child(n);grupo.far.append(n)
		grupo.erase("tools");faixas.append(grupo)
	for ator: Node3D in get_tree().get_nodes_in_group("bh_cidadaos")+get_tree().get_nodes_in_group("bunny_havoc_inimigos"):
		var visual: Node3D=ator.get_node("Visual")
		var pecas: Array[MeshInstance3D]=[]
		for p: MeshInstance3D in visual.find_children("*","MeshInstance3D",true,false):
			if p.is_visible_in_tree() and p.mesh!=null:pecas.append(p)
		var originais: Array[MeshInstance3D]=pecas
		var proxy:=MeshInstance3D.new();proxy.name="DetalheDistante";proxy.mesh=Malhas.planta(visual,originais);proxy.layers=0;visual.add_child(proxy)
		var perto: Array=[]
		for p in pecas:perto.append({"node":p,"layers":p.layers})
		if visual.has_meta("bh_blocos_animados"):
			var blocos: MultiMeshInstance3D=visual.get_meta("bh_blocos_animados").visual
			perto.append({"node":blocos,"layers":blocos.layers})
		atores.append({"ator":ator,"near":perto,"far":proxy,"distante":false})
	_cartoes=preload("res://Sistemas/Visual/cartoes_personagens.gd").new();fase.add_child(_cartoes);_cartoes.configurar(atores)
	for g in atores:g.ator.visibility_changed.connect(atualizar.bind(true))
	atualizar(true)
func qualidade(novo: int) -> void:
	modo=novo
	if _cartoes!=null:_cartoes.modo=modo;atualizar(true)
func _process(dt: float) -> void:
	_tempo+=dt
	if _tempo>=0.12:atualizar()
func atualizar(forcar: bool=false) -> void:
	_tempo=0
	var filme: Node=fase.get_node_or_null("FinalOriginal")
	var centro: Vector3=camera.global_position if filme!=null and filme.ativo else jogador.global_position
	for grupo in faixas:
		var distante: bool=absf(centro.z-grupo.z)>(64.0 if grupo.distante else 80.0)
		if distante==grupo.distante and not forcar:continue
		grupo.distante=distante
		for p in grupo.near:p.node.layers=0 if distante else p.layers
		for p in grupo.far:p.layers=1 if distante else 0
	for grupo in atores:
		var distante: bool=grupo.ator.global_position.distance_to(centro)>(24.0 if grupo.distante else 28.0)
		if grupo.ator.get("derrotado_agora")==true or grupo.ator.get("_voo")==true:distante=false
		if distante==grupo.distante and not forcar:continue
		grupo.distante=distante
		for p in grupo.near:p.node.layers=0 if distante else p.layers
		grupo.far.layers=1 if distante else 0

	if _cartoes!=null:_cartoes.atualizar()
