extends Node3D
## Prepara os programas de materiais antes do primeiro movimento, sem desenhá-los no jogo.
func _ready() -> void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 if DisplayServer.get_name()=="headless":queue_free();return
 preparar.call_deferred()
func preparar() -> void:
 var fase: Node3D=get_parent();var originais: Array[MultiMeshInstance3D]=[]
 for g in fase.get_node("CenarioEstatico")._impostores.groups:originais.append(g.node)
 for ator: Node3D in [fase.jogador,fase.combate.urso]:
  var visual: Node3D=ator.get_node("Visual")
  if visual.has_meta("bh_blocos_animados"):originais.append(visual.get_meta("bh_blocos_animados").visual)
 var pausado: bool=get_tree().paused;get_tree().paused=true
 var viewport:=SubViewport.new();viewport.size=Vector2i(2,2);viewport.world_3d=get_world_3d();viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS;add_child(viewport)
 var centro:=Vector3(12000,12000,0)
 for original in originais:
  var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_colors=original.multimesh.use_colors;mm.use_custom_data=original.multimesh.use_custom_data;mm.mesh=original.multimesh.mesh;mm.instance_count=1;mm.set_instance_transform(0,Transform3D.IDENTITY)
  if mm.use_colors:mm.set_instance_color(0,Color.WHITE)
  var n:=MultiMeshInstance3D.new();n.multimesh=mm;n.material_override=original.material_override;n.cast_shadow=original.cast_shadow;n.layers=1;viewport.add_child(n);n.top_level=true;n.global_position=centro;n.scale=Vector3.ONE*.02
 var camera:=Camera3D.new();viewport.add_child(camera);camera.top_level=true;camera.global_position=centro+Vector3(0,0,3);camera.look_at(centro);camera.cull_mask=1;camera.current=true
 for i in 3:await RenderingServer.frame_post_draw
 get_tree().paused=pausado;queue_free()
