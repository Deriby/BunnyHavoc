extends Node3D
## Mantém os nós de coleta; só combina sua apresentação e ignora desenhos menores que um pixel.
var groups: Array=[]
var camera: Camera3D
var _tempo: float=0
var _sujo: bool=true
var desenhadas: int=0
func configurar(fase: Node3D) -> void:
 top_level=true;global_transform=Transform3D.IDENTITY;camera=fase.get_node("Camera3D")
 var data: Dictionary={}
 for p in get_tree().get_nodes_in_group("bh_cenouras"):
  if p.is_in_group("bh_segredos"):continue
  var visual: Node3D=p.get_node_or_null("Visual")
  if visual==null or not visual.has_meta("bh_visual_agrupado"):continue
  var lote: MeshInstance3D=visual.get_meta("bh_visual_agrupado").lote
  var key: int=lote.mesh.get_instance_id()
  if not data.has(key):data[key]={"mesh":lote.mesh,"entries":[]}
  data[key].entries.append({"node":p,"visual":visual,"lote":lote,"dist":0.0})
  lote.layers=0;p.visibility_changed.connect(func():_sujo=true)
 for d in data.values():
  var n:=MultiMeshInstance3D.new();var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.mesh=d.mesh;mm.instance_count=d.entries.size();n.multimesh=mm;n.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;add_child(n)
  var box: AABB;var primeiro: bool=true
  for e in d.entries:
   var a: AABB=e.lote.global_transform*mm.mesh.get_aabb();box=a if primeiro else box.merge(a);primeiro=false
  mm.custom_aabb=box.grow(2);groups.append({"multi":n,"entries":d.entries,"height":mm.mesh.get_aabb().size.y})
 process_physics_priority=18;_physics_process(0)
func _physics_process(dt: float) -> void:
 _tempo+=dt
 if _sujo or _tempo>.15:
  _sujo=false;_tempo=0;desenhadas=0
  var h: float=get_viewport().get_texture().get_height()*get_viewport().scaling_3d_scale
  var focal: float=h/(2*tan(deg_to_rad(camera.fov*.5)))
  for g in groups:
   for e in g.entries:
    e.dist=e.node.global_position.distance_to(camera.global_position) if e.node.is_visible_in_tree() else INF
   g.entries.sort_custom(func(a,b):return a.dist<b.dist)
   var count: int=0
   for e in g.entries:
    if is_inf(e.dist):break
    if float(g.height)*focal/maxf(.01,e.dist)<1.0:break
    count+=1
   g.multi.multimesh.visible_instance_count=count;desenhadas+=count
 for g in groups:
  var count: int=g.multi.multimesh.visible_instance_count
  for i in count:
   var e: Dictionary=g.entries[i]
   g.multi.multimesh.set_instance_transform(i,e.lote.global_transform if e.node.is_visible_in_tree() else Transform3D(Basis.IDENTITY.scaled(Vector3.ZERO),Vector3.ZERO))
