extends "res://Sistemas/Coleta/objeto_interativo.gd"
signal quebrada(recompensa: int, origem: Node3D)
@export var recompensa: int = 5
@export var som_local: bool = true
@export var impulso_pisao: float = 8.0

func _ready() -> void:
	process_physics_priority = 16
	add_to_group("bh_caixas")

func _physics_process(_dt: float) -> void:
	if not visible or not pode_interagir():
		return
	var delta: Vector3 = _jogador.global_position - global_position
	var yy: float = delta.y
	# The native box top is at 1.26; feet must still register the original stomp.
	if yy >= 1.4 or yy <= -0.6:
		return
	var perto: bool = absf(delta.x) < 0.95 and absf(delta.z) < 0.95
	var combo: RefCounted = _jogador.get("_combate") as RefCounted
	if perto and yy > 0.7 and _jogador.velocity.y <= 0.0:
		quebrar()
		_jogador.velocity.y = impulso_pisao
	elif combo != null and combo.pode_atingir(self, 1.8):
		combo.registrar_acerto(self)
		quebrar()
	elif perto:
		var movimento := Vector3.ZERO
		if 0.95 - absf(delta.x) < 0.95 - absf(delta.z):
			movimento.x = (1.0 if delta.x >= 0 else -1.0) * (0.95 - absf(delta.x))
		else:
			movimento.z = (1.0 if delta.z >= 0 else -1.0) * (0.95 - absf(delta.z))
		if not _jogador.test_move(_jogador.global_transform, movimento):
			_jogador.global_position += movimento

func quebrar() -> void:
	if not visible:
		return
	visible = false
	$Colisao.collision_layer = 0
	if som_local:
		$Som.play()
	quebrada.emit(recompensa, self)

func reiniciar() -> void:
	visible = true
	$Colisao.collision_layer = 4

func destruir_por_explosao() -> void:
	quebrar()
