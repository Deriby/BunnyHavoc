extends "caixa.gd"
## Mola reutilizável: impulso 16,5 no pisão, sem quebrar nem dar cenouras.
var intervalo: float = 0.0
func _physics_process(dt: float) -> void:
	intervalo = maxf(0.0, intervalo - dt)
	$Visual.scale.y = lerpf($Visual.scale.y, 0.76 if intervalo > 0.0 else 1.0, minf(1.0, dt * 17.0))
	super._physics_process(dt)
func quebrar() -> void:
	if intervalo <= 0.0:
		intervalo = 0.25
		$Som.stream = preload("res://Sistemas/Coleta/audio/mola.wav")
		$Som.play()
func destruir_por_explosao() -> void:
	super.quebrar()
func reiniciar() -> void:
	intervalo = 0.0
	$Visual.scale = Vector3.ONE
	super.reiniciar()
