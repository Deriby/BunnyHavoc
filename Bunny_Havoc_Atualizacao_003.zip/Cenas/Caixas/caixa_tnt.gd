extends "caixa.gd"
## TNT original: pavio de 1,1 s e explosão em cadeia com raio 4,45.
const Explosao = preload("res://Cenas/Efeitos/explosao.tscn")
signal explodiu
var pavio: float = 0.0

func _physics_process(dt: float) -> void:
	if pavio > 0.0 and visible and pode_interagir():
		pavio = maxf(0.0, pavio - dt)
		$Visual.scale = Vector3.ONE * (1.035 if int(pavio * 10) % 2 == 0 else 1.0)
		if pavio == 0.0:
			detonar()
	super._physics_process(dt)

func quebrar() -> void:
	if visible and pavio <= 0.0:
		pavio = 1.1
		$Som.stream = preload("res://Sistemas/Coleta/audio/tnt_pavio.wav")
		$Som.play()

func detonar() -> void:
	if not visible:
		return
	var origem: Vector3 = global_position + Vector3.UP * 0.68
	visible = false
	pavio = 0.0
	$Colisao.collision_layer = 0
	quebrada.emit(0, self)
	explodiu.emit()
	var efeito := Explosao.instantiate() as Node3D
	get_tree().current_scene.add_child(efeito)
	efeito.global_position = origem
	for caixa in get_tree().get_nodes_in_group("bh_caixas"):
		if not caixa.visible or caixa.global_position.distance_to(global_position) > 4.45:
			continue
		if caixa.has_method("detonar"):
			caixa.detonar()
		else:
			var anterior: int = caixa.recompensa
			caixa.recompensa = 0
			caixa.destruir_por_explosao()
			caixa.recompensa = anterior
	for inimigo in get_tree().get_nodes_in_group("bunny_havoc_inimigos"):
		if inimigo.visible and inimigo.global_position.distance_to(origem) < 5.05:
			if inimigo.has_method("atingido_por_explosao"):
				inimigo.atingido_por_explosao()
			else:
				inimigo.receber_golpe(99, 0.0, false)
	if localizar_jogador() != null and (_jogador.global_position + Vector3.UP * 0.9).distance_to(origem) < 4.9:
		var vida: Node = _jogador.get_node_or_null("Saude")
		if vida != null:
			vida.receber_dano(3, self)

func reiniciar() -> void:
	pavio = 0.0
	$Visual.scale = Vector3.ONE
	super.reiniciar()
