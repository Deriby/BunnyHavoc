extends Node3D
## Trajetórias e batidas de asa da fonte; pássaros distantes não atualizam malhas.
const Modelo = preload("res://Biblioteca/Modelos/Passaro.glb")
var aves: Array[Dictionary] = []
var tempo: float = 0.0
var jogador: Node3D
func _ready() -> void:
	var dados: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/Completa/layout.json"))
	for d: Dictionary in dados.birds:
		var n: Node3D=Modelo.instantiate()
		add_child(n)
		aves.append({"n":n,"d":d,"a":n.find_child("Asa_0",true,false),"b":n.find_child("Asa_1",true,false)})
func _physics_process(dt: float) -> void:
	tempo+=dt
	if jogador==null:
		jogador=get_parent().get_node_or_null("Jogador")
	for item: Dictionary in aves:
		var d: Dictionary=item.d
		var n: Node3D=item.n
		n.visible=jogador==null or absf(float(d.z)-jogador.position.z)<100.0
		if not n.visible:
			continue
		n.position=Vector3(float(d.center)+sin(tempo*float(d.speed)+float(d.p))*7.0,float(d.base)+sin(tempo*1.6+float(d.p))*0.65,float(d.z)+sin(tempo*0.45+float(d.p))*4.0)
		n.rotation.y=PI/2.0 if cos(tempo*float(d.speed)+float(d.p))>0.0 else -PI/2.0
		item.a.rotation.z=-sin(tempo*14.0+float(d.p))*0.8
		item.b.rotation.z=-item.a.rotation.z
