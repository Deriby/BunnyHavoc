# Bunny Havoc — Fase 1 completa no Godot

O Bosque Verde agora vai do início até a cutscene original do resgate:
sete vãos grandes, sete checkpoints, sete plataformas, 19 inimigos originais
mais o urso aprovado, 14 NPCs, 13 caixas e três segredos. Os prefabs anteriores
continuam no lugar; `Fase1/Completa` acrescenta cenário, colisão e objetos.

Aplicar **atualização 003** sobre o projeto Lagarto ou atualizações 001/002,
na pasta de `project.godot`, com Godot
fechado. F5 joga. Controles e instalação em `LEIA-ME.txt`. Não é uma recriação:
as malhas e posições vêm dos construtores Three.js preservados. O Bunnyck,
os modelos aprovados e o céu nativo com energia 1.5 foram mantidos.

A cutscene tem as 18 etapas originais. Poses, câmera, escalas e visibilidade
foram amostradas do diretor original a 20 Hz e são interpoladas no Godot.
Não depende de navegador ou Three.js em execução. A voz sintetizada foi
extraída para `final.wav`; animação em `final.json.gz`, modelo em `Final.glb`.
Enter avança o diálogo; o final exibe resultados e salva o progresso local.

As caixas reforçada, mola e Nitro têm cenas e scripts próprios. A coleta
concede uma vida a cada 100 cenouras; segredos valem 25. O pisão usa a altura
do colisor nativo. A regra de queda da antiga arena foi desativada nesta fase,
que já usa a altura real do terreno. Os cidadãos escolhem o interlocutor mais
próximo e reutilizam diálogo, com rotinas e modelos individuais.

A Vila e a Fase 2 ainda não foram migradas. A entrada das tocas bônus permanece
desativada como na fonte atual. O HTML/TypeScript original continua preservado.

`export_presets.cfg` prepara Windows e Web, incluindo os JSON/GZIP. Instalar
os templates da mesma versão local do Godot antes de exportar. Foram testados
o editor/runtime Godot 4.4 e renderização Compatibility Linux; exports de
Windows/Web não foram executados nesta entrega.

Gerar: `node tools/export_godot_phase1.cjs`, depois
`python3 tools/build_godot_phase1.py`. Os geradores nunca reexportam os GLBs
já aprovados. As entregas são patches, não pastas completas.
