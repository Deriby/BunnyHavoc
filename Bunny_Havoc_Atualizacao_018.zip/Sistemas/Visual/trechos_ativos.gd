extends Node
## Fase inteira. Suspende callbacks, sem remover atores ou colisões.
const TAMANHO: float = 32.0
var habilitado: bool = true
var atores: Array[Dictionary] = []
var suspensos: int = 0
var fase: Node3D
var jogador: Node3D
var camera: Camera3D
var _tempo: float = 0.0
var _setor: int = 2147483647
var _piloto: bool = false

func configurar(raiz: Node3D) -> void:
	fase = raiz
	jogador = fase.get_node("Jogador")
	camera = fase.get_node("Camera3D")
	process_physics_priority = -100
	# Lista fechada: plataformas, caixas, coleta, arena e cinema seguem independentes.
	for ator: Node3D in get_tree().get_nodes_in_group("bunny_havoc_inimigos") + get_tree().get_nodes_in_group("bh_cidadaos"):
		if not fase.is_ancestor_of(ator):
			continue
		atores.append({"node": ator, "dorme": false, "physics": false, "process": false})
	atualizar(true)

func _physics_process(dt: float) -> void:
	_tempo += dt
	var setor: int = floori(jogador.global_position.z / TAMANHO)
	var piloto: bool = _usar_piloto()
	if _tempo >= 0.15 or setor != _setor or piloto != _piloto:
		atualizar()

func _usar_piloto() -> bool:
	var filme: Node = fase.get("final")
	return habilitado and (filme == null or not filme.ativo)

func _protegido(ator: Node3D) -> bool:
	# Nunca interrompe diálogo, ataque, reação, voo ou animação de morte.
	if ator.get("conversando") == true or ator.get("derrotado_agora") == true or ator.get("_voo") == true:
		return true
	var estado: Variant = ator.get("estado")
	return estado != null and estado not in ["patrol", "walk"]

func atualizar(_forcar: bool = false) -> void:
	_tempo = 0.0
	_setor = floori(jogador.global_position.z / TAMANHO)
	_piloto = _usar_piloto()
	suspensos = 0
	var setor_camera: int = floori(camera.global_position.z / TAMANHO)
	for item: Dictionary in atores:
		var ator: Node3D = item.node
		if not is_instance_valid(ator):
			continue
		var setor_ator: int = floori(ator.global_position.z / TAMANHO)
		# Dois setores de antecipação; o terceiro evita oscilar na fronteira.
		var margem: int = 2 if item.dorme else 3
		var dormir: bool = _piloto and absi(setor_ator - _setor) > margem and absi(setor_ator - setor_camera) > margem and not _protegido(ator)
		if dormir != item.dorme:
			if dormir:
				item.physics = ator.is_physics_processing()
				item.process = ator.is_processing()
				ator.set_physics_process(false)
				ator.set_process(false)
			else:
				ator.set_physics_process(item.physics)
				ator.set_process(item.process)
			item.dorme = dormir
		if item.dorme:
			suspensos += 1

func _exit_tree() -> void:
	for item: Dictionary in atores:
		if item.dorme and is_instance_valid(item.node):
			item.node.set_physics_process(item.physics)
			item.node.set_process(item.process)
