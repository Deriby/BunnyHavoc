extends SceneTree
## Compilação offline: mesmas faces, materiais e poses; sem reconstruir a fase.
const DESTINO: String = "res://Fase1/Estatico/Trechos"
func _initialize() -> void: gerar.call_deferred()
func gerar() -> void:
	DirAccess.make_dir_recursive_absolute(DESTINO)
	var fonte: Node3D = load("res://Fase1/Estatico/CenarioEstatico.tscn").instantiate()
	var faixas: Dictionary = {}
	var originais: int = 0
	for n in fonte.get_children():
		if not n is MeshInstance3D or not String(n.name).begins_with("Bloco_") or not String(n.name).ends_with("_0"): continue
		var coords: PackedStringArray = String(n.name).split("_")
		var faixa: int = floori(float(coords[2]) / 2.0)
		var lateral: int = floori(float(coords[1]) / 2.0)
		if not faixas.has(faixa): faixas[faixa] = {}
		if not faixas[faixa].has(lateral): faixas[faixa][lateral] = {}
		var grupo: Dictionary = faixas[faixa][lateral]
		for s in n.mesh.get_surface_count():
			var mat: Material = n.mesh.surface_get_material(s)
			var key: int = mat.get_instance_id()
			if not grupo.has(key):
				var st := SurfaceTool.new(); st.begin(Mesh.PRIMITIVE_TRIANGLES); st.set_material(mat); grupo[key] = st
			grupo[key].append_from(n.mesh, s, n.transform)
		originais += 1
	var mapa: Dictionary = {}
	var lotes: int = 0
	for faixa in faixas:
		var cena := Node3D.new(); cena.name = "Trecho_%d" % faixa
		for lateral in faixas[faixa]:
			var mesh := ArrayMesh.new()
			for tool in faixas[faixa][lateral].values(): tool.index(); tool.commit(mesh)
			var importer: Resource = ClassDB.instantiate("ImporterMesh")
			for s in mesh.get_surface_count(): importer.add_surface(Mesh.PRIMITIVE_TRIANGLES, mesh.surface_get_arrays(s), [], {}, mesh.surface_get_material(s))
			importer.generate_lods(25.0, 60.0, [])
			var path: String = DESTINO + "/terreno_%d_%d.res" % [faixa, lateral]
			assert(ResourceSaver.save(importer.get_mesh(), path, ResourceSaver.FLAG_COMPRESS) == OK)
			var n := MeshInstance3D.new(); n.name = "Terreno_%d" % lateral; n.mesh = load(path)
			cena.add_child(n); n.owner = cena; lotes += 1
		var packed := PackedScene.new(); assert(packed.pack(cena) == OK)
		var path: String = DESTINO + "/trecho_%d.tscn" % faixa
		assert(ResourceSaver.save(packed, path) == OK)
		mapa[str(faixa)] = {"path": path, "z": (faixa + 0.5) * 64.0}
		cena.free()
	var leve := Node3D.new(); leve.name = "CenarioEstatico"
	leve.set_meta("streaming_trechos", true)
	leve.set_meta("trechos", mapa)
	leve.set_meta("montes_folhas", fonte.get_meta("montes_folhas", []))
	for n in fonte.get_children():
		if not String(n.name).begins_with("Longe_") or not String(n.name).ends_with("_0"): continue
		var copia: Node = n.duplicate(); leve.add_child(copia); copia.owner = leve; copia.layers = 1
	var packed := PackedScene.new(); assert(packed.pack(leve) == OK)
	assert(ResourceSaver.save(packed, "res://Fase1/Estatico/CenarioTrechos.tscn") == OK)
	print(JSON.stringify({"originalMeshes": originais, "groupedMeshes": lotes, "sections": mapa.size(), "originalFacesAndMaterialsRetained": true}))
	leve.free(); fonte.free(); quit()
