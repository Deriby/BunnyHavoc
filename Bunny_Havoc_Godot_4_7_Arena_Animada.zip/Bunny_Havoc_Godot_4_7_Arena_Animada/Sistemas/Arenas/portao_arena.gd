extends StaticBody3D
## Duas folhas de madeira com dobradiças, trava e peso; física só muda em estados seguros.
signal bateu(fechando: bool)
signal comecou(fechando: bool)
var fechado: bool=false
var movendo: bool=false
var abertura: float=1.0
var tempo: float=0
var _de: float=1
var _para: float=1
var _folhas: Array[Node3D]=[]
var _trava: Node3D
var _fora: float=1
var _impacto_emitido: bool=false
var _visual: Node3D
const DURACAO_FECHAR: float=1.10
const DURACAO_ABRIR: float=1.35
func configurar(z: float) -> void:
	position.z=z;_fora=signf(z);collision_layer=0;collision_mask=0
	var col:=CollisionShape3D.new();col.name="CollisionShape3D"
	var shape:=BoxShape3D.new();shape.size=Vector3(16,4,.75);col.shape=shape;col.position.y=1.9;add_child(col)
	_visual=Node3D.new();_visual.name="Visual";add_child(_visual)
	var fixo:=SurfaceTool.new();fixo.begin(Mesh.PRIMITIVE_TRIANGLES)
	for x in [-7.7,7.7]:
		_caixa(fixo,Vector3(x,2,0),Vector3(.44,4.1,.65),Color("55412f"))
		_caixa(fixo,Vector3(x,.16,0),Vector3(.76,.32,.85),Color("676157"))
		for y in [1.0,2.9]:_caixa(fixo,Vector3(x,y,.36),Vector3(.52,.24,.10),Color("726675"))
	_mesh(fixo,_visual)
	for lado in [-1,1]:
		var p:=Node3D.new();p.name="FolhaE" if lado<0 else "FolhaD";p.position.x=lado*7.5;_visual.add_child(p);_folhas.append(p)
		var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
		for i in 8:
			var x: float=-lado*(.45+i*.94)
			var h: float=3.72+sin((i+lado)*3.7)*.12
			var cor:=Color("795536") if i%3==0 else Color("6c4b30") if i%3==1 else Color("825e3d")
			_caixa(st,Vector3(x,h*.5,0),Vector3(.87,h,.42),cor,sin(i*8+lado)*.018)
			_caixa(st,Vector3(x,.85,.22),Vector3(.58,.055,.014),cor.darkened(.2))
			_caixa(st,Vector3(x,2.15,.22),Vector3(.035,.65,.014),cor.darkened(.22))
		for y in [.92,2.82]:
			_caixa(st,Vector3(-lado*3.75,y,.26),Vector3(7.48,.24,.18),Color("49372c"))
			for x in [.5,3.7,6.9]:_caixa(st,Vector3(-lado*x,y,.37),Vector3(.10,.10,.035),Color("b6a289"))
		_caixa(st,Vector3(-lado*3.75,1.9,-.24),Vector3(.19,3.6,.16),Color("584030"),lado*.88)
		_mesh(st,p)
	_trava=Node3D.new();_trava.name="Trava";_trava.position=Vector3(-.65,1.92,.4);_visual.add_child(_trava)
	var trava:=SurfaceTool.new();trava.begin(Mesh.PRIMITIVE_TRIANGLES)
	_caixa(trava,Vector3(.65,0,0),Vector3(1.5,.22,.20),Color("a58a5f"));_mesh(trava,_trava)
	ajustar(false,false)
func _caixa(st: SurfaceTool,pos: Vector3,tamanho: Vector3,cor: Color,angulo: float=0) -> void:
	var box:=BoxMesh.new();box.size=tamanho
	var data: Array=box.surface_get_arrays(0);var b:=Basis(Vector3.FORWARD,angulo)
	for index: int in data[Mesh.ARRAY_INDEX]:
		st.set_color(cor);st.set_normal(b*data[Mesh.ARRAY_NORMAL][index]);st.add_vertex(b*data[Mesh.ARRAY_VERTEX][index]+pos)
func _mesh(st: SurfaceTool,pai: Node3D) -> void:
	var mat:=StandardMaterial3D.new();mat.vertex_color_use_as_albedo=true
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_PER_VERTEX;mat.specular_mode=BaseMaterial3D.SPECULAR_DISABLED
	st.set_material(mat);st.index();var n:=MeshInstance3D.new();n.mesh=st.commit();n.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;pai.add_child(n)
func ajustar(valor: bool,animar: bool=true) -> void:
	fechado=valor;tempo=0;_de=abertura;_para=0 if valor else 1;_impacto_emitido=false
	movendo=animar and not is_equal_approx(_de,_para)
	if valor:collision_layer=1
	if not movendo:
		abertura=_para;collision_layer=1 if valor else 0;_aplicar(0)
	else:comecou.emit(valor)
	set_physics_process(movendo)
func _physics_process(dt: float) -> void:
	tempo+=dt
	var duracao: float=DURACAO_FECHAR if fechado else DURACAO_ABRIR
	var t: float=clampf(tempo/duracao,0,1)
	var k: float=pow(clampf((t-.08)/.72,0,1),1.8) if fechado else smoothstep(.14,.96,t)
	abertura=lerpf(_de,_para,k)
	var tremer: float=0
	if fechado and t>=.80:
		tremer=sin((t-.8)/.2*TAU*1.5)*.035*(1-smoothstep(.8,1,t))
		if not _impacto_emitido:_impacto_emitido=true;bateu.emit(true)
	_aplicar(tremer)
	if not fechado and t>.90:collision_layer=0
	if t>=1:
		abertura=_para;movendo=false;collision_layer=1 if fechado else 0;_aplicar(0);set_physics_process(false)
		if not fechado:bateu.emit(false)
func _aplicar(tremer: float) -> void:
	for i in _folhas.size():
		var lado: float=-1 if i==0 else 1
		_folhas[i].rotation.y=lado*_fora*(abertura*PI*.52+tremer)
	_trava.visible=abertura<.28
	_trava.rotation.z=-smoothstep(0,.20,abertura)*.72
