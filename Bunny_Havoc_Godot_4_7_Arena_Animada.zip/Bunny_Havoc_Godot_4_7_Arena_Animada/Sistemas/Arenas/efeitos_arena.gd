extends Node3D
## Pool fixo: poeira/folhas em uma chamada de desenho e quatro vozes de áudio reutilizadas.
const CAPACIDADE: int=48
var partes: Array[Dictionary]=[]
var sons: Array[AudioStreamPlayer3D]=[]
var cursor: int=0
var voz: int=0
var visual: MultiMeshInstance3D
func _ready() -> void:
	top_level=true;global_transform=Transform3D.IDENTITY
	visual=MultiMeshInstance3D.new();add_child(visual)
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for y in [-1,1]:
		for i in 4:
			var a:=Vector3(cos(i*PI/2),0,sin(i*PI/2));var b:=Vector3(cos((i+1)*PI/2),0,sin((i+1)*PI/2))
			for p in [Vector3(0,y,0),a if y<0 else b,b if y<0 else a]:st.set_color(Color.WHITE);st.set_normal(Vector3.UP);st.add_vertex(p)
	var mat:=StandardMaterial3D.new();mat.vertex_color_use_as_albedo=true;mat.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED;mat.cull_mode=BaseMaterial3D.CULL_DISABLED;st.set_material(mat)
	var mm:=MultiMesh.new();mm.transform_format=MultiMesh.TRANSFORM_3D;mm.use_colors=true;mm.mesh=st.commit();mm.instance_count=CAPACIDADE;visual.multimesh=mm
	visual.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;visual.visible=false
	for i in CAPACIDADE:
		partes.append({"vida":0.0,"pos":Vector3.ZERO,"vel":Vector3.ZERO,"max":.5,"escala":.1,"folha":false,"chao":0.0})
		mm.set_instance_transform(i,Transform3D(Basis.IDENTITY.scaled(Vector3.ZERO),Vector3.ZERO))
	for i in 4:
		var p:=AudioStreamPlayer3D.new();p.unit_size=14;p.max_distance=45;p.volume_db=-15;add_child(p);sons.append(p)
	set_physics_process(false)
func poeira(pos: Vector3,forte: bool=false) -> void:
	for i in (12 if forte else 7):
		var p: Dictionary=partes[cursor];cursor=(cursor+1)%CAPACIDADE
		var a: float=i*2.399963
		p.vida=.42+(i%3)*.055;p.max=p.vida;p.pos=pos+Vector3(cos(a)*.12,.07,sin(a)*.12)
		p.vel=Vector3(cos(a)*(.9 if forte else .55),.7+(i%3)*.21,sin(a)*(.9 if forte else .55))
		p.escala=.13+(i%3)*.035;p.folha=i%5==0;p.chao=pos.y+.035
	visual.visible=true;set_physics_process(true)
func som(tipo: String,pos: Vector3) -> void:
	var p: AudioStreamPlayer3D=sons[voz];voz=(voz+1)%sons.size();p.global_position=pos
	p.stream=preload("res://Sistemas/Coleta/audio/metal.wav") if tipo=="sino" else preload("res://Sistemas/Coleta/audio/caixa.wav") if tipo=="madeira" else preload("res://PassosBunnyck/audio/passo_02.wav")
	p.pitch_scale=.82 if tipo=="madeira" else 1.08 if tipo=="sino" else .91+(voz%3)*.06
	p.volume_db=-18 if tipo=="sino" else -17 if tipo=="madeira" else -12;p.play()
func _physics_process(dt: float) -> void:
	var ativos: int=0
	for i in partes.size():
		var p: Dictionary=partes[i]
		if p.vida<=0:continue
		p.vida=maxf(0,p.vida-dt);p.pos+=p.vel*dt;p.vel.y-=dt*3.0
		p.pos.y=maxf(p.chao,p.pos.y)
		var u: float=1-float(p.vida)/float(p.max)
		var escala: Vector3=Vector3(.8,.20,1.25) if p.folha else Vector3.ONE
		escala*=float(p.escala)*(1+u*.8)*smoothstep(0,.12,float(p.vida))
		var b:=Basis.from_euler(Vector3(u*3,i*.9+u*4,u*2)).scaled(escala)
		visual.multimesh.set_instance_transform(i,Transform3D(b,p.pos))
		var cor:=Color("87964b") if p.folha else Color("b39970");cor.a=(1-u)*.65
		visual.multimesh.set_instance_color(i,cor)
		if p.vida>0:ativos+=1
	if ativos==0:visual.visible=false;set_physics_process(false)
func limpar() -> void:
	for i in partes.size():
		partes[i].vida=0
		visual.multimesh.set_instance_transform(i,Transform3D(Basis.IDENTITY.scaled(Vector3.ZERO),Vector3.ZERO))
	for p in sons:p.stop()
	visual.visible=false;set_physics_process(false)
func _exit_tree() -> void:
	for p in sons:
		p.stop();p.stream=null
