extends RefCounted
## Trajetória e pose da chegada; nenhum atacante fica ativo antes de pousar e se firmar.
const PREPARO: float=.22
const VOO: float=.54
const POUSO: float=.34
const DURACAO: float=PREPARO+VOO+POUSO
static func criar(n: CharacterBody3D,destino: Vector3,ponto: Vector3,indice: int,vigia: bool) -> Dictionary:
	var inicio: Vector3=destino if vigia else destino+Vector3(signf(ponto.x)*3,0,0)
	n.ativo=false;n.entrando=true;n.visible=false;n.collision_layer=0
	return {"node":n,"fim":destino,"inicio":inicio,"tempo":-indice*.18,"vigia":vigia,"saltou":false,"pousou":false,"altura":1.45+indice*.07}
static func atualizar(item: Dictionary,dt: float) -> Array[String]:
	var eventos: Array[String]=[];item.tempo+=dt
	var n: CharacterBody3D=item.node
	if item.tempo<0:return eventos
	n.visible=true
	var t: float=item.tempo
	if item.vigia:
		n.global_position=item.fim;n.animacao.chegada("ordem",clampf(t/.6,0,1),n.global_position)
		if t>=.6:eventos.append("pronto")
	elif t<PREPARO:
		n.global_position=item.inicio;n.animacao.chegada("preparo",t/PREPARO,n.global_position)
	elif t<PREPARO+VOO:
		var u: float=(t-PREPARO)/VOO
		n.global_position=item.inicio.lerp(item.fim,smoothstep(0,1,u))+Vector3.UP*(4*u*(1-u)*float(item.altura))
		n.animacao.chegada("salto",u,n.global_position)
		if not item.saltou:item.saltou=true;eventos.append("salto")
	else:
		n.global_position=item.fim
		var u: float=clampf((t-PREPARO-VOO)/POUSO,0,1)
		n.animacao.chegada("pouso",u,n.global_position)
		if not item.pousou:item.pousou=true;eventos.append("pouso")
		if u>=1:eventos.append("pronto")
	return eventos
