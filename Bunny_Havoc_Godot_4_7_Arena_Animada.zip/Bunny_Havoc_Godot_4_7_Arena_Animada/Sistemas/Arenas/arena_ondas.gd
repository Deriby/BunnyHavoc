extends Node3D
## Encontro reutilizável: motivo, introdução, ondas, contagem e passagem física.
const Chegada=preload("entrada_patrulha.gd")
const Portao=preload("portao_arena.gd")
const Efeitos=preload("efeitos_arena.gd")
signal concluida
@export var inimigo: PackedScene
@export var ondas: Array[int]=[3,3,4]
@export var raio: float=11.0
@export_multiline var motivo: String="Patrulha de Bibibunn: ninguém segue o coelho preto! Fechem a passagem!"
@export var pontos_entrada: Array[Vector3]=[Vector3(-8,0,-4),Vector3(8,0,-4),Vector3(-8,0,4),Vector3(8,0,4)]
var fase: Node3D
var jogador: CharacterBody3D
var saude: Node
var camera: Camera3D
var estado: String="espera"
var eliminados: int=0
var onda: int=0
var vivos: Array[CharacterBody3D]=[]
var entradas: Array[Dictionary]=[]
var corpos: Array[Dictionary]=[]
var premios: Dictionary={}
var viu_cena: bool=false
var tempo: float=0
var _pausa: float=0
var _emitida: bool=false
var _angulo_camera: Transform3D
var _fov: float
var _hud: CanvasLayer
var _texto: Label
var _legenda: Label
var _carta: ColorRect
var _barreira_entrada: StaticBody3D
var _barreira_saida: StaticBody3D
var _visual_entrada: Node3D
var _visual_saida: Node3D
var _som: AudioStreamPlayer
var _vigia: CharacterBody3D
var _efeitos: Node3D
var _sino: Node3D
var _toques: int=0
var _fechando_entrada: bool=false
var _tremor: float=0
var _toque_tempo: float=-10
var _total: int:
	get:
		var n: int=0
		for valor in ondas:n+=valor
		return n
var controla_camera: bool:
	get:return estado in ["cena","combate","abrindo"]

func _ready() -> void:
	process_physics_priority=25
	if OS.get_environment("BH_BUILD_STATIC_WORLD")=="1":set_physics_process(false);return
	_configurar.call_deferred()
func _configurar() -> void:
	fase=get_parent();jogador=fase.get_node("Jogador");saude=jogador.get_node("Saude");camera=fase.get_node("Camera3D")
	_barreira_entrada=_barreira(9.3);_barreira_saida=_barreira(-9.3)
	_visual_entrada=_barreira_entrada.get_node("Visual");_visual_saida=_barreira_saida.get_node("Visual")
	_som=AudioStreamPlayer.new();_som.volume_db=-9;add_child(_som)
	_efeitos=Efeitos.new();_efeitos.name="EfeitosLeves";add_child(_efeitos)
	_criar_hud()
	preload("res://Fase1/Arena/posto_patrulha.gd").montar(self)
	_sino=get_node("PostoDaPatrulha/Sino")
	saude.renasceu.connect(_retorno)
	reiniciar()
func _barreira(z: float) -> StaticBody3D:
	var body:=Portao.new();add_child(body);body.configurar(z)
	body.bateu.connect(_portao_bateu.bind(body))
	body.comecou.connect(_portao_comecou.bind(body))
	return body
func _portao_comecou(_fechando: bool,body: StaticBody3D) -> void:
	_efeitos.som("madeira",body.global_position+Vector3.UP)
func _portao_bateu(fechando: bool,body: StaticBody3D) -> void:
	_efeitos.som("madeira",body.global_position+Vector3.UP)
	for x in [-5.5,0,5.5]:_efeitos.poeira(body.global_position+Vector3(x,0,.2),fechando)
	_tremor=.14 if fechando else .06
func _label(size: int) -> Label:
	var l:=Label.new();l.add_theme_font_size_override("font_size",size)
	l.add_theme_constant_override("outline_size",4);l.add_theme_color_override("font_outline_color",Color("261a30"))
	l.mouse_filter=Control.MOUSE_FILTER_IGNORE;l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	_hud.add_child(l);return l
func _criar_hud() -> void:
	_hud=CanvasLayer.new();_hud.layer=36;add_child(_hud)
	_texto=_label(23);_texto.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE);_texto.offset_top=22;_texto.offset_bottom=95
	_carta=ColorRect.new();_carta.color=Color(0.05,.025,.07,.86);_carta.mouse_filter=Control.MOUSE_FILTER_IGNORE
	_hud.add_child(_carta);_carta.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE);_carta.offset_top=-116
	_legenda=_label(21);_legenda.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	_legenda.offset_top=-105;_legenda.offset_bottom=-12;_legenda.offset_left=42;_legenda.offset_right=-42
	_legenda.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
func _portao(body: StaticBody3D,fechado: bool) -> void:
	body.ajustar(fechado,false)
func iniciar() -> void:
	if estado!="espera" or saude.morto or saude.encerrado or not jogador.is_on_floor():return
	for npc in get_tree().get_nodes_in_group("bh_cidadaos"):
		if npc.conversando:return
	estado="cena";tempo=0;_toques=0;_fechando_entrada=false;_angulo_camera=camera.global_transform;_fov=camera.fov
	jogador._combate.limpar();jogador.velocity=Vector3.ZERO
	jogador.set_physics_process(false);jogador.set_process_unhandled_key_input(false)
	_barreira_entrada.collision_layer=1;_barreira_saida.collision_layer=1
	_hud.visible=true;_carta.visible=true;_legenda.visible=true
	_texto.text="EMBOSCADA NO BOSQUE"
	fase._mensagem.text="Derrote a patrulha para abrir a passagem."
	_legenda.text="Um sentinela avista Bunnyck e bate o alarme da patrulha.\nEnter: pular cena"
	if viu_cena:_entrar_combate()
func _tocar(stream: AudioStream) -> void:
	_som.stream=stream;_som.play()
func _entrar_combate() -> void:
	if estado!="cena":return
	viu_cena=true;estado="combate";tempo=0
	_portao(_barreira_entrada,true);_portao(_barreira_saida,true)
	_sino.rotation=Vector3.ZERO
	_carta.visible=false;_legenda.visible=false
	jogador.set_physics_process(true);jogador.set_process_unhandled_key_input(true)
	_proxima_onda()
func _criar_vigia() -> void:
	_vigia=inimigo.instantiate();_vigia.position=Vector3(5.7,0,-6.4)
	_vigia.jogador=jogador;_vigia.terreno=fase.trilho;_vigia.arena=self;_vigia.ativo=false
	add_child(_vigia);_vigia.collision_layer=0;_vigia.rotation.y=PI*.25
func _proxima_onda() -> void:
	if onda>=ondas.size():return
	var quantidade: int=ondas[onda];onda+=1
	for i in quantidade:
		var n: CharacterBody3D=_vigia if onda==1 and i==0 and is_instance_valid(_vigia) else inimigo.instantiate()
		var ponto: Vector3=pontos_entrada[(i+onda-1)%pontos_entrada.size()]
		var destino: Vector3=global_position+ponto
		destino.y=fase.trilho.altura(destino.z)+.04
		var veio_vigia: bool=n==_vigia
		if veio_vigia:
			destino=n.global_position;_vigia=null
		else:
			n.position=to_local(destino);n.jogador=jogador;n.terreno=fase.trilho;n.arena=self;n.ativo=false
			add_child(n)
		n.rotation.y=atan2(jogador.position.x-destino.x,jogador.position.z-destino.z)
		n.collision_layer=0;n.caiu.connect(_derrotado)
		var slot: String=str(onda)+":"+str(i)
		n.recompensa_ganha.connect(func(valor: int):
			if not premios.has(slot):premios[slot]=true;fase.itens.adicionar_cenouras(valor)
		)
		vivos.append(n)
		entradas.append(Chegada.criar(n,destino,ponto,i,veio_vigia))
	_atualizar_hud()
func _derrotado(n: CharacterBody3D) -> void:
	if not vivos.has(n) or estado!="combate":return
	vivos.erase(n);eliminados+=1;corpos.append({"node":n,"tempo":0.0});_pausa=.95
	_atualizar_hud()
func _atualizar_hud() -> void:
	_texto.text="PATRULHA DO BOSQUE  •  %d/%d\nOnda %d/%d" % [eliminados,_total,onda,ondas.size()]
func pedir_ataque(n: CharacterBody3D) -> bool:
	# Dois atacantes por vez; os demais cercam e aguardam a própria preparação.
	var ataques: int=0
	for outro in vivos:
		if outro!=n and outro.estado in ["windup","lunge"]:ataques+=1
	return ataques<2
func _physics_process(dt: float) -> void:
	if jogador==null:return
	if estado=="espera":
		if absf(jogador.global_position.x-global_position.x)<raio-1 and jogador.global_position.z<global_position.z+5 and jogador.global_position.z>global_position.z-6:iniciar()
		return
	if saude.morto or saude.encerrado:
		if estado=="abrindo":_concluir()
		elif controla_camera:_cancelar_tentativa()
		return
	tempo+=dt;_tremor=maxf(0,_tremor-dt)
	if estado=="cena":
		if is_instance_valid(_vigia):
			var alvo: Vector3=_sino.global_position if tempo>.4 and tempo<1.4 else jogador.global_position
			_vigia.rotation.y=lerp_angle(_vigia.rotation.y,atan2(alvo.x-_vigia.global_position.x,alvo.z-_vigia.global_position.z),1-exp(-8*dt))
			_vigia.animacao.vigia(tempo,_vigia.global_position)
		while _toques<2 and tempo>=(.68 if _toques==0 else 1.13):
			_toques+=1;_toque_tempo=tempo;_efeitos.som("sino",_sino.global_position)
		var decorrido: float=tempo-_toque_tempo
		_sino.rotation.z=sin(decorrido*26)*.32*exp(-decorrido*3.8) if decorrido<1.4 else 0
		if tempo>=1.75 and not _fechando_entrada:
			_fechando_entrada=true;_barreira_entrada.ajustar(true,true)
		if tempo>1.5:_legenda.text=motivo+"\nEnter: pular cena"
		if tempo>3.8:_legenda.text="Bunnyck: Dez contra um? Eu estava mesmo precisando aquecer!\nEnter: pular cena"
		if tempo>=5.8:_entrar_combate()
	elif estado=="combate":
		for item in entradas.duplicate():
			var n: CharacterBody3D=item.node
			if not is_instance_valid(n) or n.derrotado_agora:entradas.erase(item);continue
			for evento in Chegada.atualizar(item,dt):
				match evento:
					"salto":_efeitos.poeira(item.inicio);_efeitos.som("passo",item.inicio)
					"pouso":_efeitos.poeira(item.fim);_efeitos.som("passo",item.fim)
					"pronto":
						n.entrando=false;n.ativo=true;n.collision_layer=2;n.animacao.reiniciar(n.global_position);entradas.erase(item)
		for item in corpos.duplicate():
			item.tempo+=dt
			if item.tempo>1.0:item.node.queue_free();corpos.erase(item)
		_pausa=maxf(0,_pausa-dt)
		if vivos.is_empty() and entradas.is_empty() and _pausa<=0:
			if eliminados>=_total:_vencer()
			else:_proxima_onda()
	elif estado=="abrindo":
		if tempo>=1.60:
			_concluir()
	if controla_camera:_camera_arena(dt)
func _camera_arena(dt: float) -> void:
	var olho: Vector3=global_position+Vector3(jogador.position.x*.10,17,21)
	var alvo: Vector3=global_position+Vector3(jogador.position.x*.08,1,0)
	if estado=="cena" and tempo<1.65:
		olho=global_position+Vector3(12,7,5);alvo=global_position+Vector3(4,1.8,-5)
	if estado=="cena" and tempo>=1.65 and tempo<3.10:
		olho=global_position+Vector3(9,8,13);alvo=global_position+Vector3(0,1.8,9.3)
	var orientada:=Transform3D(Basis.IDENTITY,olho).looking_at(alvo)
	var k: float=1-exp(-4*dt)
	camera.global_position=camera.global_position.lerp(olho,k)
	camera.quaternion=camera.quaternion.slerp(orientada.basis.get_rotation_quaternion(),k)
	camera.fov=lerpf(camera.fov,60,1-exp(-3*dt))
	if _tremor>0:camera.position+=Vector3(sin(tempo*71)*.12,cos(tempo*83)*.08,0)*(_tremor/.14)
func _vencer() -> void:
	estado="abrindo";tempo=0
	_barreira_saida.ajustar(false,true);_barreira_entrada.ajustar(false,true)
	fase._mensagem.text="Patrulha derrotada! Continue atrás de Bunnyldu."
	_texto.text="PATRULHA DERROTADA!  %d/%d\nCaminho liberado" % [eliminados,_total]
	_tocar(preload("res://Sistemas/Coleta/audio/segredo.wav"))
	_carta.visible=true;_legenda.visible=true;_legenda.text="A patrulha recua. Bunnyck pode continuar atrás de Bunnyldu."
func _concluir() -> void:
	_portao(_barreira_saida,false);_portao(_barreira_entrada,false)
	estado="concluida";_hud.visible=false;fase.trilho.pronto=false
	if not _emitida:_emitida=true;concluida.emit()
func _limpar() -> void:
	for n in vivos:n.queue_free()
	for item in corpos:item.node.queue_free()
	vivos.clear();entradas.clear();corpos.clear()
	_efeitos.limpar();_tremor=0
	_som.stop()
	if _sino!=null:_sino.rotation=Vector3.ZERO
func _cancelar_tentativa() -> void:
	_limpar();estado="espera";eliminados=0;onda=0;tempo=0;_pausa=0
	if not is_instance_valid(_vigia):_criar_vigia()
	else:_vigia.animacao.reiniciar(_vigia.global_position);_vigia.entrando=false;_vigia.visible=true
	_hud.visible=false;_portao(_barreira_entrada,false);_portao(_barreira_saida,true)
	fase.trilho.pronto=false
func _retorno() -> void:
	if estado!="concluida":_cancelar_tentativa()
func reiniciar() -> void:
	if jogador==null:return
	var era_cena: bool=estado=="cena"
	_cancelar_tentativa();premios.clear();viu_cena=false;_emitida=false
	if era_cena and not saude.morto and not saude.encerrado:
		jogador.set_physics_process(true);jogador.set_process_unhandled_key_input(true)
func _input(event: InputEvent) -> void:
	if estado=="cena" and event is InputEventKey and event.pressed and not event.echo and event.keycode in [KEY_ENTER,KEY_KP_ENTER]:
		_entrar_combate();get_viewport().set_input_as_handled()
