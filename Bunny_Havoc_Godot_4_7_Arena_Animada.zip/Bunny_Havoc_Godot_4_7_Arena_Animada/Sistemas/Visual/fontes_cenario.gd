@tool
extends Node3D
## As cenas de autoria aparecem no editor; o jogo carrega apenas o cenário pronto.
@export var mostrar_fontes: bool=false
var _tempo: float=0
var _faixas: Array=[]
const FONTES: Array[String]=["res://Fase1/Cenario.tscn","res://Fase1/Trecho2/Cenario.tscn","res://Fase1/Trecho4/Cenario.tscn","res://Fase1/Completa/Cenario.tscn"]
func _ready() -> void:
	var autoria: bool=Engine.is_editor_hint() or OS.get_environment("BH_BUILD_STATIC_WORLD")=="1"
	visible=autoria if mostrar_fontes else not autoria
	set_process(not mostrar_fontes and not autoria)
	if not mostrar_fontes and not autoria:
		for grupo: Dictionary in get_meta("faixas_hlod",[]):
			var nodes: Array=[]
			for nome: String in grupo.near:nodes.append(get_node(nome))
			_faixas.append({"near":nodes,"far":get_node(grupo.far),"z":grupo.z,"distante":false})
		atualizar_hlod.call_deferred()
	if not mostrar_fontes or not autoria or get_child_count()>0:return
	for i in FONTES.size():
		var cena: PackedScene=load(FONTES[i])
		var n: Node3D=cena.instantiate()
		n.name=["Cenario","Continuacao","DepoisTravessia","BosqueProfundo"][i]
		add_child(n)

func _process(dt: float) -> void:
	_tempo+=dt
	if _tempo>=0.12:atualizar_hlod()
func atualizar_hlod() -> void:
	_tempo=0
	var fase: Node=get_parent()
	var p: Node3D=fase.get_node_or_null("Jogador")
	if p==null:return
	var centro: float=p.global_position.z
	var filme: Node=fase.get("final")
	if filme!=null and filme.ativo:centro=fase.get_node("Camera3D").global_position.z
	for grupo in _faixas:
		var longe: bool=absf(centro-float(grupo.z))>(80.0 if grupo.distante else 96.0)
		for n in grupo.near:n.layers=0 if longe else 1
		grupo.far.layers=1 if longe else 0
		grupo.distante=longe
