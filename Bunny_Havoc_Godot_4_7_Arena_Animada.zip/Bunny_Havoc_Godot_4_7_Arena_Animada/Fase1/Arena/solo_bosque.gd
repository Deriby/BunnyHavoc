@tool
extends RefCounted
## Superfícies de terra comuns ao bake, ao editor e à colisão da clareira.
const CENTRO := Vector2(0, -119)
const RAIO: float = 11.0
const BORDA: float = 12.0
const ALTURAS: Array = [[30,0],[-40,0],[-80,5],[-125,5],[-155,2],[-195,2],[-235,8],[-275,8],[-315,4],[-355,4],[-390,9],[-440,9]]
static var _material: StandardMaterial3D
static func altura(z: float) -> float:
	for i in ALTURAS.size()-1:
		if z<=ALTURAS[i][0] and z>=ALTURAS[i+1][0]:
			return lerpf(ALTURAS[i][1],ALTURAS[i+1][1],smoothstep(0,1,(ALTURAS[i][0]-z)/float(ALTURAS[i][0]-ALTURAS[i+1][0])))
	return 0.0 if z>30 else 9.0
static func distancia(p: Vector3) -> float:
	return Vector2(p.x,p.z).distance_to(CENTRO)
static func largura(z: float) -> float:
	for area in [[-56,-84],[-144,-172],[-232,-260],[-330,-380]]:
		if z<area[0] and z>area[1]:return 4+3*pow(sin(PI*(area[0]-z)/float(area[0]-area[1])),.6)
	return 4.0
static func material() -> StandardMaterial3D:
	if _material==null:
		_material=StandardMaterial3D.new()
		_material.vertex_color_use_as_albedo=true
		_material.albedo_texture=preload("res://Recursos/Texturas/terra_bosque.png")
		_material.texture_filter=BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
		_material.shading_mode=BaseMaterial3D.SHADING_MODE_PER_VERTEX
		_material.specular_mode=BaseMaterial3D.SPECULAR_DISABLED
		_material.roughness=1.0
	return _material
static func cor(p: Vector3, circular: bool=false) -> Color:
	var caminho: float=absf(p.x-.22*sin(p.z*.21)-.12*sin(p.z*.61))/maxf(1,largura(p.z)-.65)
	var mistura: float=smoothstep(.68,1.0,caminho)
	if circular:mistura=smoothstep(9.5,BORDA,distancia(p))
	var variacao: float=sin(p.x*1.7+p.z*.81)*.025+cos(p.z*.37-p.x*2.2)*.018
	return Color(.60+variacao,.38+variacao,.19+variacao).lerp(Color(.25,.49,.12),mistura)
static func malha_clareira() -> ArrayMesh:
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES);st.set_material(material())
	# Anéis densos apenas no chão novo: silhueta circular e borda irregular suave.
	for anel in 12:
		for i in 64:
			var pontos: Array[Vector3]=[]
			for par in [[anel,i],[anel+1,i],[anel+1,i+1],[anel,i+1]]:
				var a: float=TAU*par[1]/64.0
				var r: float=par[0]*(1+.012*sin(a*7)+.009*cos(a*11))
				var p:=Vector3(cos(a)*r,0,CENTRO.y+sin(a)*r)
				p.y=altura(p.z)+.025;pontos.append(p)
			for j in [0,1,2,0,2,3]:
				var p: Vector3=pontos[j]
				st.set_normal(Vector3.UP);st.set_uv(Vector2(p.x,p.z)/3.5);st.set_color(cor(p,true));st.add_vertex(p)
	st.index();return st.commit()
static func faces_clareira() -> PackedVector3Array:
	# Mesmo topo visual, sem a elevação anti-z-fighting.
	var faces: PackedVector3Array=malha_clareira().get_faces()
	for i in faces.size():faces[i].y-=.025
	return faces
static func alargar(z: float, original: float) -> float:
	var dz: float=z-CENTRO.y
	return maxf(original,sqrt(maxf(0,RAIO*RAIO-dz*dz))) if absf(dz)<RAIO else original
