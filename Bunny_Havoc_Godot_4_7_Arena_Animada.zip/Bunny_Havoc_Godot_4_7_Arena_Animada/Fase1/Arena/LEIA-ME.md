# Arena de ondas — Bosque Verde

A clareira da patrulha fica junto da Luna, depois do segundo checkpoint.
O vigia toca o alarme e manda fechar as barricadas para impedir Bunnyck de
alcançar Bunnyldu, por ordem de Bibibunn. Enter pula a apresentação (5,8 s).

São dez patrulheiros bípedes em ondas de 3, 3 e 4. Cada um tem dois pontos
de resistência, usa o dano/recuo/combo nativo e só causa dano durante o ataque
anunciado. No máximo dois preparam/realizam ataques ao mesmo tempo.
Os reforços saltam das laterais; a passagem abre depois da décima derrota.
A câmera abre durante o encontro e devolve o controle ao trilho ao terminar.

Morrer reinicia as ondas ao voltar, sem repetir a introdução já vista e sem
premiar duas vezes o mesmo patrulheiro. Depois de vencida, a arena continua
aberta nas mortes seguintes. R reinicia todo o encontro e suas recompensas.

## Reutilizar em outras fases

Duplique EmboscadaBosque.tscn e configure o script Sistemas/Arenas/arena_ondas.gd:
- inimigo: cena compatível com jogador/terreno/arena, ativo e sinal caiu;
- ondas: quantidade por onda; a soma é o objetivo;
- motivo: fala da patrulha que explica a emboscada;
- pontos_entrada: posições locais de chegada dos reforços;
- raio e posição: limites e centro do encontro.

O controlador espera os nós Jogador (com Saude), Camera3D e as referências
trilho, itens e _mensagem da fase. A fase suspende seu trilho de câmera
quando controla_camera é verdadeiro e chama reiniciar() no reinício completo.
As próximas fases precisam de geometria, colisões, motivos e inimigos próprios;
não são adicionadas arenas automaticamente em fases ainda não migradas.

## Solo

solo_bosque.gd define a clareira circular e a textura compartilhada de terra.
O vão curto do trecho da Luna foi coberto para formar o piso contínuo da arena.
O salto grande seguinte, plataformas, caixas e checkpoints foram preservados.
Luna foi colocada na lateral segura; o besouro deste trecho fica antes da arena.
A clareira tem cerca de 22 m de diâmetro útil, com borda verde ao redor.
O caminho segue a geometria da fase, com terra texturizada e transição verde.

Para atualizar o cenário pré-agrupado após editar suas fontes, com o projeto
já importado, execute o Godot 4.7.2 no diretório que contém project.godot:

    godot --headless --path . --script res://Ferramentas/gerar_cenario.gd

Use o caminho do executável do Godot se ele não estiver no PATH do Windows.
O gerador já está incluído neste projeto. Não é necessário para jogar.

## Animações detalhadas

O vigia se vira, levanta o braço, toca o sino em dois tempos e aponta a ordem.
O sino tem pivô próprio e balanço amortecido. A câmera mostra o vigia e depois
o portão da entrada fechando, antes de abrir para o combate.

Os portões usam duas folhas com dobradiças, trava, aceleração, batida e breve
vibração. Abrem para fora da clareira, sem ocupar o espaço de combate. Durante
a abertura, a colisão só sai quando as folhas já estão quase fora do caminho.
Pular a cena e reiniciar deixam visual e colisão nos mesmos estados finais.

Cada reforço fica oculto até sua vez, prepara o salto, percorre um arco,
recolhe as pernas e amortiza o pouso antes de poder atacar. O vigia já estava
no chão e faz um gesto de comando em vez de repetir o salto dos reforços.
A chegada não altera a geometria nem os materiais aprovados do personagem.

Poeira e folhas usam um pool fixo de 48 partículas simples, uma MultiMesh e
quatro vozes de áudio reutilizadas. Não há processos de partículas ativos
quando o efeito termina. Sons existentes foram reaproveitados.

Scripts separados: Sistemas/Arenas/portao_arena.gd, entrada_patrulha.gd e
efeitos_arena.gd. Poses no arquivo de animação do lagarto humanoide.
