extends SceneTree
## Gere a partir da versão de autoria, antes de substituir a apresentação da fase.
const TAMANHO: float=32.0
const Solo=preload("res://Fase1/Arena/solo_bosque.gd")
var grupos: Dictionary={}
var materiais: Dictionary={}
var texturas: Dictionary={}
var triangulos: int=0
func _initialize() -> void:run.call_deferred()
func material_fixo(original: BaseMaterial3D) -> BaseMaterial3D:
	var novo: BaseMaterial3D=original.duplicate()
	if novo.albedo_texture!=null:
		var img: Image=novo.albedo_texture.get_image()
		var sha: String=img.get_data().hex_encode().sha256_text()
		if not texturas.has(sha):
			var path: String="res://Fase1/Estatico/Texturas/atlas_"+sha+".res"
			assert(ResourceSaver.save(ImageTexture.create_from_image(img),path,ResourceSaver.FLAG_COMPRESS)==OK)
			texturas[sha]=load(path)
		novo.albedo_texture=texturas[sha]
	var chave: String=str(novo.albedo_color)+str(novo.vertex_color_use_as_albedo)+str(novo.shading_mode)+str(novo.cull_mode)+str(novo.albedo_texture.get_instance_id() if novo.albedo_texture!=null else 0)+str(novo.roughness)+str(novo.transparency)
	if not materiais.has(chave):
		var path: String="res://Fase1/Estatico/Materiais/material_%d.res" % materiais.size()
		assert(ResourceSaver.save(novo,path,ResourceSaver.FLAG_COMPRESS)==OK)
		materiais[chave]=load(path)
	return materiais[chave]
func adicionar(mesh: Mesh,t: Transform3D,override: Material=null,categoria: int=1) -> void:
	var normal_t: Basis=t.basis.inverse().transposed()
	for s in mesh.get_surface_count():
		var mat: BaseMaterial3D=material_fixo(override if override!=null else mesh.surface_get_material(s))
		var arrays: Array=mesh.surface_get_arrays(s)
		var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
		var indices: PackedInt32Array=arrays[Mesh.ARRAY_INDEX] if arrays[Mesh.ARRAY_INDEX]!=null else PackedInt32Array()
		var total: int=indices.size() if not indices.is_empty() else vertices.size()
		for j in range(0,total,3):
			var face: Array[int]=[];var centro:=Vector3.ZERO
			for k in 3:
				var index: int=indices[j+k] if not indices.is_empty() else j+k
				face.append(index);centro+=t*vertices[index]
			centro/=3.0
			var setor:=Vector3i(floori(centro.x/TAMANHO),floori(centro.z/TAMANHO),categoria)
			if not grupos.has(setor):grupos[setor]={}
			var id: int=mat.get_instance_id()
			if not grupos[setor].has(id):
				var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES);st.set_material(mat);grupos[setor][id]=st
			var tool: SurfaceTool=grupos[setor][id]
			for index in face:
				tool.set_normal((normal_t*arrays[Mesh.ARRAY_NORMAL][index]).normalized())
				tool.set_color(arrays[Mesh.ARRAY_COLOR][index] if arrays[Mesh.ARRAY_COLOR]!=null else Color.WHITE)
				tool.set_uv(arrays[Mesh.ARRAY_TEX_UV][index] if arrays[Mesh.ARRAY_TEX_UV]!=null else Vector2.ZERO)
				tool.add_vertex(t*vertices[index])
			triangulos+=1
func run() -> void:
	OS.set_environment("BH_BUILD_STATIC_WORLD","1")
	DirAccess.make_dir_recursive_absolute("res://Fase1/Estatico/Texturas")
	DirAccess.make_dir_recursive_absolute("res://Fase1/Estatico/Materiais")
	var fase: Node3D=load("res://Fase1Trecho.tscn").instantiate();root.add_child(fase);current_scene=fase
	await process_frame;await process_frame
	var desempenho: Node=fase.get_node("Desempenho")
	for n: MeshInstance3D in desempenho.terreno.get_children():adicionar(n.mesh,n.global_transform,null,0)
	var pecas: int=0
	for v in get_nodes_in_group("bh_vegetacao"):
		for n in v.get_children():
			if not n is MultiMeshInstance3D or not n.has_meta("bh_instancias"):continue
			for t: Transform3D in n.get_meta("bh_instancias"):
				if Solo.distancia((n.global_transform*t).origin)<15.0:continue
				pecas+=1
				adicionar(n.multimesh.mesh,n.global_transform*t,n.material_override)
	var malhas=load("res://Sistemas/Visual/malhas_compartilhadas.gd")
	var cena:=Node3D.new();cena.name="CenarioEstatico"
	cena.set_meta("triangulos_originais",triangulos);cena.set_meta("pecas_vegetacao",pecas);cena.set_meta("tamanho_bloco",TAMANHO)
	var folhas: Array[Vector3]=[]
	for n in fase.find_children("*","Node3D",true,false):
		if n.scene_file_path.get_file()=="FolhasCaidas.tscn":folhas.append(n.global_position)
	cena.set_meta("montes_folhas",folhas)
	DirAccess.make_dir_recursive_absolute("res://Fase1/Estatico/Malhas")
	var ordem: Array=grupos.keys();ordem.sort()
	var lods: int=0;var total_superficies: int=0
	var faixas: Dictionary={}
	for setor: Vector3i in ordem:
		var mesh:=ArrayMesh.new()
		for tool: SurfaceTool in grupos[setor].values():tool.index();tool.commit(mesh)
		var importer: Resource=ClassDB.instantiate("ImporterMesh")
		for i in mesh.get_surface_count():importer.add_surface(Mesh.PRIMITIVE_TRIANGLES,mesh.surface_get_arrays(i),[],{},mesh.surface_get_material(i))
		importer.generate_lods(25.0,60.0,[])
		for i in importer.get_surface_count():lods+=importer.get_surface_lod_count(i)
		mesh=importer.get_mesh();total_superficies+=mesh.get_surface_count()
		var caminho: String="res://Fase1/Estatico/Malhas/bloco_%d_%d_%d.res" % [setor.x,setor.y,setor.z]
		assert(ResourceSaver.save(mesh,caminho,ResourceSaver.FLAG_COMPRESS)==OK)
		var n:=MeshInstance3D.new();n.name="Bloco_%d_%d_%d" % [setor.x,setor.y,setor.z];n.mesh=load(caminho);cena.add_child(n);n.owner=cena
		var faixa:=Vector2i(floori(float(setor.y)/2.0),setor.z)
		if not faixas.has(faixa):faixas[faixa]={"near":[],"tools":{},"far":"","z":(faixa.x+0.5)*64.0}
		faixas[faixa].near.append(String(n.name))
		for i in mesh.get_surface_count():
			var mat: Material=mesh.surface_get_material(i)
			var id: int=mat.get_instance_id()
			if not faixas[faixa].tools.has(id):
				var tool:=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES);tool.set_material(mat);faixas[faixa].tools[id]=tool
			faixas[faixa].tools[id].append_from(mesh,i,Transform3D.IDENTITY)
	var hlod_tri: int=0
	for faixa in faixas:
		var completa:=ArrayMesh.new()
		for tool: SurfaceTool in faixas[faixa].tools.values():tool.index();tool.commit(completa)
		var importer: Resource=ClassDB.instantiate("ImporterMesh")
		for i in completa.get_surface_count():importer.add_surface(Mesh.PRIMITIVE_TRIANGLES,completa.surface_get_arrays(i),[],{},completa.surface_get_material(i))
		importer.generate_lods(25.0,60.0,[])
		var leve:=ArrayMesh.new()
		for i in completa.get_surface_count():
			var arrays: Array=completa.surface_get_arrays(i)
			var melhor: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
			for j in importer.get_surface_lod_count(i):
				var indices: PackedInt32Array=importer.get_surface_lod_indices(i,j)
				if importer.get_surface_lod_size(i,j)<=0.18 and indices.size()<melhor.size():melhor=indices
			arrays[Mesh.ARRAY_INDEX]=melhor;hlod_tri+=melhor.size()/3
			var temporaria:=ArrayMesh.new();temporaria.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays);temporaria.surface_set_material(0,completa.surface_get_material(i))
			var tool:=SurfaceTool.new();tool.create_from(temporaria,0);tool.deindex();tool.index();tool.set_material(completa.surface_get_material(i));tool.commit(leve)
		var importer_far: Resource=ClassDB.instantiate("ImporterMesh")
		for i in leve.get_surface_count():importer_far.add_surface(Mesh.PRIMITIVE_TRIANGLES,leve.surface_get_arrays(i),[],{},leve.surface_get_material(i))
		importer_far.generate_lods(25.0,60.0,[]);leve=importer_far.get_mesh()
		var path: String="res://Fase1/Estatico/Malhas/longe_%d_%d.res" % [faixa.x,faixa.y]
		assert(ResourceSaver.save(leve,path,ResourceSaver.FLAG_COMPRESS)==OK)
		var n:=MeshInstance3D.new();n.name="Longe_%d_%d" % [faixa.x,faixa.y];n.mesh=load(path);n.layers=0;cena.add_child(n);n.owner=cena
		faixas[faixa].far=String(n.name);faixas[faixa].erase("tools")
	var logicos: Dictionary={}
	for key: Vector3i in ordem:logicos[Vector2i(key.x,key.y)]=true
	cena.set_meta("blocos_logicos",logicos.size())
	cena.set_meta("faixas_hlod",faixas.values());cena.set_meta("triangulos_distantes",hlod_tri)
	cena.set_meta("lods",lods);cena.set_meta("superficies",total_superficies)

	var packed:=PackedScene.new();assert(packed.pack(cena)==OK)
	assert(ResourceSaver.save(packed,"res://Fase1/Estatico/CenarioEstatico.tscn")==OK)
	print(JSON.stringify({"triangles":triangulos,"pieces":pecas,"sectors":logicos.size(),"staticMeshes":ordem.size(),"surfaces":total_superficies,"lods":lods,"textures":texturas.size(),"hlodTriangles":hlod_tri}))
	for n in fase.find_children("*","AudioStreamPlayer",true,false):n.stop();n.stream=null
	malhas=null;cena.free();fase.queue_free();await process_frame;quit()
