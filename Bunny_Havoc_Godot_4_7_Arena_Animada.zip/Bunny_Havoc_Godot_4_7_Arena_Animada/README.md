# Bunny Havoc — terra e arena do bosque

Projeto nativo completo para Godot 4.7.2 Compatibility. Importe project.godot
em pasta nova e F5. F3 alterna qualidade; F4 exibe FPS. Sem filtro PS1 ou fog.

A trilha tem terra texturizada, com transição para grama. A nova clareira da
Luna abriga uma emboscada explicada por um vigia da patrulha de Bibibunn.
São dez lagartos humanoides em três ondas. Veja [a documentação da arena](Fase1/Arena/LEIA-ME.md).

A arena reaproveita combo, recuo, dano, colisões e recompensas existentes.
O bloqueio de socos considera obstáculos sólidos, mas não encurta o soco
por causa do próprio inimigo que deveria receber o golpe.

O cenário continua pré-agrupado em setores de 32 m com LOD/HLOD nativos.
A clareira remove vegetação que atravessaria o piso novo e cobre o vão curto
original desse trecho. O salto grande seguinte continua presente.
Os GLBs originais não foram alterados. NPCs, caixas, cenouras, plataformas,
checkpoints, herói e atores da cutscene continuam separados.
A vegetação é estática; aves, borboletas, poeira e folhas levantadas continuam.

As quatro cenas de floresta continuam como fontes de autoria no nó Bosque.
O runtime usa Fase1/Estatico/CenarioEstatico.tscn; não carrega os milhares de
nós decorativos. Ferramentas/gerar_cenario.gd está incluído para refazer o bake
fora do jogo. A edição do solo está em Fase1/Arena/solo_bosque.gd; mudanças no
solo/fontes exigem gerar novamente o cenário para atualizar a apresentação.

Inclui a Fase 1 atual, cinematográfica e com progresso salvo. Vila e Fase 2
ainda não migradas. Nenhuma garantia de FPS ou de hardware mínimo por RAM.
