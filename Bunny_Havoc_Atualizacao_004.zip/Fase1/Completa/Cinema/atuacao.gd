extends RefCounted
## Camada de atuação sobre as poses originais, sem mudar malhas ou a coreografia.
var atores: Dictionary = {}

func configurar(filme: Node3D, rig: Dictionary) -> void:
	for nome in rig:
		var partes: Dictionary = {}
		for chave in rig[nome]:
			var valor: Variant = rig[nome][chave]
			if valor is Array:
				partes[chave] = valor.map(func(n): return filme.find_child(str(n),true,false))
			else:
				partes[chave] = filme.find_child(str(valor),true,false)
		atores[nome] = partes

func rosto(nome: String) -> Vector3:
	var a: Dictionary = atores[nome]
	if a.has("head"):
		return (a.head as Node3D).global_position
	return (a.root as Node3D).to_global(Vector3(0,1.46,0))

func atualizar(t: float, fase: String, falante: String, progresso: float) -> void:
	var ck: Dictionary = atores.bunnyck
	var ld: Dictionary = atores.bunnyldu
	var bb: Dictionary = atores.bibibunn
	var gesto: float = sin(clampf(progresso,0.0,1.0)*PI)
	var pulso: float = sin(t*2.2)*0.012
	if fase in ["intro","teleportReact","taunt","trappedDialogue"]:
		ck.core.position.y *= 0.25
		ck.core.rotation.x += pulso
		for i in 2:
			var braco: Node3D = ck.arms[i]
			braco.rotation.x = lerpf(braco.rotation.x,-0.22-(0.5*gesto if falante=="Bunnyck" and i==1 else 0.0),0.72)
			braco.rotation.z *= 0.55
			(ck.ears[i] as Node3D).rotation.x *= 0.55
	if fase in ["intro","teleportReact"]:
		ld.core.position.y *= 0.3
		ld.head.rotation.z *= 0.35
		ld.head.rotation.x += -0.065*gesto if falante=="Bunnyldu" else pulso
		for i in 2:
			var alvo: float = -0.38-0.43*gesto if i==0 and falante=="Bunnyldu" else 0.12
			(ld.arms[i] as Node3D).rotation.x = lerpf(ld.arms[i].rotation.x,alvo,0.65)
	if fase=="taunt":
		bb.core.rotation.z *= 0.4
		bb.core.position.y += pulso
		bb.head.rotation.x += 0.055*gesto
		bb.head.rotation.z = lerpf(bb.head.rotation.z,-0.055,0.65)
		(bb.arms[0] as Node3D).rotation.x = lerpf(bb.arms[0].rotation.x,-0.25,0.8)
		(bb.arms[0] as Node3D).rotation.z = lerpf(bb.arms[0].rotation.z,-0.55,0.65)
		(bb.arms[1] as Node3D).rotation.x = lerpf(bb.arms[1].rotation.x,-0.75-0.45*gesto,0.8)
	if fase in ["trappedDialogue","aftermath"]:
		ld.core.position.y *= 0.35
		ld.head.rotation.z *= 0.4
		for i in 2:
			(ld.arms[i] as Node3D).rotation.x = lerpf(ld.arms[i].rotation.x,-1.15,0.55)
	# Hands, cage anchors and the projectile path stay with the original animator.
