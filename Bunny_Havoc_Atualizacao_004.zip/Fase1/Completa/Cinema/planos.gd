extends RefCounted
## Planos e contraplanos permanecem do mesmo lado do eixo entre os irmãos.
var id: String = ""
var foco: Vector3 = Vector3.ZERO
var sujeito: String = "bunnyck"

func atualizar(camera: Camera3D, atuacao: RefCounted, fase: String, q: float, t: float, falante: String, linha_t: float) -> void:
	var ck: Vector3 = atuacao.rosto("bunnyck")
	var ld: Vector3 = atuacao.rosto("bunnyldu")
	var bb: Vector3 = atuacao.rosto("bibibunn")
	var a: Vector3 = atuacao.atores.bunnyck.root.global_position
	var b: Vector3 = atuacao.atores.bunnyldu.root.global_position
	var eixo: Vector3 = Vector3(b.x-a.x,0,b.z-a.z).normalized()
	var lado:=Vector3(-eixo.z,0,eixo.x)
	var pos: Vector3 = camera.global_position
	var fov: float = camera.fov
	id=fase
	sujeito="bunnyck"
	foco=ck
	if fase in ["intro","teleportReact","trappedDialogue"]:
		if fase=="intro" and q<2.4:
			id="reencontro_aberto"
			foco=ck.lerp(ld,0.55)-Vector3.UP*0.15
			pos=foco+Vector3(2.3,2.8,10.0-0.5*smoothstep(0.0,2.4,q))
			fov=48.0
		else:
			var heroi: bool = falante=="Bunnyck"
			sujeito="bunnyck" if heroi else "bunnyldu"
			id="resposta_bunnyck" if heroi else "confidencia_bunnyldu"
			var centro: Vector3 = ck if heroi else ld
			var rumo: Vector3 = eixo if heroi else -eixo
			var dist: float = 5.5 if heroi else 6.4
			if fase=="trappedDialogue":
				dist=6.8
				id="irmao_atras_das_grades" if not heroi else "promessa_bunnyck"
			dist-=0.20*smoothstep(0.0,3.0,linha_t)
			pos=centro+rumo*dist+lado*(1.55 if fase=="trappedDialogue" else 1.15)+Vector3.UP*0.55
			foco=centro-Vector3.UP*0.18+lado*0.16
			fov=41.0
	elif fase in ["riftWarning","teleport"]:
		sujeito="bibibunn"
		id="pressagio" if fase=="riftWarning" else "entrada_bibibunn"
		if fase=="riftWarning":
			foco=Vector3(1.0+0.65*smoothstep(0.0,1.2,q),11.0,-394.1)
			pos=Vector3(1.4,13.3,-384.7)
			fov=49.0
		else:
			foco=Vector3(4.2,11.1,-394.25)
			pos=Vector3(7.8,12.2,-387.4)-Vector3(0.15,0,0.3)*smoothstep(0.0,2.5,q)
			fov=45.0
	elif fase=="taunt" or (fase=="aftermath" and falante!="Bunnyck"):
		sujeito="bibibunn"
		id="ameaca_bibibunn"
		var rumo: Vector3 = Vector3(a.x-bb.x,0,a.z-bb.z).normalized()
		var lateral:=Vector3(rumo.z,0,-rumo.x)
		var dist: float = 6.7-0.28*smoothstep(0.0,4.0,linha_t)
		pos=bb+rumo*dist+lateral*1.1+Vector3.UP*0.28
		foco=bb-Vector3.UP*0.2+lateral*0.18
		fov=40.0
	elif fase=="aftermath" and falante=="Bunnyck":
		id="determinacao_bunnyck"
		var rumo: Vector3 = Vector3(bb.x-ck.x,0,bb.z-ck.z).normalized()
		pos=ck+rumo*5.7+lado*0.8+Vector3.UP*0.6
		foco=ck-Vector3.UP*0.12
		fov=40.0
	elif fase=="windup":
		id="duelo_antecipacao"
		foco=ck.lerp(bb,0.55)-Vector3.UP*0.4
		pos=foco+Vector3(1.5,2.3,8.5-q*0.6)
		fov=51.0
	else:
		# Preserve the broad choreography for the cage flight and physical throws.
		var gaiola: Node3D = atuacao.atores.cage.root
		var centro: Vector3 = (gaiola.global_position+Vector3.UP*2.1) if gaiola!=null else ld
		if fase in ["cageFly","cageDrop","throwPrep","throwLaunch","airborne","catch","liftApproach","escape"]:
			foco=centro.lerp(bb,0.25)
			sujeito="cage"
			var distancia: Vector3 = pos-foco
			pos=foco+distancia*(1.06 if fase=="escape" else 0.95)
			fov=clampf(fov-2.0,48.0,68.0)
		else:
			foco=ck-Vector3.UP*0.25
			fov=clampf(fov-2.0,48.0,68.0)
		if fase=="forestReveal":
			id="despedida_bosque"
			pos+=Vector3(0,0.4,q*0.4)
	# A short damped impulse reads as weight; it never accumulates on the camera.
	var impulso: float = 0.0
	if fase=="knockdown":
		impulso=0.075*exp(-q*9.0)
	elif fase=="catch":
		impulso=0.06*exp(-q*8.0)
	elif fase=="cageDrop":
		impulso=0.045*exp(-absf(q-0.75)*15.0)
	pos+=Vector3(sin(q*73.0),cos(q*61.0)*0.55,0)*impulso
	camera.global_position=pos
	if pos.distance_squared_to(foco)>0.01:
		camera.look_at(foco)
	camera.fov=fov
