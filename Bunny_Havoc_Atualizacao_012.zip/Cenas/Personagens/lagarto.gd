extends CharacterBody3D
## Espreita e recuo curto antes do bote; direção travada permite esquivar.
const Animacao=preload("animacao_lagarto.gd")
var animacao: RefCounted=Animacao.new()
signal recompensa_ganha(valor: int)
@export var amplitude: float = 1.45
@export var fase: float = 0.0
@export var velocidade: float = 1.0
@export var ativo: bool = true
var jogador: CharacterBody3D
var terreno: RefCounted
var hp: int = 2
var derrotado_agora: bool = false
var estado: String = "patrol"
var _frente_bote := Vector3.FORWARD
var _origem: Vector3
var _casa: Vector3
var _tempo: float = 0.0
var _idade: float = 0.0
var _cool: float = 0.0
var _voo: bool = false
var _voo_idade: float = 0.0
var _duracao: float = 0.30
var _final: bool = false
var _heading: float = 0.0
var _progresso: float = 0.0
var _chao: float
var _inicio_voo: float = 0.0
var _corpo: Node3D
var _cabeca: Node3D
var _cauda: Node3D
var _pernas: Array[Node3D] = []
var _aviso: Label3D

func _ready() -> void:
	process_physics_priority = 15
	_origem = global_position
	_casa = _origem
	_chao = _origem.y
	_corpo = $Visual.find_child("Corpo", true, false)
	_cabeca = $Visual.find_child("Cabeca", true, false)
	_cauda = $Visual.find_child("Cauda", true, false)
	for i in 4:
		_pernas.append($Visual.find_child("Perna_" + str(i), true, false))
	_aviso = Label3D.new()
	_aviso.name = "Aviso"
	_aviso.text = "!"
	_aviso.font_size = 80
	_aviso.pixel_size = 0.004
	_aviso.modulate = Color("ffdc68")
	_aviso.position.y = 1.8
	_aviso.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_aviso.visible = false
	add_child(_aviso)
	animacao.configurar(_corpo,_cabeca,_cauda,_pernas,global_position)
	add_to_group("bunny_havoc_inimigos")

func _altura(z: float) -> float:
	return terreno.altura(z) if terreno != null else _origem.y

func _mover(passo: Vector3) -> void:
	var partes: int = maxi(1, ceili(passo.length() / 0.04))
	for i in partes:
		var p: Vector3 = global_position + passo / partes
		var query := PhysicsRayQueryParameters3D.create(Vector3(p.x, _chao + 0.5, p.z), Vector3(p.x, _chao - 0.3, p.z), 1, [get_rid()])
		var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(query)
		if hit.is_empty() or absf(hit.position.y - _chao) > 0.25 or test_move(global_transform, passo / partes):
			break
		global_position.x = p.x
		global_position.z = p.z
		_chao = hit.position.y

func _physics_process(dt: float) -> void:
	if jogador == null and get_tree().current_scene != null:
		jogador = get_tree().current_scene.find_child("Jogador", true, false) as CharacterBody3D
	if not visible or jogador == null or not ativo:
		return
	var vida: Node = jogador.get_node("Saude")
	if vida.morto or vida.encerrado or not jogador.is_physics_processing():
		return
	_tempo += dt
	_cool = maxf(0.0, _cool-dt)
	if _voo:
		_animar_voo(dt)
	else:
		_patrulhar(dt)
	if not derrotado_agora:
		_contato(vida)

func _patrulhar(dt: float) -> void:
	_idade += dt
	var delta_pos: Vector3 = jogador.global_position - global_position
	var distancia: float = Vector2(delta_pos.x, delta_pos.z).length()
	var perseguindo: bool = distancia < 15.0 and absf(jogador.global_position.z - _casa.z) < 15.0 and absf(delta_pos.y) < 3.5
	if not perseguindo and estado in ["patrol","stalk"]:
		estado = "patrol"
	if perseguindo and distancia < 4.2 and _cool <= 0.0 and estado == "patrol":
		estado = "stalk"
		_idade = 0.0
	elif estado == "stalk" and _idade > 0.42:
		estado = "windup"
		_idade = 0.0
		_frente_bote = Vector3(delta_pos.x,0,delta_pos.z).normalized()
		if _frente_bote.length_squared()<0.1:_frente_bote=Vector3(sin(rotation.y),0,cos(rotation.y))
	elif estado == "windup" and _idade > 0.32:
		estado = "lunge"
		_idade = 0.0
	elif estado == "lunge" and _idade > 0.40:
		estado = "recover"
		_idade = 0.0
		_cool = 1.1
	elif estado == "recover" and _idade > 0.50:
		estado = "patrol"
		_idade = 0.0
	_aviso.visible = estado == "windup"
	var alvo: Vector3 = jogador.global_position if perseguindo else _casa + Vector3(sin(_tempo * velocidade * 0.85 + fase) * amplitude, 0, sin(_tempo * 0.44 + fase) * 0.6)
	var diferenca := Vector3(alvo.x - global_position.x, 0, alvo.z - global_position.z)
	var passo := Vector3.ZERO
	if estado in ["windup","lunge"]:
		rotation.y = atan2(_frente_bote.x,_frente_bote.z)
		if estado=="lunge":passo=_frente_bote*8.1*dt
	elif estado=="stalk":
		if diferenca.length()>0.08:
			rotation.y=lerp_angle(rotation.y,atan2(diferenca.x,diferenca.z),1-exp(-10*dt))
			passo=-diferenca.normalized()*0.75*dt
	elif estado!="recover" and diferenca.length()>0.08:
		rotation.y=lerp_angle(rotation.y,atan2(diferenca.x,diferenca.z),1-exp(-9*dt))
		var rapidez: float=3.7+(velocidade-0.75)*1.6 if perseguindo else 1.25
		passo=diferenca.normalized()*minf(diferenca.length(),rapidez*dt)
	if absf(global_position.z+passo.z-_casa.z)<11.5:_mover(passo)
	global_position.y = _chao + 0.04
	animacao.atualizar(dt,global_position,estado,_idade,_tempo,perseguindo)

func _contato(vida: Node) -> void:
	var d: Vector3 = jogador.global_position - global_position
	var combo: RefCounted = jogador.get("_combate")
	if d.y > -0.6 and d.y < 1.6 and combo.pode_atingir(self, 1.45):
		combo.registrar_acerto(self)
		var golpe: Dictionary = combo.golpe_para(self)
		var heading: float = golpe.heading
		if combo.estado.step == 1:
			heading = atan2(-d.x,-d.z) if Vector2(d.x,d.z).length() > 0.001 else heading
		receber_golpe(golpe.damage, heading, golpe.finisher)
	elif not _voo and _cool <= 0.0 and absf(d.x) < 0.85 and absf(d.z) < 0.95 and d.y > -0.6 and d.y < 1.5:
		if jogador.velocity.y < -0.6 and d.y > 0.55:
			receber_golpe(1, atan2(-d.x,-d.z), false)
			jogador.velocity.y = 9.0
		elif estado in ["patrol","lunge"]:
			vida.receber_dano(1, self)

func receber_golpe(dano: int, heading: float, finalizador: bool, premiar: bool = true) -> bool:
	if derrotado_agora or not visible or (_voo and _final):
		return false
	hp = maxi(0, hp-dano)
	_inicio_voo = maxf(0.0, global_position.y - _chao)
	_voo = true
	_voo_idade = 0.0
	_final = finalizador
	_duracao = 0.62 if finalizador else 0.30
	_heading = heading
	_progresso = 0.0
	_cool = 0.85
	estado = "hurt"
	_aviso.visible = false
	if hp == 0:
		derrotado_agora = true
		collision_layer = 0
		if premiar:
			recompensa_ganha.emit(6)
	return true

func _animar_voo(dt: float) -> void:
	_voo_idade += dt
	var u: float = minf(1.0, _voo_idade / _duracao)
	var progresso: float = 1.0 - pow(1.0-u,2)
	_mover(Vector3(sin(_heading),0,cos(_heading)) * (progresso-_progresso) * (3.2 if _final else 0.38))
	_progresso = progresso
	global_position.y = _chao + (sin(u*PI)*1.25 if _final else 4*u*(1-u)*0.46) + (1-u)*_inicio_voo
	animacao.dano(u)
	_corpo.rotation.x = -(0.30 if _final else 0.12) * sin(u*PI)
	_corpo.rotation.z = (PI*1.6 if derrotado_agora else 0.62 if _final else 0.12) * sin(u*PI/2)
	var encolher: float = 1.0 - 0.5*maxf(0.0,(u-0.78)/0.22) if derrotado_agora else 1.0
	_corpo.scale = Vector3.ONE * encolher
	var pivo := Vector3(0, 0.55*encolher, 0)
	_corpo.position = Vector3(0,0.55,0) - Basis.from_euler(_corpo.rotation)*pivo
	if derrotado_agora and u == 1.0:
		visible = false
	elif _voo_idade >= _duracao + 0.16:
		_voo = false
		global_position.y = _chao + 0.04
		_casa = global_position
		_corpo.transform = Transform3D.IDENTITY
		estado = "recover"
		_idade = 0.0

func atingido_por_explosao() -> void:
	receber_golpe(99, 0.0, false, false)

func reiniciar() -> void:
	global_position = _origem
	_casa = _origem
	_chao = _origem.y
	hp = 2
	derrotado_agora = false
	visible = true
	collision_layer = 2
	_voo = false
	_cool = 0.0
	_idade = 0.0
	_tempo = 0.0
	_frente_bote = Vector3.FORWARD
	estado = "patrol"
	_corpo.transform = Transform3D.IDENTITY
	animacao.reiniciar(global_position)
	_aviso.visible = false
	for p in _pernas + [_cabeca, _cauda]:
		p.rotation = Vector3.ZERO
