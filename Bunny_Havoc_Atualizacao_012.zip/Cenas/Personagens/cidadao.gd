extends "res://Sistemas/Coleta/objeto_interativo.gd"
## Diálogo e interação compartilhados pelos cidadãos; a rotina pode ser especializada.
var terreno: RefCounted
var conversando: bool = false
var _inicio: Vector3
var _tempo: float = 0.0
var _linha: int = 0
var _corpo: Node3D
var _cabeca: Node3D
var _cabeca_rotina: Quaternion=Quaternion.IDENTITY
var _olhar: Vector2=Vector2.ZERO
var _moeda: Node3D
var _bracos: Array[Node3D] = []
var _aviso: Label3D
var _painel: PanelContainer
var _texto: Label
var _dicas: Label3D
@export var nome: String = "Rufus"
@export var rotacao_descanso: float = -0.9
@export var falas: Array[String] = ["Meu expediente? Catar objetos brilhantes! É uma carreira honesta.", "Ouvi dizer que os lagartos precisam de dois golpes para cair. Não subestime eles!", "Bunnyck: Valeu pela dica!"]
@export var falantes: Array[String] = []

func _ready() -> void:
	process_physics_priority = 19
	add_to_group("bh_cidadaos")
	_inicio = global_position
	_corpo = $Visual.find_child("Corpo", true, false)
	_cabeca = $Visual.find_child("Cabeca", true, false)
	if _cabeca!=null:_cabeca_rotina=_cabeca.quaternion
	rotation.y=rotacao_descanso
	_moeda = $Visual.find_child("Moeda", true, false)
	for i in 2:
		_bracos.append($Visual.find_child("Braco_" + str(i), true, false))
	_aviso = Label3D.new()
	_aviso.text = "Enter: conversar"
	_aviso.font_size = 48
	_aviso.pixel_size = 0.0035
	_aviso.position.y = 2.9
	_aviso.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_aviso.visible = false
	add_child(_aviso)
	_dicas = Label3D.new()
	_dicas.font_size = 32
	_dicas.pixel_size = 0.0025
	_dicas.position.y = 3.4
	_dicas.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_dicas.width = 520
	_dicas.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(_dicas)
	var layer := CanvasLayer.new()
	add_child(layer)
	_painel = PanelContainer.new()
	_painel.position = Vector2(200, 438)
	_painel.custom_minimum_size = Vector2(752, 145)
	_painel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_painel)
	_texto = Label.new()
	_texto.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_texto.custom_minimum_size = Vector2(710, 125)
	_texto.add_theme_font_size_override("font_size", 21)
	_texto.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_painel.add_child(_texto)
	_painel.visible = false

func _physics_process(dt: float) -> void:
	if localizar_jogador() == null:
		return
	var vida: Node = _jogador.get_node("Saude")
	if vida.morto or vida.encerrado:
		fechar()
		_aviso.visible = false
		_dicas.visible = false
		return
	_tempo += dt
	var perto: float = Vector2(global_position.x - _jogador.global_position.x, global_position.z - _jogador.global_position.z).length()
	var proximo: bool = perto < 6.2 and _mais_proximo(perto)
	_aviso.visible = perto < 3.6 and not conversando and proximo
	_dicas.visible = perto < 6.2 and not conversando and proximo
	_dicas.text = nome + ": " + falas[int(_tempo / 6.0) % mini(2, falas.size())]
	if conversando:
		_jogador.set_process_unhandled_key_input(false)
		_acompanhar_com_cabeca(dt,perto)
		return
	if _cabeca!=null:_cabeca.quaternion=_cabeca_rotina
	_animar_rotina(dt)
	if _cabeca!=null:_cabeca_rotina=_cabeca.quaternion
	_acompanhar_com_cabeca(dt,perto)
	for i in 2:
		var palpebra := $Visual.find_child("Palpebra_" + str(i), true, false) as Node3D
		if palpebra != null:
			palpebra.scale.y = 1.0 if fmod(_tempo, 3.3) < 0.12 else 0.001

func _acompanhar_com_cabeca(dt: float,distancia: float) -> void:
	if _cabeca==null:return
	var alvo: Vector2=Vector2.ZERO
	if distancia<8.0 and distancia>0.05:
		var olhos: Vector3=_jogador.global_position+Vector3.UP*1.65
		var local: Vector3=_cabeca.get_parent().to_local(olhos)-_cabeca.position
		local=Basis(_cabeca_rotina).inverse()*local
		var peso: float=1.0-smoothstep(6.0,8.0,distancia)
		alvo=Vector2(clampf(atan2(local.x,local.z),-1.05,1.05),clampf(-atan2(local.y,maxf(0.1,Vector2(local.x,local.z).length())),-0.32,0.38))*peso
	_olhar=_olhar.lerp(alvo,1.0-exp(-7.0*dt))
	_cabeca.quaternion=_cabeca_rotina*Quaternion(Vector3.UP,_olhar.x)*Quaternion(Vector3.RIGHT,_olhar.y)

func _animar_rotina(_dt: float) -> void:
	position.x = _inicio.x + sin(_tempo * 0.6) * 0.2
	position.z = _inicio.z + cos(_tempo * 0.42) * 0.168
	position.y = terreno.altura(position.z) if terreno != null else _inicio.y
	var k: float = fmod(_tempo, 10.0) / 10.0
	var b: float = clampf(minf((k-0.05)/0.06, (0.5-k)/0.06), 0.0, 1.0)
	var e: float = clampf(minf((k-0.55)/0.06, (0.85-k)/0.06), 0.0, 1.0)
	_corpo.position.y = -0.35 * b * 0.9
	_corpo.rotation.x = 0.4 * b
	_bracos[0].rotation.x = (-0.9 + sin(_tempo * 14) * 0.8) * b
	_bracos[1].rotation.x = (-0.9 - sin(_tempo * 14) * 0.8) * b - 2.5 * e
	_bracos[1].rotation.z = 0.3 * e
	_cabeca.rotation = Vector3(0.3 * b - 0.1 * e, sin(_tempo * 3) * 0.4 * e, sin(_tempo * 1.3) * 0.05)
	_moeda.visible = e > 0.1

func _mais_proximo(distancia: float) -> bool:
	for npc: Node3D in get_tree().get_nodes_in_group("bh_cidadaos"):
		if npc == self or not npc.visible:
			continue
		var d: float = Vector2(npc.global_position.x-_jogador.global_position.x,npc.global_position.z-_jogador.global_position.z).length()
		if d < distancia - 0.001:
			return false
	return true

func _input(event: InputEvent) -> void:
	if not event is InputEventKey or not event.pressed or event.echo:
		return
	var key: int = event.physical_keycode if event.physical_keycode else event.keycode
	if conversando:
		if key == KEY_R:
			fechar()
			return
		if key == KEY_ESCAPE:
			fechar()
		elif key == KEY_ENTER or key == KEY_KP_ENTER:
			_linha += 1
			if _linha >= falas.size():
				fechar()
			else:
				_atualizar_texto()
		get_viewport().set_input_as_handled()
	elif (key == KEY_ENTER or key == KEY_KP_ENTER) and _aviso.visible and pode_interagir():
		conversando = true
		_linha = 0
		_jogador.velocity = Vector3.ZERO
		(_jogador.get("_combate") as RefCounted).limpar()
		_jogador.set_physics_process(false)
		_painel.visible = true
		_atualizar_texto()
		get_viewport().set_input_as_handled()

func _atualizar_texto() -> void:
	var pessoa: String = falantes[_linha] if _linha < falantes.size() else (nome if _linha < falas.size() - 1 else "")
	_texto.text = (pessoa + "\n" if not pessoa.is_empty() else "") + falas[_linha] + "\n\nEnter: continuar    Esc: fechar"

func fechar() -> void:
	if not conversando:
		return
	conversando = false
	_painel.visible = false
	if localizar_jogador() != null:
		var vida: Node = _jogador.get_node("Saude")
		if not vida.morto and not vida.encerrado:
			_jogador.set_physics_process(true)
			_jogador.set_process_unhandled_key_input(true)
