extends "caixa.gd"
## O bloco ! aciona todas as Nitros da fase e permanece como apoio metálico.
var ativado: bool=false
var _rebote_pendente: bool=false
var _material: StandardMaterial3D
func _ready() -> void:
	super._ready()
	_material=arte.material
func pisar() -> void:
	_rebote_pendente=not ativado
	quebrar()
func _rebater() -> void:
	if _rebote_pendente:
		super._rebater();_rebote_pendente=false
func quebrar() -> void:
	if ativado:return
	ativado=true
	arte.atualizar_estado(false,true)
	arte.impacto(.10)
	quebrada.emit(0,self)
	for caixa in get_tree().get_nodes_in_group("bh_nitro"):
		if caixa.visible:caixa.detonar()
func destruir_por_explosao() -> void:pass
func reiniciar() -> void:
	super.reiniciar()
	ativado=false;_rebote_pendente=false
	_material.albedo_color=Color.WHITE
	$Visual.scale=Vector3.ONE
