@tool
extends Node3D
## Apenas apresentação: anima o modelo com a base fixa, nunca o colisor.
const Malhas=preload("malhas_caixas.gd")
@export_enum("normal","carrot","spring","tnt","nitro","armored","switch") var tipo: String="normal":
	set(value):
		tipo=value
		if is_node_ready():_montar()
var material: StandardMaterial3D
var corpo: MeshInstance3D
var tampa: MeshInstance3D
var _tempo: float=0
var _impacto: float=99
var _forca: float=.12
var _ligado: bool=false
var _dano: bool=false
var _tinta: float=0
func _ready() -> void:_montar()
func _montar() -> void:
	corpo=get_node_or_null("Corpo")
	if corpo==null:corpo=MeshInstance3D.new();corpo.name="Corpo";add_child(corpo)
	if material==null:material=Malhas.material().duplicate()
	corpo.mesh=Malhas.obter(tipo,_dano,_ligado);corpo.material_override=material
	if tipo in ["carrot","spring"]:
		tampa=get_node_or_null("Tampa")
		if tampa==null:tampa=MeshInstance3D.new();tampa.name="Tampa";add_child(tampa)
		tampa.mesh=Malhas.tampa(tipo);tampa.material_override=material;tampa.position.y=.555
	if tampa!=null:tampa.visible=tipo in ["carrot","spring"]
func impacto(forca: float=.13) -> void:
	_impacto=0;_forca=forca;_tinta=.11
func atualizar_estado(dano: bool=false,ligado: bool=false) -> void:
	_dano=dano;_ligado=ligado
	if corpo!=null:corpo.mesh=Malhas.obter(tipo,dano,ligado)
func _process(dt: float) -> void:
	if Engine.is_editor_hint():return
	var caixa: Node3D=get_parent().get_parent()
	if not caixa.visible or not caixa.pode_interagir():return
	_tempo+=dt;_impacto+=dt;_tinta=maxf(0,_tinta-dt)
	var kick: float=exp(-_impacto*11)*cos(_impacto*21)
	var sy: float=1-_forca*kick
	var sx: float=1/sqrt(sy)
	scale=Vector3(sx,sy,sx);position=Vector3(0,.58*(sy-1),0);rotation=Vector3.ZERO
	material.albedo_color=Color(1,1,1).lerp(Color(1.15,1.10,.88),_tinta/.11)
	if tipo=="armored":rotation.z=sin(_impacto*52)*exp(-_impacto*16)*.045
	if tipo=="nitro":
		var q: float=fposmod(_tempo+float(caixa.get_instance_id()%13)*.19,3.8)
		var nervosismo: float=sin(PI*clampf(q/.28,0,1)) if q<.28 else 0
		rotation.z=sin(q*70)*nervosismo*.025
		if nervosismo>0:position.y+=nervosismo*.018
	if tipo=="tnt" and caixa.pavio>0:
		var pressa: float=1-caixa.pavio/3.0
		rotation.z=sin(_tempo*(24+pressa*25))*(.012+pressa*.024)
		var flash: float=maxf(0,sin(_tempo*(9+pressa*11)))
		material.albedo_color=Color(1,1,1).lerp(Color(1.15,.72,.56),flash*(.18+pressa*.2))
	if tipo=="switch" and _ligado:
		scale.y*=.96;position.y-=.023
	if tampa!=null:tampa.position.y=.555-maxf(kick,0)*(.06 if tipo=="spring" else .025)
func reiniciar() -> void:
	_impacto=99;_tinta=0;_tempo=0;_dano=false;_ligado=false
	scale=Vector3.ONE;position=Vector3.ZERO;rotation=Vector3.ZERO
	material.albedo_color=Color.WHITE;atualizar_estado()
	if tampa!=null:tampa.position.y=.555
