extends Node3D
## Instancing preservado; vento por planta, pivotado na base, só perto da câmera.
@export var otimizar_em_execucao: bool=true
@export var vento_ativo: bool=true
var lotes: int=0
var pecas: int=0
var vento: Array[Dictionary]=[]
var _tempo: float=0
var _acumulado: float=0
var _zonas: Dictionary={}
var _jogador: Node3D
func _amplitude(planta: Node3D) -> float:
	var nome: String=planta.scene_file_path.get_file()
	if nome=="ArvoreCopaRedonda.tscn":return 0.007
	if nome=="Pinheiro.tscn":return 0.005
	if nome=="Arbusto.tscn":return 0.025
	if nome=="Samambaia.tscn":return 0.085
	if nome.begins_with("Flor") or nome=="TufoGrama.tscn":return 0.10
	return 0
func _ready() -> void:
	add_to_group("bh_vegetacao")
	if not otimizar_em_execucao:return
	var grupos: Dictionary={}
	for node: MeshInstance3D in $Instancias.find_children("*","MeshInstance3D",true,false):
		if not node.is_visible_in_tree() or node.mesh==null:continue
		var material: Material=node.get_active_material(0)
		var chave: String=str(node.mesh.get_rid())+":"+str(material.get_rid())
		if not grupos.has(chave):grupos[chave]={"mesh":node.mesh,"material":material,"transforms":[],"movimentos":[]}
		var grupo: Dictionary=grupos[chave]
		var base: Transform3D=global_transform.affine_inverse()*node.global_transform
		var planta: Node3D=node
		while planta.get_parent()!=null and planta.get_parent()!=$Instancias:
			if planta.scene_file_path.ends_with(".tscn"):break
			planta=planta.get_parent()
		var amp: float=_amplitude(planta)
		if vento_ativo and amp>0:
			var item: Dictionary={"i":grupo.transforms.size(),"base":base,"pivot":to_local(planta.global_position),"z":planta.global_position.z,"fase":planta.global_position.x*0.71+planta.global_position.z*0.23,"amp":amp,"baixo":amp>=0.025,"reacao":Vector2.ZERO,"idade_reacao":99.0}
			grupo.movimentos.append(item)
			if item.baixo:
				var zona: int=floori(float(item.z)/4.0)
				if not _zonas.has(zona):_zonas[zona]=[]
				_zonas[zona].append(item)
		grupo.transforms.append(base);pecas+=1
	for grupo: Dictionary in grupos.values():
		var multi:=MultiMesh.new();multi.transform_format=MultiMesh.TRANSFORM_3D;multi.mesh=grupo.mesh
		multi.instance_count=grupo.transforms.size()
		for i in multi.instance_count:multi.set_instance_transform(i,grupo.transforms[i])
		var node:=MultiMeshInstance3D.new();node.multimesh=multi;node.material_override=grupo.material
		node.extra_cull_margin=0.45
		add_child(node);lotes+=1
		if not grupo.movimentos.is_empty():vento.append({"node":node,"items":grupo.movimentos})
	$Instancias.visible=false
	set_process(vento_ativo and not vento.is_empty())
func _process(dt: float) -> void:
	_tempo+=dt;_acumulado+=dt
	if _acumulado<0.05:return
	var intervalo: float=minf(_acumulado,0.1)
	_acumulado=0
	if _jogador==null:
		var cena: Node=get_tree().current_scene
		if cena!=null:_jogador=cena.get_node_or_null("Jogador")
	for grupo: Dictionary in vento:
		for item: Dictionary in grupo.items:
			item.idade_reacao+=intervalo
			if _jogador!=null and absf(item.z-_jogador.global_position.z)>55:continue
			(grupo.node as MultiMeshInstance3D).multimesh.set_instance_transform(int(item.i),pose_vento(item))
func pose_vento(item: Dictionary) -> Transform3D:
	var onda: float=sin(_tempo*1.35+item.fase)*0.65+sin(_tempo*0.47+item.fase*0.21)*0.35
	var b:=Basis(Vector3(0.8,0,0.6),onda*float(item.amp))
	var r: Vector2=item.reacao*exp(-float(item.idade_reacao)*4.8)*cos(float(item.idade_reacao)*9.0)
	if r.length_squared()>0.000001:b=Basis(Vector3(r.x,0,r.y).normalized(),r.length())*b
	var original: Transform3D=item.base
	return Transform3D(b*original.basis,item.pivot+b*(original.origin-item.pivot))

func reagir(posicao: Vector3,forca: float,raio: float) -> void:
	var local: Vector3=to_local(posicao)
	for zona in range(floori((posicao.z-raio)/4.0),floori((posicao.z+raio)/4.0)+1):
		for item: Dictionary in _zonas.get(zona,[]):
			if absf(float(item.z)-posicao.z)>raio:continue
			var delta: Vector3=item.pivot-local
			var dist: float=Vector2(delta.x,delta.z).length()
			if dist>=raio or absf(delta.y)>1.5:continue
			var eixo:=Vector2(delta.z,-delta.x).normalized()
			if eixo.length_squared()<0.01:eixo=Vector2.RIGHT
			item.reacao=eixo*minf(0.4,forca*(1.0-dist/raio))
			item.idade_reacao=0.0

func limpar_reacoes() -> void:
	for grupo: Dictionary in vento:
		for item: Dictionary in grupo.items:
			item.reacao=Vector2.ZERO;item.idade_reacao=99.0
			(grupo.node as MultiMeshInstance3D).multimesh.set_instance_transform(int(item.i),pose_vento(item))
