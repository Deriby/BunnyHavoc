# Atualização 012 — visual e animações das caixas

Feche o Godot e extraia na pasta de project.godot do projeto completo 4.7.
Inclui todas as atualizações de 008 a 011; F5 para jogar.

As sete caixas usam um atlas original de 512x512 com tábuas, veios, nós,
frestas, desgaste, símbolos pintados e metal escovado. Bordas chanfradas,
travessas, rebites e tampas acrescentam volume à silhueta low-poly.
Normais têm travessas em X; cenouras têm um selo roxo/laranja; mola tem seta
azul/dourada; reforçada tem cintas metálicas e rachaduras após o primeiro hit;
TNT é vermelha e Nitro verde, com faixas de perigo e letras bem contrastantes.
O interruptor verde muda para uma face cinza com marca de acionamento.

Impactos comprimem o modelo com retorno elástico, mantendo a base fixa.
A mola comprime mais e move a tampa. A TNT treme mais perto de explodir;
Nitro tem pequenos movimentos nervosos. Reforçada recebe um tranco no hit.
Quebras lançam tábuas texturizadas, que caem, assentam e encolhem. Quiques
na caixa de cenouras mostram duas pequenas cenouras indo até o Bunnyck.
Pools fixos: 24 lascas e 8 cenouras; malhas/atlas compartilhados.

Colisores, posições, recompensas, contagem de 14 caixas, cinco/dez quiques,
TNT 3-2-1, Nitro/interruptor e controles mantêm as regras da 011.
Personagens, cenário, áudio e coreografia da cutscene não foram alterados.
Os GLBs originais continuam intactos; os prefabs agora usam Visual/ModeloCaixa.
Novos visuais em Cenas/Caixas/Visual; build do atlas: tools/build_crate_atlas.py.

# Atualização 011 — caixas com regras de Crash 3

Aplicar sobre o projeto completo Godot 4.7, na pasta de project.godot.
Inclui 008, 009 e 010; não precisa instalar os patches anteriores separados.

Caixa normal: giro/socos, pisão e pancada por baixo quebram. Pisão faz quicar;
segurar Espaço aumenta o rebote. A caixa continua sólida ao encostar de lado.
Caixa de cenouras: cinco quiques, duas cenouras por quique (dez no total).
Giro/soco quebra cedo e rende só uma; explosões não dão cenouras restantes.
Mola de madeira: mantém impulso 16,5, dura dez quiques e pode ser quebrada
com um golpe. Assim ela também pode completar a contagem total de caixas.
TNT: pisão ou cabeçada inicia 3-2-1; giro/soco explode imediatamente.
Nitro: contato/golpe/pisão continuam explodindo. Novo interruptor verde !
perto do fim (X 2, Z -381) aciona as Nitros restantes. Conta como caixa ao
acionar, continua sólido e não produz estilhaços de madeira.
A fase passa a ter 14 caixas. Contagem e recompensas não repetem ao atingir
caixa destruída/interruptor acionado. Recompensas de caixas e quiques agora
passam pela regra de vida extra a cada cem cenouras. R restaura todos os estados.

A reforçada mantém seus dois impactos. Não foi adicionado ataque de barriga,
novas caixas de metal/Aku Aku, gemas ou uma mudança nas regras de checkpoint.
Este pacote aplica as regras descritas às caixas atuais do Bunny Havoc.
Modelos, personagens, combo, áudios e coreografia da cutscene preservados.

# Atualização 010 — cenário reage ao Bunnyck

Feche o Godot e extraia na pasta de project.godot do projeto completo 4.7.
Inclui as atualizações 008 e 009; não exige instalá-las separadamente.

Oito pássaros pousados reutilizam o modelo original. Fogem ao se aproximar
ou atacar, permanecem afastados enquanto o jogador está perto e voltam depois.
As 26 aves de fundo continuam com as trajetórias anteriores.
Grama, flores, samambaias e arbustos flexionam perto da passagem/golpes e
voltam suavemente. Troncos não recebem essa reação. Malhas agrupadas mantidas;
busca de plantas próximas dividida em faixas de 4 m, com pivôs fixos na base.
Golpes levantam 3 a 5 folhas só junto aos montes autorados, uma vez por golpe.
Passos produzem 2 a 3 pequenas nuvens sincronizadas ao áudio, só no corredor
firme original. Sem poeira em saltos, plataformas, caixas ou bordas laterais.
26 objetos fixos reutilizados (12 poeira, 14 folhas), malhas compartilhadas,
sem criar emissores durante a ação. Diminuem e desaparecem em menos de 1,1 s.
Conversas, morte e cutscene bloqueiam as reações. R limpa efeitos e reinicia
aves e flexões. Modelos, trilha, colisores, combate, áudio, céu e PSX mantidos.
Arquivos reutilizáveis em Sistemas/Ambiente/ReacoesBosque.tscn.

# Atualização 009 — inimigos com personalidade

Aplicar sobre a pasta do projeto completo Godot 4.7. Este patch inclui também
as mudanças da atualização 008; não precisa instalar a 008 antes.

Besouro: percebe o jogador, anuncia a investida com antenas/preparo e avança
numa direção fixa. Para diante de buracos/paredes, recupera por 0,85 s sem
causar dano de contato e volta à patrulha. Continua com 1 HP e recompensa 3.
Lagarto: espreita e recua por 0,42 s, prepara por 0,32 s, dá um bote em linha
reta por 0,40 s e recupera parado. Não gira atrás de uma esquiva nem causa
dano de contato durante preparo/recuperação. Continua com 2 HP e recompensa 6.
Urso: pausa de farejo em quatro patas antes da perseguição, uma vez por
aproximação. Levanta e emite o som original antes da garra. Trava a direção
no fim do preparo, não acompanha a esquiva durante a garra e fica sem dano
de contato no farejo/preparo/recuperação. Garra estendida só alcança à frente.

Golpes do jogador continuam interrompendo os ataques. Modelos, mortes,
controles, cutscene, cenário, céu 1.5 e PSX preservados. R limpa os estados.

# Atualização 008 — habitantes e bosque vivos

Aplicar sobre o projeto completo Godot 4.7 entregue anteriormente, na pasta
de `project.godot`, com o editor fechado. Reabrir e jogar com F5.

Os 14 NPCs mantêm a orientação de descanso e suas atividades. A cabeça segue
o jogador suavemente dentro de 8 m, com giro limitado, inclusive no diálogo;
quando ele se afasta, volta à pose da atividade. O Vixxo recebeu um pivô de
pescoço montado com as próprias peças do GLB, sem mudar suas malhas.

Besouros: passada ligada ao deslocamento, bola rolando pela distância e antenas
atentas. Lagartos: respiração/farejo, passada diagonal, mandíbula, preparação
do bote e recuperação. Urso: atenção com a cabeça e farejo em quatro patas.
IA, velocidades, tempos de ataque, dano, HP, colisores e mortes foram mantidos.

Vento discreto na vegetação existente, sem desmontar o instancing. Atualiza
plantas próximas em 20 Hz, com pivô na base; árvores quase não inclinam,
folhas/flores/samambaias respondem mais. Pássaros fazem curvas e planeiam.
68 detalhes em 17 composições nas margens: samambaias com folhas dobradas,
troncos facetados com anéis e casca, raízes e folhas caídas, junto a cogumelos.
São cenas reutilizáveis em `Cenas/Natureza/Detalhes`, com malhas compartilhadas.
Os apoios seguem a inclinação original do terreno. Oito borboletas aparecem
perto do jogador e ficam ocultas na cutscene. Nenhum detalhe novo tem colisão.
A trilha, plataformas, itens, cutscene, céu 1.5 e shader PSX foram preservados.

Para editar: `Fase1/Vida/VidaBosque.tscn` contém as composições. `Vento Ativo`
em cada Vegetacao liga/desliga a animação das plantas. Testado no Godot 4.7.2.

# Referência do projeto completo Godot 4.7

Extraia em uma pasta nova e importe `project.godot` pelo Godot 4.7.
**F5 joga. Para assistir direto: `PreviaFinal.tscn` + F6; R repete.**
A pasta inclui todas as atualizações anteriores. Validação no Godot 4.7.2,
renderer Compatibility. Instruções e controles em `LEIA-ME.txt`.

A cutscene de Bunnyldu e Bibibunn agora usa poses por situação, olhares entre
os personagens, gestos com preparação e repouso, reações pontuais à magia e
à jaula, recuperação após o golpe e passada baseada no deslocamento da fuga.
Piscadas e movimento de boca reutilizam as peças do modelo. A boca acompanha
o envelope do áudio original; não é captura facial nem sincronização fonética.
As transições locais são amostradas e misturadas de forma determinística.
Nenhuma malha ou áudio foi reexportado. Raízes dos atores, trajetória da jaula
e braço de sustentação da Bibi continuam com a coreografia original.

A importação 4.7.2 pode deixar o uso de COLOR_0 desativado nos materiais.
`Fase1/cores_vertices.gd` reativa as cores existentes nas cenas de cenário,
inclusive na vegetação instanciada, no editor e em execução. A geometria não muda.

A base da cena permanece em `Fase1/Completa/final.json.gz`, `Final.glb` e
`final.wav`. A direção fica em `Fase1/Completa/Cinema`: atuação, transições,
rig, envelope da fala, planos, luzes e áudio complementar. Enter revela e
avança as falas; luzes, volume, aves e controle são restaurados ao sair.

O Bosque Verde inclui o percurso completo, sete vãos grandes/checkpoints/
plataformas, 19 inimigos da fonte mais o urso aprovado, 14 NPCs, 13 caixas e
três segredos. Há saúde de três corações, combo, dano/arremesso, coleta e save.
Câmera e janela de salto da atualização 005 foram mantidas. Céu: energia 1.5.
As cenas reutilizáveis e exemplos continuam disponíveis para criar fases.
A Vila e a Fase 2 ainda não fazem parte da migração nativa. As tocas bônus
permanecem desativadas como na fonte. O jogo web original é preservado no repo.

F2 alterna o pacote PSX enviado pelo usuário com o visual original; começa
ligado. Shaders originais CC0 de Francisco Cidade em `addons/psx_shader`.
O adaptador conserva cores/texturas e restaura os materiais ao desligar.
Ajustes em `Fase1Trecho.tscn` > `FiltroPS1`: Ativado, Tamanho Pixel (3 padrão,
2 mais definido), Materiais 3d e Dithering. As mudanças valem ao reiniciar.
HUD e legendas ficam acima do filtro; materiais PSX não recebem sombras,
conforme o shader fornecido. A renderização 3D continua na resolução normal.

`export_presets.cfg` prepara Windows e Web. Instale os templates da mesma
versão do editor. Nesta entrega foram validados importação e execução Linux;
as exportações Windows/Web não foram executadas nem é teste na GPU do usuário.

Geradores no repositório: `tools/export_godot_phase1.cjs --rig-only` extrai os
nomes de pivôs sem reexportar geometria. O envelope vem do RMS de `final.wav`.
`tools/package_godot.py --cinema47` inclui fontes versionadas e manifesto SHA256,
sem caches de importação. `tools/test_godot_full.py` testa o ZIP independente.
