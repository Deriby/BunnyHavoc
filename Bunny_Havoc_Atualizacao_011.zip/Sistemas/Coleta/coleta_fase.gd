extends Node3D
## Contagem e efeitos compartilhados; cada cena cuida de seu comportamento.
signal mudou
var cenouras: int = 0
var quebradas: int = 0
var caixas: Array[Dictionary] = []
var frutas: Array[Dictionary] = []
var _jogador: CharacterBody3D
var _som: AudioStreamPlayer
var _partes: Array[Dictionary] = []
var _cursor: int = 0
const COLETA = preload("audio/coleta.wav")
const QUEBRA = preload("audio/caixa.wav")

@export var reiniciar_com_R: bool = true
@export var exibir_contador: bool = false
var _configurado: bool = false
var _inicio_original := Vector3.ZERO
var _contabilizadas: Dictionary={}
var _raiz: Node3D
var _contador: Label

func _ready() -> void:
	process_physics_priority = 14
	_autoconfigurar.call_deferred()

func _autoconfigurar() -> void:
	if _configurado:
		return
	var raiz := get_parent() as Node3D
	var jogador := raiz.find_child("Jogador", true, false) as CharacterBody3D
	if jogador != null:
		configurar(raiz, jogador)

func configurar(raiz: Node3D, jogador: CharacterBody3D) -> void:
	if _configurado:
		return
	_configurado = true
	_raiz = raiz
	_jogador = jogador
	_inicio_original = jogador.get("_inicio")
	_som = AudioStreamPlayer.new()
	add_child(_som)
	for node in raiz.find_children("*", "Node3D", true, false):
		if node.is_in_group("bh_caixas"):
			node.configurar_jogador(jogador)
			node.som_local = false
			node.connect("quebrada", _receber_caixa)
			node.connect("cenouras_liberadas", _receber_fruta)
			caixas.append({"node": node, "body": node.get_node("Colisao"), "reward": node.recompensa, "ground": node.global_position.y})
		elif node.is_in_group("bh_cenouras"):
			node.configurar_jogador(jogador)
			node.som_local = false
			node.connect("coletada", _receber_fruta)
			frutas.append({"node": node})
		elif node.is_in_group("bh_checkpoints"):
			node.configurar_jogador(jogador)
		elif node.is_in_group("bunny_havoc_inimigos") and node.has_signal("recompensa_ganha"):
			node.jogador = jogador
			node.connect("recompensa_ganha", adicionar_cenouras)
	if exibir_contador:
		var layer := CanvasLayer.new()
		add_child(layer)
		_contador = Label.new()
		_contador.position = Vector2(20, 112)
		_contador.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_contador.add_theme_font_size_override("font_size", 18)
		_contador.add_theme_constant_override("outline_size", 4)
		layer.add_child(_contador)
		mudou.connect(_atualizar_contador)
		_atualizar_contador()
	var geometry := BoxMesh.new()
	geometry.size = Vector3(0.12, 0.09, 0.16)
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("dda36c")
	for i in 24:
		var node := MeshInstance3D.new()
		node.mesh = geometry
		node.material_override = material
		node.visible = false
		add_child(node)
		_partes.append({"node": node, "life": 0.0, "velocity": Vector3.ZERO})

func _receber_fruta(valor: int, _origem: Node3D) -> void:
	adicionar_cenouras(valor)
	_som.stream = preload("audio/segredo.wav") if _origem.is_in_group("bh_segredos") else COLETA
	_som.play()

func adicionar_cenouras(valor: int) -> void:
	var marcos_antes: int = cenouras / 100
	cenouras += valor
	var vidas_extra: int = cenouras / 100 - marcos_antes
	if vidas_extra > 0 and is_instance_valid(_jogador):
		var saude: Node = _jogador.get_node_or_null("Saude")
		if saude != null:
			saude.vidas += vidas_extra
			saude.mudou.emit()
	mudou.emit()

func _receber_caixa(recompensa: int, node: Node3D) -> void:
	if _contabilizadas.has(node.get_instance_id()):return
	_contabilizadas[node.get_instance_id()]=true
	quebradas += 1
	adicionar_cenouras(recompensa)
	_som.stream = QUEBRA if node.gerar_estilhacos else preload("audio/metal.wav")
	_som.play()
	if not node.gerar_estilhacos:return
	for i in 11:
		var parte: Dictionary = _partes[_cursor]
		_cursor = (_cursor + 1) % _partes.size()
		parte.life = 0.42
		(parte.node as Node3D).global_position = node.global_position + node.basis * Vector3(0, 0.68, 0)
		(parte.node as Node3D).visible = true
		var a: float = i * 2.399
		parte.velocity = Vector3(cos(a) * 2.5, 1.5 + (i % 3) * 0.5, sin(a) * 2.5)
	mudou.emit()

func _physics_process(dt: float) -> void:
	for parte: Dictionary in _partes:
		if float(parte.life) <= 0.0:
			continue
		parte.life = maxf(0.0, float(parte.life) - dt)
		var node: Node3D = parte.node
		node.visible = float(parte.life) > 0.0
		node.position += (parte.velocity as Vector3) * dt
		parte.velocity = (parte.velocity as Vector3) - Vector3.UP * dt * 9.0
		node.rotation += Vector3(3, 5, 2) * dt

func reiniciar() -> void:
	_contabilizadas.clear()
	cenouras = 0
	quebradas = 0
	for caixa: Dictionary in caixas:
		caixa.node.reiniciar()
	for fruta: Dictionary in frutas:
		fruta.node.reiniciar()
	for parte: Dictionary in _partes:
		parte.life = 0.0
		(parte.node as Node3D).visible = false
	mudou.emit()

func _atualizar_contador() -> void:
	_contador.text = "Cenouras: %d    Caixas: %d/%d" % [cenouras, quebradas, caixas.size()]

func _input(event: InputEvent) -> void:
	if not reiniciar_com_R or not _configurado:
		return
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode == KEY_R or event.keycode == KEY_R):
		reiniciar()
		_jogador.set("_inicio", _inicio_original)
		for node in _raiz.find_children("*", "Node3D", true, false):
			if node.is_in_group("bh_checkpoints"):
				node.reiniciar()
			elif node.is_in_group("bunny_havoc_inimigos") and node.has_signal("recompensa_ganha"):
				node.reiniciar()
