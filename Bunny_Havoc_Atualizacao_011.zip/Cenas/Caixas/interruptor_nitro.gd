extends "caixa.gd"
## O bloco ! aciona todas as Nitros da fase e permanece como apoio metálico.
var ativado: bool=false
var _rebote_pendente: bool=false
var _material: StandardMaterial3D
func _ready() -> void:
	super._ready()
	_material=$Visual/Frente.material_override.duplicate()
	for n: MeshInstance3D in $Visual.find_children("Painel*","MeshInstance3D",false,false)+[$Visual/Frente]:n.material_override=_material
func pisar() -> void:
	_rebote_pendente=not ativado
	quebrar()
func _rebater() -> void:
	if _rebote_pendente:
		super._rebater();_rebote_pendente=false
func quebrar() -> void:
	if ativado:return
	ativado=true
	_material.albedo_color=Color("768376").srgb_to_linear()
	$Visual.scale.y=0.94
	for label: Label3D in $Visual.find_children("Sinal*","Label3D",false,false):label.text=""
	quebrada.emit(0,self)
	for caixa in get_tree().get_nodes_in_group("bh_nitro"):
		if caixa.visible:caixa.detonar()
func destruir_por_explosao() -> void:pass
func reiniciar() -> void:
	super.reiniciar()
	ativado=false;_rebote_pendente=false
	_material.albedo_color=Color("4aaf43").srgb_to_linear()
	$Visual.scale=Vector3.ONE
	for label: Label3D in $Visual.find_children("Sinal*","Label3D",false,false):label.text="!"
