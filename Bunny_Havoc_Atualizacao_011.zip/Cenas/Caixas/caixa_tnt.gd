extends "caixa.gd"
## Pisão acende 3-2-1; golpe explode na hora. A explosão em cadeia é preservada.
const Explosao = preload("res://Cenas/Efeitos/explosao.tscn")
signal explodiu
var pavio: float = 0.0
var _contagem: Label3D

func _ready() -> void:
	super._ready()
	_contagem=Label3D.new();_contagem.font_size=100;_contagem.pixel_size=0.005
	_contagem.position.y=1.75;_contagem.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	_contagem.modulate=Color("ffdf81");_contagem.outline_modulate=Color("562934")
	_contagem.visible=false;add_child(_contagem)

func _physics_process(dt: float) -> void:
	if pavio > 0.0 and visible and pode_interagir():
		pavio = maxf(0.0, pavio - dt)
		_contagem.text=str(maxi(1,ceili(pavio)))
		$Visual.scale = Vector3.ONE * (1.035 if int(pavio * 10) % 2 == 0 else 1.0)
		if pavio == 0.0:
			detonar()
	super._physics_process(dt)

func pisar() -> void:quebrar()
func bater_por_baixo() -> void:quebrar()
func golpear() -> void:detonar()
func quebrar() -> void:
	if visible and pavio <= 0.0:
		pavio = 3.0
		_contagem.text="3";_contagem.visible=true
		$Som.stream = preload("res://Sistemas/Coleta/audio/tnt_pavio.wav")
		$Som.play()

func detonar() -> void:
	if not visible:
		return
	var origem: Vector3 = global_position + Vector3.UP * 0.68
	visible = false
	_contagem.visible=false
	pavio = 0.0
	$Colisao.collision_layer = 0
	quebrada.emit(0, self)
	explodiu.emit()
	var efeito := Explosao.instantiate() as Node3D
	get_tree().current_scene.add_child(efeito)
	efeito.global_position = origem
	for caixa in get_tree().get_nodes_in_group("bh_caixas"):
		if not caixa.visible or caixa.global_position.distance_to(global_position) > 4.45:
			continue
		if caixa.has_method("detonar"):
			caixa.detonar()
		else:
			var anterior: int = caixa.recompensa
			caixa.recompensa = 0
			caixa.destruir_por_explosao()
			caixa.recompensa = anterior
	for inimigo in get_tree().get_nodes_in_group("bunny_havoc_inimigos"):
		if inimigo.visible and inimigo.global_position.distance_to(origem) < 5.05:
			if inimigo.has_method("atingido_por_explosao"):
				inimigo.atingido_por_explosao()
			else:
				inimigo.receber_golpe(99, 0.0, false)
	if localizar_jogador() != null and (_jogador.global_position + Vector3.UP * 0.9).distance_to(origem) < 4.9:
		var vida: Node = _jogador.get_node_or_null("Saude")
		if vida != null:
			vida.receber_dano(3, self)

func reiniciar() -> void:
	_contagem.visible=false
	pavio = 0.0
	$Visual.scale = Vector3.ONE
	super.reiniciar()
