extends "caixa.gd"
## Mola de madeira: lançamento alto, dez quiques ou um golpe para quebrar.
var intervalo: float=0.0
var quiques: int=0
func _physics_process(dt: float) -> void:
	intervalo=maxf(0,intervalo-dt)
	$Visual.scale.y=lerpf($Visual.scale.y,0.76 if intervalo>0 else 1.0,minf(1,dt*17))
	super._physics_process(dt)
func pisar() -> void:
	if not visible or intervalo>0:return
	intervalo=0.25;quiques+=1
	$Som.stream=preload("res://Sistemas/Coleta/audio/mola.wav");$Som.play()
	if quiques>=10:super.quebrar()
func bater_por_baixo() -> void:pisar()
func quebrar() -> void:super.quebrar()
func destruir_por_explosao() -> void:super.quebrar()
func reiniciar() -> void:
	intervalo=0;quiques=0;$Visual.scale=Vector3.ONE
	super.reiniciar()
