extends "caixa.gd"
## Cinco quiques dão duas cenouras cada; golpe quebra cedo e dá só uma.
var quiques: int=0
var _compressao: float=0.0
func _physics_process(dt: float) -> void:
	_compressao=maxf(0,_compressao-dt)
	$Visual.scale.y=1.0-0.20*sin(clampf(_compressao/0.20,0,1)*PI)
	super._physics_process(dt)
func pisar() -> void:
	if not visible:return
	quiques+=1;_compressao=0.20
	cenouras_liberadas.emit(2,self)
	if quiques>=5:
		_finalizar(0)
	else:
		$Som.play()
func bater_por_baixo() -> void:pisar()
func quebrar() -> void:
	if visible:_finalizar(1)
func _finalizar(valor: int) -> void:
	var anterior: int=recompensa
	recompensa=valor
	super.quebrar()
	recompensa=anterior
func destruir_por_explosao() -> void:
	if visible:_finalizar(0)
func reiniciar() -> void:
	quiques=0;_compressao=0;$Visual.scale=Vector3.ONE
	super.reiniciar()
