extends RefCounted
## Une peças estáticas do mesmo membro/material; preserva cada pivô animado.
static var _cache: Dictionary={}
static var _assinaturas: Dictionary={}
static var _materiais: Dictionary={}
static func _material_equivalente(material: BaseMaterial3D) -> BaseMaterial3D:
	var id: int=material.get_instance_id()
	if _assinaturas.has(id):return _assinaturas[id]
	var propriedades: Array=[]
	for p: Dictionary in material.get_property_list():
		if not (int(p.usage)&PROPERTY_USAGE_STORAGE) or String(p.name).begins_with("resource_"):continue
		var valor: Variant=material.get(p.name)
		if valor is Resource:valor=valor.get_instance_id()
		propriedades.append([p.name,valor])
	var assinatura: String=var_to_bytes(propriedades).hex_encode().sha256_text()
	if not _materiais.has(assinatura):_materiais[assinatura]=material
	_assinaturas[id]=_materiais[assinatura]
	return _materiais[assinatura]
static func agrupar(raiz: Node3D) -> void:
	if raiz.has_meta("bh_lotes_personagens"):return
	var registros: Array=[]
	_visitar(raiz,registros)
	raiz.set_meta("bh_lotes_personagens",registros)
static func _visitar(pai: Node3D,registros: Array) -> void:
	var grupos: Dictionary={}
	for n in pai.get_children():
		if n is Node3D and not n is MeshInstance3D:_visitar(n,registros)
		if not n is MeshInstance3D:continue
		if not n.visible or n.mesh==null or n.mesh.get_surface_count()!=1 or n.transform.basis.determinant()<=0:continue
		var material: Material=n.get_active_material(0)
		if not material is BaseMaterial3D or material.transparency!=BaseMaterial3D.TRANSPARENCY_DISABLED:continue
		material=_material_equivalente(material)
		n.material_override=material
		# Pálpebras, sobrancelhas e casco mantêm nós independentes para animação.
		if not String(n.name).begins_with("Malha_"):continue
		var chave: String=str(material.get_instance_id())+":"+str(n.cast_shadow)+":"+str(n.layers)
		if not grupos.has(chave):grupos[chave]={"material":material,"pecas":[]}
		grupos[chave].pecas.append(n)
	for grupo: Dictionary in grupos.values():
		var pecas: Array=grupo.pecas
		if pecas.size()<2:continue
		var material: Material=grupo.material
		var chave: String=str(material.get_instance_id())
		for p: MeshInstance3D in pecas:chave+="/"+str(p.mesh.get_rid())+":"+str(p.transform)
		if not _cache.has(chave):
			var tool:=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
			for p: MeshInstance3D in pecas:tool.append_from(p.mesh,0,p.transform)
			tool.set_material(material);_cache[chave]=tool.commit()
		var lote:=MeshInstance3D.new();lote.name="LoteVisual"+str(registros.size())
		lote.mesh=_cache[chave];lote.cast_shadow=pecas[0].cast_shadow;lote.layers=pecas[0].layers
		pai.add_child(lote)
		for p: MeshInstance3D in pecas:
			p.visible=false;p.set_meta("bh_somente_autoria",true)
		registros.append({"lote":lote,"pecas":pecas})
