extends RefCounted
## Distribui triângulos originais em setores; não altera colisão nem atributos.
const TAMANHO: float=16.0
static func dividir(raiz: Node3D) -> void:
	for source: MeshInstance3D in raiz.find_children("*","MeshInstance3D",true,false):
		if source.mesh==null or source.has_meta("bh_somente_autoria"):continue
		var setores: Array=[]
		for surface in source.mesh.get_surface_count():
			if source.mesh.surface_get_primitive_type(surface)!=Mesh.PRIMITIVE_TRIANGLES:continue
			var data: Array=source.mesh.surface_get_arrays(surface)
			if data[Mesh.ARRAY_BONES]!=null and not data[Mesh.ARRAY_BONES].is_empty():continue
			var vertices: PackedVector3Array=data[Mesh.ARRAY_VERTEX]
			var indices:=PackedInt32Array()
			if data[Mesh.ARRAY_INDEX]!=null:indices=data[Mesh.ARRAY_INDEX]
			var total: int=indices.size() if not indices.is_empty() else vertices.size()
			var grupos: Dictionary={}
			for t in range(0,total,3):
				var face: Array[int]=[]
				for j in 3:face.append(indices[t+j] if not indices.is_empty() else t+j)
				var centro: Vector3=source.global_transform*((vertices[face[0]]+vertices[face[1]]+vertices[face[2]])/3.0)
				var chave:=Vector2i(floori(centro.x/TAMANHO),floori(centro.z/TAMANHO))
				if not grupos.has(chave):grupos[chave]=[]
				grupos[chave].append_array(face)
			for face_indices: Array in grupos.values():
				var arrays: Array=[];arrays.resize(Mesh.ARRAY_MAX)
				for attribute in [Mesh.ARRAY_VERTEX,Mesh.ARRAY_NORMAL,Mesh.ARRAY_COLOR,Mesh.ARRAY_TEX_UV,Mesh.ARRAY_TEX_UV2,Mesh.ARRAY_TANGENT]:
					if data[attribute]==null or data[attribute].is_empty():continue
					var selecionado: Variant=data[attribute].duplicate();selecionado.resize(0)
					for index: int in face_indices:
						if attribute==Mesh.ARRAY_TANGENT:
							for j in 4:selecionado.append(data[attribute][index*4+j])
						else:selecionado.append(data[attribute][index])
					arrays[attribute]=selecionado
				var mesh:=ArrayMesh.new();mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
				var node:=MeshInstance3D.new();node.name=String(source.name)+"_Setor_"+str(setores.size())
				node.set_meta("bh_setor_terreno",true)
				node.mesh=mesh;node.material_override=source.get_active_material(surface)
				node.transform=source.transform;node.cast_shadow=source.cast_shadow;node.layers=source.layers
				source.get_parent().add_child(node);setores.append(node)
		if not setores.is_empty():
			source.visible=false;source.set_meta("bh_somente_autoria",true)
			source.set_meta("bh_setores_terreno",setores)
