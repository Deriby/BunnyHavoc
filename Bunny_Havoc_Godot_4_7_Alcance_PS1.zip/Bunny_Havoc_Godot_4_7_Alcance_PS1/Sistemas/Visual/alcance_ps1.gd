extends Node
## Corte real de desenho em torno do jogador. Não toca em visibilidade lógica.
var raio: float=55.0
var raio_atual: float=55.0
var centro:=Vector3.ZERO
var desenhadas: int=0
var ocultas: int=0
var registros: Dictionary={}
var fase: Node3D
var jogador: Node3D
var camera: Camera3D
var ambiente: Environment
var _ceu: ProceduralSkyMaterial
var _originais: Dictionary={}
var _tempo: float=0
var _anterior:=Vector3(INF,INF,INF)
var _cinema: bool=false
var _configurado: bool=false
func _ready() -> void:
	fase=get_parent().get_parent()
	_configurar.call_deferred()
func _configurar() -> void:
	jogador=fase.get_node("Jogador");camera=fase.get_node("Camera3D")
	ambiente=fase.get_node("WorldEnvironment").environment
	_originais={"far":camera.far,"begin":ambiente.fog_depth_begin,"end":ambiente.fog_depth_end}
	if ambiente.sky!=null and ambiente.sky.sky_material is ProceduralSkyMaterial:
		_ceu=ambiente.sky.sky_material
		_originais["ground_bottom"]=_ceu.ground_bottom_color;_originais["ground_horizon"]=_ceu.ground_horizon_color
		# O fundo que surge atrás do corte deve continuar a névoa, não expor
		# o hemisfério marrom padrão do céu como uma faixa flutuante.
		var cor_fundo: Color=ambiente.fog_light_color/maxf(.01,ambiente.background_energy_multiplier)
		cor_fundo.a=1
		_ceu.ground_bottom_color=cor_fundo;_ceu.ground_horizon_color=cor_fundo
	_visitar(fase)
	get_tree().node_added.connect(_novo_no)
	_configurado=true;atualizar(true)
func _visitar(node: Node) -> void:
	if node.has_meta("bh_somente_autoria"):return
	if node is GeometryInstance3D:_registrar(node)
	for filho in node.get_children():_visitar(filho)
func _novo_no(node: Node) -> void:
	if node is GeometryInstance3D:_registrar_depois.call_deferred(node)
func _registrar_depois(node: Node) -> void:
	if is_instance_valid(node) and fase.is_ancestor_of(node):_registrar(node)
func _registrar(node: GeometryInstance3D) -> void:
	if registros.has(node.get_instance_id()):return
	var parent: Node=node
	var estatico: bool=false
	while parent!=null and parent!=fase:
		if parent.has_meta("bh_somente_autoria"):return
		# O filme controla seus próprios atores e sua própria visibilidade.
		if parent.name==&"FinalOriginal":return
		if parent.name==&"Bosque" or parent.name==&"Detalhes":estatico=true
		parent=parent.get_parent()
	var local: AABB=node.get_aabb()
	if node is MultiMeshInstance3D and node.multimesh!=null:local=node.multimesh.custom_aabb
	elif node is MeshInstance3D and node.mesh!=null:local=node.mesh.get_aabb()
	registros[node.get_instance_id()]={"node":node,"layers":node.layers,"local":local,"bounds":node.global_transform*local,"static":estatico}
func definir_raio(valor: float) -> void:
	raio=valor
	if _configurado:atualizar(true)
func _process(dt: float) -> void:
	if not _configurado:return
	_tempo+=dt
	var filme: Node=fase.get_node_or_null("FinalOriginal")
	var cinema: bool=filme!=null and bool(filme.get("ativo"))
	var alvo: Vector3=camera.global_position if cinema else jogador.global_position
	if _tempo>=.1 or alvo.distance_squared_to(_anterior)>4 or cinema!=_cinema:atualizar(cinema!=_cinema)
func atualizar(forcar: bool=false) -> void:
	if not _configurado:return
	var filme: Node=fase.get_node_or_null("FinalOriginal")
	var cinema: bool=filme!=null and bool(filme.get("ativo"))
	var mudou: bool=cinema!=_cinema or forcar
	_cinema=cinema;raio_atual=90.0 if cinema else raio
	centro=camera.global_position if cinema else jogador.global_position
	_anterior=centro;_tempo=0
	# Limita também vértices/fragmentos dos setores que cruzam o limite.
	camera.far=raio_atual+(30.0 if cinema else camera.global_position.distance_to(jogador.global_position)+18.0)
	if mudou:
		ambiente.fog_depth_begin=40.0 if cinema else raio*.35
		ambiente.fog_depth_end=75.0 if cinema else raio*.62
		var filtro: Node=fase.get_node_or_null("FiltroPS1")
		if filtro!=null:filtro.materiais.sincronizar_nevoa()
	desenhadas=0;ocultas=0
	var mortos: Array=[]
	for id in registros:
		var record: Dictionary=registros[id]
		if not is_instance_valid(record.node):mortos.append(id);continue
		var bounds: AABB=record.bounds if record.static else record.node.global_transform*record.local
		var dx: float=maxf(bounds.position.x-centro.x,maxf(0,centro.x-bounds.end.x))
		var dz: float=maxf(bounds.position.z-centro.z,maxf(0,centro.z-bounds.end.z))
		var perto: bool=dx*dx+dz*dz<=raio_atual*raio_atual
		var layers: int=record.layers if perto else 0
		if record.node.layers!=layers:record.node.layers=layers
		if perto:desenhadas+=1
		else:ocultas+=1
	for id in mortos:registros.erase(id)
func _exit_tree() -> void:
	for record: Dictionary in registros.values():
		if is_instance_valid(record.node):record.node.layers=record.layers
	if is_instance_valid(camera) and not _originais.is_empty():camera.far=_originais.far
	if ambiente!=null and not _originais.is_empty():
		ambiente.fog_depth_begin=_originais.begin;ambiente.fog_depth_end=_originais.end
	if _ceu!=null and _originais.has("ground_bottom"):
		_ceu.ground_bottom_color=_originais.ground_bottom;_ceu.ground_horizon_color=_originais.ground_horizon
