extends RefCounted
## Alterações opacas são notificadas no ponto de origem, sem varrer o cenário.
## BaseMaterial3D.changed não é emitido por alterações em albedo_color.
const CHAVE: StringName=&"bh_psx_cores"
static func definir(material: BaseMaterial3D,cor: Color) -> void:
	if material.albedo_color==cor:return
	material.albedo_color=cor
	var shaders: Dictionary=material.get_meta(CHAVE,{})
	for shader: ShaderMaterial in shaders.values():shader.set_shader_parameter("albedo_color",cor)
static func conectar(material: BaseMaterial3D,shader: ShaderMaterial) -> void:
	var shaders: Dictionary=material.get_meta(CHAVE,{})
	shaders[shader.get_instance_id()]=shader
	material.set_meta(CHAVE,shaders)
static func desconectar(material: BaseMaterial3D,shader: ShaderMaterial) -> void:
	var shaders: Dictionary=material.get_meta(CHAVE,{})
	shaders.erase(shader.get_instance_id())
	if shaders.is_empty():material.remove_meta(CHAVE)
	else:material.set_meta(CHAVE,shaders)
