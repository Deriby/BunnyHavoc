extends RefCounted
## Adapta materiais em execução aos shaders originais do pacote enviado.
## Nunca grava no GLB. O F2 restaura os mesmos recursos/overrides anteriores.
const OPAQUE=preload("res://addons/psx_shader/shaders/psx.gdshader")
const DOUBLE=preload("res://addons/psx_shader/shaders/psx_double_sided.gdshader")
const TRANSPARENT=preload("res://addons/psx_shader/shaders/psx_transparent.gdshader")
const ADDITIVE=preload("res://addons/psx_shader/shaders/psx_additive.gdshader")
const Cores=preload("cores_material.gd")
var entradas: Dictionary={}
var materiais: Dictionary={}
var animados: Dictionary={}
var pixel_size: float=3.0
var ambiente: Environment
var _branco: ImageTexture
var _tempo_limpeza: float=0.0

func iniciar(raiz: Node) -> void:
	var env: WorldEnvironment=raiz.find_child("WorldEnvironment",true,false)
	ambiente=env.environment if env!=null else null
	if _branco==null:
		_branco=_textura(Color.WHITE)
	_visitar(raiz)

func _visitar(node: Node) -> void:
	if _somente_autoria(node):return
	if node is MeshInstance3D or node is MultiMeshInstance3D:adicionar(node)
	for filho in node.get_children():_visitar(filho)

func _somente_autoria(node: Node) -> bool:
	if node.has_meta("bh_somente_autoria"):return true
	# Irmãos posteriores ao FiltroPS1 ainda podem não ter executado _ready.
	var parent: Node=node.get_parent()
	return node.name==&"Instancias" and parent!=null and parent.has_method("pose_vento") and bool(parent.get("otimizar_em_execucao"))

func _textura(cor: Color) -> ImageTexture:
	var imagem:=Image.create(1,1,false,Image.FORMAT_RGBA8)
	imagem.fill(cor)
	return ImageTexture.create_from_image(imagem)

func _converter(original: Material, usados: Array) -> Material:
	if not original is BaseMaterial3D:
		return original
	var id: int=original.get_instance_id()
	usados.append(id)
	if materiais.has(id):
		materiais[id].usos+=1
		return materiais[id].shader
	var base:=original as BaseMaterial3D
	var novo:=ShaderMaterial.new()
	var alfa: bool=base.transparency==BaseMaterial3D.TRANSPARENCY_ALPHA or base.transparency==BaseMaterial3D.TRANSPARENCY_ALPHA_DEPTH_PRE_PASS
	novo.shader=ADDITIVE if base.blend_mode==BaseMaterial3D.BLEND_MODE_ADD else TRANSPARENT if alfa else DOUBLE if base.cull_mode==BaseMaterial3D.CULL_DISABLED else OPAQUE
	novo.render_priority=base.render_priority
	novo.set_shader_parameter("albedo_tex",base.albedo_texture if base.albedo_texture!=null else _branco)
	novo.set_shader_parameter("albedo_color",base.albedo_color)
	novo.set_shader_parameter("vertex_color_mix",1.0 if base.vertex_color_use_as_albedo else 0.0)
	novo.set_shader_parameter("pixel_size",pixel_size)
	novo.set_shader_parameter("lit",0.0 if base.shading_mode==BaseMaterial3D.SHADING_MODE_UNSHADED else 1.0)
	novo.set_shader_parameter("uv_scale",Vector2(base.uv1_scale.x,base.uv1_scale.y))
	novo.set_shader_parameter("uv_offset",Vector2(base.uv1_offset.x,base.uv1_offset.y))
	if base.transparency==BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR:
		novo.set_shader_parameter("cutout",base.alpha_scissor_threshold)
	if base.billboard_mode!=BaseMaterial3D.BILLBOARD_DISABLED:
		novo.set_shader_parameter("billboard",2 if base.billboard_mode==BaseMaterial3D.BILLBOARD_FIXED_Y else 1)
	if ambiente!=null and ambiente.fog_enabled:
		novo.set_shader_parameter("fog_amount",1.0)
		novo.set_shader_parameter("fog_color",ambiente.fog_light_color)
		novo.set_shader_parameter("fog_start",ambiente.fog_depth_begin)
		novo.set_shader_parameter("fog_end",ambiente.fog_depth_end)
	if base.emission_enabled:
		novo.set_shader_parameter("emission_tex",base.emission_texture if base.emission_texture!=null else _textura(base.emission))
		novo.set_shader_parameter("emission_strength",base.emission_energy_multiplier)
	else:
		novo.set_shader_parameter("emission_strength",0.0)
	materiais[id]={"original":base,"shader":novo,"cor":base.albedo_color,"usos":1}
	Cores.conectar(base,novo)
	# Fades existentes continuam aceitando escrita direta; opacos notificam a cor.
	if alfa or base.has_meta("bh_psx_animado"):animados[id]=materiais[id]
	return novo

func adicionar(node: Node) -> void:
	if not is_instance_valid(node) or entradas.has(node.get_instance_id()):return
	var ancestral: Node=node
	while ancestral!=null:
		if _somente_autoria(ancestral):return
		ancestral=ancestral.get_parent()
	if node is MultiMeshInstance3D:
		if node.multimesh==null or node.multimesh.mesh==null:return
		var usados: Array=[]
		var original: Material=node.material_override
		var source: Material=original if original!=null else node.multimesh.mesh.surface_get_material(0)
		entradas[node.get_instance_id()]={"node":node,"override":original,"surfaces":[],"ids":usados,"sombras":node.cast_shadow}
		node.material_override=_converter(source,usados)
		_otimizar_sombras(node)
		return
	if not node is MeshInstance3D:return
	var mesh:=node as MeshInstance3D
	if mesh.mesh==null:return
	var usados: Array=[]
	var entry: Dictionary={"node":mesh,"override":mesh.material_override,"surfaces":[],"ids":usados,"sombras":mesh.cast_shadow}
	if mesh.material_override!=null:
		mesh.material_override=_converter(mesh.material_override,usados)
	else:
		for i in mesh.mesh.get_surface_count():
			entry.surfaces.append(mesh.get_surface_override_material(i))
			mesh.set_surface_override_material(i,_converter(mesh.get_active_material(i),usados))
	entradas[mesh.get_instance_id()]=entry
	_otimizar_sombras(mesh)

func _otimizar_sombras(mesh: GeometryInstance3D) -> void:
	# O pacote enviado usa shadows_disabled em todas as variantes: o mapa não
	# aparece no PSX, mas seus objetos ainda estavam sendo desenhados nas sombras.
	var ativos: Array=[]
	if mesh.material_override!=null:ativos.append(mesh.material_override)
	elif mesh is MeshInstance3D:
		for i in mesh.mesh.get_surface_count():ativos.append(mesh.get_active_material(i))
	if not ativos.is_empty() and ativos.all(func(m):return m is ShaderMaterial and m.shader in [OPAQUE,DOUBLE,TRANSPARENT,ADDITIVE]):
		mesh.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func atualizar(dt: float) -> void:
	# O diretor original continua animando os BaseMaterial3D, inclusive fades.
	for m: Dictionary in animados.values():
		var cor: Color=m.original.albedo_color
		if cor!=m.cor:
			m.shader.set_shader_parameter("albedo_color",cor)
			m.cor=cor
	_tempo_limpeza+=dt
	if _tempo_limpeza<2.0:return
	_tempo_limpeza=0.0
	for id in entradas.keys():
		if not is_instance_valid(entradas[id].node):
			_liberar(entradas[id]);entradas.erase(id)

func sincronizar_nevoa() -> void:
	if ambiente==null:return
	for m: Dictionary in materiais.values():
		m.shader.set_shader_parameter("fog_amount",1.0 if ambiente.fog_enabled else 0.0)
		m.shader.set_shader_parameter("fog_start",ambiente.fog_depth_begin)
		m.shader.set_shader_parameter("fog_end",ambiente.fog_depth_end)
		m.shader.set_shader_parameter("fog_color",ambiente.fog_light_color)

func _liberar(entry: Dictionary) -> void:
	for id in entry.ids:
		materiais[id].usos-=1
		if materiais[id].usos==0:
			Cores.desconectar(materiais[id].original,materiais[id].shader)
			animados.erase(id);materiais.erase(id)

func parar() -> void:
	for entry in entradas.values():
		if not is_instance_valid(entry.node):continue
		var mesh: GeometryInstance3D=entry.node
		mesh.material_override=entry.override
		mesh.cast_shadow=entry.sombras
		if mesh is MeshInstance3D:
			for i in entry.surfaces.size():mesh.set_surface_override_material(i,entry.surfaces[i])
	for m: Dictionary in materiais.values():Cores.desconectar(m.original,m.shader)
	entradas.clear();materiais.clear();animados.clear()
