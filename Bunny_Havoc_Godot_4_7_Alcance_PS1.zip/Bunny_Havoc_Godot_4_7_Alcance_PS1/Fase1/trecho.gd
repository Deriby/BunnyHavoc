extends Node3D
## Dois recortes contínuos: composição extraída e sistemas compartilhados.
const CameraFase = preload("camera_fase.gd")
var layout: Dictionary
var itens: Node3D
var trilho: RefCounted = CameraFase.new()
var jogador: CharacterBody3D
var combate: Node3D
var saude: Node
var checkpoint_ativo: bool = false
var concluido: bool = false
var plataformas: Array[AnimatableBody3D] = []
var _contador: Label
var _mensagem: Label
var _estatuas: Array[Node3D] = []
var checkpoint_z: float = 8.0
var _extras: Array[Node3D] = []
var final: Node3D
var _resultado: Control
var _total_mortes: int = 0
var _tempo_jogo: float = 0.0
var _hud_oculto: Array[CanvasLayer] = []

func _ready() -> void:
	process_physics_priority = 20
	layout = JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/layout.json")) as Dictionary
	var extensao: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/Trecho2/layout.json"))
	layout.physicalFaces.append_array(extensao.physicalFaces)
	layout.bounds.endZ = extensao.bounds.endZ
	for key in ["heightKnots", "openAreas", "pits"]:
		layout[key] = extensao[key]
	var encontro: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/Trecho3/layout.json"))
	layout.physicalFaces.append_array(encontro.physicalFaces)
	layout.bounds.endZ = encontro.bounds.endZ
	var depois: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/Trecho4/layout.json"))
	layout.physicalFaces.append_array(depois.physicalFaces)
	layout.bounds.endZ = depois.bounds.endZ
	var completa: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/Completa/layout.json"))
	layout.physicalFaces.append_array(completa.physicalFaces)
	layout.bounds.endZ = completa.bounds.endZ
	layout.pits = completa.pits
	jogador = $Jogador as CharacterBody3D
	combate = $Combate as Node3D
	combate.detectar_queda = false
	saude = jogador.get_node("Saude")
	_criar_colisao()
	itens = $Coleta
	itens.configurar(self, jogador)
	itens.connect("mudou", _atualizar_hud)
	for node in $Objetos.find_children("*", "Node3D", true, false):
		if node is AnimatableBody3D:
			plataformas.append(node)
		if node.is_in_group("bh_checkpoints"):
			_estatuas.append(node)
			node.somente_avanco = true
			node.connect("ativado", _ativar_checkpoint)
		if node.scene_file_path.get_file() in ["Besouro.tscn", "Lagarto.tscn"]:
			node.jogador = jogador
			node.terreno = trilho
			_extras.append(node)
		if node.has_signal("explodiu"):
			node.connect("explodiu", _impacto_explosao)
		if node.has_method("_animar_rotina") and node.has_method("fechar"):
			node.configurar_jogador(jogador)
			node.terreno = trilho
			_extras.append(node)
	var urso: CharacterBody3D = combate.urso
	urso.global_position = Vector3(0, 0, -36)
	urso.set("_inicio", urso.global_position)
	urso.collision_mask = 5
	urso.connect("derrotado", _urso_derrotado)
	trilho.configurar($Camera3D, jogador, layout.cameraAnchors, layout)
	trilho.atualizar(0.0)
	saude.connect("renasceu", _renascer)
	var layer := CanvasLayer.new()
	add_child(layer)
	_contador = _label(layer, Vector2(20, 112), 18)
	_mensagem = _label(layer, Vector2(20, 140), 16)
	_mensagem.text = "Bosque Verde — siga a trilha e atravesse o primeiro vão"
	_atualizar_hud()
	for node in combate.get_node("HUD").get_children():
		if node is Label and node.text.begins_with("WASD"):
			node.text = "WASD / setas: mover   K / Ctrl: correr   Espaço: pular   J / Shift: combo   R: reiniciar fase"
	var musica := AudioStreamPlayer.new()
	musica.name = "MusicaBosque"
	var stream := preload("audio/phase-1-theme.mp3").duplicate() as AudioStreamMP3
	stream.loop = true
	musica.stream = stream
	musica.volume_db = -14.0
	add_child(musica)
	musica.play()
	final = preload("Completa/final.gd").new()
	final.name = "FinalOriginal"
	add_child(final)
	final.connect("terminou", _concluir_fase)
	var pensamentos: Node3D = preload("Completa/pensamentos.gd").new()
	pensamentos.name = "Pensamentos"
	jogador.add_child(pensamentos)

func _label(layer: CanvasLayer, pos: Vector2, size: int) -> Label:
	var label := Label.new()
	label.position = pos
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_color_override("font_color", Color("fff0dc"))
	label.add_theme_color_override("font_outline_color", Color("241335"))
	label.add_theme_constant_override("outline_size", 4)
	label.add_theme_font_size_override("font_size", size)
	layer.add_child(label)
	return label

func _atualizar_hud() -> void:
	if _contador != null:
		var segredos: int = 0
		for node in get_tree().get_nodes_in_group("bh_segredos"):
			if not node.visible:
				segredos += 1
		_contador.text = "Cenouras: %d    Caixas: %d/%d    Segredos: %d/3" % [itens.cenouras, itens.quebradas, itens.caixas.size(), segredos]

func _criar_colisao() -> void:
	var piso := StaticBody3D.new()
	piso.name = "PisoOriginal"
	var collision := CollisionShape3D.new()
	var shape := ConcavePolygonShape3D.new()
	var faces := PackedVector3Array()
	for point: Array in layout.physicalFaces:
		faces.append(Vector3(float(point[0]), float(point[1]), float(point[2])))
	shape.backface_collision = true
	shape.set_faces(faces)
	collision.shape = shape
	piso.add_child(collision)
	add_child(piso)
	# O corredor alarga na clareira, seguindo wp(z), sem degraus laterais.
	var laterais := StaticBody3D.new()
	laterais.name = "LimitesTrilha"
	var forma := ConcavePolygonShape3D.new()
	var pontos := PackedVector3Array()
	for side in [-1, 1]:
		for z in range(int(layout.bounds.endZ) - 1, 13):
			var x0: float = side * (_largura(z) - 0.15)
			var x1: float = side * (_largura(z + 1) - 0.15)
			pontos.append_array(PackedVector3Array([Vector3(x0,-10,z),Vector3(x1,-10,z+1),Vector3(x1,24,z+1),Vector3(x0,-10,z),Vector3(x1,24,z+1),Vector3(x0,24,z)]))
	forma.backface_collision = true
	forma.set_faces(pontos)
	var col := CollisionShape3D.new()
	col.shape = forma
	laterais.add_child(col)
	add_child(laterais)
	_limite(Vector3(0, 2, 12.8), Vector3(8, 24, 0.8))
	_limite(Vector3(0, 2, float(layout.bounds.endZ) - 1.3), Vector3(8, 24, 0.8))

func _largura(z: float) -> float:
	for area: Array in layout.openAreas:
		if z < float(area[0]) and z > float(area[1]):
			return 4.0 + 3.0 * pow(sin(PI * (float(area[0]) - z) / (float(area[0]) - float(area[1]))), 0.6)
	return 4.0

func _limite(pos: Vector3, tamanho: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = tamanho
	collision.shape = shape
	body.add_child(collision)
	add_child(body)

func _ativar_checkpoint(posicao: Vector3) -> void:
	checkpoint_ativo = true
	checkpoint_z = posicao.z
	_mensagem.text = "Checkpoint ativado! Você reaparece deste lado do vão."

func _urso_derrotado() -> void:
	(combate.get("_mensagem") as Label).text = "Urso derrotado! Continue pela trilha."

func _impacto_explosao() -> void:
	combate.set("_shake", 0.65)
	combate.set("_forca_shake", 1.0)

func _renascer() -> void:
	_total_mortes += 1
	trilho.pronto = false
	_mensagem.text = "Retorno ao checkpoint" if checkpoint_ativo else "Tente novamente — cenouras e caixas coletadas foram mantidas"

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode == KEY_R or event.keycode == KEY_R):
		final.parar()
		for hud in _hud_oculto:
			if is_instance_valid(hud):
				hud.visible = true
		_hud_oculto.clear()
		if is_instance_valid(_resultado):
			_resultado.get_parent().queue_free()
		var musica: AudioStreamPlayer = get_node("MusicaBosque")
		if not musica.playing:
			musica.play()
		_tempo_jogo = 0.0
		_total_mortes = 0
		checkpoint_ativo = false
		checkpoint_z = 8.0
		concluido = false
		jogador.set("_inicio", Vector3(0, 0, 8))
		itens.reiniciar()
		trilho.pronto = false
		for estatua in _estatuas:
			estatua.reiniciar()
		for extra in _extras:
			if extra.has_method("fechar"):
				extra.fechar()
			if extra.has_method("reiniciar"):
				extra.reiniciar()
		for efeito in get_tree().get_nodes_in_group("bh_efeitos_temporarios"):
			efeito.queue_free()
		_mensagem.text = "Bosque Verde — siga a trilha e atravesse o primeiro vão"
	elif event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode == KEY_M or event.keycode == KEY_M):
		AudioServer.set_bus_mute(0, not AudioServer.is_bus_mute(0))
		get_viewport().set_input_as_handled()

func _physics_process(dt: float) -> void:
	if final != null and (final.ativo or concluido):
		return
	if not combate.iniciado:
		(combate.get("_mensagem") as Label).text = "J / Shift repetido: giro → soco → soco final"
	_tempo_jogo += dt
	var ativo: bool = not saude.morto and not saude.encerrado
	var p: Vector3 = jogador.global_position
	if ativo and p.y < trilho.altura(p.z) - 1.5:
		saude.receber_dano(3, null, "pit")
	if ativo:
		if jogador.is_physics_processing() and jogador.is_on_floor() and p.z < -387.0:
			_iniciar_final()
			return
	trilho.atualizar(dt)
	# O trilho usa alvo próprio; a vibração nunca se acumula na posição da câmera.
	var shake: float = float(combate.get("_shake")) * float(combate.get("_forca_shake"))
	if shake > 0.0:
		$Camera3D.position += Vector3(sin(trilho.tempo * 67.0) * shake * 0.16, cos(trilho.tempo * 81.0) * shake * 0.10, 0)

func _iniciar_final() -> void:
	for hud: CanvasLayer in find_children("*","CanvasLayer",true,false):
		if hud.visible and not final.is_ancestor_of(hud) and not hud.is_in_group("bh_pos_processamento"):
			hud.visible = false
			_hud_oculto.append(hud)
	for extra in _extras:
		if extra.has_method("fechar"):
			extra.fechar()
	for caixa: Dictionary in itens.caixas:
		if caixa.node.position.z <= -368.0:
			caixa.node.visible = false
	_mensagem.text = ""
	final.iniciar(jogador, $Camera3D)

func _concluir_fase() -> void:
	concluido = true
	(get_node("MusicaBosque") as AudioStreamPlayer).stop()
	var progresso: Dictionary = {}
	var path: String = "user://progresso_bunny_havoc.json"
	if FileAccess.file_exists(path):
		var antigo: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
		if antigo is Dictionary:
			progresso = antigo
	progresso["fase1"] = {"concluida":true,"cenouras":itens.cenouras,"caixas":itens.quebradas,"vidas":saude.vidas,"coracoes":saude.coracoes}
	progresso["faseLiberada"] = maxi(int(progresso.get("faseLiberada",1)),2)
	var arquivo: FileAccess = FileAccess.open(path,FileAccess.WRITE)
	if arquivo != null:
		arquivo.store_string(JSON.stringify(progresso,"\t"))
	var layer:=CanvasLayer.new()
	layer.layer=40
	add_child(layer)
	_resultado=PanelContainer.new()
	layer.add_child(_resultado)
	_resultado.position=Vector2(225,150)
	_resultado.custom_minimum_size=Vector2(700,350)
	var box:=VBoxContainer.new()
	_resultado.add_child(box)
	var title:=Label.new()
	title.text="BOSQUE VERDE CONCLUÍDO!"
	title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size",30)
	box.add_child(title)
	var dados_resultado:=Label.new()
	dados_resultado.text="Bunnyck parte atrás de Bibibunn!\n\nCenouras: %d   Caixas: %d/%d\nVidas: %d   Corações: %d\n\nProgresso salvo. Obrigado por jogar!\nR: jogar esta fase novamente" % [itens.cenouras,itens.quebradas,itens.caixas.size(),saude.vidas,saude.coracoes]
	dados_resultado.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
	dados_resultado.add_theme_font_size_override("font_size",22)
	box.add_child(dados_resultado)
	var botao:=Button.new()
	botao.text="Jogar novamente"
	box.add_child(botao)
	botao.pressed.connect(func():
		var event:=InputEventKey.new()
		event.physical_keycode=KEY_R
		event.pressed=true
		Input.parse_input_event(event)
		event=event.duplicate()
		event.pressed=false
		Input.parse_input_event(event)
	)
