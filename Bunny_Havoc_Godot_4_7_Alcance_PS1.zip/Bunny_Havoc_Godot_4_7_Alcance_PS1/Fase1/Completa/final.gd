extends Node3D
const Cores=preload("res://Sistemas/Visual/cores_material.gd")
## Reproduz os dados do diretor Three.js: dezoito fases, poses e câmera aprovadas.
signal terminou
const Modelo = preload("Final.glb")
var ativo: bool = false
var tempo: float = 0.0
var dados: Dictionary
var jogador: CharacterBody3D
var camera: Camera3D
var filme: Node3D
var espera: Node3D
var nos: Array[Node3D] = []
var materiais: Array[BaseMaterial3D] = []
var cursores: Array[int] = []
var _texto: Label
var _painel: Control
var _voz: AudioStreamPlayer
var direcao: Node3D
var _tela: Control
var _nome: Label
var _cartela: Label
var _fade: ColorRect
var _indice: int = -1
var _revelar: bool = false
var fase: String = ""

func _ready() -> void:
	process_physics_priority=30
	var bytes: PackedByteArray=FileAccess.get_file_as_bytes("res://Fase1/Completa/final.json.gz")
	dados=JSON.parse_string(bytes.decompress_dynamic(128*1024*1024,FileAccess.COMPRESSION_GZIP).get_string_from_utf8())
	filme=Modelo.instantiate()
	add_child(filme)
	for i in dados.names.size():
		var n:=filme.find_child(str(dados.names[i]),true,false) as Node3D
		nos.append(n)
		cursores.append(0)
		var mat: BaseMaterial3D=null
		if n is MeshInstance3D and n.mesh!=null and n.get_active_material(0)!=null:
			mat=n.get_active_material(0).duplicate() as BaseMaterial3D
			if mat!=null:
				n.material_override=mat
		materiais.append(mat)
		if n!=null:
			_aplicar(i,dados.initial[i],dados.initial[i],0.0)
	var bl:=filme.find_child(str(dados.actors.bunnyldu),true,false) as Node3D
	espera=bl.duplicate() as Node3D
	add_child(espera)
	espera.position=Vector3(0,9,-398)
	espera.visible=true
	filme.visible=false
	var layer:=CanvasLayer.new()
	layer.layer=30
	add_child(layer)
	var tela:=Control.new()
	_tela=tela
	tela.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tela.mouse_filter=Control.MOUSE_FILTER_IGNORE
	layer.add_child(tela)
	for baixo in [false,true]:
		var barra:=ColorRect.new()
		barra.color=Color("08090e")
		barra.mouse_filter=Control.MOUSE_FILTER_IGNORE
		tela.add_child(barra)
		barra.anchor_right=1.0
		barra.anchor_top=0.875 if baixo else 0.0
		barra.anchor_bottom=1.0 if baixo else 0.125
	var vinheta:=ColorRect.new()
	tela.add_child(vinheta)
	vinheta.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vinheta.mouse_filter=Control.MOUSE_FILTER_IGNORE
	var shader:=Shader.new()
	shader.code="shader_type canvas_item; void fragment(){vec2 q=(UV-vec2(0.5))*vec2(1.0,0.65);float v=smoothstep(0.25,0.65,length(q));COLOR=vec4(0.015,0.015,0.035,v*0.18);}"
	var material:=ShaderMaterial.new()
	material.shader=shader
	vinheta.material=material
	_fade=ColorRect.new()
	_fade.mouse_filter=Control.MOUSE_FILTER_IGNORE
	tela.add_child(_fade)
	_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade.color=Color(0,0,0,0)
	_cartela=Label.new()
	tela.add_child(_cartela)
	_cartela.position=Vector2(48,25)
	_cartela.text="BOSQUE VERDE  /  O REENCONTRO"
	_cartela.add_theme_font_size_override("font_size",15)
	_cartela.modulate=Color("d9cfbd")
	_painel=Control.new()
	tela.add_child(_painel)
	_painel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_painel.mouse_filter=Control.MOUSE_FILTER_IGNORE
	_nome=Label.new()
	_painel.add_child(_nome)
	_nome.anchor_left=0.1
	_nome.anchor_right=0.85
	_nome.anchor_top=1.0
	_nome.anchor_bottom=1.0
	_nome.offset_top=-79
	_nome.offset_bottom=-57
	_nome.add_theme_font_size_override("font_size",16)
	_texto=Label.new()
	_texto.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	_texto.add_theme_font_size_override("font_size",21)
	_painel.add_child(_texto)
	_texto.anchor_left=0.1
	_texto.anchor_right=0.85
	_texto.anchor_top=1.0
	_texto.anchor_bottom=1.0
	_texto.offset_top=-57
	_texto.offset_bottom=-6
	var dica:=Label.new()
	_painel.add_child(dica)
	dica.text="ENTER  ›"
	dica.modulate=Color("a8a3ac")
	dica.add_theme_font_size_override("font_size",13)
	dica.anchor_left=0.88
	dica.anchor_right=0.98
	dica.anchor_top=1.0
	dica.anchor_bottom=1.0
	dica.offset_top=-27
	_painel.visible=false
	_tela.visible=false
	_voz=AudioStreamPlayer.new()
	_voz.stream=preload("final.wav")
	add_child(_voz)
	direcao=preload("Cinema/direcao.gd").new()
	add_child(direcao)

func iniciar(p: CharacterBody3D,c: Camera3D) -> void:
	jogador=p
	camera=c
	ativo=true
	tempo=0.0
	_indice=-1
	_revelar=false
	_tela.visible=true
	for i in cursores.size():
		cursores[i]=0
	filme.visible=true
	espera.visible=false
	jogador.visible=false
	jogador.velocity=Vector3.ZERO
	(jogador.get("_combate") as RefCounted).limpar()
	jogador.set_physics_process(false)
	jogador.set_process_unhandled_key_input(false)
	direcao.iniciar()
	_voz.play()
	_atualizar()

func parar() -> void:
	ativo=false
	_voz.stop()
	_voz.pitch_scale=1.0
	direcao.parar()
	_tela.visible=false
	filme.visible=false
	espera.visible=true
	_painel.visible=false
	if is_instance_valid(jogador):
		jogador.visible=true
		jogador.set_physics_process(true)
		jogador.set_process_unhandled_key_input(true)

func _physics_process(dt: float) -> void:
	if not ativo:
		return
	var rate: float=direcao.velocidade(tempo)
	_voz.pitch_scale=rate
	tempo+=dt*rate
	if tempo>=float(dados.frames.size()-1)/float(dados.fps):
		ativo=false
		_painel.visible=false
		_voz.stop()
		direcao.parar()
		_tela.visible=false
		for actor in ["bunnyldu","bibibunn","cage"]:
			(filme.find_child(str(dados.actors[actor]),true,false) as Node3D).visible=false
		terminou.emit()
		return
	_atualizar()

func _aplicar(i: int,a: Array,b: Array,u: float) -> void:
	var n: Node3D=nos[i]
	if n==null:
		return
	var pos:=Vector3(float(a[0]),float(a[1]),float(a[2])).lerp(Vector3(float(b[0]),float(b[1]),float(b[2])),u)
	var qa:=Quaternion(float(a[3]),float(a[4]),float(a[5]),float(a[6])).normalized()
	var qb:=Quaternion(float(b[3]),float(b[4]),float(b[5]),float(b[6])).normalized()
	var escala:=Vector3(float(a[7]),float(a[8]),float(a[9])).lerp(Vector3(float(b[7]),float(b[8]),float(b[9])),u)
	var basis:=Basis(qa.slerp(qb,u))
	basis.x*=escala.x
	basis.y*=escala.y
	basis.z*=escala.z
	n.transform=Transform3D(basis,pos)
	n.visible=float(a[10])>0.5
	var mat: BaseMaterial3D=materiais[i]
	if mat!=null:
		var color: Color=mat.albedo_color
		color.a=lerpf(float(a[11]),float(b[11]),u)
		Cores.definir(mat,color)

func _atualizar() -> void:
	var frame: float=tempo*float(dados.fps)
	for i in nos.size():
		var track: Array=dados.tracks[i]
		if track.is_empty():
			continue
		var cursor: int=cursores[i]
		while cursor+1<track.size() and float(track[cursor+1][0])<=frame:
			cursor+=1
		while cursor>0 and float(track[cursor][0])>frame:
			cursor-=1
		cursores[i]=cursor
		var a: Array=track[cursor]
		var b: Array=track[mini(cursor+1,track.size()-1)]
		var u: float=clampf((frame-float(a[0]))/maxf(1.0,float(b[0])-float(a[0])),0.0,1.0)
		_aplicar(i,a.slice(1),b.slice(1),u)
	var f: int=mini(int(frame),dados.frames.size()-1)
	var cam: Array=dados.frames[f]
	var next: Array=dados.frames[mini(f+1,dados.frames.size()-1)]
	var u: float=frame-floorf(frame)
	camera.global_position=Vector3(float(cam[0]),float(cam[1]),float(cam[2])).lerp(Vector3(float(next[0]),float(next[1]),float(next[2])),u)
	camera.quaternion=Quaternion(float(cam[3]),float(cam[4]),float(cam[5]),float(cam[6])).normalized().slerp(Quaternion(float(next[3]),float(next[4]),float(next[5]),float(next[6])).normalized(),u)
	camera.fov=lerpf(float(cam[7]),float(next[7]),u)
	var indice: int=0
	for j in dados.dialogues.size():
		if float(dados.dialogues[j].frame)<=frame:
			indice=j
		else:
			break
	if indice!=_indice:
		_revelar=false
		_indice=indice
	var entry: Dictionary=dados.dialogues[indice]
	fase=str(entry.phase)
	var text: String=str(entry.text)
	_painel.visible=not text.is_empty()
	var count: int=int((frame-float(entry.frame))/float(dados.fps)/0.032)
	var speaker: String=text.get_slice("\n",0)
	var fala: String=text.substr(text.find("\n")+1) if not text.is_empty() else ""
	_nome.text=speaker.to_upper()
	_nome.modulate=Color("ff80c1") if speaker=="Bibibunn" else Color("e0c8ff") if speaker=="Bunnyck" else Color("dddedb")
	_texto.text=fala if _revelar else fala.left(count)
	_cartela.modulate.a=1.0-smoothstep(2.0,3.7,tempo)
	_fade.color.a=1.0-smoothstep(0.0,0.65,tempo)
	direcao.atualizar()

func _input(event: InputEvent) -> void:
	if not ativo or not event is InputEventKey or not event.pressed or event.echo:
		return
	var key: int=event.physical_keycode if event.physical_keycode else event.keycode
	if key==KEY_ENTER or key==KEY_KP_ENTER:
		if _painel.visible:
			if not _revelar:
				_revelar=true
			elif _indice+1<dados.dialogues.size():
				tempo=float(dados.dialogues[_indice+1].frame)/float(dados.fps)
				_voz.play(tempo)
				direcao.sincronizar()
			_atualizar()
		get_viewport().set_input_as_handled()
