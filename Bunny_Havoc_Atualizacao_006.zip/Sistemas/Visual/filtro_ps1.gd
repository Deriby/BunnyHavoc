extends CanvasLayer
## Pós-processamento opcional do mundo 3D. HUD e legendas ficam acima.
@export var ativado: bool = false:
	set(value):
		ativado=value
		if is_node_ready():
			$Tela.visible=value
@export_range(90,720,1) var altura_virtual: int = 180
@export_range(8,64,1) var niveis_cor: int = 32
@export_range(0.0,1.0,0.05) var dithering: float = 0.65

func _ready() -> void:
	# Material próprio: outras cenas podem usar configurações diferentes.
	var material: ShaderMaterial=$Tela.material.duplicate()
	material.set_shader_parameter("altura_virtual",float(altura_virtual))
	material.set_shader_parameter("niveis_cor",float(niveis_cor))
	material.set_shader_parameter("dithering",dithering)
	$Tela.material=material
	$Tela.visible=ativado

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F2 or event.keycode==KEY_F2):
		ativado=not ativado
		get_viewport().set_input_as_handled()
