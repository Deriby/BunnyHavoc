extends AnimatableBody3D
## Mesma trajetória da fonte: seno de 1,1 rad/s; transporte pelo piso nativo.
var amplitude: float = 2.1
var fase: float = -48.0
var tempo: float = 0.0

func _ready() -> void:
	process_physics_priority = -10
	sync_to_physics = false

func _physics_process(dt: float) -> void:
	tempo += dt
	position.x = sin(tempo * 1.1 + fase) * amplitude
