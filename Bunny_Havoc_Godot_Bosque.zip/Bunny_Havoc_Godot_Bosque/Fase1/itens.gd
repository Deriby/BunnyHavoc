extends RefCounted
## Geometria/layout originais; recompensa imediata e um acerto por golpe.
signal mudou
var cenouras: int = 0
var quebradas: int = 0
var caixas: Array[Dictionary] = []
var frutas: Array[Dictionary] = []
var _jogador: CharacterBody3D
var _combo: RefCounted
var _som: AudioStreamPlayer
var _partes: Array[Dictionary] = []
var _cursor: int = 0
var _tempo: float = 0.0
const COLETA = preload("audio/coleta.wav")
const QUEBRA = preload("audio/caixa.wav")

func configurar(objetos: Node3D, layout: Dictionary, jogador: CharacterBody3D, raiz: Node3D) -> void:
	_jogador = jogador
	_combo = jogador.get("_combate") as RefCounted
	_som = AudioStreamPlayer.new()
	raiz.add_child(_som)
	for dado: Dictionary in layout.crates:
		var node := objetos.find_child(dado.name, true, false) as Node3D
		var body := StaticBody3D.new()
		body.collision_layer = 4
		body.collision_mask = 0
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = Vector3(1.17, 1.16, 1.17)
		collision.shape = shape
		body.add_child(collision)
		node.add_child(body)
		caixas.append({"node": node, "body": body, "reward": int(dado.reward), "ground": float(dado.position[1]) - 0.68})
	for dado: Dictionary in layout.carrots:
		frutas.append({"node": objetos.find_child(dado.name, true, false), "y": float(dado.position[1])})
	var geometry := BoxMesh.new()
	geometry.size = Vector3(0.12, 0.09, 0.16)
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("dda36c")
	for i in 24:
		var node := MeshInstance3D.new()
		node.mesh = geometry
		node.material_override = material
		node.visible = false
		raiz.add_child(node)
		_partes.append({"node": node, "life": 0.0, "velocity": Vector3.ZERO})

func _quebrar(caixa: Dictionary) -> void:
	var node: Node3D = caixa.node
	if not node.visible:
		return
	node.visible = false
	(caixa.body as StaticBody3D).collision_layer = 0
	cenouras += int(caixa.reward)
	quebradas += 1
	_som.stream = QUEBRA
	_som.play()
	for i in 11:
		var parte: Dictionary = _partes[_cursor]
		_cursor = (_cursor + 1) % _partes.size()
		parte.life = 0.42
		(parte.node as Node3D).global_position = node.global_position
		(parte.node as Node3D).visible = true
		var a: float = i * 2.399
		parte.velocity = Vector3(cos(a) * 2.5, 1.5 + (i % 3) * 0.5, sin(a) * 2.5)
	mudou.emit()

func atualizar(dt: float, interagir: bool) -> void:
	_tempo += dt
	for parte: Dictionary in _partes:
		if float(parte.life) <= 0.0:
			continue
		parte.life = maxf(0.0, float(parte.life) - dt)
		var node: Node3D = parte.node
		node.visible = float(parte.life) > 0.0
		node.position += (parte.velocity as Vector3) * dt
		parte.velocity = (parte.velocity as Vector3) - Vector3.UP * dt * 9.0
		node.rotation += Vector3(3, 5, 2) * dt
	for fruta: Dictionary in frutas:
		var node: Node3D = fruta.node
		if not node.visible:
			continue
		node.rotation.y += dt * 3.0
		node.position.y = float(fruta.y) + sin(_tempo * 3.0 + node.position.z) * 0.12
		var delta: Vector3 = node.global_position - _jogador.global_position
		if interagir and absf(delta.x) < 0.8 and absf(delta.z) < 0.8 and absf(delta.y - 0.8) < 1.2:
			node.visible = false
			cenouras += 1
			_som.stream = COLETA
			_som.play()
			mudou.emit()
	if not interagir:
		return
	for caixa: Dictionary in caixas:
		var node: Node3D = caixa.node
		if not node.visible:
			continue
		var delta: Vector3 = _jogador.global_position - node.global_position
		var yy: float = _jogador.global_position.y - float(caixa.ground)
		if yy >= 1.2 or yy <= -0.6:
			continue
		var perto: bool = absf(delta.x) < 0.95 and absf(delta.z) < 0.95
		if perto and yy > 0.7 and _jogador.velocity.y <= 0.0:
			_quebrar(caixa)
			_jogador.velocity.y = 8.0
		elif _combo.pode_atingir(node, 1.8):
			_combo.registrar_acerto(node)
			_quebrar(caixa)
		elif perto:
			var movimento: Vector3 = Vector3.ZERO
			if 0.95 - absf(delta.x) < 0.95 - absf(delta.z):
				movimento.x = (1.0 if delta.x >= 0 else -1.0) * (0.95 - absf(delta.x))
			else:
				movimento.z = (1.0 if delta.z >= 0 else -1.0) * (0.95 - absf(delta.z))
			if not _jogador.test_move(_jogador.global_transform, movimento):
				_jogador.global_position += movimento

func reiniciar() -> void:
	cenouras = 0
	quebradas = 0
	for caixa: Dictionary in caixas:
		(caixa.node as Node3D).visible = true
		(caixa.body as StaticBody3D).collision_layer = 4
	for fruta: Dictionary in frutas:
		(fruta.node as Node3D).visible = true
	for parte: Dictionary in _partes:
		parte.life = 0.0
		(parte.node as Node3D).visible = false
	mudou.emit()
