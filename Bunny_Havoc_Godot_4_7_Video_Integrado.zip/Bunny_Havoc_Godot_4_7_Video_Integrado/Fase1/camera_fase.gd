extends RefCounted
## Trilho original com leitura do chão e antecipação limitada da aterrissagem.
var camera: Camera3D
var jogador: CharacterBody3D
var pontos: Array
var olho := Vector3.ZERO
var olhar := Vector3.ZERO
var pronto: bool = false
var ultimo := Vector3.ZERO
var tempo: float = 0.0
var pouso := Vector3.ZERO
var fim_z: float = -56.0
var centros_vaos: Array = [-48.0]
var alturas: Array = [[30, 0], [-40, 0], [-80, 5], [-125, 5]]

func configurar(c: Camera3D, p: CharacterBody3D, anchors: Array, dados: Dictionary = {}) -> void:
	camera = c
	jogador = p
	pontos = anchors
	fim_z = float(dados.get("bounds", {}).get("endZ", -56.0))
	centros_vaos = dados.get("pits", [-48.0])
	alturas = dados.get("heightKnots", alturas)

func altura(z: float) -> float:
	for i in alturas.size() - 1:
		var a: Array = alturas[i]
		var b: Array = alturas[i + 1]
		if z <= float(a[0]) and z >= float(b[0]):
			return lerpf(float(a[1]), float(b[1]), smoothstep(0.0, 1.0, (float(a[0]) - z) / (float(a[0]) - float(b[0]))))
	return float(alturas[0][1]) if z > float(alturas[0][0]) else float(alturas[-1][1])

func amostrar(z: float) -> Dictionary:
	var i: int = 0
	while i < pontos.size() - 2 and z < float(pontos[i + 1].z):
		i += 1
	var a: Dictionary = pontos[i]
	var b: Dictionary = pontos[i + 1]
	var u: float = smoothstep(0.0, 1.0, (float(a.z) - z) / (float(a.z) - float(b.z)))
	var resultado: Dictionary = {}
	for chave in ["h", "dist", "lead", "fov", "side"]:
		resultado[chave] = lerpf(float(a[chave]), float(b[chave]), u)
	return resultado

func atualizar(dt: float) -> void:
	tempo += dt
	var p: Vector3 = jogador.global_position
	var z: float = clampf(p.z, fim_z, 12.0)
	var s: Dictionary = amostrar(z)
	var perigo: float = 0.0
	var margem_z: float = z
	for centro in centros_vaos:
		var dz: float = z - float(centro)
		var peso: float = 1.0 - smoothstep(0.0, 1.0, (dz - 2.0) / 18.0 if dz >= 0.0 else (-dz - 2.0) / 11.0)
		if peso > perigo:
			perigo = peso
			margem_z = float(centro) - 6.8
	var voo: float = clampf(p.y - altura(z), 0.0, 8.0)
	var correndo: bool = Vector2(jogador.velocity.x, jogador.velocity.z).length() > 8.03
	# A câmera segue o relevo; o salto não puxa o horizonte inteiro para cima.
	var chao: float = altura(z)
	var ar: bool = not jogador.is_on_floor() and p.y > chao + 0.1
	var t_pouso: float = 0.0
	if ar:
		for i in 3:
			var queda: float = p.y - altura(z + jogador.velocity.z * t_pouso)
			var g: float = maxf(1.0, float(jogador.get("gravidade")))
			t_pouso = clampf((jogador.velocity.y + sqrt(maxf(0.0, jogador.velocity.y * jogador.velocity.y + 2.0 * g * queda))) / g, 0.0, 0.65)
	pouso = p + Vector3(jogador.velocity.x, 0, jogador.velocity.z) * t_pouso
	pouso.y = altura(pouso.z)
	var base: float = chao + voo * 0.18
	var olhar_z: float = z - float(s.lead) - perigo * 1.8 - (0.75 if correndo else 0.0)
	# Ao avançar, abre o quadro até a margem de chegada, sem virar ao voltar.
	if jogador.velocity.z < -0.5:
		olhar_z = lerpf(olhar_z, minf(olhar_z, margem_z), perigo * 0.55)
	if ar:
		olhar_z = lerpf(olhar_z, minf(olhar_z, pouso.z - 0.8), 0.30)
	var mirar_y: float = lerpf(chao, altura(olhar_z), 0.45) + 1.5 + voo * 0.18
	var alvo_olho := Vector3(p.x * 0.60 + clampf(jogador.velocity.x * 0.075, -0.65, 0.65) + float(s.side), base + float(s.h) + perigo * 1.85, z + float(s.dist) + perigo * 2.35 + (0.60 if correndo else 0.0))
	var alvo_olhar := Vector3(p.x * 0.78 + clampf(jogador.velocity.x * 0.10, -0.65, 0.65), mirar_y, olhar_z)
	var alvo_fov: float = float(s.fov) + perigo * 2.25 + (0.6 if correndo else 0.0)
	if not pronto or Vector2(p.x - ultimo.x, p.z - ultimo.z).length() > 24.0:
		olho = alvo_olho
		olhar = alvo_olhar
		camera.fov = alvo_fov
		pronto = true
	else:
		olho = olho.lerp(alvo_olho, 1.0 - exp(-(3.8 if perigo > 0.3 else 4.3) * dt))
		olhar = olhar.lerp(alvo_olhar, 1.0 - exp(-(5.0 if perigo > 0.3 else 5.7) * dt))
		camera.fov = lerpf(camera.fov, alvo_fov, 1.0 - exp(-2.6 * dt))
	ultimo = p
	camera.global_position = olho
	camera.look_at(olhar)
