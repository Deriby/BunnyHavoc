@tool
extends Node3D
## Godot 4.7.2 importa COLOR_0, mas pode deixar seu uso desligado no material.
## Reativa somente superfícies que já possuem cores, sem modificar as malhas.
func _ready() -> void:
	var materiais: Dictionary={}
	for kind in ["MeshInstance3D","MultiMeshInstance3D"]:
		for node in find_children("*",kind,true,false):
			var mesh: Mesh=node.mesh if node is MeshInstance3D else node.multimesh.mesh if node.multimesh!=null else null
			if mesh==null:continue
			for i in mesh.get_surface_count():
				if not (mesh.surface_get_format(i)&Mesh.ARRAY_FORMAT_COLOR):continue
				var mat: Material=node.get_active_material(i) if node is MeshInstance3D else node.material_override if node.material_override!=null else mesh.surface_get_material(i)
				if mat is BaseMaterial3D and not mat.vertex_color_use_as_albedo:
					var id: int=mat.get_instance_id()
					if not materiais.has(id):
						var novo: BaseMaterial3D=mat.duplicate()
						novo.vertex_color_use_as_albedo=true
						materiais[id]=novo
					var copia: BaseMaterial3D=materiais[id]
					if node is MeshInstance3D:node.set_surface_override_material(i,copia)
					else:node.material_override=copia
