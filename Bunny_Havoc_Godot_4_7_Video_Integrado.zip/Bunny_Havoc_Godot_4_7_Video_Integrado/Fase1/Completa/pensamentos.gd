extends Node3D
## Falas originais ao insistir cinco segundos contra os limites da trilha.
const FALAS: Array[String] = ["Qual é, preciso me focar...", "Porque eu insisto nisso?", "Meu irmão precisa de mim!", "Por algum motivo, não quero ir por ali...", "Se por ali fosse mais rápido, eu estava naquele caminho e não aqui."]
var jogador: CharacterBody3D
var tempo: float = 0.0
var duracao: float = 0.0
var ultima: int = -1
var balao: Label3D
func _ready() -> void:
	jogador=get_parent() as CharacterBody3D
	balao=Label3D.new()
	balao.position.y=3.3
	balao.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	balao.font_size=32
	balao.pixel_size=0.0035
	balao.width=280
	balao.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	balao.visible=false
	add_child(balao)
	jogador.get_node("Saude").renasceu.connect(reiniciar)
func _physics_process(dt: float) -> void:
	if not jogador.is_physics_processing():
		reiniciar()
		return
	duracao=maxf(0.0,duracao-dt)
	balao.visible=duracao>0.0
	var eixo: Vector2=jogador.call("_ler_direcao")
	var parado: bool=Vector2(jogador.velocity.x,jogador.velocity.z).length()<0.5
	tempo=tempo+dt if eixo.length()>0.1 and parado and jogador.is_on_floor() else 0.0
	if tempo>5.0 and duracao<=0.0:
		tempo=0.0
		ultima=(ultima+1+randi_range(0,FALAS.size()-2))%FALAS.size()
		balao.text=FALAS[ultima]
		duracao=4.5
func reiniciar() -> void:
	tempo=0.0
	duracao=0.0
	balao.visible=false
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and (event.physical_keycode==KEY_R or event.keycode==KEY_R):
		reiniciar()
