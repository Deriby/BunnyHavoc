extends RefCounted
## Atuação sobre as mesmas malhas: poses, olhar, reação e animação facial.
const Transicoes=preload("transicoes.gd")
var transicoes: RefCounted=Transicoes.new()
var atores: Dictionary={}
var fases: Dictionary={}
var duracoes: Dictionary={}
var fala: Dictionary
var peso: float=1.0
var energia_fala: float=0.0

func configurar(filme: Node3D,rig: Dictionary,dados: Dictionary) -> void:
	for nome in rig:
		var partes: Dictionary={}
		for chave in rig[nome]:
			var valor: Variant=rig[nome][chave]
			partes[chave]=valor.map(func(n):return filme.find_child(str(n),true,false)) if valor is Array else filme.find_child(str(valor),true,false)
		atores[nome]=partes
	transicoes.configurar(atores,dados)
	fala=JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/Completa/Cinema/fala.json"))
	for e: Dictionary in dados.dialogues:
		if not fases.has(e.phase):fases[e.phase]=float(e.frame)/float(dados.fps)
	var keys: Array=fases.keys()
	for i in keys.size():duracoes[keys[i]]=(float(fases[keys[i+1]]) if i+1<keys.size() else float(dados.frames.size())/float(dados.fps))-float(fases[keys[i]])

func rosto(nome: String) -> Vector3:
	var a: Dictionary=atores[nome]
	return (a.head as Node3D).global_position if a.has("head") else (a.root as Node3D).to_global(Vector3(0,1.46,0))
func _pose(node: Node3D,rot: Vector3,forca: float=1.0) -> void:
	var q:=Basis.from_euler(rot,EULER_ORDER_XYZ).get_rotation_quaternion()
	node.quaternion=node.quaternion.slerp(q,peso*forca)
func _inclinar(node: Node3D,roll: float) -> void:
	# Euler pode representar yaw > 90° como X=PI/Z=PI; manter o rumo real.
	var frente: Vector3=node.basis.z
	var yaw: float=atan2(frente.x,frente.z)
	var alvo: Quaternion=(Basis(Vector3.UP,yaw)*Basis(Vector3.BACK,roll)).get_rotation_quaternion()
	node.quaternion=node.quaternion.slerp(alvo,peso)
func _pulso(q: float,atraso: float=0.0,forca: float=1.0) -> float:
	var x: float=maxf(0,q-atraso)
	return sin(x*16.0)*exp(-x*5.5)*forca if q>=atraso else 0.0
func _olhar(a: Dictionary,alvo: Vector3,forca: float) -> void:
	if not a.has("head"):return
	var head: Node3D=a.head
	var local: Vector3=head.get_parent().to_local(alvo)-head.position
	var yaw: float=clampf(atan2(local.x,local.z),-0.48,0.48)
	var pitch: float=clampf(-atan2(local.y,maxf(0.1,Vector2(local.x,local.z).length())),-0.18,0.20)
	head.rotation.y=lerp_angle(head.rotation.y,yaw,peso*forca)
	head.rotation.x=lerpf(head.rotation.x,pitch,peso*forca)
	for pupil: Node3D in a.get("pupils",[]):pupil.position.x+=sin(yaw)*0.025*peso
func _rosto(a: Dictionary,nome: String,falante: String,t: float,fase: String) -> void:
	var ativo: bool=nome==falante.to_lower()
	var nervoso: bool=fase in ["riftWarning","teleportReact","cageFly","cageDrop"]
	var bravo: bool=nome=="bunnyck" and fase in ["trappedDialogue","aftermath","escape","forestReveal"]
	# Fechamento curto e assimétrico; não repete uma piscada a cada fala.
	var offset: float=0.0 if nome=="bunnyldu" else 1.4
	var ciclo: float=fposmod(t+offset,4.9 if nome=="bunnyldu" else 5.7)
	var blink: float=sin(PI*clampf(ciclo/0.16,0,1)) if ciclo<0.16 and t>0.5 and not nervoso else 0
	for eye: Node3D in a.get("eyes",[]):eye.scale.y*=1.0-blink*0.91
	for pupil: Node3D in a.get("pupils",[]):pupil.scale.y*=1.0-blink*0.91
	if a.has("mouth"):
		var y: float=lerpf(0.75,1.35,energia_fala) if ativo else 0.95
		if nome=="bunnyck":y=1.4+energia_fala*3.2 if ativo else 2.0 if nervoso else 0.35
		a.mouth.scale.y=lerpf(a.mouth.scale.y,y,0.95)
	if nome=="bunnyldu":
		a.smile.visible=not ativo and not nervoso and fase=="intro"
		a.gasp.visible=nervoso
		a.frown.visible=not nervoso and not a.smile.visible and not ativo
		a.open.visible=ativo and not nervoso
		# Trapped speech uses the existing open mouth, no permanent panic loop.
		if ativo:a.gasp.visible=false;a.open.visible=true
	elif nome=="bibibunn":
		a.smile.visible=true;a.gasp.visible=false
	for i in a.get("brows",[]).size():
		var brow: Node3D=a.brows[i]
		var lado: float=-1 if i==0 else 1
		if nome=="bunnyck":brow.rotation.z=lado*(0.32 if nervoso else -0.30 if bravo else -0.06)
		elif ativo:brow.rotation.z+=lado*energia_fala*0.045

func atualizar(t: float,fase: String,falante: String,progresso: float) -> void:
	transicoes.atualizar(t)
	var ck: Dictionary=atores.bunnyck;var ld: Dictionary=atores.bunnyldu;var bb: Dictionary=atores.bibibunn
	var q: float=t-float(fases[fase]);var dur: float=duracoes[fase]
	peso=smoothstep(0.0,0.20,q)*(1.0-smoothstep(maxf(0,dur-0.16),dur,q))
	var u: float=clampf(progresso,0,1)
	var gesto: float=smoothstep(0.04,0.22,u)*(1.0-smoothstep(0.55,0.90,u))
	var acento: float=sin(PI*clampf((u-0.22)/0.30,0,1))*0.10
	var breath: float=sin(t*2.1)*0.012
	var f: float=t*float(fala.fps)
	var i: int=mini(int(f),fala.envelope.size()-2)
	energia_fala=lerpf(float(fala.envelope[i]),float(fala.envelope[i+1]),f-floorf(f))
	if fase=="intro":
		ck.core.position.y=lerpf(ck.core.position.y,breath,peso)
		ld.core.position.y=lerpf(ld.core.position.y,breath*0.7,peso)
		_pose(ck.legs[0],Vector3(0.03,0,0));_pose(ck.legs[1],Vector3(-0.03,0,0))
		_pose(ck.arms[0],Vector3(-0.13,0,-0.14));_pose(ck.arms[1],Vector3(-0.20-(0.72*gesto if falante=="Bunnyck" else 0),0,0.18))
		_pose(ld.arms[0],Vector3(-0.22-(0.66*gesto if falante=="Bunnyldu" else 0),0,-0.20))
		_pose(ld.arms[1],Vector3(0.10-gesto*0.22,0,0.15))
		_pose(ld.head,Vector3(-0.045*gesto+acento,0,-0.025))
		_inclinar(ck.core,-0.025)
		_olhar(ld,rosto("bunnyck"),0.8)
	elif fase in ["riftWarning","teleport","teleportReact","cageFly","cageDrop"]:
		var kick: float=_pulso(q,0.05,0.12)
		var alto: bool=fase in ["cageFly","cageDrop"]
		for a: Dictionary in [ck,ld]:
			a.core.position.y=lerpf(a.core.position.y,-absf(kick)*0.3,peso)
			for n in 2:
				_pose(a.arms[n],Vector3(-0.65-(0.30 if n==0 else 0),0,(-1 if n==0 else 1)*0.28))
				_pose(a.legs[n],Vector3(0.06 if n==0 else -0.08,0,0))
				a.ears[n].rotation.x=lerpf(a.ears[n].rotation.x,-0.18-kick,peso)
		var target: Vector3=atores.cage.root.global_position+Vector3.UP*4 if alto else Vector3(4.2,11.2,-394.25)
		_olhar(ld,target,0.75)
		if fase=="cageDrop":
			var impacto: float=_pulso(q,0.72,0.11)
			ld.core.position.y-=maxf(0,impacto)*peso
			ck.core.rotation.x+=impacto*0.5*peso
	elif fase=="taunt":
		ck.core.position.y=breath;ld.core.position.y=breath*0.7
		for a: Dictionary in [ck,ld]:
			for n in 2:_pose(a.legs[n],Vector3.ZERO);_pose(a.arms[n],Vector3(-0.28,0,(-1 if n==0 else 1)*0.20))
		bb.core.position.y=breath*0.6
		_inclinar(bb.core,-0.025)
		_pose(bb.arms[0],Vector3(-0.12,0,-0.28))
		_pose(bb.arms[1],Vector3(-0.40-0.65*gesto,0,0.32+gesto*0.18))
		_pose(bb.head,Vector3(-0.025-gesto*0.05,0,-0.07+acento*0.35))
		_olhar(bb,rosto("bunnyck"),0.55);_olhar(ld,rosto("bibibunn"),0.7)
	elif fase in ["trappedDialogue","aftermath"]:
		ld.core.position.y=lerpf(ld.core.position.y,-0.025+breath*0.4,peso)
		for n in 2:
			_pose(ld.arms[n],Vector3(-1.22,0,(-1 if n==0 else 1)*0.31))
			_pose(ld.legs[n],Vector3(0.07 if n==0 else -0.06,0,0))
		_pose(ld.head,Vector3(-0.025,0,0.02));_olhar(ld,rosto("bunnyck"),0.6)
		if fase=="trappedDialogue":
			ck.core.position.y=lerpf(ck.core.position.y,-0.04,peso)
			_pose(ck.arms[0],Vector3(-0.25,0,-0.16));_pose(ck.arms[1],Vector3(-0.35-(0.85*gesto if falante=="Bunnyck" else 0),0,0.28))
		else:
			var rise: float=smoothstep(0,3.1,q)
			_pose(ck.arms[0],Vector3(lerpf(-1.85,-0.25,rise),0,-0.38))
			_pose(ck.arms[1],Vector3(lerpf(-1.1,-0.28,rise)-(0.80*gesto if falante=="Bunnyck" else 0),0,0.22))
			_pose(ck.legs[0],Vector3(0.38*(1-rise),0,0));_pose(ck.legs[1],Vector3(-0.24*(1-rise),0,0))
			_olhar(bb,rosto("bunnyck"),0.6)
	elif fase=="windup":
		_pose(ck.arms[0],Vector3(-0.8-q*0.4,0,-0.38));_pose(ck.arms[1],Vector3(-0.7-q*0.3,0,0.35))
	elif fase=="knockdown":
		ck.ears[0].rotation.x+=_pulso(q,0,0.30)*peso
		ck.ears[1].rotation.x+=_pulso(q,0.04,0.25)*peso
	elif fase in ["throwPrep","throwLaunch","airborne","catch","escape","forestReveal"]:
		# Cage, carrier roots and Bibi's load-bearing arm remain in the base clip.
		ld.core.position.y=lerpf(ld.core.position.y,-0.04,peso)
		for n in 2:
			_pose(ld.arms[n],Vector3(-1.18,0,(-1 if n==0 else 1)*0.30))
			_pose(ld.legs[n],Vector3(0.13 if n==0 else -0.10,0,0))
			ld.ears[n].rotation.x=lerpf(ld.ears[n].rotation.x,-0.3,peso)
		if fase in ["throwLaunch","airborne","catch"]:
			for n in 2:ck.ears[n].rotation.x+=_pulso(q,0.06+n*0.035,0.15)*peso
		if fase in ["escape","forestReveal"]:
			var start_z: float=-395.36
			var stride: float=(start_z-bb.root.global_position.z)*PI/0.65
			for n in 2:_pose(bb.legs[n],Vector3(sin(stride+n*PI)*0.48,0,0))
			if fase=="escape":
				var walk: float=smoothstep(0,0.2,q)*(1-smoothstep(2.3,2.8,q))
				var passo: float=(ck.root.global_position.z+391.86)*PI/0.55
				for n in 2:
					_pose(ck.legs[n],Vector3(sin(passo+n*PI)*0.45*walk,0,0))
					_pose(ck.arms[n],Vector3(-0.28+sin(passo+(n+1)*PI)*0.35*walk,0,(-1 if n==0 else 1)*0.18))
			else:
				for n in 2:_pose(ck.legs[n],Vector3.ZERO);_pose(ck.arms[n],Vector3(-0.22,0,(-1 if n==0 else 1)*0.17))
	# Small secondary ear motion follows poses rather than a constant frantic cycle.
	if fase in ["intro","taunt","trappedDialogue","aftermath"]:
		for a: Dictionary in [ck,ld,bb]:
			for n in 2:a.ears[n].rotation.x=lerpf(a.ears[n].rotation.x,sin(t*1.8+n*0.7)*0.035,peso*0.8)
	for nome in atores:
		if nome=="cage":continue
		_rosto(atores[nome],nome,falante,t,fase)
