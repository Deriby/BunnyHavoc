extends Node
## Cena de revisão pelo F6; não altera o início normal do jogo pelo F5.
func _ready() -> void:
	assistir.call_deferred()
func assistir() -> void:
	await get_tree().process_frame
	var fase: Node3D=get_parent()
	fase.get_node("Jogador").position=Vector3(0,9,-388)
	fase._iniciar_final()
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_R or event.keycode==KEY_R):
		assistir.call_deferred()
