extends RefCounted
## Mistura local determinística nas mudanças de ação. Raízes e jaula não mudam.
var pontos: Array[Dictionary]=[]
var estaticos: Dictionary={}
const JANELA: float=0.20

func configurar(atores: Dictionary, dados: Dictionary) -> void:
	var ids: Dictionary={}
	for a: Dictionary in atores.values():
		for chave in ["core","head","arms","legs","ears","tail","eyes","pupils","brows","mouth"]:
			if not a.has(chave):continue
			var lista: Array=a[chave] if a[chave] is Array else [a[chave]]
			for node: Node3D in lista:
				var i: int=dados.names.find(node.name)
				if i>=0:
					ids[node]=i
					node.rotation_order=EULER_ORDER_XYZ
					if dados.tracks[i].is_empty():estaticos[node]=_transformar(dados.initial[i])
	var ultima: String=""
	for e: Dictionary in dados.dialogues:
		if e.phase==ultima:continue
		ultima=e.phase
		var poses: Dictionary={}
		for node in ids:poses[node]=_amostrar(dados,int(ids[node]),maxf(0,float(e.frame)-JANELA*0.5*float(dados.fps)))
		pontos.append({"tempo":float(e.frame)/float(dados.fps),"fase":str(e.phase),"poses":poses})

func _transformar(a: Array) -> Transform3D:
	var q:=Quaternion(float(a[3]),float(a[4]),float(a[5]),float(a[6])).normalized()
	var basis:=Basis(q)
	basis.x*=float(a[7]);basis.y*=float(a[8]);basis.z*=float(a[9])
	return Transform3D(basis,Vector3(float(a[0]),float(a[1]),float(a[2])))
func _amostrar(dados: Dictionary,i: int,frame: float) -> Transform3D:
	var track: Array=dados.tracks[i]
	if track.is_empty():return _transformar(dados.initial[i])
	var j: int=0
	while j+1<track.size() and float(track[j+1][0])<=frame:j+=1
	var a: Array=track[j];var b: Array=track[mini(j+1,track.size()-1)]
	var u: float=clampf((frame-float(a[0]))/maxf(1,float(b[0])-float(a[0])),0,1)
	return _transformar(a.slice(1)).interpolate_with(_transformar(b.slice(1)),u)
func atualizar(t: float) -> void:
	for node in estaticos:node.transform=estaticos[node]
	for i in range(1,pontos.size()):
		var e: Dictionary=pontos[i]
		var inicio: float=float(e.tempo)-JANELA*0.5
		if t<inicio:break
		if t>=inicio+JANELA:continue
		var u: float=smoothstep(inicio,inicio+JANELA,t)
		for node in e.poses:node.transform=(e.poses[node] as Transform3D).interpolate_with(node.transform,u)
		break
