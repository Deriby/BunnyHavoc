extends Node3D
const Atuacao = preload("atuacao.gd")
const Planos = preload("planos.gd")
var atuacao: RefCounted = Atuacao.new()
var planos: RefCounted = Planos.new()
var final: Node3D
var ativo: bool = false
var _ambiente: Environment
var _sol: DirectionalLight3D
var _musica: AudioStreamPlayer
var _aves: Node3D
var _salvo: Dictionary = {}
var _luzes: Array[OmniLight3D] = []
var _som: AudioStreamPlayer
var _fases: Dictionary = {}

func _ready() -> void:
	final=get_parent()
	var rig: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://Fase1/Completa/Cinema/rig.json"))
	atuacao.configurar(final.filme,rig,final.dados)
	atuacao.atores["cage"]={"root":final.filme.find_child(str(final.dados.actors.cage),true,false)}
	for e: Dictionary in final.dados.dialogues:
		if not _fases.has(e.phase):
			_fases[e.phase]=float(e.frame)/float(final.dados.fps)
	for spec in [[Color("ffdab0"),Vector3(-5,14,-390),1.2,15.0],[Color("8ab9ff"),Vector3(4,13.5,-400),1.6,13.0],[Color("ff4bba"),Vector3(4.2,11,-394.25),0.0,7.5]]:
		var light:=OmniLight3D.new()
		light.light_color=spec[0]
		light.position=spec[1]
		light.light_energy=spec[2]
		light.omni_range=spec[3]
		light.omni_attenuation=1.4
		light.shadow_enabled=false
		light.visible=false
		add_child(light)
		_luzes.append(light)
	_som=AudioStreamPlayer.new()
	_som.stream=preload("cinema.ogg")
	add_child(_som)

func iniciar() -> void:
	if ativo:
		parar()
	var cena: Node=final.get_parent()
	_ambiente=(cena.get_node("WorldEnvironment") as WorldEnvironment).environment
	_sol=cena.get_node("DirectionalLight3D")
	_musica=cena.get_node("MusicaBosque")
	_salvo={"ambient":_ambiente.ambient_light_energy,"sun":_sol.light_energy,"music":_musica.volume_db}
	_aves=cena.get_node_or_null("Passaros")
	if _aves!=null:
		_salvo["birds"]=_aves.visible
		_aves.visible=false
	_ambiente.ambient_light_energy=0.28
	_sol.light_energy=0.62
	for light in _luzes:
		light.visible=true
	ativo=true
	_som.play()

func parar() -> void:
	_som.stop()
	for light in _luzes:
		light.visible=false
	if not _salvo.is_empty():
		_ambiente.ambient_light_energy=float(_salvo.ambient)
		_sol.light_energy=float(_salvo.sun)
		_musica.volume_db=float(_salvo.music)
		if _aves!=null:
			_aves.visible=bool(_salvo.birds)
	_salvo.clear()
	ativo=false

func sincronizar() -> void:
	if ativo:
		_som.play(final.tempo)

func velocidade(t: float) -> float:
	var a: float=float(_fases.throwLaunch)
	var b: float=float(_fases.airborne)
	if t>=a and t<a+0.24:
		return lerpf(0.7,1.0,smoothstep(a,a+0.24,t))
	if t>=b+0.2 and t<b+0.75:
		return 0.65+0.35*absf((t-b-0.475)/0.275)
	return 1.0

func atualizar() -> void:
	if not ativo:
		return
	var e: Dictionary=final.dados.dialogues[final._indice]
	var text: String=str(e.text)
	var falante: String=text.get_slice("\n",0) if not text.is_empty() else ""
	var t: float=final.tempo
	var linha_t: float=t-float(e.frame)/float(final.dados.fps)
	var proxima: float=float(final.dados.frames.size())/float(final.dados.fps)
	if final._indice+1<final.dados.dialogues.size():
		proxima=float(final.dados.dialogues[final._indice+1].frame)/float(final.dados.fps)
	var u: float=clampf(linha_t/maxf(0.5,proxima-float(e.frame)/float(final.dados.fps)),0.0,1.0)
	atuacao.atualizar(t,str(e.phase),falante,u)
	var q: float=t-float(_fases[e.phase])
	planos.atualizar(final.camera,atuacao,str(e.phase),q,t,falante,linha_t)
	var magia: float=0.0
	if e.phase=="riftWarning":
		magia=smoothstep(0.0,1.2,q)*0.7
	elif e.phase=="teleport":
		magia=2.8*sin(clampf(q/2.55,0.0,1.0)*PI)+0.2
	elif e.phase in ["taunt","windup","catch","escape"]:
		magia=0.45
	_luzes[2].light_energy=magia
	_luzes[2].global_position=atuacao.atores.bibibunn.root.global_position+Vector3.UP*1.8
	_musica.volume_db=-26.0 if not text.is_empty() else -21.0
	_som.pitch_scale=final._voz.pitch_scale
