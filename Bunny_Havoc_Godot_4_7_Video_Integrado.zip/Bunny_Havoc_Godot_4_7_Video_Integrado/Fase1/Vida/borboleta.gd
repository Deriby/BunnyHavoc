@tool
extends Node3D
const Modelos=preload("res://Cenas/Natureza/Detalhes/modelos_bosque.gd")
var asas: Array[MeshInstance3D]=[]
func _ready() -> void:
	for i in 2:
		var asa:=MeshInstance3D.new();asa.mesh=Modelos.obter("asa");asa.name="Asa"+str(i)
		asa.scale.x=1 if i==0 else -1
		add_child(asa);asas.append(asa)
	var corpo:=MeshInstance3D.new();var geo:=BoxMesh.new();geo.size=Vector3(0.035,0.045,0.23)
	var material:=StandardMaterial3D.new();material.albedo_color=Color("443242");geo.material=material;corpo.mesh=geo;add_child(corpo)
func animar(t: float) -> void:
	for i in 2:asas[i].rotation.z=(1 if i==0 else -1)*(0.30+sin(t*18)*0.75)
