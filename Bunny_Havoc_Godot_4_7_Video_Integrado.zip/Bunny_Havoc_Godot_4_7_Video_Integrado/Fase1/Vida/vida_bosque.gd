extends Node3D
## Fauna discreta das margens; os objetos do caminho continuam livres.
var tempo: float=0
var fauna: Array[Dictionary]=[]
func _ready() -> void:
	for b: Node3D in $Borboletas.get_children():fauna.append({"n":b,"base":b.position,"fase":float(fauna.size())*1.73})
func _process(dt: float) -> void:
	tempo+=dt
	var fase: Node=get_tree().current_scene
	if fase==null:return
	var player: Node3D=fase.get_node_or_null("Jogador")
	var filme: Variant=fase.get("final")
	$Borboletas.visible=filme==null or not filme.ativo
	for item: Dictionary in fauna:
		var n: Node3D=item.n
		n.visible=player==null or absf(item.base.z-player.position.z)<48.0
		if not n.visible or not $Borboletas.visible:continue
		var q: float=tempo+float(item.fase)
		n.position=item.base+Vector3(sin(q*0.65)*0.55,sin(q*1.2)*0.16,cos(q*0.8)*0.40)
		n.rotation.y=atan2(cos(q*0.65)*0.65,-sin(q*0.8)*0.8)
		n.animar(q)
