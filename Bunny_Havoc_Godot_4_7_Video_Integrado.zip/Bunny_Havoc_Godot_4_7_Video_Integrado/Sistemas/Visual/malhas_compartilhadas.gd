extends RefCounted
## Consolida cores em vértices e compartilha recursos; nenhuma malha-fonte é gravada.
const Materiais=preload("materiais_compartilhados.gd")
static var _superficies: Dictionary={}
static var _plantas: Dictionary={}
static var lods_gerados: int=0
static var _lod_cache: Dictionary={}
static func superficie(mesh: Mesh,i: int,material: Material) -> ArrayMesh:
	var chave: String=str(mesh.get_rid())+":"+str(i)+":"+str(material.get_instance_id())
	if _superficies.has(chave):return _superficies[chave]
	var arrays: Array=mesh.surface_get_arrays(i).duplicate(true)
	var mat: Material=material
	if material is BaseMaterial3D and material.albedo_texture==null and material.transparency==BaseMaterial3D.TRANSPARENCY_DISABLED and not material.emission_enabled:
		var cor: Color=material.albedo_color
		var quantidade: int=arrays[Mesh.ARRAY_VERTEX].size()
		var cores:=PackedColorArray();cores.resize(quantidade)
		for j in quantidade:
			var original: Color=arrays[Mesh.ARRAY_COLOR][j] if material.vertex_color_use_as_albedo and arrays[Mesh.ARRAY_COLOR]!=null and not arrays[Mesh.ARRAY_COLOR].is_empty() else Color.WHITE
			if material.vertex_color_is_srgb:original=original.srgb_to_linear()
			cores[j]=original*cor
		arrays[Mesh.ARRAY_COLOR]=cores
		var novo: BaseMaterial3D=material.duplicate()
		novo.albedo_color=Color.WHITE;novo.vertex_color_use_as_albedo=true;novo.vertex_color_is_srgb=false
		mat=Materiais.equivalente(novo)
	elif material is BaseMaterial3D:mat=Materiais.equivalente(material)
	var nova:=ArrayMesh.new();nova.add_surface_from_arrays(mesh.surface_get_primitive_type(i),arrays)
	nova.surface_set_material(0,mat)
	var assinatura: String=(var_to_bytes(arrays).hex_encode()+str(mat.albedo_color)+str(mat.albedo_texture.resource_path if mat.albedo_texture!=null else "")+str(mat.shading_mode)+str(mat.cull_mode)+str(mat.transparency)).sha256_text()
	nova.set_meta("bh_sha",assinatura)
	nova=com_lods(nova)
	_superficies[chave]=nova
	return nova
static func relativo(node: Node3D,raiz: Node3D) -> Transform3D:
	var t: Transform3D=node.transform
	var pai: Node=node.get_parent()
	while pai!=raiz:
		if pai is Node3D:t=pai.transform*t
		pai=pai.get_parent()
	return t
static func planta(raiz: Node3D,pecas: Array[MeshInstance3D]) -> ArrayMesh:
	var chave: String=""
	var partes: Array=[]
	for p in pecas:
		var t: Transform3D=relativo(p,raiz)
		for i in p.mesh.get_surface_count():
			var mesh: ArrayMesh=superficie(p.mesh,i,p.get_active_material(i))
			partes.append({"mesh":mesh,"t":t})
			chave+=str(mesh.get_meta("bh_sha"))+str(t)
	chave=chave.sha256_text()
	if _plantas.has(chave):return _plantas[chave]
	var arquivo: String="res://Recursos/Otimizados/Natureza/"+chave+".res"
	if ResourceLoader.exists(arquivo) and OS.get_environment("BH_BUILD_VISUAL_CACHE")!="1":
		_plantas[chave]=load(arquivo);return _plantas[chave]
	var grupos: Dictionary={}
	for p: Dictionary in partes:
		var mat: Material=p.mesh.surface_get_material(0)
		var id: int=mat.get_instance_id()
		if not grupos.has(id):
			var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES);st.set_material(mat);grupos[id]=st
		grupos[id].append_from(p.mesh,0,p.t)
	var resultado:=ArrayMesh.new()
	for st: SurfaceTool in grupos.values():
		st.index();st.commit(resultado)
	resultado=com_lods(resultado)
	_plantas[chave]=resultado
	return resultado
static func agrupar_visual(raiz: Node3D) -> void:
	if raiz.has_meta("bh_visual_agrupado"):return
	var pecas: Array[MeshInstance3D]=[]
	for n: MeshInstance3D in raiz.find_children("*","MeshInstance3D",true,false):
		if n.is_visible_in_tree() and n.mesh!=null:pecas.append(n)
	if pecas.size()<2:return
	var node:=MeshInstance3D.new();node.name="MalhaAgrupada";node.mesh=planta(raiz,pecas);raiz.add_child(node)
	for p in pecas:p.visible=false;p.set_meta("bh_somente_autoria",true)
	raiz.set_meta("bh_visual_agrupado",{"lote":node,"pecas":pecas})

static func com_lods(mesh: ArrayMesh) -> ArrayMesh:
	var dados: Array=[]
	for i in mesh.get_surface_count():
		var m: BaseMaterial3D=mesh.surface_get_material(i)
		dados.append([mesh.surface_get_arrays(i),str(m.albedo_color),m.albedo_texture.resource_path if m.albedo_texture!=null else "",m.vertex_color_use_as_albedo,m.shading_mode,m.cull_mode])
	var chave: String=var_to_bytes(dados).hex_encode().sha256_text()
	if _lod_cache.has(chave):return _lod_cache[chave]
	var path: String="res://Recursos/Otimizados/"+chave+".res"
	var resultado: ArrayMesh=mesh
	if ResourceLoader.exists(path) and OS.get_environment("BH_BUILD_VISUAL_CACHE")!="1":
		resultado=load(path)
	elif OS.get_environment("BH_BUILD_VISUAL_CACHE")=="1":
		var importer: Resource=ClassDB.instantiate("ImporterMesh")
		for i in mesh.get_surface_count():importer.add_surface(Mesh.PRIMITIVE_TRIANGLES,mesh.surface_get_arrays(i),[],{},mesh.surface_get_material(i))
		importer.generate_lods(25.0,60.0,[])
		var count: int=0
		for i in importer.get_surface_count():count+=importer.get_surface_lod_count(i)
		resultado=importer.get_mesh();resultado.set_meta("bh_lods",count)
	for i in resultado.get_surface_count():resultado.surface_set_material(i,Materiais.equivalente(resultado.surface_get_material(i)))
	for k in mesh.get_meta_list():resultado.set_meta(k,mesh.get_meta(k))
	lods_gerados+=int(resultado.get_meta("bh_lods",0))
	_lod_cache[chave]=resultado
	return resultado
