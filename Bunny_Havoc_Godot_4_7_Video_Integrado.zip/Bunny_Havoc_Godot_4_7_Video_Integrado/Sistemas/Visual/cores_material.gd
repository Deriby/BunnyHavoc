extends RefCounted
## Mantém um ponto único para as mudanças de cor dos efeitos e caixas.
static func definir(material: BaseMaterial3D,cor: Color) -> void:
	if material.albedo_color!=cor:material.albedo_color=cor
