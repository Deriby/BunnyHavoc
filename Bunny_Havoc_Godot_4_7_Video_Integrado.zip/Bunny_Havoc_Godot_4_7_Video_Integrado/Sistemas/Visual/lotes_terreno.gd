extends RefCounted
## Faixas de 48 m com materiais compartilhados; preserva todos os triângulos.
const Malhas=preload("malhas_compartilhadas.gd")
const TAMANHO: float=48.0
static func agrupar(fase: Node3D) -> Node3D:
	var raiz:=Node3D.new();raiz.name="TerrenoAgrupado";fase.add_child(raiz)
	var grupos: Dictionary={};var fontes: Array[MeshInstance3D]=[];var originais: int=0
	for source: MeshInstance3D in fase.get_node("Bosque").find_children("*","MeshInstance3D",true,false):
		if source.mesh==null or not source.is_visible_in_tree():continue
		var pai: Node=source.get_parent();var terreno: bool=false
		while pai!=fase:
			if pai.name==&"Terreno":terreno=true;break
			pai=pai.get_parent()
		if not terreno:continue
		fontes.append(source)
		for i in source.mesh.get_surface_count():
			var mesh: ArrayMesh=Malhas.superficie(source.mesh,i,source.get_active_material(i))
			var data: Array=mesh.surface_get_arrays(0)
			var vertices: PackedVector3Array=data[Mesh.ARRAY_VERTEX]
			var indices: PackedInt32Array=data[Mesh.ARRAY_INDEX] if data[Mesh.ARRAY_INDEX]!=null else PackedInt32Array()
			var total: int=indices.size() if not indices.is_empty() else vertices.size()
			var t: Transform3D=source.global_transform
			var normal_t: Basis=t.basis.inverse().transposed()
			var mat: Material=mesh.surface_get_material(0)
			for j in range(0,total,3):
				var face: Array[int]=[];var centro:=Vector3.ZERO
				for k in 3:
					var index: int=indices[j+k] if not indices.is_empty() else j+k
					face.append(index);centro+=t*vertices[index]
				var setor: int=floori(centro.z/(3.0*TAMANHO))
				var chave: String=str(setor)+":"+str(mat.get_instance_id())
				if not grupos.has(chave):
					var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES);st.set_material(mat);grupos[chave]=st
				var tool: SurfaceTool=grupos[chave]
				for index: int in face:
					tool.set_normal((normal_t*data[Mesh.ARRAY_NORMAL][index]).normalized())
					tool.set_color(data[Mesh.ARRAY_COLOR][index] if data[Mesh.ARRAY_COLOR]!=null else Color.WHITE)
					tool.set_uv(data[Mesh.ARRAY_TEX_UV][index] if data[Mesh.ARRAY_TEX_UV]!=null else Vector2.ZERO)
					tool.add_vertex(t*vertices[index])
				originais+=1
	for st: SurfaceTool in grupos.values():
		st.index();var n:=MeshInstance3D.new();n.mesh=Malhas.com_lods(st.commit());raiz.add_child(n)
	for source in fontes:
		source.visible=false;source.set_meta("bh_somente_autoria",true)
	raiz.set_meta("fontes",fontes);raiz.set_meta("triangulos",originais)
	return raiz
