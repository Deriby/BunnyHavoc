extends RefCounted
## Une peças estáticas do mesmo membro/material; preserva cada pivô animado.
static var _cache: Dictionary={}
const Materiais=preload("materiais_compartilhados.gd")
const Malhas=preload("malhas_compartilhadas.gd")
static func agrupar(raiz: Node3D) -> void:
	if raiz.has_meta("bh_lotes_personagens"):return
	var registros: Array=[]
	_visitar(raiz,registros)
	raiz.set_meta("bh_lotes_personagens",registros)
static func _visitar(pai: Node3D,registros: Array) -> void:
	var grupos: Dictionary={}
	for n in pai.get_children():
		if n is Node3D and not n is MeshInstance3D:_visitar(n,registros)
		if not n is MeshInstance3D:continue
		if not n.visible or n.mesh==null or n.mesh.get_surface_count()!=1 or n.transform.basis.determinant()<=0:continue
		var material: Material=n.get_active_material(0)
		if not material is BaseMaterial3D or material.transparency!=BaseMaterial3D.TRANSPARENCY_DISABLED:continue
		material=Materiais.equivalente(material)
		n.material_override=material
		# Pálpebras, sobrancelhas e casco mantêm nós independentes para animação.
		if not String(n.name).begins_with("Malha_"):continue
		var unificada: ArrayMesh=Malhas.superficie(n.mesh,0,material)
		var chave: String=str(unificada.surface_get_material(0).get_instance_id())+":"+str(n.cast_shadow)+":"+str(n.layers)
		if not grupos.has(chave):grupos[chave]={"material":unificada.surface_get_material(0),"pecas":[]}
		grupos[chave].pecas.append(n)
	for grupo: Dictionary in grupos.values():
		var pecas: Array=grupo.pecas
		if pecas.size()<2:continue
		var material: Material=grupo.material
		var chave: String=str(material.get_instance_id())
		for p: MeshInstance3D in pecas:chave+="/"+str(p.mesh.get_rid())+":"+str(p.transform)
		if not _cache.has(chave):
			var tool:=SurfaceTool.new();tool.begin(Mesh.PRIMITIVE_TRIANGLES)
			for p: MeshInstance3D in pecas:tool.append_from(Malhas.superficie(p.mesh,0,p.get_active_material(0)),0,p.transform)
			tool.set_material(material);_cache[chave]=tool.commit()
		var lote:=MeshInstance3D.new();lote.name="LoteVisual"+str(registros.size())
		lote.mesh=_cache[chave];lote.cast_shadow=pecas[0].cast_shadow;lote.layers=pecas[0].layers
		pai.add_child(lote)
		for p: MeshInstance3D in pecas:
			p.visible=false;p.set_meta("bh_somente_autoria",true)
		registros.append({"lote":lote,"pecas":pecas})
