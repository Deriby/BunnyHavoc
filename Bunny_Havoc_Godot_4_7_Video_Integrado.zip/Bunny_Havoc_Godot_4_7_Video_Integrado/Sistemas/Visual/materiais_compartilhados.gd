extends RefCounted
## Deduplica materiais visualmente idênticos.
static var _assinaturas: Dictionary={}
static var _materiais: Dictionary={}
static func equivalente(material: BaseMaterial3D) -> BaseMaterial3D:
	var id: int=material.get_instance_id()
	if _assinaturas.has(id):return _assinaturas[id]
	if material.shading_mode==BaseMaterial3D.SHADING_MODE_PER_PIXEL:
		material=material.duplicate()
		material.shading_mode=BaseMaterial3D.SHADING_MODE_PER_VERTEX
		material.specular_mode=BaseMaterial3D.SPECULAR_DISABLED
	var propriedades: Array=[]
	for p: Dictionary in material.get_property_list():
		if not (int(p.usage)&PROPERTY_USAGE_STORAGE) or String(p.name).begins_with("resource_"):continue
		var valor: Variant=material.get(p.name)
		if valor is Resource:valor=valor.get_instance_id()
		propriedades.append([p.name,valor])
	var assinatura: String=var_to_bytes(propriedades).hex_encode().sha256_text()
	if not _materiais.has(assinatura):_materiais[assinatura]=material
	_assinaturas[id]=_materiais[assinatura]
	return _materiais[assinatura]
