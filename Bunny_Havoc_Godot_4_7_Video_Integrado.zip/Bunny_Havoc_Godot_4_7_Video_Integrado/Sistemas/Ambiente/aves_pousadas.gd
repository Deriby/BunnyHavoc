extends Node3D
## Aves nas margens reutilizam o modelo original; não interferem na colisão.
const Modelo=preload("res://Biblioteca/Modelos/Passaro.glb")
var aves: Array[Dictionary]=[]
var tempo: float=0
var jogador: CharacterBody3D
func configurar(fase: Node3D,p: CharacterBody3D) -> void:
	jogador=p
	var zs: Array=[-20.0,-34.0,-80.0,-120.0,-190.0,-236.0,-282.0,-356.0]
	for i in zs.size():
		var z: float=zs[i];var x: float=2.8 if i%2==0 else -2.8
		var y: float=fase.trilho.altura(z)
		var raio:=PhysicsRayQueryParameters3D.create(Vector3(x,y+2,z),Vector3(x,y-2,z),1,[p.get_rid()])
		var piso: Dictionary=fase.get_world_3d().direct_space_state.intersect_ray(raio)
		if piso.is_empty():continue
		var n: Node3D=Modelo.instantiate();add_child(n)
		var menor: float=INF
		for mesh: MeshInstance3D in n.find_children("*","MeshInstance3D",true,false):
			var box: AABB=(n.global_transform.affine_inverse()*mesh.global_transform)*mesh.get_aabb()
			menor=minf(menor,box.position.y)
		var base:=Vector3(x,float(piso.position.y)-menor+0.025,z)
		n.position=base;n.rotation.y=-0.7 if i%2==0 else 0.7
		aves.append({"n":n,"base":base,"yaw":n.rotation.y,"idade":0.0,"estado":"idle","frente":Vector3.RIGHT,"fase":i*1.73,"a":n.find_child("Asa_0",true,false),"b":n.find_child("Asa_1",true,false)})
func atualizar(dt: float) -> void:
	tempo+=dt
	for item: Dictionary in aves:
		var n: Node3D=item.n;var base: Vector3=item.base
		item.idade+=dt
		var delta: Vector3=jogador.global_position-base
		var distancia: float=Vector2(delta.x,delta.z).length()
		var perto: bool=distancia<(5.0 if jogador._combate.atacando else 3.4) and absf(delta.y)<2.0
		if item.estado=="idle" and perto:
			item.estado="flee";item.idade=0.0
			item.frente=Vector3(-delta.x,0,-delta.z).normalized()
			if item.frente.length_squared()<0.1:item.frente=Vector3.RIGHT
		elif item.estado=="away" and item.idade>8.0 and distancia>8.0:
			item.estado="return";item.idade=0.0
		if item.estado=="idle":
			n.position=base+Vector3.UP*maxf(0,sin(tempo*2.0+item.fase))*0.025
			n.rotation=Vector3(sin(tempo*1.7+item.fase)*0.045,float(item.yaw)+sin(tempo*0.7+item.fase)*0.10,0)
			item.a.rotation.z=-0.13;item.b.rotation.z=0.13
		elif item.estado in ["flee","return"]:
			var u: float=clampf(float(item.idade)/2.2,0,1)
			var q: float=u if item.estado=="flee" else 1-u
			n.position=base+item.frente*7*pow(q,1.25)+Vector3.UP*(q*4.8+sin(q*PI)*0.8)
			var dir: Vector3=item.frente if item.estado=="flee" else -item.frente
			n.rotation.y=lerp_angle(n.rotation.y,atan2(dir.x,dir.z),1-exp(-7*dt))
			n.rotation.x=lerpf(n.rotation.x,-0.18 if item.estado=="flee" else 0.12,1-exp(-6*dt))
			item.a.rotation.z=sin(tempo*23+item.fase)*0.85;item.b.rotation.z=-item.a.rotation.z
			if u>=1:
				item.estado="away" if item.estado=="flee" else "idle";item.idade=0.0
		n.visible=item.estado!="away" and absf(base.z-jogador.position.z)<65
func reiniciar() -> void:
	tempo=0
	for item: Dictionary in aves:
		item.estado="idle";item.idade=0.0
		item.n.position=item.base;item.n.rotation=Vector3(0,item.yaw,0)
		item.a.rotation.z=-0.13;item.b.rotation.z=0.13
