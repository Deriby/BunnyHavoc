extends Node3D
## Reações visuais independentes do controlador, combate e composição da fase.
const Efeitos=preload("efeitos_bosque.gd")
var efeitos: RefCounted=Efeitos.new()
var jogador: CharacterBody3D
var fase: Node3D
var vegetacao: Array[Node]=[]
var montes: Array[Vector3]=[]
var _acumulado: float=0
var _ultimo_golpe: int=-1
var _ultimo_passo := Vector3.ZERO
var _lado: float=1
func _ready() -> void:
	process_physics_priority=25
	_configurar.call_deferred()
func _configurar() -> void:
	fase=get_parent();jogador=fase.get_node("Jogador")
	vegetacao=get_tree().get_nodes_in_group("bh_vegetacao")
	for n in fase.find_children("*","Node3D",true,false):
		if n.scene_file_path.get_file()=="FolhasCaidas.tscn":montes.append(n.global_position)
	efeitos.configurar($Efeitos)
	$AvesPousadas.configurar(fase,jogador)
	jogador.get_node("Passos").passo_tocado.connect(_passo)
	_ultimo_passo=jogador.global_position
func _liberado() -> bool:
	return jogador!=null and jogador.visible and jogador.is_physics_processing() and not fase.saude.morto and not fase.saude.encerrado and (fase.final==null or not fase.final.ativo)
func _physics_process(dt: float) -> void:
	if jogador==null:return
	visible=_liberado()
	if not visible:
		efeitos.limpar();return
	efeitos.atualizar(dt)
	$AvesPousadas.atualizar(dt)
	_acumulado+=dt
	if _acumulado>=0.05:
		_acumulado=0
		if jogador.is_on_floor() and Vector2(jogador.velocity.x,jogador.velocity.z).length()>0.6:
			for lote: Node in vegetacao:lote.reagir(jogador.global_position,0.26,1.25)
	var combo: RefCounted=jogador._combate
	var golpe: Dictionary=combo.estado
	if combo.atacando and golpe.activeHit and int(golpe.serial)!=_ultimo_golpe:
		_ultimo_golpe=int(golpe.serial)
		var frente:=Vector3(sin(float(golpe.heading)),0,cos(float(golpe.heading)))
		var centro: Vector3=jogador.global_position+(Vector3.ZERO if golpe.step==1 else frente*0.8)
		for lote: Node in vegetacao:lote.reagir(centro,0.36,2.0 if golpe.step==1 else 1.35)
		for monte: Vector3 in montes:
			if Vector2(monte.x-centro.x,monte.z-centro.z).length()<2.7 and absf(monte.y-centro.y)<1.4:
				efeitos.levantar_folhas(monte,frente,golpe.step==1)
				break
func _passo() -> void:
	if not _liberado() or not jogador.is_on_floor():return
	var pos: Vector3=jogador.global_position
	# Só terra firme original; nunca plataformas, caixas, grama lateral ou buracos.
	if absf(pos.x)>fase._largura(pos.z)-0.65:return
	if pos.distance_to(_ultimo_passo)<0.15:return
	var raio:=PhysicsRayQueryParameters3D.create(pos+Vector3.UP*0.16,pos-Vector3.UP*0.22,1,[jogador.get_rid()])
	var piso: Dictionary=get_world_3d().direct_space_state.intersect_ray(raio)
	if piso.is_empty() or piso.collider.name!="PisoOriginal":return
	_ultimo_passo=pos;_lado=-_lado
	var frente:=Vector3(jogador.velocity.x,0,jogador.velocity.z).normalized()
	var pe: Vector3=piso.position+Vector3.UP*0.035+Vector3(-frente.z,0,frente.x)*_lado*0.15
	efeitos.passo(pe,frente,Vector2(jogador.velocity.x,jogador.velocity.z).length()>8.0)
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_R or event.keycode==KEY_R):reiniciar()
func reiniciar() -> void:
	efeitos.limpar();$AvesPousadas.reiniciar();_ultimo_golpe=-1;_acumulado=0;_lado=1
	if jogador!=null:_ultimo_passo=jogador.global_position
	for lote: Node in vegetacao:lote.limpar_reacoes()
