extends RefCounted
## Dois pools pequenos e fixos. Sem criar nós/materiais durante os passos.
const Modelos=preload("res://Cenas/Natureza/Detalhes/modelos_bosque.gd")
var poeira: Array[Dictionary]=[]
var folhas: Array[Dictionary]=[]
var _serial: int=0
func configurar(raiz: Node3D) -> void:
	var mesh:=SphereMesh.new();mesh.radial_segments=6;mesh.rings=3;mesh.radius=0.5;mesh.height=1.0
	var mat:=StandardMaterial3D.new();mat.albedo_color=Color("baa17a").srgb_to_linear();mat.roughness=1.0
	mesh.material=mat
	_criar_pool(raiz,poeira,mesh,12)
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	Modelos._folha(st,Vector3(-0.13,0,0),Vector3(0.14,0,0),0.075,Color("a3874b"))
	var leafmat:=StandardMaterial3D.new();leafmat.vertex_color_use_as_albedo=true
	leafmat.cull_mode=BaseMaterial3D.CULL_DISABLED;leafmat.roughness=1.0;st.set_material(leafmat)
	_criar_pool(raiz,folhas,st.commit(),14)
func _criar_pool(raiz: Node3D,pool: Array[Dictionary],mesh: Mesh,quantidade: int) -> void:
	for i in quantidade:
		var n:=MeshInstance3D.new();n.mesh=mesh;n.visible=false
		n.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;raiz.add_child(n)
		pool.append({"n":n,"ativo":false,"idade":0.0,"duracao":1.0,"base":Vector3.ZERO,"vel":Vector3.ZERO,"fase":i*2.399,"tamanho":1.0})
func _emitir(pool: Array[Dictionary],pos: Vector3,vel: Vector3,duracao: float,tamanho: float) -> void:
	for item: Dictionary in pool:
		if item.ativo:continue
		item.ativo=true;item.idade=0.0;item.base=pos;item.vel=vel;item.duracao=duracao;item.tamanho=tamanho
		item.n.global_position=pos;item.n.scale=Vector3.ONE*tamanho;item.n.visible=true
		return
func passo(pos: Vector3,direcao: Vector3,correndo: bool) -> void:
	_serial+=1
	for i in (3 if correndo else 2):
		var a: float=_serial*2.399+i*TAU/3
		var lateral:=Vector3(cos(a),0,sin(a))*0.18
		_emitir(poeira,pos+lateral*0.22,Vector3(lateral.x,0.28,lateral.z)-direcao*0.20,0.42,0.14 if correndo else 0.10)
func levantar_folhas(pos: Vector3,direcao: Vector3,giro: bool) -> void:
	_serial+=1
	for i in (5 if giro else 3):
		var a: float=_serial*2.399+i*2.1
		var radial:=Vector3(cos(a),0,sin(a))
		_emitir(folhas,pos+radial*0.18+Vector3.UP*0.04,radial*(0.65 if giro else 0.28)+direcao*0.8+Vector3.UP*(1.8+0.12*i),0.85+0.04*i,0.75+0.1*(i%3))
func atualizar(dt: float) -> void:
	for pool: Array in [poeira,folhas]:
		for item: Dictionary in pool:
			if not item.ativo:continue
			item.idade+=dt
			var t: float=item.idade;var u: float=t/item.duracao
			if u>=1:item.ativo=false;item.n.visible=false;continue
			var folha: bool=pool==folhas
			item.n.global_position=item.base+item.vel*t+Vector3.DOWN*(1.7 if folha else 0.12)*t*t
			if folha:
				item.n.rotation=Vector3(t*5+item.fase,t*3,sin(t*9+item.fase)*0.6)
			else:item.n.rotation=Vector3(item.fase,t*0.5,0)
			var fim: float=1-smoothstep(0.58,1,u)
			item.n.scale=Vector3.ONE*float(item.tamanho)*fim*(1.0 if folha else 0.65+u*0.6)
func limpar() -> void:
	for pool: Array in [poeira,folhas]:
		for item: Dictionary in pool:item.ativo=false;item.n.visible=false
