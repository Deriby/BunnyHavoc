extends Node3D
## Integra os componentes existentes à arena, sem substituir o controlador.

const Vida = preload("vida_bunnyck.gd")

var jogador: CharacterBody3D
var urso: CharacterBody3D
var vida: Node
var iniciado: bool = false
@export var detectar_queda: bool = true
var _combo: RefCounted
var _coracoes: Label
var _vidas: Label
var _mensagem: Label
var _camera: Camera3D
var _posicao_camera: Vector3
var _shake: float = 0.0
var _forca_shake: float = 1.0

func _ready() -> void:
	process_physics_priority = 10
	var node: Node = get_parent()
	while node != null and jogador == null:
		if node is CharacterBody3D and node.name == "Jogador":
			jogador = node as CharacterBody3D
		else:
			jogador = node.get_node_or_null("Jogador") as CharacterBody3D
		node = node.get_parent()
	if jogador == null:
		push_warning("Coloque Combate.tscn na cena que contém o Jogador.")
		set_physics_process(false)
		return
	top_level = true
	global_transform = Transform3D.IDENTITY
	_combo = jogador.get("_combate") as RefCounted
	urso = $Urso as CharacterBody3D
	urso.jogador = jogador
	urso.global_position = jogador.global_position + Vector3(0, 0, -5.5)
	urso.set("_inicio", urso.global_position)
	urso.chao_y = jogador.global_position.y
	vida = Vida.new()
	vida.name = "Saude"
	jogador.add_child(vida)
	vida.connect("mudou", _atualizar_hud)
	vida.connect("renasceu", _retomar)
	vida.connect("fim_de_jogo", _fim)
	urso.connect("derrotado", _vitoria)
	urso.connect("pancada_no_chao", _impacto)
	_camera = get_viewport().get_camera_3d()
	_criar_hud()
	_atualizar_hud()

func _label(parent: Node, texto: String, pos: Vector2, tamanho: int, cor: Color) -> Label:
	var label := Label.new()
	label.text = texto
	label.position = pos
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", tamanho)
	label.add_theme_color_override("font_color", cor)
	label.add_theme_color_override("font_outline_color", Color("241335"))
	label.add_theme_constant_override("outline_size", 4)
	parent.add_child(label)
	return label

func _criar_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUD"
	add_child(layer)
	_coracoes = _label(layer, "", Vector2(18, 12), 30, Color("ff5d7c"))
	_vidas = _label(layer, "", Vector2(20, 49), 16, Color("fff0dc"))
	_mensagem = _label(layer, "Mexa-se ou ataque para começar", Vector2(20, 82), 16, Color("ffe6a4"))
	var ajuda := _label(layer, "WASD / setas: mover   Espaço: pular   J / Shift: combo   R: reiniciar treino", Vector2.ZERO, 14, Color("fff0dc"))
	ajuda.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	ajuda.position = Vector2(20, get_viewport().get_visible_rect().size.y - 30)

func _atualizar_hud() -> void:
	if _coracoes == null:
		return
	_coracoes.text = "♥ ".repeat(vida.coracoes) + "♡ ".repeat(3 - vida.coracoes)
	_vidas.text = "Vidas × " + str(vida.vidas)

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var tecla: int = event.physical_keycode if event.physical_keycode else event.keycode
		if tecla == KEY_R:
			vida.reiniciar()
			_retomar()
			get_viewport().set_input_as_handled()

func _retomar() -> void:
	urso.reiniciar()
	urso.ativo = false
	iniciado = false
	_mensagem.text = "Mexa-se ou ataque para começar"

func _fim() -> void:
	urso.ativo = false
	_mensagem.text = "Fim de jogo — R para recomeçar"

func _vitoria() -> void:
	_mensagem.text = "Urso derrotado! R para treinar novamente"

func _impacto() -> void:
	_shake = 0.26
	_forca_shake = 2.0

func _physics_process(dt: float) -> void:
	if jogador == null:
		return
	if not iniciado and not vida.encerrado and (Vector2(jogador.velocity.x, jogador.velocity.z).length() > 0.2 or _combo.atacando or jogador.velocity.y > 0.1):
		iniciado = true
		urso.ativo = true
		_mensagem.text = "J / Shift repetido: giro → soco → soco final"
	if not vida.morto and not vida.encerrado:
		if detectar_queda and jogador.global_position.y < float(jogador.get("_inicio").y) - 3.0:
			vida.receber_dano(3, null, "pit")
		elif not urso.derrotado_agora and urso.visible:
			_resolver_contato()
	_shake = maxf(0.0, _shake - dt)
	if is_instance_valid(_camera) and _shake > 0.0:
		_camera.position.x += sin(_shake * 170.0) * _shake * 0.16 * _forca_shake
		_camera.position.y += cos(_shake * 140.0) * _shake * 0.10 * _forca_shake

func _resolver_contato() -> void:
	var delta_pos: Vector3 = jogador.global_position - urso.global_position
	var contato: bool = absf(delta_pos.x) < 1.35 and absf(delta_pos.z) < 1.05 and delta_pos.y < 1.8 and delta_pos.y > -0.7
	var na_frente: bool = delta_pos.dot(urso.global_basis.z)>0.0
	contato = contato or (na_frente and urso.alcance_ataque > 0.0 and Vector2(delta_pos.x, delta_pos.z).length() < urso.alcance_ataque and delta_pos.y < 1.7 and delta_pos.y > -0.7)
	var golpe: bool = _combo.pode_atingir(urso, 2.05) and delta_pos.y < 1.8 and delta_pos.y > -0.6
	if golpe:
		_combo.registrar_acerto(urso)
		var info: Dictionary = _combo.golpe_para(urso)
		var heading: float = info.heading
		if _combo.estado.step == 1:
			heading = atan2(-delta_pos.x, -delta_pos.z) if Vector2(delta_pos.x, delta_pos.z).length() > 0.001 else heading
		urso.receber_golpe(info.damage, heading, info.finisher)
		_combo.aplicar_pose()
	elif jogador.pisou_em(urso):
		urso.receber_golpe(1, atan2(-delta_pos.x, -delta_pos.z), false)
		jogador.velocity.y = 9.0
	elif contato and jogador.velocity.y < -0.6 and delta_pos.y > 0.67:
		urso.receber_golpe(1, atan2(-delta_pos.x, -delta_pos.z), false)
		jogador.velocity.y = 9.0
	elif (contato or jogador.encostou_em(urso)) and urso.pode_causar_dano():
		if vida.receber_dano(1, urso):
			_shake = 0.18
			_forca_shake = 1.0
