extends RefCounted
## Mesmo modelo: passada quadrúpede, elevação para a garra e retorno suave.

var corpo: Node3D
var torso: Node3D
var cabeca: Node3D
var mandibula: Node3D
var pernas: Array[Node3D] = []
var bracos: Array[Node3D] = []
var antebracos: Array[Node3D] = []
var ombros: Array[Node3D] = []
var olhar_local: Vector3=Vector3.FORWARD
var _atencao: float=0.0
var _origens: Dictionary = {}
const INCLINACAO: float = 1.248576
var _tempo: float = 0.0
var _em_pe: float = 0.0
var _passada: float = 0.0
var _atividade: float = 0.0
var _recuperando_ataque: bool = false
var _patas: Array[MeshInstance3D] = []

func configurar(visual: Node3D) -> void:
	corpo = visual.find_child("CorpoUrso", true, false) as Node3D
	torso = visual.find_child("Torso", true, false) as Node3D
	cabeca = visual.find_child("Cabeca", true, false) as Node3D
	mandibula = visual.find_child("Mandibula", true, false) as Node3D
	for lado in ["E", "D"]:
		pernas.append(visual.find_child("Perna_" + lado, true, false) as Node3D)
		bracos.append(visual.find_child("Braco_" + lado, true, false) as Node3D)
		antebracos.append(visual.find_child("Antebraco_" + lado, true, false) as Node3D)
		ombros.append(visual.find_child("Ombro_" + lado, true, false) as Node3D)
	for node in [corpo, torso, cabeca, mandibula] + pernas + bracos + antebracos + ombros:
		node.rotation_order = EULER_ORDER_XYZ
		_origens[node] = node.transform
	# A terceira malha de cada membro é a pata; as duas primeiras são os segmentos.
	for membro: Node3D in pernas + bracos:
		_patas.append(membro.find_children("UrsoPeca_*", "MeshInstance3D", true, false)[2] as MeshInstance3D)
	aplicar_quadrupede()

func reiniciar() -> void:
	for node: Node3D in _origens:
		node.transform = _origens[node]
	corpo.visible = true

func suavizar(node: Node3D, eixo: int, alvo: float, taxa: float, dt: float) -> void:
	var rot: Vector3 = node.rotation
	rot[eixo] = lerpf(rot[eixo], alvo, minf(1.0, taxa * dt))
	node.rotation = rot

func _apoiar_pata(indice: int, membro: Node3D, altura: float) -> void:
	var pata: MeshInstance3D = _patas[indice]
	var referencia: Transform3D = (corpo.get_parent() as Node3D).global_transform.affine_inverse()
	var transformacao: Transform3D = referencia * pata.global_transform
	var caixa: AABB = pata.get_aabb()
	var menor: float = INF
	for k in 8:
		menor = minf(menor, (transformacao * caixa.get_endpoint(k)).y)
	# Corrige pelo eixo vertical do pai, inclusive com o torso inclinado.
	var pai: Transform3D = referencia * (membro.get_parent() as Node3D).global_transform
	membro.position += pai.basis.inverse() * Vector3(0, -0.07 + altura - menor, 0)

func aplicar_quadrupede(fase: float = 0.0, atividade: float = 0.0) -> void:
	reiniciar()
	torso.rotation.x = INCLINACAO
	corpo.position.z = -0.48
	cabeca.rotation.x = -INCLINACAO
	var respiracao: float = sin(_tempo * 2.1) * 0.012
	corpo.position.y = respiracao + absf(sin(fase)) * 0.025 * atividade
	corpo.rotation.z = sin(fase) * 0.018 * atividade
	cabeca.rotation.z = -sin(fase) * 0.025 * atividade
	mandibula.rotation.x = 0.035 + atividade * 0.055
	for i in 2:
		var passo: float = fase + i * PI
		# Pares diagonais: a dianteira esquerda acompanha a traseira direita.
		pernas[i].rotation.x = sin(passo) * 0.28 * atividade
		bracos[i].rotation.x = -INCLINACAO + sin(passo + PI) * 0.24 * atividade
		antebracos[i].rotation.x = -maxf(0.0, cos(passo + PI)) * 0.22 * atividade
		_apoiar_pata(i, pernas[i], maxf(0.0, cos(passo)) * 0.10 * atividade)
		_apoiar_pata(i + 2, bracos[i], maxf(0.0, cos(passo + PI)) * 0.13 * atividade)

func atualizar(dt: float, estado: String, idade: float, perseguindo: bool, movendo: bool) -> void:
	_tempo += dt
	_atividade = move_toward(_atividade, 1.0 if estado == "walk" and movendo else 0.0, dt * 7.0)
	_passada += dt * (9.0 if perseguindo else 5.0) * _atividade
	var alvo_em_pe: float = 0.0
	if estado == "wind":
		_recuperando_ataque = true
		alvo_em_pe = smoothstep(0.0, 0.30, idade)
	elif estado == "swipe":
		_recuperando_ataque = true
		alvo_em_pe = 1.0
	elif estado == "recover" and _recuperando_ataque:
		alvo_em_pe = 1.0 - smoothstep(0.06, 0.55, idade)
	elif estado == "walk":
		_recuperando_ataque = false
	_em_pe = move_toward(_em_pe, alvo_em_pe, dt * 6.0)
	aplicar_quadrupede(_passada, _atividade)
	var peso_olhar: float=(1.0-_em_pe)*(1.0 if perseguindo else 0.0)
	var yaw: float=clampf(atan2(olhar_local.x,olhar_local.z),-0.30,0.30)*peso_olhar
	_atencao=lerpf(_atencao,yaw,1.0-exp(-5.0*dt))
	cabeca.rotation.y=_atencao
	var sniff: float=sin(PI*clampf((fposmod(_tempo,7.8)-1.2)/1.1,0,1))*(1.0-_em_pe)*(0.0 if perseguindo else 1.0)
	cabeca.rotation.x+=0.12*sniff
	cabeca.rotation.z+=sin(_tempo*1.4)*0.018*(1.0-_em_pe)
	mandibula.rotation.x+=0.035*sniff
	if estado=="sniff":
		var farejo: float=sin(clampf(idade/0.65,0,1)*PI)
		cabeca.rotation.x+=farejo*0.22
		mandibula.rotation.x+=farejo*0.06
	if _em_pe <= 0.0:
		return
	# Poses originais da garra; apenas a transição de postura foi refinada.
	var tronco: float = 0.0
	var braco: float = 0.0
	var abertura: float = 0.0
	var antebraco: float = 0.0
	var head: float = 0.0
	var boca: float = 0.0
	if estado == "wind":
		var u: float = smoothstep(0.0, 0.5, idade)
		tronco = -0.55 * u
		braco = -2.7 * u
		abertura = 0.5 * u
		antebraco = -0.9 * u
		head = -0.4 * u
		boca = 0.7 * u
	elif estado == "swipe":
		var u: float = smoothstep(0.0, 0.22, idade)
		tronco = -0.55 + 0.9 * u
		braco = -2.7 + 3.2 * u
		abertura = 0.5 - 0.3 * u
		antebraco = -0.9 * (1.0 - u)
		head = -0.4 + 0.7 * u
		boca = 0.5
	elif estado == "recover":
		var u: float = smoothstep(0.0, 0.6, idade)
		tronco = 0.35 * (1.0 - u)
		braco = 0.5 * (1.0 - u)
		abertura = 0.2 * (1.0 - u)
		head = 0.3 * (1.0 - u)
		boca = 0.3 * (1.0 - u)
	corpo.position *= 1.0 - _em_pe
	corpo.rotation *= 1.0 - _em_pe
	torso.rotation.x = lerpf(torso.rotation.x, tronco, _em_pe)
	cabeca.rotation.x = lerpf(cabeca.rotation.x, head, _em_pe)
	mandibula.rotation.x = lerpf(mandibula.rotation.x, boca, _em_pe)
	for i in 2:
		var sinal: float = -1.0 if i == 0 else 1.0
		bracos[i].rotation.x = lerpf(bracos[i].rotation.x, braco, _em_pe)
		bracos[i].rotation.z = sinal * abertura * _em_pe
		antebracos[i].rotation.x = lerpf(antebracos[i].rotation.x, antebraco, _em_pe)
		bracos[i].position = bracos[i].position.lerp((_origens[bracos[i]] as Transform3D).origin, _em_pe)
		pernas[i].position = pernas[i].position.lerp((_origens[pernas[i]] as Transform3D).origin, _em_pe)
		pernas[i].rotation.x = lerpf(pernas[i].rotation.x, -0.15 if estado == "wind" else 0.0, _em_pe)
		_apoiar_pata(i, pernas[i], 0.0)

func dano(idade: float, duracao: float, _finalizador: bool) -> void:
	var u: float = clampf(idade / duracao, 0.0, 1.0)
	_em_pe = 0.0
	_recuperando_ataque = false
	aplicar_quadrupede()
	corpo.rotation.x = -0.12 * sin(u * PI)
	corpo.rotation.z = 0.12 * sin(u * PI)
	cabeca.rotation.x -= 0.18 * sin(u * PI)
	for i in 2:
		bracos[i].rotation.x -= 0.35 * sin(u * PI)
		bracos[i].rotation.z = (-1.0 if i == 0 else 1.0) * 0.15 * sin(u * PI)
		pernas[i].rotation.x = (-0.25 if i == 0 else 0.3) * sin(u * PI)

func retomar() -> void:
	_em_pe = 0.0
	_atividade = 0.0
	_recuperando_ataque = false
	aplicar_quadrupede()
