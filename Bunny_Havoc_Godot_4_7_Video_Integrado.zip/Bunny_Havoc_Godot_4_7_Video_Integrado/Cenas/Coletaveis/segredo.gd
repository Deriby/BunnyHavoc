extends "cenoura.gd"
## Três cenouras douradas da fonte: 25 cenouras cada, mantidas após morrer.
func _ready() -> void:
	super._ready()
	add_to_group("bh_segredos")
func _physics_process(dt: float) -> void:
	_tempo += dt
	if not visible:
		return
	rotation.y += dt * 1.8
	position.y = _base_y + sin(_tempo * 2.0) * 0.22
	if pode_interagir():
		var d: Vector3 = global_position - _jogador.global_position
		if Vector2(d.x,d.z).length() < 1.0 and absf(d.y) < 1.9:
			coletar()
