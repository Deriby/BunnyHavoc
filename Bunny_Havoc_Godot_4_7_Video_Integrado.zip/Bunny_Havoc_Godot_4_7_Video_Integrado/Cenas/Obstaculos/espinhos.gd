extends "res://Sistemas/Coleta/objeto_interativo.gd"
@export var meia_largura: float = 1.68
@export var dano: int = 3
func _ready() -> void:
	preload("res://Sistemas/Visual/malhas_compartilhadas.gd").agrupar_visual($Visual)
	process_physics_priority = 17
func _physics_process(_dt: float) -> void:
	if not pode_interagir():
		return
	var local: Vector3 = to_local(_jogador.global_position)
	if absf(local.x) < meia_largura and absf(local.z) < 0.7 and local.y < 0.7:
		var saude := _jogador.get_node_or_null("Saude")
		if saude != null:
			saude.receber_dano(dano)
