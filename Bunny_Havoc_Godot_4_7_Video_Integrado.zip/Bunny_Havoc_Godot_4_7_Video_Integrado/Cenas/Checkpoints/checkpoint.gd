extends "res://Sistemas/Coleta/objeto_interativo.gd"
const Malhas=preload("res://Sistemas/Visual/malhas_compartilhadas.gd")
const Cores=preload("res://Sistemas/Visual/cores_material.gd")
signal ativado(posicao: Vector3)
@export var somente_avanco: bool = false
@export var giro_visual: float = 0.0
var ativo: bool = false
var _malha_inativa: ArrayMesh
var _malha_ativa: ArrayMesh
var _lote: MeshInstance3D
var _materiais: Array[Dictionary] = []

func _ready() -> void:
	process_physics_priority = 18
	$Visual.rotate_y(giro_visual)
	add_to_group("bh_checkpoints")
	for mesh: MeshInstance3D in $Visual.find_children("*", "MeshInstance3D", true, false):
		var material := mesh.get_active_material(0).duplicate() as StandardMaterial3D
		mesh.material_override = material
		_materiais.append({"material": material, "color": material.albedo_color})
	Malhas.agrupar_visual($Visual)
	var registro: Dictionary=$Visual.get_meta("bh_visual_agrupado")
	_lote=registro.lote;_malha_inativa=_lote.mesh
	var originais: Array=[]
	var pecas: Array[MeshInstance3D]=[];pecas.assign(registro.pecas)
	for p in pecas:
		originais.append(p.material_override)
		var mat: BaseMaterial3D=p.material_override.duplicate();mat.albedo_color=Color("9b5cff");p.material_override=mat
	_malha_ativa=Malhas.planta($Visual,pecas)
	for i in pecas.size():pecas[i].material_override=originais[i]


func _physics_process(_dt: float) -> void:
	if ativo or not pode_interagir() or not _jogador.is_on_floor():
		return
	var caixa := $Gatilho/CollisionShape3D as CollisionShape3D
	var metade: Vector3 = (caixa.shape as BoxShape3D).size * 0.5
	var local: Vector3 = caixa.to_local(_jogador.global_position)
	if absf(local.x) < metade.x and absf(local.y) < metade.y and absf(local.z) < metade.z:
		ativar()

func ativar() -> void:
	if ativo or localizar_jogador() == null:
		return
	if somente_avanco and $Reaparecimento.global_position.z >= float((_jogador.get("_inicio") as Vector3).z) - 0.01:
		return
	ativo = true
	_lote.mesh=_malha_ativa
	_jogador.set("_inicio", $Reaparecimento.global_position)
	for item: Dictionary in _materiais:
		Cores.definir(item.material,Color("9b5cff"))
	$Som.play()
	ativado.emit($Reaparecimento.global_position)

func reiniciar() -> void:
	ativo = false
	_lote.mesh=_malha_inativa
	for item: Dictionary in _materiais:
		Cores.definir(item.material,item.color)
