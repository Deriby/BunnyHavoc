extends RefCounted
## Malhas compartilhadas: folhas dobradas, casca facetada e anéis de madeira.
static var cache: Dictionary={}
static func obter(tipo: String) -> ArrayMesh:
	if cache.has(tipo):return cache[tipo]
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	match tipo:
		"samambaia":_samambaia(st)
		"tronco":_tronco(st)
		"raizes":_raizes(st)
		"folhas":_folhas(st)
		"asa":_asa(st)
	var material:=StandardMaterial3D.new()
	material.vertex_color_use_as_albedo=true
	material.cull_mode=BaseMaterial3D.CULL_DISABLED
	material.roughness=1.0
	st.set_material(material)
	var mesh: ArrayMesh=st.commit();mesh.resource_name=tipo
	cache[tipo]=mesh
	return mesh
static func _tri(st: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,cor: Color) -> void:
	var normal: Vector3=(b-a).cross(c-a).normalized()
	for p in [a,b,c]:st.set_normal(normal);st.set_color(cor.srgb_to_linear());st.add_vertex(p)
static func _folha(st: SurfaceTool,base: Vector3,ponta: Vector3,largura: float,cor: Color) -> void:
	var dir: Vector3=(ponta-base).normalized()
	var lateral: Vector3=Vector3(-dir.z,0,dir.x)*largura
	var meio: Vector3=base.lerp(ponta,0.48)+Vector3.UP*largura*0.20
	var bordo: Vector3=base.lerp(ponta,0.4)
	_tri(st,base,bordo+lateral,meio,cor.darkened(0.10))
	_tri(st,bordo+lateral,ponta,meio,cor)
	_tri(st,meio,ponta,bordo-lateral,cor.lightened(0.06))
	_tri(st,base,meio,bordo-lateral,cor)
static func _samambaia(st: SurfaceTool) -> void:
	for f in 7:
		var ang: float=float(f)*TAU/7.0+0.12
		var dir:=Vector3(cos(ang),0,sin(ang))
		var lateral:=Vector3(-dir.z,0,dir.x)
		var length: float=0.68+0.13*sin(f*2.1)
		for n in 7:
			var u: float=float(n)/7.0
			var v: float=float(n+1)/7.0
			var a: Vector3=dir*u*length+Vector3.UP*(0.07+sin(u*PI*0.85)*0.37)
			var b: Vector3=dir*v*length+Vector3.UP*(0.07+sin(v*PI*0.85)*0.37)
			_tri(st,a-lateral*0.009,b-lateral*0.005,a+lateral*0.009,Color("486d32"))
			_tri(st,b-lateral*0.005,b+lateral*0.005,a+lateral*0.009,Color("486d32"))
			if n==0:continue
			var tam: float=0.25*sin((u*0.86+0.12)*PI)*(1-u*0.35)
			for s in [-1,1]:
				var tip: Vector3=a+lateral*s*tam+dir*0.10+Vector3.UP*0.025
				_folha(st,a,tip,tam*0.23,Color("46944d") if f%2 else Color("367943"))
static func _madeira(st: SurfaceTool,a: Vector3,b: Vector3,r1: float,r2: float,cor: Color) -> void:
	var dir: Vector3=(b-a).normalized()
	var up: Vector3=Vector3.UP if absf(dir.y)<0.9 else Vector3.RIGHT
	var x: Vector3=dir.cross(up).normalized();var y: Vector3=dir.cross(x).normalized()
	for i in 8:
		var p: float=i*TAU/8;var q: float=(i+1)*TAU/8
		var u: Vector3=x*cos(p)+y*sin(p);var v: Vector3=x*cos(q)+y*sin(q)
		var shade: Color=cor.lightened(0.06) if i%3 else cor.darkened(0.16)
		_tri(st,a+u*r1,a+v*r1,b+u*r2,shade)
		_tri(st,a+v*r1,b+v*r2,b+u*r2,shade)
static func _corte(st: SurfaceTool,pos: Vector3,r: float) -> void:
	for ring in 5:
		var a: float=r*ring/5.0;var b: float=r*(ring+1)/5.0
		var cor: Color=Color("be965b") if ring%2 else Color("8c623b")
		for i in 8:
			var p: float=i*TAU/8;var q: float=(i+1)*TAU/8
			var u:=Vector3(0,cos(p),sin(p));var v:=Vector3(0,cos(q),sin(q))
			_tri(st,pos+u*a,pos+u*b,pos+v*b,cor)
			_tri(st,pos+u*a,pos+v*b,pos+v*a,cor)
static func _tronco(st: SurfaceTool) -> void:
	var a:=Vector3(-0.95,0.27,0);var b:=Vector3(-0.23,0.30,0.04);var c:=Vector3(0.85,0.24,-0.025)
	_madeira(st,a,b,0.24,0.29,Color("6d4931"));_madeira(st,b,c,0.29,0.19,Color("785237"))
	_corte(st,a-Vector3.RIGHT*0.005,0.235);_corte(st,c+Vector3.RIGHT*0.005,0.185)
	_madeira(st,Vector3(-0.30,0.48,0.04),Vector3(-0.12,0.76,0.15),0.10,0.045,Color("6b4932"))
	for i in 4:
		var ang: float=0.35+i*0.62
		var offset:=Vector3(0,sin(ang)*0.27,cos(ang)*0.27)
		_madeira(st,b+offset*0.90,c+offset*0.60,0.016,0.009,Color("493728"))
	for i in 5:
		var base:=Vector3(-0.6+i*0.23,0.48,-0.08)
		_folha(st,base,base+Vector3(0.15,0.08,0.14),0.07,Color("5c7e42"))
static func _raizes(st: SurfaceTool) -> void:
	for i in 4:
		var ang: float=-0.6+i*0.56
		var d:=Vector3(cos(ang),0,sin(ang))
		_madeira(st,Vector3(0,0.14,0),d*0.43+Vector3.UP*0.08,0.12,0.075,Color("795238"))
		_madeira(st,d*0.43+Vector3.UP*0.08,d*(0.85+i*0.08)+Vector3.UP*0.015,0.075,0.012,Color("63472f"))
static func _folhas(st: SurfaceTool) -> void:
	for i in 13:
		var a: float=i*2.399
		var base:=Vector3(cos(a)*0.14*sqrt(i),0.015+0.004*(i%3),sin(a)*0.13*sqrt(i))
		var d:=Vector3(cos(a+0.8),0,sin(a+0.8))
		_folha(st,base,base+d*(0.20+(i%3)*0.04),0.07,[Color("9b7541"),Color("967d43"),Color("b0924d")][i%3])
static func _asa(st: SurfaceTool) -> void:
	var c:=Color("efad4f");var dark:=Color("50384b")
	_tri(st,Vector3.ZERO,Vector3(-0.27,0,0.17),Vector3(-0.32,0,-0.10),dark)
	_tri(st,Vector3.ZERO,Vector3(-0.32,0,-0.10),Vector3(-0.08,0,-0.23),dark)
	_tri(st,Vector3(-0.025,0.005,0),Vector3(-0.24,0.005,0.13),Vector3(-0.27,0.005,-0.08),c)
	_tri(st,Vector3(-0.025,0.005,0),Vector3(-0.27,0.005,-0.08),Vector3(-0.08,0.005,-0.19),c.lightened(0.15))
