@tool
extends Node3D
const Modelos=preload("modelos_bosque.gd")
@export_enum("samambaia","tronco","raizes","folhas") var tipo: String="samambaia":
	set(value):
		tipo=value
		if is_node_ready():_montar()
func _ready() -> void:_montar()
func _montar() -> void:
	var visual:=get_node_or_null("Visual") as MeshInstance3D
	if visual==null:
		visual=MeshInstance3D.new();visual.name="Visual";add_child(visual)
	visual.mesh=Modelos.obter(tipo)
