extends RefCounted
## Peso ao empurrar a bola; passada e rolamento dependem do deslocamento real.
var corpo: Node3D
var pernas: Array[Node3D]
var antenas: Array[Node3D]
var bola: Node3D
var _ultimo: Vector3
var _passada: float=0
var _tempo: float=0
var _atividade: float=0
func configurar(c: Node3D,p: Array[Node3D],a: Array[Node3D],b: Node3D,pos: Vector3) -> void:
	corpo=c;pernas=p;antenas=a;bola=b;_ultimo=pos
func atualizar(dt: float,pos: Vector3,direcao: float,distancia_jogador: float) -> void:
	_tempo+=dt
	var deslocamento: float=Vector2(pos.x-_ultimo.x,pos.z-_ultimo.z).length()
	_ultimo=pos
	_passada+=minf(deslocamento,0.3)*10.0
	_atividade=move_toward(_atividade,clampf(deslocamento/maxf(dt,0.001),0,1),dt*7)
	corpo.scale.x=direcao
	corpo.position.y=0.015+sin(_tempo*2.3)*0.008+absf(sin(_passada))*0.035*_atividade
	corpo.rotation.x=sin(_passada)*0.025*_atividade
	corpo.rotation.z=-0.035+sin(_passada*2)*0.022*_atividade
	bola.rotation.z-=minf(deslocamento,0.3)/0.58
	for i in pernas.size():
		var ph: float=_passada+([0.0,PI,PI,0.0][i])
		pernas[i].rotation.z=sin(ph)*0.42*_atividade
		pernas[i].rotation.x=maxf(0,cos(ph))*0.13*_atividade
	var atento: float=1.0-smoothstep(2.0,6.0,distancia_jogador)
	for i in antenas.size():
		antenas[i].rotation.x=-0.10-atento*0.22+sin(_tempo*3.1+i*1.9)*0.11
		antenas[i].rotation.z=sin(_tempo*1.3+i*2.4)*0.08
func reiniciar(pos: Vector3) -> void:
	_ultimo=pos;_passada=0;_tempo=0;_atividade=0
	corpo.rotation=Vector3.ZERO;corpo.position=Vector3.ZERO

func intencao(estado: String,idade: float) -> void:
	if estado in ["notice","windup"]:
		var u: float = smoothstep(0,0.48,idade) if estado=="windup" else 0.0
		corpo.rotation.z-=0.13*u
		corpo.position.y-=0.045*u
		for i in antenas.size():
			antenas[i].rotation.x=-0.38-0.18*u
			antenas[i].rotation.z=(1 if i else -1)*0.12
	elif estado=="charge":
		corpo.rotation.z+=0.10
		for a in antenas:a.rotation.x=-0.65
	elif estado=="recover":
		var peso: float=1.0-smoothstep(0.25,0.85,idade)
		corpo.rotation.z-=0.12*peso
		for i in antenas.size():antenas[i].rotation.z+=sin(idade*19+i*PI)*0.25*peso
