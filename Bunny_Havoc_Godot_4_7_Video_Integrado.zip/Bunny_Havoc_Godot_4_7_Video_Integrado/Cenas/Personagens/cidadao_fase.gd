extends "cidadao.gd"
## Atividades extraídas de citizenLife(): coleta, vassoura, estudo, corrida e dança.
@export var atividade: String = "talk"
@export var periodo: float = 10.0
@export var vagar: float = 0.0
@export var fase: float = 0.0
var _pernas: Array[Node3D] = []
var _cauda: Node3D
var _adereco: Node3D
var _sono: Node3D

func _ready() -> void:
	super._ready()
	for i in 2:
		_pernas.append($Visual.find_child("Perna_" + str(i), true, false))
	_cauda = $Visual.find_child("Cauda", true, false)
	_adereco = $Visual.find_child("Adereco", true, false)
	_sono = $Visual.find_child("Sono", true, false)

func janela(a: float, b: float, r: float = 0.06) -> float:
	var k: float = fmod(_tempo + fase * 2.0, periodo) / periodo
	return clampf(minf((k-a)/r,(b-k)/r),0.0,1.0)

func _animar_rotina(dt: float) -> void:
	if _corpo == null:
		position.y = _inicio.y + absf(sin(_tempo * 2.0)) * 0.05
		return
	var ph: float = _tempo * 0.6 + fase
	position.x = _inicio.x + sin(ph) * vagar
	position.z = _inicio.z + cos(ph * 0.7) * vagar * 0.84
	position.y = terreno.altura(position.z) if terreno != null else _inicio.y
	var crouch: float = 0.0
	var bend: float = 0.0
	var la: float = 0.0
	var ra: float = 0.0
	var raz: float = 0.0
	var laz: float = 0.0
	var hx: float = 0.0
	var hy: float = 0.0
	var hz: float = sin(_tempo*1.3+fase)*0.05
	var tl: float = sin(_tempo*2.0+fase)*0.16
	var tz: float = 0.0
	var lg: float = vagar * 0.45
	var lf: float = 9.0
	var dist: float = Vector2(position.x-_jogador.position.x,position.z-_jogador.position.z).length()
	match atividade:
		"gather":
			var b: float = janela(0.08,0.4)
			var e: float = janela(0.45,0.78)
			crouch=0.3*b; bend=0.45*b
			la=(-0.4-sin(_tempo*9.0)*0.7)*b-2.0*e
			ra=(-0.4+sin(_tempo*9.0)*0.7)*b-2.0*e
			hx=0.4*b+sin(_tempo*16.0)*0.1*e
		"sweep":
			var sw: float = sin(_tempo*3.2+fase)
			var w: float = janela(0.75,0.92)
			la=-1.0*(1.0-w)-0.2*w; ra=-1.0*(1.0-w)-2.7*w
			laz=sw*0.35*(1.0-w); raz=laz+0.2*w; hx=-0.2*w
			_corpo.rotation.y=sw*0.25*(1.0-w)
		"study":
			var near: float = 1.0 if dist < 3.2 else 0.0
			crouch=0.4+0.15*near; bend=0.4+0.2*near
			ra=-1.4+sin(_tempo*1.7)*0.15-near*0.2; raz=sin(_tempo*1.1)*0.2
			la=-0.5-near*0.9; hx=0.35+sin(_tempo*2.4)*0.1+near*0.35
			hy=sin(_tempo*1.3)*0.3*(1.0-near); hz+=sin(_tempo*30.0)*0.03*near; lg=0.0
		"jog":
			var s: float = janela(0.72,0.92,0.05)
			lf=10.5; lg=0.7*(1.0-s)
			la=sin(_tempo*10.0)*0.9*(1.0-s)-3.0*s; ra=-sin(_tempo*10.0)*0.9*(1.0-s)-3.0*s
			position.y+=absf(sin(_tempo*10.0))*0.12*(1.0-s)
			tz=sin(_tempo*14.0)*0.5; tl=sin(_tempo*14.0)*0.1; hx=sin(_tempo*20.0)*0.05
		"sleep":
			var acordado: float = clampf((4.0-dist)/1.2,0.0,1.0)
			crouch=0.48*(1.0-acordado); bend=0.28*(1.0-acordado)
			hx=0.32*(1.0-acordado); la=-0.5; ra=-0.5-2.2*acordado; lg=0.0
			if _sono != null:
				_sono.visible=acordado < 0.3
				_sono.position.y=sin(_tempo*1.5)*0.1
		"dance":
			var q: float = sin(_tempo*5.0)
			position.y+=absf(q)*0.1; _corpo.rotation.z=q*0.08
			la=-1.8+q*0.9; ra=-1.8-q*0.9; laz=0.5; raz=0.5
			hy=sin(_tempo*2.5)*0.3; hz=q*0.12; tl=q*0.4; tz=q*0.3; lg=0.45
		_:
			var ga: float = sin(_tempo*3.1)
			la=-0.8+ga*0.5; ra=-1.0-ga*0.5; laz=0.3+ga*0.2; raz=laz
			hx=sin(_tempo*6.2)*0.08; hy=sin(_tempo*0.9)*0.35
	var smooth: float = minf(1.0,dt*12.0)
	_corpo.position.y=lerpf(_corpo.position.y,-crouch*0.9,smooth)
	_corpo.rotation.x=lerpf(_corpo.rotation.x,bend,smooth)
	for i in 2:
		if _pernas[i]!=null:
			_pernas[i].rotation.x=-crouch*0.9+sin(_tempo*lf+i*PI)*lg
		if _bracos[i]!=null:
			_bracos[i].rotation.x=lerpf(_bracos[i].rotation.x,la if i==0 else ra,smooth)
			_bracos[i].rotation.z=-laz if i==0 else raz
	if _cabeca!=null:
		_cabeca.rotation=Vector3(hx,hy,hz)
	if _cauda!=null:
		_cauda.rotation.x=tl
		_cauda.rotation.z=tz
