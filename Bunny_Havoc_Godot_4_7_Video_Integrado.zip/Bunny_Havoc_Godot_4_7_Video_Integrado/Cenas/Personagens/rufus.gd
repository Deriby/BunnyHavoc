extends "res://Cenas/Personagens/cidadao.gd"
## Rufus usa a rotina compartilhada de procurar objetos, sem alterar seu modelo.
