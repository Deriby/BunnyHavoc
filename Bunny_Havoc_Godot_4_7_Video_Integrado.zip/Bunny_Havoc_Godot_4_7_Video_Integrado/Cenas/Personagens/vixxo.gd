extends "cidadao_fase.gd"
## O GLB original do Vixxo não tinha pescoço. Agrupa suas peças, sem mudar malhas.
func _ready() -> void:
	var visual: Node3D=$Visual
	if visual.find_child("Cabeca",true,false)==null:
		var primeira: Node3D=visual.find_child("Malha_6",true,false)
		var base: Node3D=primeira.get_parent()
		var head:=Node3D.new();head.name="Cabeca";head.position=Vector3(0,1.95,0);base.add_child(head)
		for indice in [6,7,8,9,10,16,17,18,19,20,25,26,27]:
			var peca: Node3D=visual.find_child("Malha_"+str(indice),true,false)
			peca.reparent(head,true)
	super._ready()
