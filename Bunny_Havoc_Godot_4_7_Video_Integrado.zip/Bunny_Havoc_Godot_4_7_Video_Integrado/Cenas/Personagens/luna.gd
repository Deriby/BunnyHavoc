extends "res://Cenas/Personagens/cidadao.gd"
## Rotina original de Luna: sentada na almofada, observa o céu e se espreguiça.
var _pernas: Array[Node3D] = []
var _cauda: Node3D

func _ready() -> void:
	super._ready()
	for i in 2:
		_pernas.append($Visual.find_child("Perna_" + str(i), true, false))
	_cauda = $Visual.find_child("Cauda", true, false)

func _animar_rotina(dt: float) -> void:
	var k: float = fmod(_tempo, 12.0) / 12.0
	var alongar: float = clampf(minf((k - 0.7) / 0.1, (0.92 - k) / 0.1), 0.0, 1.0)
	var suavizar: float = minf(1.0, dt * 12.0)
	_corpo.position.y = lerpf(_corpo.position.y, -0.5, suavizar)
	_corpo.rotation.x = lerpf(_corpo.rotation.x, 0.1, suavizar)
	for i in 2:
		_pernas[i].rotation.x = lerpf(_pernas[i].rotation.x, -1.35, suavizar)
		_bracos[i].rotation.x = lerpf(_bracos[i].rotation.x, -0.35 - 2.6 * alongar, suavizar)
	_cabeca.rotation.x = lerpf(_cabeca.rotation.x, -0.12 + sin(_tempo * 0.7) * 0.05 - 0.3 * alongar, suavizar)
	_cabeca.rotation.z = sin(_tempo * 1.3) * 0.05
	_cauda.rotation.x = sin(_tempo * 1.5) * 0.5
	_cauda.rotation.z = sin(_tempo * 1.5) * 0.2
