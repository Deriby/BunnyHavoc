extends "caixa.gd"
## Dois impactos separados, como a caixa 2x original. Finalizador também conta um.
var impactos: int = 0
var intervalo: float = 0.0

func _physics_process(dt: float) -> void:
	intervalo = maxf(0.0, intervalo - dt)
	super._physics_process(dt)

func quebrar() -> void:
	if not visible or intervalo > 0.0:
		return
	arte.impacto(.05)
	impactos += 1
	arte.atualizar_estado(impactos==1)
	intervalo = 0.28
	if impactos >= 2:
		super.quebrar()
	else:
		$Som.stream = preload("res://Sistemas/Coleta/audio/metal.wav")
		$Som.play()

func destruir_por_explosao() -> void:
	intervalo = 0.0
	impactos = 2
	super.quebrar()

func reiniciar() -> void:
	impactos = 0
	intervalo = 0.0
	$Visual.position.x = 0.0
	super.reiniciar()
