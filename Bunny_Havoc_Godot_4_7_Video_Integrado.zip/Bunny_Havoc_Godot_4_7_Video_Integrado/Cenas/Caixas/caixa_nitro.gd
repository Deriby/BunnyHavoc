extends "caixa_tnt.gd"
## Contato/golpe/pisão explodem; interruptores encontram as Nitros pelo grupo.
func _ready() -> void:
	super._ready()
	add_to_group("bh_nitro")
func _physics_process(dt: float) -> void:
	if visible and pode_interagir():
		var d: Vector3 = _jogador.global_position - global_position
		if absf(d.x) < 1.06 and absf(d.z) < 1.06 and absf(d.y + 0.17) < 1.3:
			detonar()
	super._physics_process(dt)
func quebrar() -> void:
	detonar()
