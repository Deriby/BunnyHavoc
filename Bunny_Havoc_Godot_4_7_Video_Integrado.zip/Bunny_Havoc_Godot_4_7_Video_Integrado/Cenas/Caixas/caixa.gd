extends "res://Sistemas/Coleta/objeto_interativo.gd"
const Cores=preload("res://Sistemas/Visual/cores_material.gd")
signal quebrada(recompensa: int, origem: Node3D)
signal cenouras_liberadas(valor: int, origem: Node3D)
@export var recompensa: int = 5
@export var som_local: bool = true
@export var impulso_pisao: float = 8.0
@export var gerar_estilhacos: bool = true
var _intervalo_contato: float = 0.0
var arte: Node3D

func _ready() -> void:
	arte=$Visual/Modelo
	process_physics_priority = 16
	add_to_group("bh_caixas")

func _physics_process(dt: float) -> void:
	_intervalo_contato=maxf(0.0,_intervalo_contato-dt)
	if not visible or not pode_interagir():return
	var delta: Vector3=_jogador.global_position-global_position
	var perto: bool=absf(delta.x)<0.88 and absf(delta.z)<0.88
	var topo: float=$Colisao.position.y+0.58
	var base: float=$Colisao.position.y-0.58
	var combo: RefCounted=_jogador.get("_combate") as RefCounted
	if delta.y> -0.6 and delta.y<topo+0.12 and combo!=null and combo.pode_atingir(self,1.8):
		combo.registrar_acerto(self)
		golpear()
	elif perto and _intervalo_contato<=0 and delta.y>=topo-0.10 and delta.y<=topo+0.12 and _jogador.velocity.y<=0:
		_intervalo_contato=0.14
		pisar()
		_rebater()
	elif perto and _intervalo_contato<=0 and absf(delta.y+1.8-base)<0.18 and (_jogador.velocity.y>0 or _jogador.is_on_ceiling()):
		_intervalo_contato=0.14
		bater_por_baixo()

func _rebater() -> void:
	if not _jogador.is_physics_processing():return
	var impulso: float=impulso_pisao
	if Input.is_physical_key_pressed(KEY_SPACE):impulso=maxf(impulso,12.8)
	_jogador.velocity.y=maxf(_jogador.velocity.y,impulso)

func pisar() -> void:
	arte.impacto();quebrar()
func bater_por_baixo() -> void:
	arte.impacto(.08);quebrar()
func golpear() -> void:
	arte.impacto(.08);quebrar()

func quebrar() -> void:
	if not visible:return
	visible=false
	$Colisao.collision_layer=0
	if som_local:$Som.play()
	quebrada.emit(recompensa,self)

func reiniciar() -> void:
	visible=true
	$Colisao.collision_layer=4
	_intervalo_contato=0.0
	arte.reiniciar()

func destruir_por_explosao() -> void:quebrar()
