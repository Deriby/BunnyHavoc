extends RefCounted
## Silhuetas chanfradas e UVs compartilhados. Uma malha por tipo/estado.
const Atlas=preload("caixas_atlas.png")
static var cache: Dictionary={}
static var _material: StandardMaterial3D
static func material() -> StandardMaterial3D:
	if _material==null:
		_material=StandardMaterial3D.new();_material.albedo_texture=Atlas
		_material.texture_filter=BaseMaterial3D.TEXTURE_FILTER_NEAREST
		_material.vertex_color_use_as_albedo=true;_material.roughness=0.88
	return _material
static func _uv(tile: int,x: float,y: float) -> Vector2:
	return (Vector2(tile%4,tile/4)*128+Vector2(2+x*124,2+y*124))/512
static func _quad(st: SurfaceTool,a: Vector3,b: Vector3,c: Vector3,d: Vector3,tile: int,cor: Color=Color.WHITE) -> void:
	var normal: Vector3=(b-a).cross(c-a).normalized()
	var pts: Array=[a,c,b,a,d,c];var uvs: Array=[Vector2(0,1),Vector2(1,0),Vector2(1,1),Vector2(0,1),Vector2(0,0),Vector2(1,0)]
	for i in 6:st.set_normal(normal);st.set_color(cor);st.set_uv(_uv(tile,uvs[i].x,uvs[i].y));st.add_vertex(pts[i])
static func _viga(st: SurfaceTool,a: Vector3,b: Vector3,raio: float,tile: int) -> void:
	var dir: Vector3=(b-a).normalized()
	var ref: Vector3=Vector3.UP if absf(dir.y)<0.9 else Vector3.RIGHT
	var x: Vector3=dir.cross(ref).normalized();var y: Vector3=dir.cross(x).normalized()
	var cross_section: Array[Vector2]=[Vector2(-.7,-1),Vector2(.7,-1),Vector2(1,-.7),Vector2(1,.7),Vector2(.7,1),Vector2(-.7,1),Vector2(-1,.7),Vector2(-1,-.7)]
	for i in 8:
		var p: Vector3=(x*cross_section[i].x+y*cross_section[i].y)*raio
		var q: Vector3=(x*cross_section[(i+1)%8].x+y*cross_section[(i+1)%8].y)*raio
		_quad(st,a+p,a+q,b+q,b+p,tile,Color(1,1,1) if i%2 else Color(.87,.87,.87))
	for end in [0,1]:
		var center: Vector3=a if end==0 else b
		var normal: Vector3=-dir if end==0 else dir
		for i in 8:
			var p: Vector2=cross_section[i];var q: Vector2=cross_section[(i+1)%8]
			var coords: Array=[Vector2.ZERO,p,q] if end==0 else [Vector2.ZERO,q,p]
			for coord: Vector2 in coords:
				st.set_normal(normal);st.set_color(Color.WHITE);st.set_uv(_uv(8 if tile==8 else 15,.5+coord.x*.48,.5+coord.y*.48));st.add_vertex(center+(x*coord.x+y*coord.y)*raio)

static func _painel(st: SurfaceTool,tile: int,top: int) -> void:
	var h: float=.515
	_quad(st,Vector3(-h,-h,h),Vector3(h,-h,h),Vector3(h,h,h),Vector3(-h,h,h),tile)
	_quad(st,Vector3(h,-h,-h),Vector3(-h,-h,-h),Vector3(-h,h,-h),Vector3(h,h,-h),tile)
	_quad(st,Vector3(h,-h,h),Vector3(h,-h,-h),Vector3(h,h,-h),Vector3(h,h,h),tile)
	_quad(st,Vector3(-h,-h,-h),Vector3(-h,-h,h),Vector3(-h,h,h),Vector3(-h,h,-h),tile)
	_quad(st,Vector3(-h,h,h),Vector3(h,h,h),Vector3(h,h,-h),Vector3(-h,h,-h),top)
	_quad(st,Vector3(-h,-h,-h),Vector3(h,-h,-h),Vector3(h,-h,h),Vector3(-h,-h,h),9)
static func _rebite(st: SurfaceTool,pos: Vector3,normal: Vector3) -> void:
	var dir: Vector3=Vector3.UP
	var x: Vector3=normal.cross(dir).normalized()*0.027
	var y: Vector3=dir*0.027
	_quad(st,pos-x-y,pos+x-y,pos+x+y,pos-x+y,8,Color(.87,.77,.51))
static func obter(tipo: String,dano: bool=false,ligado: bool=false) -> ArrayMesh:
	var key: String=tipo+str(dano)+str(ligado)
	if cache.has(key):return cache[key]
	var faces: Dictionary={"normal":0,"carrot":1,"spring":2,"tnt":3,"nitro":4,"armored":13 if dano else 5,"switch":14 if ligado else 6}
	var tops: Dictionary={"normal":9,"carrot":10,"spring":11,"tnt":12,"nitro":4,"armored":8,"switch":14 if ligado else 6}
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_painel(st,int(faces[tipo]),int(tops[tipo]))
	var metal: bool=tipo in ["armored","switch"]
	var tile: int=8 if metal else 7
	var h: float=.525
	for x in [-h,h]:
		for z in [-h,h]:_viga(st,Vector3(x,-h,z),Vector3(x,h,z),.060,tile)
	for y in [-h,h]:
		for z in [-h,h]:_viga(st,Vector3(-h,y,z),Vector3(h,y,z),.060,tile)
		for x in [-h,h]:_viga(st,Vector3(x,y,-h),Vector3(x,y,h),.060,tile)
	for side in [-1.0,1.0]:
		if tipo=="normal":
			_viga(st,Vector3(-.40,-.40,.56*side),Vector3(.40,.40,.56*side),.045,7)
			_viga(st,Vector3(.40,-.40,.56*side),Vector3(-.40,.40,.56*side),.045,7)
			_viga(st,Vector3(.56*side,-.40,-.40),Vector3(.56*side,.40,.40),.045,7)
			_viga(st,Vector3(.56*side,-.40,.40),Vector3(.56*side,.40,-.40),.045,7)
		for x in [-.46,.46]:
			for y in [-.46,.46]:_rebite(st,Vector3(x,y,.590*side),Vector3(0,0,side))
		if tipo=="armored":
			for x in [-.31,.31]:_viga(st,Vector3(x,-.51,.56*side),Vector3(x,.51,.56*side),.035,8)
	st.set_material(material());var mesh: ArrayMesh=st.commit();mesh.resource_name="Caixa_"+key
	cache[key]=mesh;return mesh
static func lasca() -> ArrayMesh:
	if cache.has("lasca"):return cache.lasca
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_viga(st,Vector3(-.18,0,0),Vector3(.18,.015,0),.032,7)
	st.set_material(material());cache.lasca=st.commit();return cache.lasca
static func tampa(tipo: String) -> ArrayMesh:
	var key: String="tampa_"+tipo
	if cache.has(key):return cache[key]
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_quad(st,Vector3(-.39,0,.39),Vector3(.39,0,.39),Vector3(.39,0,-.39),Vector3(-.39,0,-.39),11 if tipo=="spring" else 10)
	for side in [-.4,.4]:_viga(st,Vector3(-.4,0,side),Vector3(.4,0,side),.025,8 if tipo=="spring" else 7)
	st.set_material(material());cache[key]=st.commit();return cache[key]
