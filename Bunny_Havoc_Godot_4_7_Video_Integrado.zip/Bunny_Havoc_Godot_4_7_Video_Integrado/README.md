# Bunny Havoc — renderização nativa para vídeo integrado

Godot 4.7.2 Compatibility. Fase 1 completa com os sistemas existentes.
Extraia em uma pasta nova, importe `project.godot` e use F5.

O filtro de tela, o adaptador de materiais, os cinco shaders PSX e o controlador
de corte radial foram removidos. Não há névoa ou mudança da distância por F3.
O céu conserva energia 1,5 e a câmera mantém seu alcance original.

F3 alterna resolução interna: Leve 240 linhas, Mínimo 180, Nítido resolução
completa. A ampliação bilinear é nativa; a interface fica na resolução normal.
F4 exibe FPS. Sombras dinâmicas desligadas; cenário e proxies usam iluminação
por vértice. A cutscene conserva suas três luzes, direção e atuação.

`materiais_compartilhados.gd` deduplica materiais. `malhas_compartilhadas.gd`
incorpora as cores nas malhas compartilhadas, mantendo texturas, normais e UVs.
Peças estáticas de cada membro de NPCs/lagartos/besouros são agrupadas, mantendo
pivôs independentes, expressões e referências de animação. Bunnyck, urso e
atores do filme conservam seus modelos e hierarquias originais.

`lotes_terreno.gd` une o terreno em faixas de 48 m. Todos os 117.630 triângulos
originais ficam no nível máximo de detalhe; a colisão continua independente.
`vegetacao_lote.gd` agrupa plantas por modelo e setor, mantendo os ajustes ao
solo. O vento e as reações próximas continuam ativos; as peças para edição
permanecem em Instancias, ocultas durante o jogo.

`lotes_distantes.gd` implementa HLOD: além de 80 m de cada faixa (retorno em
64 m), vegetação aparece em lotes estáticos equivalentes, conservando silhuetas,
cores e posições. Não é descarregada nem cortada por distância. NPCs e inimigos
a mais de 40 m usam uma pose agrupada e retornam às peças animadas em 32 m;
AI, colisão, dano, diálogos e recompensas continuam ativos. Reações e mortes
restauram as peças animadas. O centro acompanha a câmera durante o filme.
Essa troca altera apenas camadas de desenho, nunca a visibilidade lógica.

`Recursos/Otimizados` contém malhas e LODs pré-calculados. A superfície completa
é mantida perto; a engine escolhe menos triângulos para detalhes pequenos na
tela. Arquivos GLB, áudios e texturas originais não são alterados. LODs são
gerados fora do jogo por `tools/build_visual_cache.gd`; a distribuição não
precisa de ImporterMesh nem de ferramentas de editor para jogar. Se uma malha
for editada sem regenerar o cache, usa-se a malha completa como fallback.

As colisões corrigidas e o pulinho de dano continuam presentes. Três corações,
vidas, combo, checkpoints, plataformas, caixas, cutscene e save preservados.
Não é promessa de FPS para qualquer PC com 6 GB: CPU, vídeo integrado e driver
continuam determinantes. As medições publicadas identificam o hardware usado.
