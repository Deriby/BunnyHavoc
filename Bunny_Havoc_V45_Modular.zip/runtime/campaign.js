/* Catálogo da vila e progressão. Os IDs são estáveis no save: 3 fases + 1 chefe por área. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.BunnyHavocCampaign=api;})(typeof globalThis!=='undefined'?globalThis:this,()=>{
'use strict';
const areas=[
 {id:1,name:'Bosque das Copas',theme:'forest',color:0x63db70,x:-30,z:-25},
 {id:2,name:'Vila das Neves',theme:'snow',color:0x5bcaff,x:27,z:-29},
 {id:3,name:'Cais das Cascatas',theme:'water',color:0x35d6e3,x:-35,z:8},
 {id:4,name:'Distrito das Forjas',theme:'forge',color:0xff9b32,x:35,z:5},
 {id:5,name:'Jardins da Lua',theme:'sakura',color:0xe877ff,x:25,z:34}
].map(Object.freeze);
const slots=areas.flatMap(area=>Array.from({length:4},(_,i)=>Object.freeze({id:(area.id-1)*4+i+1,area:area.id,index:i+1,boss:i===3,name:area.id===1&&i===0?'Bosque Verde':area.id===1&&i===1?'Selva de Pinheiros':i===3?'Chefe da área '+area.id:'Fase '+((area.id-1)*3+i+1),payload:area.id===1&&i<2?'phase'+(i+1):null})));
function normalize(input){
 if(!input||typeof input!=='object'||Array.isArray(input))return null;
 const completed=Array.from({length:20},(_,i)=>input.completed?.[i]===true);
 // Na V8, unlocked=2 já representava a primeira fase concluída.
 if(input.schema!==9&&Number(input.unlocked)===2)completed[0]=true;
 let unlocked=1;while(unlocked<=20&&completed[unlocked-1])unlocked++;unlocked=Math.min(20,unlocked);
 const p=input.villagePosition,valid=p&&Number.isFinite(p.x)&&Number.isFinite(p.z)&&Math.abs(p.x)<80&&Math.abs(p.z)<80;
 const stats={};for(let i=1;i<=20;i++)if(input.stats?.[i]&&typeof input.stats[i]==='object')stats[i]=Object.fromEntries(['carrots','hearts','boxes'].map(k=>[k,Math.min(999999,Math.max(0,Number(input.stats[i][k])||0))]));
 return {schema:9,name:String(input.name||'Aventura').slice(0,40),completed,unlocked,lastLevel:Math.min(unlocked,Math.max(1,Number(input.lastLevel)|0)),stats,villagePosition:valid?{x:p.x,z:p.z}:{x:0,z:24}};
}
function status(save,id,trial=false){const slot=slots[id-1];if(!slot)return 'locked';const s=normalize(save);if(!trial&&(!s||id>s.unlocked))return 'locked';if(!slot.payload)return 'upcoming';return s?.completed[id-1]?'complete':'open';}
function complete(save,id,score){const s=normalize(save);if(!s||!slots[id-1]?.payload||!['open','complete'].includes(status(s,id)))return s;s.completed[id-1]=true;s.stats[id]=score;s.lastLevel=Math.min(20,id+1);return normalize(s);}
return Object.freeze({areas:Object.freeze(areas),slots:Object.freeze(slots),normalize,status,complete});
});
