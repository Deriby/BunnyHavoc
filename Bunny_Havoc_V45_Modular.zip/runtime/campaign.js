"use strict";
(() => {
  // src/campaign/catalog.ts
  var definitions = [
    { id: 1, name: "Bosque das Copas", theme: "forest", color: 6544240, x: -30, z: -25 },
    { id: 2, name: "Vila das Neves", theme: "snow", color: 6015743, x: 27, z: -29 },
    { id: 3, name: "Cais das Cascatas", theme: "water", color: 3528419, x: -35, z: 8 },
    { id: 4, name: "Distrito das Forjas", theme: "forge", color: 16751410, x: 35, z: 5 },
    { id: 5, name: "Jardins da Lua", theme: "sakura", color: 15235071, x: 25, z: 34 }
  ];
  var areas = Object.freeze(definitions.map((area) => Object.freeze(area)));
  var slots = Object.freeze(areas.flatMap((area) => Array.from({ length: 4 }, (_, i) => Object.freeze({
    id: (area.id - 1) * 4 + i + 1,
    area: area.id,
    index: i + 1,
    boss: i === 3,
    name: area.id === 1 && i === 0 ? "Bosque Verde" : area.id === 1 && i === 1 ? "Selva de Pinheiros" : i === 3 ? "Chefe da \xE1rea " + area.id : "Fase " + ((area.id - 1) * 3 + i + 1),
    payload: area.id === 1 && i < 2 ? i === 0 ? "phase1" : "phase2" : null
  }))));

  // src/campaign/progression.ts
  function normalize(input) {
    if (!input || typeof input !== "object" || Array.isArray(input)) return null;
    const source = input;
    const previous = source.completed;
    const completed = Array.from({ length: 20 }, (_, i) => previous?.[i] === true);
    if (source.schema !== 9 && Number(source.unlocked) === 2) completed[0] = true;
    let unlocked = 1;
    while (unlocked <= 20 && completed[unlocked - 1]) unlocked++;
    unlocked = Math.min(20, unlocked);
    const p = source.villagePosition;
    const valid = p && Number.isFinite(p.x) && Number.isFinite(p.z) && Math.abs(p.x) < 80 && Math.abs(p.z) < 80;
    const storedStats = source.stats;
    const stats = {};
    for (let i = 1; i <= 20; i++) {
      const value = storedStats?.[i];
      if (value && typeof value === "object") {
        const fields = value;
        const numeric = (key) => Math.min(999999, Math.max(0, Number(fields[key]) || 0));
        stats[i] = { carrots: numeric("carrots"), hearts: numeric("hearts"), boxes: numeric("boxes") };
      }
    }
    return {
      schema: 9,
      name: String(source.name || "Aventura").slice(0, 40),
      completed,
      unlocked,
      lastLevel: Math.min(unlocked, Math.max(1, Number(source.lastLevel) | 0)),
      stats,
      villagePosition: valid ? { x: p.x, z: p.z } : { x: 0, z: 24 }
    };
  }
  function status(save, id, trial = false) {
    const slot = slots[id - 1];
    if (!slot) return "locked";
    const s = normalize(save);
    if (!trial && (!s || id > s.unlocked)) return "locked";
    if (!slot.payload) return "upcoming";
    return s?.completed[id - 1] ? "complete" : "open";
  }
  function complete(save, id, score) {
    const s = normalize(save);
    if (!s || !slots[id - 1]?.payload || !["open", "complete"].includes(status(s, id))) return s;
    s.completed[id - 1] = true;
    s.stats[id] = score;
    s.lastLevel = Math.min(20, id + 1);
    return normalize(s);
  }

  // src/campaign/index.ts
  var Campaign = Object.freeze({ areas, slots, normalize, status, complete });

  // src/app/campaign-bridge.ts
  window.BunnyHavocCampaign = Campaign;
})();
