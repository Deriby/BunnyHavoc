
(() => {
    const overlay = document.getElementById('ov');
    const play = overlay.onclick;
    overlay.onclick = event => { reset(); play(event); forestOutro.start(); };
    if (2 === 1) addEventListener('message', event => {
        if (event.source === window && event.data?.type === 'bunny-havoc-fase1-concluida') {
            overlay.innerHTML = '<h1>FASE 1 COMPLETA!</h1><p>Clique para assistir novamente.</p>';
            overlay.style.display = 'flex';
        }
    });
})();
