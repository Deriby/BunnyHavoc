
(() => {
 let published = false;
 const level = 1;
 // O token e injetado diretamente no HTML pelo launcher. window.frameElement pode
 // retornar null dependendo das restricoes de origem de arquivos locais.
 const token = String(window.__BH_SESSION_ID__ || window.frameElement?.dataset?.loadToken || '');
 const report = (type,detail='') => window.parent?.postMessage({type,level,token,detail:String(detail).slice(0,500)},'*');
 window.addEventListener('error', e => {if (!published) report('bunny-havoc-stage-error',e.message||'Erro carregando a fase');});
 window.addEventListener('unhandledrejection', e => {if (!published) report('bunny-havoc-stage-error',String(e.reason||'Falha inicializando o jogo'));});
 if (!window.THREE?.WebGLRenderer) {report('bunny-havoc-stage-error','Three.js não carregou. Verifique a conexão com a internet: cdnjs.cloudflare.com.');return;}
 // THREE r128 define render() em CADA INSTANCIA do WebGLRenderer,
 // nao em WebGLRenderer.prototype. Interceptar o prototype nunca detectava
 // o primeiro quadro, embora a fase estivesse renderizando corretamente.
 const OriginalRenderer = THREE.WebGLRenderer;
 THREE.WebGLRenderer = function(...args) {
   const renderer = new OriginalRenderer(...args);
   const renderOriginal = renderer.render;
   renderer.render = function(...renderArgs) {
     const result = renderOriginal.apply(this, renderArgs);
     if (!published) {
       published = true;
       queueMicrotask(() => report('bunny-havoc-stage-ready'));
     }
     return result;
   };
   return renderer;
 };
 THREE.WebGLRenderer.prototype = OriginalRenderer.prototype;
 Object.setPrototypeOf(THREE.WebGLRenderer, OriginalRenderer);
})();
