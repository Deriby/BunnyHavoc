"use strict";
(() => {
  // src/app/scene-contracts.ts
  var scenePaths = {
    phase1: "scenes/phase1.html",
    phase2: "scenes/phase2.html",
    village: "scenes/village.html"
  };

  // src/app/scene-bootstrap.ts
  var script = document.currentScript;
  var key = script?.dataset.bhScene;
  if (key && Object.hasOwn(scenePaths, key) && window.parent !== window) {
    const frame = window.frameElement;
    if (frame) {
      const token = new URL(location.href).searchParams.get("bh-session") ?? "";
      const session = window.parent.BunnyHavocScenes?.readSession(
        frame,
        key,
        token
      );
      if (session?.scene === "village") {
        window.__BHVILLAGE__ = session.state;
      } else if (session) {
        window.__BH_SESSION_ID__ = session.token;
        if (!session.trial) {
          document.addEventListener("DOMContentLoaded", () => document.getElementById("previewLevel2")?.remove(), { once: true });
        }
      }
    }
  }
})();
