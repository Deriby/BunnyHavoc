// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
const bhVideo = () => window.parent?.BunnyHavocSettings?.get?.() || {};
if (bhVideo().psx !== false)
    THREE.ShaderChunk.project_vertex += '\n gl_Position.xy=floor(gl_Position.xy/gl_Position.w*vec2(213.,120.)+.5)/vec2(213.,120.)*gl_Position.w;';
const T = THREE, $ = id => document.getElementById(id), bgm = (window.parent.BunnyHavocAudio && window.parent.BunnyHavocAudio.getAudio(2)) || $('bgm');
const R = new T.WebGLRenderer({ antialias: false });
R.setPixelRatio(1);
R.setSize(innerWidth, innerHeight);
document.body.prepend(R.domElement);
const LH = 240, RT = new T.WebGLRenderTarget(2, 2, { minFilter: T.NearestFilter, magFilter: T.NearestFilter }), qm = new T.ShaderMaterial({ uniforms: { t: { value: RT.texture }, res: { value: new T.Vector2(2, 2) } }, vertexShader: 'varying vec2 v;void main(){v=uv;gl_Position=vec4(position.xy,0.,1.);}', fragmentShader: `uniform sampler2D t;uniform vec2 res;varying vec2 v;
void main(){vec3 c=texture2D(t,v).rgb;vec2 p=floor(v*res);float a=mod(p.x,2.),b=mod(p.y,2.);float d=(a<.5?(b<.5?0.:3.):(b<.5?2.:1.))/4.+.125;
c=c*1.08-.02;c=mix(vec3(dot(c,vec3(.3,.59,.11))),c,1.15);c*= vec3(0.977,1.012,1.040);c=floor(c*31.+d)/31.;vec2 q=v-.5;c*=1.-dot(q,q)*.5;gl_FragColor=vec4(c,1.);}` }), qs = new T.Scene(), qc = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
qs.add(new T.Mesh(new T.PlaneGeometry(2, 2), qm));
function fit() { const video = bhVideo(), pixelHeight = ({ low: 168, medium: 240, high: 360 })[video.quality] || 240; const LW = Math.max(160, Math.round(pixelHeight * innerWidth / innerHeight)); R.setPixelRatio(video.psx === false ? ({ low: .65, medium: 1, high: Math.min(2, devicePixelRatio || 1.5) })[video.quality] || 1 : 1); R.setSize(innerWidth, innerHeight); RT.setSize(LW, pixelHeight); qm.uniforms.res.value.set(LW, pixelHeight); C.aspect = innerWidth / innerHeight; C.updateProjectionMatrix(); }
const S = new T.Scene();
{
    const cv = document.createElement('canvas');
    cv.width = 2;
    cv.height = 256;
    const g = cv.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, '#315879');
    gr.addColorStop(.55, '#80b3c3');
    gr.addColorStop(1, '#f2dfb9');
    g.fillStyle = gr;
    g.fillRect(0, 0, 2, 256);
    S.background = new T.CanvasTexture(cv);
}
S.fog = new T.Fog(0xa7d5d1, 31, 145);
const C = new T.PerspectiveCamera(60, innerWidth / innerHeight, .1, 500);
fit();
S.add(new T.HemisphereLight(0xd6ebff, 0x274e43, 1.1));
const sun = new T.DirectionalLight(0xffeed3, .78);
sun.position.set(5, 12, 6);
S.add(sun);
const M = c => new T.MeshLambertMaterial({ color: c }), mesh = (g, c, p) => { const m = new T.Mesh(g, M(c)); if (p)
    m.position.set(...p); return m; };
const B = (w, h, d) => new T.BoxGeometry(w, h, d);
let seed = 7;
const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647, rr = (a, b) => a + rnd() * (b - a), pick = a => a[Math.floor(rnd() * a.length)];
// ---- level definition
const hk = [[30, 0], [-40, 0], [-80, 5], [-125, 5], [-155, 2], [-195, 2], [-235, 8], [-275, 8], [-315, 4], [-355, 4], [-390, 9], [-440, 9], [-520, 10], [-600, 12], [-700, 12], [-810, 15], [-900, 16], [-1010, 18]];
const pits = [-56, -104, -152, -201, -250, -302, -355, -410, -467, -525, -585, -646, -708, -771, -835, -900].map(c => [c + 3.6, c - 3.6]);
const sPits = [-30, -82, -129, -178, -228, -278, -329, -383, -439, -498, -557, -618, -682, -741, -804, -865, -932].map(c => [c + 1.3, c - 1.3]);
const ALLP = pits.concat(sPits);
const opens = [[-56, -84], [-144, -172], [-232, -260], [-330, -380], [-434, -486], [-535, -606], [-652, -728], [-778, -852], [-897, -962]];
const GOAL = -980, ZMAX = 12, ZMIN = -990, PD = 9;
function hp(z) { for (let i = 0; i < hk.length - 1; i++) {
    const [z0, h0] = hk[i], [z1, h1] = hk[i + 1];
    if (z <= z0 && z >= z1) {
        const u = (z0 - z) / (z0 - z1);
        return h0 + (h1 - h0) * u * u * (3 - 2 * u);
    }
} return z > hk[0][0] ? hk[0][1] : hk[hk.length - 1][1]; }
function wp(z) { let b = 0; for (const [a, c] of opens)
    if (z < a && z > c)
        b += Math.pow(Math.sin(Math.PI * (a - z) / (a - c)), .6); return 4 + 3 * b; }
function pitF(x, z) { let f = 0; for (const [a, b] of ALLP) {
    const dz = z > a ? z - a : z < b ? b - z : 0;
    if (dz > 1.3)
        continue;
    const dx = Math.max(Math.abs(x) - wp(z) - 1.2, 0);
    f = Math.max(f, Math.max(0, 1 - Math.hypot(dx, dz) / 1.3));
} return f * f * (3 - 2 * f); }
function gh(x, z) { const w = wp(z), ax = Math.abs(x); let s = 0; if (ax > w + .8) {
    const q = ax - w - .8;
    s = Math.min(q * .28, 5) + Math.sin(x * .13 + z * .07) * Math.min(q * .1, 1.5) + Math.sin(z * .11 + x * .05) * Math.min(q * .1, 1.2);
} return hp(z) + s - PD * pitF(x, z); }
// ---- terrain (grass field, dug pits)
{
    const xs = [], zs = [];
    for (let x = -110; x < -14; x += 4)
        xs.push(x);
    for (let x = -14; x <= 14; x += .75)
        xs.push(x);
    for (let x = 18; x <= 110; x += 4)
        xs.push(x);
    for (let z = 30; z > GOAL - 25;) {
        zs.push(z);
        z -= ALLP.some(([a, b]) => z < a + 6 && z > b - 6) ? .5 : 1.25;
    }
    const nx = xs.length, nz = zs.length, pos = new Float32Array(nx * nz * 3), col = new Float32Array(nx * nz * 3), idx = [];
    const C1 = new T.Color(0x527d65), C2 = new T.Color(0x294b49), C3 = new T.Color(0x7c8588), C4 = new T.Color(0x233d4a), tc = new T.Color();
    for (let j = 0; j < nz; j++)
        for (let i = 0; i < nx; i++) {
            const x = xs[i], z = zs[j], k = (j * nx + i) * 3, pf = pitF(x, z);
            pos[k] = x;
            pos[k + 1] = gh(x, z);
            pos[k + 2] = z;
            tc.copy(Math.abs(x) < wp(z) ? C1 : C2).offsetHSL(0, 0, Math.sin(x * .9 + z * .7) * .03);
            if (pf > .02)
                tc.lerp(C3, Math.min(1, pf * 3));
            if (pf > .6)
                tc.lerp(C4, (pf - .6) * 2.5);
            col[k] = tc.r;
            col[k + 1] = tc.g;
            col[k + 2] = tc.b;
        }
    for (let j = 0; j < nz - 1; j++)
        for (let i = 0; i < nx - 1; i++) {
            const a = j * nx + i, b = a + 1, c = a + nx, d = c + 1;
            idx.push(a, b, c, b, d, c);
        }
    const g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(pos, 3));
    g.setAttribute('color', new T.BufferAttribute(col, 3));
    g.setIndex(new T.BufferAttribute(new Uint32Array(idx), 1));
    g.computeVertexNormals();
    S.add(new T.Mesh(g, new T.MeshLambertMaterial({ vertexColors: true })));
}
// ---- instancing helper
const dm = new T.Object3D();
function inst(geo, color, list, fn) { const im = new T.InstancedMesh(geo, M(color), list.length); list.forEach((o, i) => { dm.position.set(0, 0, 0); dm.rotation.set(0, 0, 0); dm.scale.set(1, 1, 1); fn(o, dm); dm.updateMatrix(); im.setMatrixAt(i, dm.matrix); }); S.add(im); return im; }
// LEVEL 2: dense tall mountain conifers, moss, ferns and alpine rocks.
// Unlike the first level, the canopy is towering, the path is shaded, and cliffs frame the corridor.
const lvl2Pines = [];
{
    let edge = [];
    for (let i = 0; i < 1780; i++) {
        const z = rr(20, GOAL - 20), s = pick([-1, 1]);
        const x = s * (wp(z) + rr(2.2, 33));
        edge.push({ x, z, y: gh(x, z), s: rr(1.5, 3.25), shade: Math.floor(rnd() * 4) });
    }
    lvl2Pines.push(...edge);
    const trunk = new T.CylinderGeometry(.23, .34, 2.7, 5);
    inst(trunk, 0x4b3830, edge, (o, d) => { d.position.set(o.x, o.y + 1.45 * o.s, o.z); d.scale.set(o.s, o.s, o.s); });
    const cones = [{ r: 1.6, h: 3.1, y: 2.1, c: 0x153f37 }, { r: 1.36, h: 3.15, y: 3.25, c: 0x21614e }, { r: 1.05, h: 3.05, y: 4.35, c: 0x30715a }, { r: .65, h: 2.6, y: 5.45, c: 0x427b63 }];
    for (const co of cones) {
        inst(new T.ConeGeometry(co.r, co.h, 6), co.c, edge, (o, d) => {
            d.position.set(o.x, o.y + co.y * o.s, o.z);
            d.scale.setScalar(o.s);
        });
    }
    // Mountain boulders and broken slate fragments cover the sides of the trails.
    const stones = [];
    for (let i = 0; i < 440; i++) {
        const z = rr(13, GOAL - 15), x = pick([-1, 1]) * (wp(z) + rr(1.1, 21));
        stones.push({ x, z, y: gh(x, z), s: rr(.25, 1.5) });
    }
    inst(new T.DodecahedronGeometry(1, 0), 0x748383, stones, (o, d) => { d.position.set(o.x, o.y + .22 * o.s, o.z); d.rotation.y = o.z * .2; d.scale.set(o.s * 1.7, o.s * .8, o.s * 1.3); });
    // Four-leaf low-poly ferns, thousands of tiny illustrated silhouettes.
    const ferns = [];
    for (let i = 0; i < 1100; i++) {
        const z = rr(16, GOAL - 15), x = pick([-1, 1]) * (wp(z) + rr(.6, 18));
        ferns.push({ x, z, y: gh(x, z), s: rr(.55, 1.65) });
    }
    for (const [col, dx, rz] of [[0x376e4b, -.18, -.35], [0x458856, .18, .35], [0x2b6046, 0, 0]]) {
        inst(new T.ConeGeometry(.24, .8, 4), col, ferns, (o, d) => { d.position.set(o.x + dx * o.s, o.y + .3 * o.s, o.z); d.rotation.z = rz; d.scale.setScalar(o.s); });
    }
    const flowers = [];
    for (let i = 0; i < 190; i++) {
        const z = rr(13, GOAL - 15), x = pick([-1, 1]) * (wp(z) + rr(.2, 9));
        flowers.push({ x, z, y: gh(x, z) });
    }
    [0xd1abd9, 0xe4d9aa, 0xb5dbe8].forEach((c, i) => inst(new T.IcosahedronGeometry(.13, 0), c, flowers.filter((_, j) => j % 3 === i), (o, d) => { d.position.set(o.x, o.y + .35, o.z); }));
}
// ---- decoração viva do bosque: cogumelos, arbustos, placas, pedras e lanternas
{
    const shrooms = [];
    for (let i = 0; i < 155; i++) {
        const z = rr(5, GOAL + 18), side = pick([-1, 1]), x = side * rr(1.2, wp(z) + 9);
        if (pitF(x, z) > .15)
            continue;
        shrooms.push({ x, y: gh(x, z), z, s: rr(.65, 1.4) });
    }
    inst(B(.1, .32, .1), 0xf5e2be, shrooms, (o, d) => { d.position.set(o.x, o.y + .15 * o.s, o.z); d.scale.setScalar(o.s); });
    [0xe95364, 0xffc052, 0x9d74e4].forEach((c, i) => inst(new T.ConeGeometry(.32, .33, 6), c, shrooms.filter((_, j) => j % 3 === i), (o, d) => { d.position.set(o.x, o.y + .38 * o.s, o.z); d.scale.setScalar(o.s); }));
    const pebbles = [];
    for (let i = 0; i < 210; i++) {
        const z = rr(12, GOAL + 14), x = pick([-1, 1]) * rr(.8, wp(z) + 10);
        if (pitF(x, z) < .14)
            pebbles.push({ x, y: gh(x, z), z, s: rr(.1, .35) });
    }
    inst(new T.DodecahedronGeometry(.3, 0), 0xc2b49d, pebbles, (o, d) => { d.position.set(o.x, o.y + .055, o.z); d.scale.set(o.s * 1.5, o.s * .55, o.s); });
    for (const z of [-18, -75, -143, -201, -277, -344]) {
        const side = z < -200 ? -1 : 1, x = side * (wp(z) + .8), y = gh(x, z), pole = new T.Group();
        pole.add(mesh(B(.16, 2.2, .16), 0x74502b, [0, 1.1, 0]));
        pole.add(mesh(B(1.2, .42, .18), 0xb9864c, [-side * .32, 1.93, 0]));
        pole.add(mesh(B(.09, .24, .22), 0xe1c78c, [side * .19, 1.93, 0]));
        pole.position.set(x, y, z);
        S.add(pole);
    }
}
// Distinctive alpine landscape: pine valley cliff walls, flowing turquoise river and waterfalls.
const pineWater = [], pineSprays = [], pineWaterfalls = [];
{
    // Water follows a sinuous course on the LEFT of the navigable track.
    const vertices = [], indices = [];
    let vi = 0;
    for (let z = 18; z > GOAL - 24; z -= 4) {
        const center = -wp(z) - 13 + Math.sin(z * .024) * 2.1;
        for (const x of [center - 5.2, center + 5.2]) {
            vertices.push(x, gh(x, z) + .22, z);
        }
        if (vi > 0) {
            const a = vi * 2 - 2, b = vi * 2;
            indices.push(a, a + 1, b, a + 1, b + 1, b);
        }
        vi++;
    }
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.Float32BufferAttribute(vertices, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    const water = new T.Mesh(geo, new T.MeshBasicMaterial({ color: 0x2cabc2, transparent: true, opacity: .82, side: T.DoubleSide, depthWrite: false }));
    S.add(water);
    pineWater.push(water);
    const crags = [];
    for (let z = 10; z > GOAL - 22; z -= 10) {
        for (const side of [-1, 1]) {
            const x = side * (wp(z) + rr(4.5, 14));
            crags.push({ x, z, y: gh(x, z), h: rr(3.5, 12.5), s: rr(1.2, 3.2) });
        }
    }
    inst(new T.CylinderGeometry(.75, 1.6, 1, 5), 0x555e67, crags, (o, d) => {
        d.position.set(o.x, o.y + o.h * .49, o.z);
        d.scale.set(o.s, o.h, o.s * 1.2);
        d.rotation.y = o.z * .03;
    });
    inst(new T.ConeGeometry(1.25, 1.6, 5), 0x6f7980, crags.filter((_, i) => i % 2 === 0), (o, d) => {
        d.position.set(o.x, o.y + o.h + .6, o.z);
        d.scale.set(o.s, 1.5, o.s);
    });
    // A waterfall on the edge of each major valley section, with white spray.
    for (const z of [-92, -213, -365, -523, -707, -864]) {
        const x = -wp(z) - 15, y = gh(x, z), g = new T.Group();
        g.add(mesh(B(7.8, 11, .3), 0x4c545a, [0, 4.8, -.5]));
        const falling = mesh(B(4.7, 10, .18), 0x62d7e5, [0, 4.8, -.13]);
        falling.material.transparent = true;
        falling.material.opacity = .75;
        g.add(falling);
        for (let i = 0; i < 7; i++) {
            let stripe = mesh(B(.18, 9.2, .07), 0xd5faff, [(i - 3) * .57, 4.65, .03]);
            stripe.material.transparent = true;
            stripe.material.opacity = .67;
            g.add(stripe);
        }
        const mist = mesh(new T.SphereGeometry(2.3, 8, 5), 0xd3f5ff, [0, .4, .45]);
        mist.material.transparent = true;
        mist.material.opacity = .35;
        g.add(mist);
        g.position.set(x, y, z);
        S.add(g);
        pineWaterfalls.push({ g, falling, mist, p: i => i });
    }
    // Misty hollow: silver-blue ground fog floating in a landmark clearing.
    for (let i = 0; i < 38; i++) {
        const z = rr(-512, -626), x = rr(-14, 14), y = hp(z) + .65;
        const m = mesh(new T.SphereGeometry(1, 7, 5), 0xddeeff, [x, y, z]);
        m.scale.set(rr(2.4, 6.0), rr(.3, .65), rr(1.7, 4.1));
        m.material.transparent = true;
        m.material.opacity = .16;
        S.add(m);
        pineSprays.push({ m, x, y, z, phase: rr(0, 10) });
    }
}
// mountains
for (let i = 0; i < 34; i++) {
    const s = i % 2 ? 1 : -1, h = rr(35, 65), rad = rr(22, 34), m = mesh(new T.ConeGeometry(rad, h, 6), i % 3 ? 0x5b6f8a : 0x6e5f8f, [s * rr(100, 150), h / 2 - 12, 20 - i * 14]);
    m.add(mesh(new T.ConeGeometry(rad * .32, h * .32, 6), 0xffffff, [0, h * .34, 0]));
    S.add(m);
}
const sunBall = new T.Mesh(new T.SphereGeometry(22, 16, 12), new T.MeshBasicMaterial({ color: 0xfff2a0, fog: false }));
S.add(sunBall);
const clouds = [];
for (let i = 0; i < 24; i++) {
    const c = new T.Group();
    for (let k = 0; k < 4; k++)
        c.add(mesh(new T.SphereGeometry(2 + rnd() * 1.5, 8, 6), 0xffffff, [k * 2.2, rnd(), rnd()]));
    c.position.set(rr(-110, 110), rr(28, 40), rr(20, -420));
    S.add(c);
    clouds.push(c);
}
const bfs = [];
for (let i = 0; i < 30; i++) {
    const b = new T.Group(), col = i % 2 ? 0xff5ac8 : 0xffe14a, w1 = mesh(B(.35, .02, .3), col, [-.18, 0, 0]), w2 = mesh(B(.35, .02, .3), col, [.18, 0, 0]);
    b.add(w1, w2);
    const z = rr(10, GOAL + 12);
    b.userData = { w1, w2, p: rnd() * 9, z, x: rr(-5, 5), h: hp(z) };
    S.add(b);
    bfs.push(b);
}
const birds = [];
for (let i = 0; i < 26; i++) {
    const b = new T.Group(), w1 = new T.Group(), w2 = new T.Group(), c = pick([0x405e9c, 0x523d68, 0xa85032, 0x3f8b77, 0x764e35]);
    b.add(mesh(B(.32, .22, .55), c, [0, 0, 0]));
    b.add(mesh(new T.ConeGeometry(.13, .26, 4), 0xf3ba39, [0, -.04, .37]));
    b.add(mesh(B(.23, .08, .26), c, [0, .03, -.38]));
    for (const sd of [-1, 1]) {
        b.add(mesh(B(.055, .065, .065), 0xffffff, [sd * .14, .08, .19]));
        b.add(mesh(B(.045, .05, .052), 0x101b32, [sd * .15, .08, .24]));
    }
    w1.add(mesh(B(.68, .09, .32), c, [-.37, 0, 0]));
    w2.add(mesh(B(.68, .09, .32), c, [.37, 0, 0]));
    b.add(w1, w2);
    const z = rr(8, GOAL + 15), base = hp(z) + rr(7, 13), phase = rr(0, 6);
    b.position.set(rr(-6, 6), base, z);
    b.userData = { w1, w2, p: phase, z, base, center: rr(-4.5, 4.5), speed: rr(.45, .8) };
    b.scale.setScalar(rr(.85, 1.25));
    S.add(b);
    birds.push(b);
}
const fgeo = new T.BufferGeometry(), fp = [];
for (let i = 0; i < 12; i++) {
    const z = rr(12, GOAL + 12);
    fp.push(rr(-14, 14), hp(z) + rr(.5, 4), z);
}
fgeo.setAttribute('position', new T.Float32BufferAttribute(fp, 3));
const fire = new T.Points(fgeo, new T.PointsMaterial({ color: 0xfff2a0, size: .18 }));
S.add(fire);
const shadow = mesh(new T.CircleGeometry(.5, 16), 0x000000, [0, .08, 0]);
shadow.material.transparent = true;
shadow.material.opacity = .35;
shadow.rotation.x = -Math.PI / 2;
S.add(shadow);
const forestExitMarker = new T.Group();
{
    const shrine = forestExitMarker;
    shrine.add(mesh(B(3.2, .3, 3.2), 0x726d7d, [0, .15, 0]));
    shrine.add(mesh(B(2.5, .18, 2.5), 0x4fae4a, [0, .4, 0]));
    const gate = mesh(B(2.2, 2.8, .35), 0xd5d9e5, [0, 1.75, 0]);
    shrine.add(gate);
    const glow = mesh(new T.RingGeometry(.65, 1.15, 24), 0xffde73, [0, 1.8, .21]);
    glow.rotation.x = Math.PI / 2;
    shrine.add(glow);
    shrine.position.set(0, hp(GOAL) + .1, GOAL - 4);
    S.add(shrine);
}
const portal = new T.Object3D();
const boxes = [], fruits = [], foes = [], spikes = [], logs = [], walls = [], plats = [], flames = [], streams = [];
const carrot = p => { const g = new T.Group(), c = mesh(new T.ConeGeometry(.17, .65, 8), 0xff8a1a); c.rotation.z = Math.PI; c.rotation.x = .3; g.add(c); for (let i = -1; i < 2; i++) {
    const l = mesh(B(.07, .3, .04), 0x3fbf3f, [i * .07, .45, 0]);
    l.rotation.z = -i * .4;
    g.add(l);
} g.position.set(...p); S.add(g); fruits.push(g); };
function treeWall(len) { const g = new T.Group(), n = Math.max(2, Math.round(len / 1.3)), sp = len / n; for (let i = 0; i < n; i++) {
    const x = (i - (n - 1) / 2) * sp, h = 1.4 + Math.random() * .4, tr = mesh(new T.CylinderGeometry(.55, .7, h, 8), 0x6b4423, [x, h / 2, 0]);
    tr.add(mesh(new T.ConeGeometry(1.4, 1.8, 7), 0x1f6e3a, [0, h / 2 + .8, 0]), mesh(new T.ConeGeometry(1.1, 1.5, 7), 0x2a8a46, [0, h / 2 + 1.7, 0]));
    g.add(tr);
} S.add(g); return g; }
// Pilares de pedra e tochas retirados: trilha livre e paisagem mais natural.
// pits: moving platform + carrot arc
pits.forEach(([a, b], i) => {
    const pc = (a + b) / 2, h = hp(pc), p = new T.Group();
    const isBridge = i % 2 === 1;
    if (isBridge) {
        // Each wood plank has its own silhouette and the posts/rope sway subtly.
        p.add(mesh(B(3.95, .18, 8.55), 0x44342a, [0, -.13, 0]));
        for (let k = -9; k <= 9; k++) {
            const deck = mesh(B(3.9, .16, .38), k % 3 ? 0xb18a52 : 0x946840, [0, .07, k * .43]);
            p.add(deck);
        }
        for (const side of [-1, 1])
            for (const k of [-4, 0, 4]) {
                p.add(mesh(B(.14, 1.12, .15), 0x654a35, [side * 1.97, .53, k]));
            }
        for (const side of [-1, 1]) {
            for (let k = -8; k <= 8; k++) {
                const z = k * .52, y = 1.12 + .35 * (1 - Math.pow(z / 4.3, 2));
                p.add(mesh(B(.07, .085, .56), 0xd5b07c, [side * 1.97, y, z]));
            }
        }
        p.userData = { dx: 0, p0: pc, top: h + .12, am: 0, hw: 1.88, hd: 4.17, rope: true };
    }
    else {
        p.add(mesh(B(3.55, .45, 3.55), 0x4f6067, [0, -.26, 0]));
        p.add(mesh(B(3.6, .14, 3.6), 0x759f66, [0, .04, 0]));
        for (const side of [-1, 1])
            p.add(mesh(B(.15, .55, 3.3), 0x715f46, [side * 1.7, .37, 0]));
        p.userData = { dx: 0, p0: pc, top: h + .10, am: 1.7, hw: 1.7, hd: 1.7, rope: false };
    }
    p.position.set(0, h, pc);
    S.add(p);
    plats.push(p);
    {
        const wg = new T.Group(), ww = wp(pc) + 3.4, wl = a - b + 3.6, wm = mesh(B(ww * 2, .1, wl), 0x2cb3c8, [0, 0, 0]);
        wm.material.transparent = true;
        wm.material.opacity = .84;
        wg.add(wm);
        const rip = [];
        for (let k = 0; k < 14; k++) {
            const r = mesh(B(.9, .03, .12), 0xe9ffff, [(k / 14 - .5) * ww * 2, .07, rr(-wl / 2 + .5, wl / 2 - .5)]);
            wg.add(r);
            rip.push(r);
        }
        wg.userData = { rip, ww };
        wg.position.set(0, h - 1.7, pc);
        S.add(wg);
        streams.push(wg);
        // Piranhas saltam por cima do tablado E dos corrimaos das pontes.
        // Arco largo e com altura suficiente para o corpo e a cauda nao atravessarem a madeira.
        // Mantemos o mesmo intervalo entre saltos e a mesma janela de vulnerabilidade no ar.
        const W = wp(pc) + 1, wy = h - 1.7;
        if (isBridge) {
            spawnPiranha(pc - 2.4, W, wy, 6.4, 0, 0);
            spawnPiranha(pc + 2.4, W, wy, 6.4, 1.6, 0);
        }
        else
            spawnPiranha(pc + .9, W, wy, 5.2, i * .7, 0, 1, true);
    }
    for (let k = 0; k < 4; k++) {
        const u = k / 3;
        carrot([0, h + 1.2 + Math.sin(u * Math.PI) * 1.0, a - .8 - u * (a - b - 1.6)]);
    }
});
// @ts-nocheck
// Restauração visual: preservar as malhas originais do Bunny Havoc.
// O Overhaul decorativo foi retirado: sem centenas de árvores sobrepostas,
// partículas extras, barreiras cenográficas gigantes ou planos opacos no horizonte.
const pineOverhaul = { update() { }, stats: { restored: true } };
// Continuação visual discreta do terreno após o gatilho de conclusão,
// sem criar obstáculos, alterar colisão ou interceptar o enquadramento da cutscene.
const phase2Endcap = (() => {
    const g = new T.Group();
    const h = hp(GOAL - 5);
    const earth = new T.MeshLambertMaterial({ color: 0x577665, side: T.DoubleSide });
    const rock = new T.MeshLambertMaterial({ color: 0x697985, flatShading: true });
    const foliage = [new T.MeshLambertMaterial({ color: 0x275f56 }),
        new T.MeshLambertMaterial({ color: 0x3c7560 })];
    // O piso distante se prolonga suavemente, sem parede artificial atravessando a paisagem.
    const floor = new T.Mesh(new T.PlaneGeometry(55, 52, 5, 4), earth);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, h - .12, GOAL - 29);
    g.add(floor);
    const trunkGeo = new T.CylinderGeometry(.26, .42, 3.2, 6);
    const crownGeo = new T.ConeGeometry(1.65, 3.4, 6);
    for (let side of [-1, 1]) {
        for (let n = 0; n < 13; n++) {
            const z = GOAL - 9 - n * 3.55;
            const x = side * (7.5 + n * .85 + (n % 3) * .5);
            const scale = .8 + (n % 4) * .14;
            const trunk = new T.Mesh(trunkGeo, new T.MeshLambertMaterial({ color: 0x69462d }));
            trunk.position.set(x, h + 1.45 * scale, z);
            trunk.scale.setScalar(scale);
            g.add(trunk);
            const crown = new T.Mesh(crownGeo, foliage[n % 2]);
            crown.position.set(x, h + 4.1 * scale, z);
            crown.scale.setScalar(scale);
            g.add(crown);
            if (n % 4 === 0) {
                const b = new T.Mesh(new T.DodecahedronGeometry(1.1, 0), rock);
                b.position.set(x - side * 1.0, h + .4, z + 1.1);
                b.scale.set(1.4, .63, .9);
                g.add(b);
            }
        }
    }
    // Pequenas colinas distantes, sem grandes placas/planos escondendo a floresta.
    for (let n = 0; n < 5; n++) {
        const x = (n - 2) * 16;
        const hill = new T.Mesh(new T.ConeGeometry(9 + (n % 2) * 3, 22, 5), new T.MeshLambertMaterial({ color: 0x536d78, flatShading: true }));
        hill.position.set(x, h + 5, GOAL - 69 - (n % 2) * 12);
        g.add(hill);
    }
    S.add(g);
    return { update() { }, visualOnly: true };
})();
// @ts-nocheck
// Bunny Havoc | Visual Overhaul V3 (Pinheiros): acabamento e camera de exploracao.
// Nenhuma mudanca em colisoes, layout, personagens, inimigos, audio ou cutscene.
// Pequenos conjuntos de particulas e malhas reutilizadas: sem criar geometrias por quadro.
const finalPolish = (() => {
    const mix = (a, b, t) => a + (b - a) * t, damp = (speed, dt) => 1 - Math.exp(-speed * Math.max(0, dt));
    let randSeed = 7890;
    const random = () => ((randSeed = (randSeed * 16807) % 2147483647) / 2147483647);
    const between = (a, b) => a + (b - a) * random();
    const isPine = true;
    const particleCount = 0;
    const positions = new Float32Array(particleCount * 3);
    const local = [];
    for (let i = 0; i < particleCount; i++)
        local.push({ x: between(-17, 17), z: between(-42, 18), h: between(.8, 8.4), phase: between(0, 6.28), wind: between(.1, .5) });
    const geometry = new T.BufferGeometry();
    geometry.setAttribute('position', new T.BufferAttribute(positions, 3));
    const material = new T.PointsMaterial({ color: 0xd7eef2, size: isPine ? .18 : .23, transparent: true, opacity: isPine ? .48 : .58, depthWrite: false, blending: T.AdditiveBlending });
    const ambience = new T.Points(geometry, material);
    ambience.frustumCulled = false;
    S.add(ambience);
    // Raios de luz triangulados; ficam fora da area de caminhada e nunca bloqueiam os controles.
    const beamMaterial = new T.MeshBasicMaterial({ color: 0xccefff, transparent: true, opacity: isPine ? .038 : .050, depthWrite: false, side: T.DoubleSide, blending: T.AdditiveBlending });
    const beamGeo = new T.CylinderGeometry(.18, 1.55, 8, 5, 1, true);
    const beams = [];
    for (let i = 0; i < 0; i++) {
        const z = -20 - i * 975 / (14 - 1), side = i % 2 ? -1 : 1, x = side * (wp(z) + between(4.4, 9.0));
        if (pitF(x, z) > .07)
            continue;
        const m = new T.Mesh(beamGeo, beamMaterial);
        m.position.set(x, gh(x, z) + 6.4, z);
        m.rotation.z = side * (.18 + random() * .13);
        m.scale.set(between(.65, 1.25), between(.8, 1.35), between(.65, 1.1));
        S.add(m);
        beams.push({ m, phase: between(0, 6.28), tilt: m.rotation.z });
    }
    // Respingo visual de poeira ao aterrissar e correr (pool fixa, nenhuma colisao).
    const puffGeometry = new T.IcosahedronGeometry(.12, 0), puffs = [];
    for (let i = 0; i < 28; i++) {
        const mat = new T.MeshBasicMaterial({ color: 0xc4d4c8, transparent: true, opacity: 0, depthWrite: false });
        const mesh = new T.Mesh(puffGeometry, mat);
        mesh.visible = false;
        S.add(mesh);
        puffs.push({ mesh, life: 0, ttl: 0, vx: 0, vy: 0, vz: 0 });
    }
    let head = 0, stepClock = 0, wasGrounded = true, hadStarted = false;
    const puff = (x, y, z, intensity) => {
        const a = puffs[head];
        head = (head + 1) % puffs.length;
        a.mesh.position.set(x, y, z);
        a.mesh.visible = true;
        a.ttl = a.life = .36 + random() * .24;
        a.vx = between(-1.1, 1.1) * intensity;
        a.vy = between(.7, 1.6) * intensity;
        a.vz = between(-1.2, 1.2) * intensity;
        a.mesh.scale.setScalar(.6 + random() * .65);
    };
    function emitGround(x, z, y, n) { for (let i = 0; i < n; i++)
        puff(x + between(-.35, .35), y + .11, z + between(-.29, .29), between(.55, 1.2)); }
    // Pontos de referencia e enquadramento interpolados em unidades/segundo;
    // a direcao da cutscene permanece 100% independente desta camera.
    const cameraTarget = new T.Vector3(), eyeTarget = new T.Vector3(), look = new T.Vector3();
    let cameraReady = false, lastX = 0, lastZ = 0;
    function camera(t, dt, st, run, cs, sprinting, cy, shake) {
        if (cs) {
            cameraReady = false;
            return;
        }
        const active = !!run;
        const targetX = active ? st.x * .60 + st.mx * .13 : st.x + Math.sin(t * .4) * 5;
        const targetZ = active ? st.z - 4.0 + Math.max(-1.3, Math.min(1.2, st.mz * .22)) : st.z;
        const targetY = active ? cy + 1.6 : cy + 1.3;
        const elevation = Math.min(1.2, Math.max(0, st.y - gh(st.x, st.z)) * .16);
        eyeTarget.set(active ? st.x * .6 + st.mx * .085 : st.x + Math.sin(t * .4) * 5, active ? cy + 5.85 + elevation : cy + 2.4, active ? st.z + 9.5 + Math.max(0, -st.mz) * .05 : st.z + Math.cos(t * .4) * 5);
        cameraTarget.set(targetX, targetY, targetZ);
        if (!cameraReady || Math.hypot(st.x - lastX, st.z - lastZ) > 22) {
            look.copy(cameraTarget);
            C.position.copy(eyeTarget);
            cameraReady = true;
        }
        else {
            look.lerp(cameraTarget, damp(active ? 6.1 : 3, dt));
            C.position.lerp(eyeTarget, damp(active ? 5.4 : 3.1, dt));
        }
        lastX = st.x;
        lastZ = st.z;
        // Impacto curto, sem deslocamento aleatorio cumulativo da camera.
        if (shake > 0) {
            C.position.x += Math.sin(t * 67) * shake * .55;
            C.position.y += Math.cos(t * 81) * shake * .4;
        }
        C.lookAt(look);
    }
    function update(t, dt, st, run, dy, cs, sprinting, moving) {
        if (!st)
            return;
        for (let i = 0; i < local.length; i++) {
            const o = local[i], j = i * 3, z = Math.max(-975 - 15, Math.min(14, st.z + o.z));
            const x = st.x + o.x;
            positions[j] = x + Math.sin(t * .6 + o.phase) * o.wind;
            positions[j + 1] = hp(z) + o.h + Math.sin(t * (isPine ? .7 : 1.1) + o.phase) * .27;
            positions[j + 2] = z + Math.cos(t * .4 + o.phase) * o.wind * 2.0;
        }
        geometry.attributes.position.needsUpdate = true;
        for (const a of beams) {
            a.m.rotation.z = a.tilt + Math.sin(t * .35 + a.phase) * .012;
        }
        beamMaterial.opacity = (isPine ? .037 : .05) * (1 + .16 * Math.sin(t * .42));
        for (const a of puffs) {
            if (a.life <= 0)
                continue;
            a.life = Math.max(0, a.life - dt);
            a.mesh.visible = a.life > 0;
            if (!a.mesh.visible)
                continue;
            a.mesh.position.x += a.vx * dt;
            a.mesh.position.y += a.vy * dt;
            a.mesh.position.z += a.vz * dt;
            a.vy += .35 * dt;
            a.mesh.material.opacity = .36 * a.life / a.ttl;
            const p = 1 - a.life / a.ttl;
            a.mesh.scale.setScalar(.65 + p * 1.85);
        }
        if (!hadStarted) {
            wasGrounded = !!st.g;
            hadStarted = true;
        }
        const canPuff = run && !cs && !dy;
        if (canPuff && st.g && !wasGrounded) {
            emitGround(st.x, st.z, gh(st.x, st.z), 7);
        }
        if (canPuff && st.g && sprinting && moving) {
            stepClock += dt;
            if (stepClock > .17) {
                stepClock = 0;
                emitGround(st.x, st.z + .12, gh(st.x, st.z), 2);
            }
        }
        else
            stepClock = 0;
        wasGrounded = !!st.g;
    }
    return { update, camera, stats: { rays: beams.length, particles: particleCount, puffs: puffs.length } };
})();
// @ts-nocheck
// Camera por trilhos (inspirada na arquitetura ZDAT observada em Crash 3).
// Implementacao ORIGINAL: nao sao trajetorias, valores nem camera extraidos de Crash.
// Camera de exploracao: independente da camera cinematografica da Bibibunn.
const cameraRails = (() => {
    const stageName = 'SELVA DE PINHEIROS';
    const anchors = [
        { z: 12.0, h: 6.10, dist: 10.80, lead: 4.50, fov: 61.0, side: 0.00 },
        { z: -75.0, h: 6.60, dist: 11.70, lead: 5.00, fov: 62.0, side: 0.12 },
        { z: -165.0, h: 6.50, dist: 11.30, lead: 5.40, fov: 62.0, side: -0.08 },
        { z: -255.0, h: 7.00, dist: 12.10, lead: 5.80, fov: 63.0, side: 0.16 },
        { z: -352.0, h: 7.30, dist: 12.00, lead: 5.80, fov: 63.0, side: -0.05 },
        { z: -455.0, h: 7.10, dist: 12.20, lead: 5.80, fov: 62.0, side: 0.12 },
        { z: -560.0, h: 7.50, dist: 12.60, lead: 6.20, fov: 63.0, side: -0.12 },
        { z: -680.0, h: 7.20, dist: 12.00, lead: 5.70, fov: 62.0, side: 0.14 },
        { z: -788.0, h: 7.70, dist: 12.90, lead: 6.10, fov: 64.0, side: -0.05 },
        { z: -890.0, h: 7.40, dist: 12.70, lead: 6.00, fov: 63.0, side: 0.15 },
        { z: -965.0, h: 7.80, dist: 13.10, lead: 5.60, fov: 64.0, side: 0.00 },
        { z: -990.0, h: 7.30, dist: 12.20, lead: 4.00, fov: 61.0, side: 0.00 }
    ];
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    const smooth = x => { const t = clamp(x, 0, 1); return t * t * (3 - 2 * t); };
    const damp = (speed, dt) => 1 - Math.exp(-speed * clamp(dt, 0, .08));
    const interp = (a, b, t) => a + (b - a) * t;
    const values = ['h', 'dist', 'lead', 'fov', 'side'];
    // Exatamente 2 pontos sao suficientes para cada interpolacao suave do trilho.
    function sample(z) {
        let i = 0;
        while (i < anchors.length - 2 && z < anchors[i + 1].z)
            i++;
        const a = anchors[i], b = anchors[i + 1];
        const u = smooth((a.z - z) / (a.z - b.z));
        const out = {};
        for (const k of values)
            out[k] = interp(a[k], b[k], u);
        return out;
    }
    // Prepara a leitura da plataforma ANTES de Bunnyck chegar ao buraco.
    // Ponto de perigo calculado a partir do mapa atual, nao de posicoes duplicadas.
    function danger(z) {
        let best = 0;
        for (let i = 0; i < pits.length; i++) {
            const a = pits[i], centre = (a[0] + a[1]) * .5, dz = z - centre;
            // Abre a camera durante a aproximacao e fecha mais rapidamente depois.
            const w = dz >= 0 ? 1 - smooth((dz - 2) / 18) : 1 - smooth((-dz - 2) / 11);
            const k = (i % 2 ? .82 : 1.0);
            best = Math.max(best, clamp(w, 0, 1) * k);
        }
        return best;
    }
    const desiredEye = new T.Vector3(), desiredLook = new T.Vector3(), eye = new T.Vector3(), look = new T.Vector3();
    let ready = false, lastX = 0, lastZ = 0, cinematic = false, fov = 60, mode = 'menu', hazard = 0;
    let levelStart = true;
    function reset() {
        ready = false; levelStart = true; }
    function camera(t, dt, st, run, cs, sprinting, cy, shake, dy) {
        // A cutscene controla posicao, rotacao e FOV por conta propria.
        if (cs) {
            cinematic = true;
            ready = false;
            mode = 'cutscene';
            return;
        }
        if (cinematic) {
            cinematic = false;
            reset();
        }
        if (!st)
            return;
        const active = !!run;
        const z = clamp(st.z, GOAL - 10, 12);
        const s = sample(z), d = active ? danger(z) : 0;
        hazard = d;
        const flight = clamp(Math.max(0, st.y - gh(st.x, st.z)), 0, 8);
        const sp = clamp(Math.hypot(st.mx || 0, st.mz || 0) / 10.3, 0, 1);
        const running = active && (sprinting || sp > .78);
        // A camera fica atras do jogador no eixo Z e nunca ultrapassa o Bunnyck.
        if (active) {
            const dist = s.dist + d * 2.35 + (running ? .60 : 0);
            const h = s.h + d * 1.85 + flight * .15;
            const forward = s.lead + d * 1.8 + (running ? .75 : 0);
            const playerGround = gh(st.x, st.z);
            const base = Math.max(playerGround, cy - flight * .45);
            const sx = st.x * .60 + clamp((st.mx || 0) * .075, -.65, .65) + s.side;
            desiredEye.set(sx, base + h, z + dist);
            desiredLook.set(st.x * .78 + clamp((st.mx || 0) * .10, -.65, .65), Math.max(playerGround + .90, cy + 1.50 + flight * .12) + d * .18, z - forward);
            mode = d > .24 ? 'travessia' : running ? 'corrida' : flight > .75 ? 'salto' : 'exploracao';
        }
        else {
            const ox = Math.sin(t * .4) * 5;
            desiredEye.set(st.x + ox, cy + 2.4, st.z + Math.cos(t * .4) * 5);
            desiredLook.set(st.x + ox, cy + 1.3, st.z);
            mode = 'menu';
        }
        const teleported = Math.hypot(st.x - lastX, st.z - lastZ) > 24;
        if (!ready || teleported) {
            eye.copy(desiredEye);
            look.copy(desiredLook);
            ready = true;
            fov = active ? s.fov : 60;
        }
        else {
            // Sem interpolacao que acumule erro, nem saltos quando a velocidade muda.
            eye.lerp(desiredEye, damp(active ? (d > .3 ? 3.8 : 4.3) : 3.2, dt));
            look.lerp(desiredLook, damp(active ? (d > .3 ? 5.0 : 5.7) : 3.4, dt));
            fov = interp(fov, clamp(s.fov + d * 2.25 + (running ? .6 : 0), 56, 68), damp(2.6, dt));
        }
        lastX = st.x;
        lastZ = st.z;
        C.position.copy(eye);
        // Camera shake so depois da interpolacao; nao contamina a posicao-alvo.
        if (shake > 0) {
            C.position.x += Math.sin(t * 67) * shake * .50;
            C.position.y += Math.cos(t * 81) * shake * .32;
        }
        if (Math.abs(C.fov - fov) > .025) {
            C.fov = fov;
            C.updateProjectionMatrix();
        }
        C.lookAt(look);
    }
    return { camera, sample, danger, reset, get state() { return { mode, hazard, fov, ready }; }, anchors, stageName };
})();
// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
// ---- inimigos low-poly: lagarto (2 golpes) e besouro rolando bola de cocô
function spawnLizard(z, x) {
    const e = new T.Group(), s = new T.Group();
    e.add(s);
    const green = 0x53aa32, shade = 0x287b2c, lime = 0x97cf55, cream = 0xf2e8bb;
    const a = (w, h, d, c, xx, yy, zz, p = s) => { const m = mesh(B(w, h, d), c, [xx, yy, zz]); p.add(m); return m; };
    a(.84, .35, .92, green, 0, .47, 0);
    a(.68, .27, .5, shade, 0, .38, -.28);
    const head = new T.Group();
    head.position.set(0, .65, .51);
    s.add(head);
    a(.7, .41, .55, green, 0, 0, 0, head);
    a(.56, .15, .35, cream, 0, -.2, .15, head);
    for (const side of [-1, 1]) {
        a(.19, .15, .09, 0xffffff, side * .22, .08, .29, head);
        a(.09, .15, .08, 0x262424, side * .22, .08, .35, head);
        a(.12, .1, .08, shade, side * .18, .27, .14, head);
    }
    const tail = new T.Group();
    tail.position.set(0, .45, -.49);
    s.add(tail);
    a(.36, .26, .62, shade, 0, 0, -.29, tail);
    a(.24, .18, .45, green, 0, .015, -.75, tail);
    a(.13, .12, .32, lime, 0, .03, -1.09, tail);
    const legs = [];
    for (const side of [-1, 1])
        for (const zz of [-.28, .33]) {
            const foot = new T.Group();
            foot.position.set(side * .45, .37, zz);
            s.add(foot);
            a(.23, .37, .25, green, side * .04, -.17, 0, foot);
            a(.3, .11, .31, lime, side * .07, -.32, .09, foot);
            legs.push(foot);
        }
    for (let i = 0; i < 4; i++)
        a(.14, .18, .18, lime, 0, .64, -.37 + i * .2);
    // Expressive tail tip + eyebrows + jaw: visual-only additions, same hitbox.
    const snout = new T.Group();
    snout.position.set(0, -.12, .19);
    head.add(snout);
    a(.50, .12, .38, cream, 0, -.10, .10, snout);
    const brows = [];
    for (const side of [-1, 1]) {
        const brow = a(.27, .075, .10, shade, side * .23, .18, .31, head);
        brows.push(brow);
    }
    e.position.set(x, hp(z), z);
    e.userData = { kind: 'lizard', hp: 2, maxHp: 2, gy: hp(z), x, z, am: Math.max(.4, Math.min(1.45, wp(z) - 1.35 - Math.abs(x))), phase: rr(0, 8), speed: rr(.75, 1.18), hurt: 0, legs, tail, head, snout, brows, model: s };
    S.add(e);
    foes.push(e);
    return e;
}
function spawnBeetle(z, x) {
    const e = new T.Group(), model = new T.Group();
    e.add(model);
    const a = (w, h, d, c, xx, yy, zz, p = model) => { const m = mesh(B(w, h, d), c, [xx, yy, zz]); p.add(m); return m; };
    const shell = mesh(new T.SphereGeometry(.46, 7, 5), 0x315b85, [-.47, .48, 0]);
    shell.scale.set(1.1, .7, 1.15);
    model.add(shell);
    a(.42, .29, .39, 0x1a344f, -.04, .36, 0);
    a(.24, .18, .21, 0x0b2238, .11, .38, .0);
    const legs = [];
    for (const side of [-1, 1])
        for (const zz of [-.28, .23]) {
            const leg = new T.Group();
            leg.position.set(-.45, .38, side * .31 + zz * .15);
            model.add(leg);
            a(.13, .32, .13, 0x273f5b, 0, -.18, side * .11, leg);
            legs.push(leg);
        }
    for (const side of [-1, 1]) {
        a(.1, .1, .08, 0xffffff, .13, .47, side * .14);
        a(.06, .07, .06, 0x171018, .19, .47, side * .14);
    }
    const dung = new T.Group();
    dung.position.set(.62, .58, 0);
    model.add(dung);
    const ball = mesh(new T.IcosahedronGeometry(.57, 1), 0x654328);
    dung.add(ball);
    for (let k = 0; k < 9; k++) {
        const ang = k * Math.PI * 2 / 9;
        const cl = mesh(B(.2, .10, .16), k % 2 ? 0x805632 : 0x4f321c, [Math.sin(ang) * .53, Math.cos(ang) * .43, Math.sin(ang * 3) * .23]);
        cl.rotation.z = ang;
        dung.add(cl);
    }
    const feelers = [];
    for (const side of [-1, 1]) {
        const a0 = new T.Group();
        a0.position.set(.17, .46, side * .13);
        model.add(a0);
        a(.05, .26, .05, 0x24384a, 0, .12, 0, a0);
        a(.11, .10, .11, 0x83bf94, 0, .29, 0, a0);
        feelers.push(a0);
    }
    e.position.set(x, hp(z), z);
    e.userData = { kind: 'beetle', hp: 1, maxHp: 1, gy: hp(z), x, z, am: Math.max(.4, Math.min(1.4, wp(z) - 1.6 - Math.abs(x))), phase: rr(0, 8), speed: rr(.9, 1.4), hurt: 0, dung, legs, feelers, shell, model };
    S.add(e);
    foes.push(e);
    return e;
}
function spawnBearLegacyNaoUtilizado(z, x) {
    const e = new T.Group(), m = new T.Group();
    e.add(m);
    const a = (w, h, d, c, xx, yy, zz, p = m) => { const o = mesh(B(w, h, d), c, [xx, yy, zz]); p.add(o); return o; };
    const BR = 0x6b4a2d, BR2 = 0x4f351f, CR = 0xe6cfaa;
    const legs = [], arms = [];
    a(1.1, .95, .9, BR, 0, 1.25, 0);
    a(.8, .55, .04, CR, 0, 1.15, .43);
    const head = new T.Group();
    head.position.set(0, 2.05, .18);
    m.add(head);
    a(1.05, .88, .96, BR, 0, 0, 0, head);
    a(.75, .4, .05, CR, 0, -.18, .47, head);
    a(.18, .15, .09, 0x222222, -.22, -.04, .52, head);
    a(.18, .15, .09, 0x222222, .22, -.04, .52, head);
    a(.14, .1, .08, 0x25140c, 0, .02, .54, head);
    a(.24, .22, .24, BR2, -.28, .35, .0, head);
    a(.24, .22, .24, BR2, .28, .35, .0, head);
    for (const s of [-1, 1]) {
        const lg = new T.Group();
        lg.position.set(s * .36, .78, s > 0 ? -.15 : .15);
        m.add(lg);
        a(.36, .7, .34, BR, 0, -.18, 0, lg);
        a(.45, .16, .48, BR2, 0, -.58, .1, lg);
        legs.push(lg);
        const lg2 = new T.Group();
        lg2.position.set(s * .36, .78, s > 0 ? .35 : -.35);
        m.add(lg2);
        a(.36, .7, .34, BR, 0, -.18, 0, lg2);
        a(.45, .16, .48, BR2, 0, -.58, .1, lg2);
        legs.push(lg2);
        const ar = new T.Group();
        ar.position.set(s * .65, 1.55, .22);
        m.add(ar);
        a(.26, .58, .26, BR, 0, -.18, 0, ar);
        a(.34, .16, .34, BR2, 0, -.5, .04, ar);
        arms.push(ar);
    }
    e.position.set(x, hp(z), z);
    e.userData = { kind: 'bear', hp: 3, maxHp: 3, gy: hp(z), x, z, am: Math.max(.4, Math.min(1.7, wp(z) - 1.5 - Math.abs(x))), phase: rr(0, 8), speed: rr(.65, .95), hurt: 0, legs, arms, head, model: m };
    S.add(e);
    foes.push(e);
    return e;
}
function spawnFish(z, x, baseY) {
    const e = new T.Group(), m = new T.Group();
    e.add(m);
    const a = (w, h, d, c, xx, yy, zz, p = m) => { const o = mesh(B(w, h, d), c, [xx, yy, zz]); p.add(o); return o; };
    const BL = 0x4aa3ff, BL2 = 0x2a67b9, WH2 = 0xeaf7ff;
    a(.65, .26, .36, BL, 0, 0, 0);
    a(.38, .14, .04, WH2, .05, -.02, .2);
    a(.22, .22, .22, BL2, -.36, 0, 0);
    const tail = new T.Group();
    tail.position.set(-.34, 0, 0);
    m.add(tail);
    a(.18, .18, .06, BL, 0, 0, .12, tail);
    a(.18, .18, .06, BL, 0, 0, -.12, tail);
    a(.07, .08, .07, 0xffffff, .18, .05, .11);
    a(.04, .05, .04, 0x101b32, .22, .05, .13);
    e.position.set(x, baseY, z);
    e.userData = { kind: 'fish', hp: 1, maxHp: 1, gy: baseY, x, z, baseY, phase: rr(0, 8), speed: rr(2.2, 3.4), leap: rr(1.1, 1.9), tail, model: m, hurt: 0 };
    S.add(e);
    foes.push(e);
    return e;
}
function spawnBear(z, x) {
    const e = new T.Group(), m = new T.Group();
    e.add(m);
    const a = (w, h, d, c, xx, yy, zz, p = m) => { const o = mesh(B(w, h, d), c, [xx, yy, zz]); p.add(o); return o; };
    const BR = 0x7a5233, DK = 0x4e331f, LT = 0xd9b98a, CL = 0xf2eee0, legs = [], arms = [], fore = [];
    for (const s of [-1, 1]) {
        const lg = new T.Group();
        lg.position.set(s * .42, .95, 0);
        m.add(lg);
        a(.5, .55, .5, BR, 0, -.27, 0, lg);
        a(.44, .45, .44, DK, 0, -.72, .02, lg);
        a(.52, .2, .7, DK, 0, -.92, .14, lg);
        for (let k = -1; k <= 1; k++)
            a(.08, .08, .18, CL, k * .15, -.94, .52, lg);
        legs.push(lg);
    }
    const tor = new T.Group();
    tor.position.set(0, .95, 0);
    m.add(tor);
    a(1.35, 1.15, 1.1, BR, 0, .6, 0, tor);
    a(1.15, .5, .9, DK, 0, 1.15, -.05, tor);
    a(.9, .8, .1, LT, 0, .55, .56, tor);
    for (let k = 0; k < 4; k++)
        a(.2, .22, .2, DK, (k - 1.5) * .3, 1.5, -.35, tor);
    a(.4, .4, .4, BR, 0, .15, -.62, tor);
    const head = new T.Group();
    head.position.set(0, 1.45, .2);
    tor.add(head);
    a(1.05, .9, .95, BR, 0, .45, 0, head);
    a(.6, .42, .55, LT, 0, .28, .62, head);
    a(.2, .14, .12, 0x1a1210, 0, .45, .9, head);
    a(.26, .24, .2, DK, -.38, 1, 0, head);
    a(.26, .24, .2, DK, .38, 1, 0, head);
    a(.14, .12, .05, LT, -.38, 1, .1, head);
    a(.14, .12, .05, LT, .38, 1, .1, head);
    for (const s of [-1, 1]) {
        a(.2, .18, .06, 0xffffff, s * .28, .62, .48, head);
        a(.1, .12, .06, 0x111111, s * .28, .6, .52, head);
        const br = a(.34, .09, .08, 0x24150c, s * .28, .84, .5, head);
        br.rotation.z = s * .4;
        a(.08, .16, .08, CL, s * .18, .17, .88, head);
    }
    const jaw = new T.Group();
    jaw.position.set(0, .12, .45);
    head.add(jaw);
    a(.52, .16, .5, DK, 0, -.02, .25, jaw);
    a(.36, .06, .34, 0xe86a7a, 0, .05, .22, jaw);
    for (const s of [-1, 1])
        a(.08, .14, .08, CL, s * .17, .1, .5, jaw);
    for (const s of [-1, 1]) {
        const ar = new T.Group();
        ar.position.set(s * .85, 1.2, 0);
        tor.add(ar);
        a(.46, .6, .46, BR, 0, -.3, 0, ar);
        const fr = new T.Group();
        fr.position.set(0, -.6, 0);
        ar.add(fr);
        a(.4, .55, .4, DK, 0, -.27, 0, fr);
        a(.5, .3, .5, BR, 0, -.65, .04, fr);
        for (let k = -1; k <= 1; k++)
            a(.07, .07, .26, CL, k * .14, -.72, .3, fr);
        arms.push(ar);
        fore.push(fr);
    }
    // Poses adicionais do urso: garra levantada e rugido; sem mudar colisão.
    const shoulders = [];
    for (const side of [-1, 1]) {
        const sh = a(.37, .3, .46, DK, side * .84, 1.38, -.06, tor);
        shoulders.push(sh);
    }
    e.scale.setScalar(1.15);
    e.position.set(x, hp(z), z);
    e.userData = { kind: 'bear', hp: 3, maxHp: 3, gy: hp(z), x, z, am: Math.max(.4, Math.min(1.7, wp(z) - 1.5 - Math.abs(x))), phase: rr(0, 8), speed: rr(.65, .95), hurt: 0, legs, arms, fore, head, jaw, tor, shoulders, model: m, at: 'walk', ct: 0, cool: 0, reach: 0 };
    S.add(e);
    foes.push(e);
    return e;
}
function spawnPiranha(z, W, wl, H, phase, flip, arcPow = 1, movingPlatform = false) {
    const e = new T.Group(), m = new T.Group();
    e.add(m);
    const a = (w, h, d, c, xx, yy, zz, p = m) => { const o = mesh(B(w, h, d), c, [xx, yy, zz]); p.add(o); return o; };
    const SG = 0x4d5a63, SG2 = 0x39444c, RD = 0xd8392c, WH = 0xf5f5f0;
    a(.85, .5, .38, SG, 0, 0, 0);
    a(.8, .2, .4, RD, 0, -.2, 0);
    a(.4, .1, .36, SG2, .05, .27, 0);
    a(.3, .22, .04, RD, -.1, .38, 0);
    a(.34, .46, .36, SG, .52, .04, 0);
    a(.18, .12, .4, RD, .45, -.12, 0);
    const jaw = new T.Group();
    jaw.position.set(.62, -.12, 0);
    m.add(jaw);
    a(.28, .12, .34, SG2, .06, -.03, 0, jaw);
    for (const zz of [-.13, -.045, .045, .13]) {
        a(.05, .09, .05, WH, .7, -.1, zz);
        a(.05, .08, .05, WH, .12, .08, zz, jaw);
    }
    for (const s of [-1, 1]) {
        a(.12, .12, .06, 0xffa31a, .52, .14, s * .2);
        a(.05, .08, .04, 0x111111, .56, .14, s * .23);
        a(.22, .05, .06, 0x222222, .52, .25, s * .2);
        a(.2, .05, .2, RD, .2, -.18, s * .24);
    }
    const tail = new T.Group();
    tail.position.set(-.42, 0, 0);
    m.add(tail);
    a(.1, .34, .08, SG, -.05, 0, 0, tail);
    a(.14, .5, .06, RD, -.14, 0, 0, tail);
    const dorsal = new T.Group();
    dorsal.position.set(-.08, .26, 0);
    m.add(dorsal);
    a(.20, .33, .24, RD, 0, .10, 0, dorsal);
    const brows = [];
    for (const side of [-1, 1])
        brows.push(a(.24, .06, .055, SG2, .5, .31, side * .20));
    e.scale.setScalar(1.15);
    e.position.set(0, wl - 80, z);
    e.userData = { kind: 'piranha', hp: 1, maxHp: 1, gy: wl - 80, z, W, wl, H, phase, period: 3.2, L: movingPlatform ? 1.65 : 1.35, flip, arcPow, movingPlatform, tail, jaw, dorsal, brows, model: m, hurt: 0 };
    S.add(e);
    foes.push(e);
    return e;
}
function spawnStream(z) {
    const w = Math.max(5.8, Math.min(8.8, wp(z) - .4)), y = hp(z) - .03, g = new T.Group();
    const water = mesh(B(w * 2.15, .09, 5.8), 0x28b8cf, [0, 0, 0]);
    water.material.transparent = true;
    water.material.opacity = .87;
    g.add(water);
    g.add(mesh(B(w * 2.2, .07, 6.1), 0x205c78, [0, -.08, 0]));
    for (let k = -4; k <= 4; k++) {
        const ripple = mesh(B(.63, .025, .1), 0xd4f9fa, [k * w / 5, .09, 1.4 + Math.sin(k * 2.4) * .7]);
        g.add(ripple);
    }
    for (let i = 0; i < 5; i++) {
        const sx = -w + .9 + i * (w * 2 - 1.8) / 4;
        const rock = mesh(new T.DodecahedronGeometry(.34), 0x90a0ab, [sx, .15, rr(-1.4, 1.4)]);
        rock.scale.set(1.1, .6, 1.1);
        g.add(rock);
    }
    const plank = mesh(B(1.1, .12, 5.1), 0x8f6838, [rr(-w * .45, w * .45), .12, 0]);
    g.add(plank);
    g.position.set(0, y, z);
    S.add(g);
    streams.push(g);
    const fishCount = 2 + (Math.random() * 2 | 0);
    for (let i = 0; i < fishCount; i++)
        spawnFish(z + rr(-1.5, 1.5), rr(-w + 1.1, w - 1.1), y + .15);
    return g;
}
// Travessia especial das plataformas móveis: a piranha sobe primeiro,
// cruza o corredor em altura segura e só mergulha depois da borda oposta.
// O easing horizontal deixa a subida/descida mais vertical nas margens.
function movingPiranhaJump(u, W, waterY, peakHeight) {
    const a = Math.max(0, Math.min(1, u));
    const easeX = .5 - .5 * Math.cos(Math.PI * a);
    const left = easeX * easeX, right = (1 - easeX) * (1 - easeX);
    const across = left / (left + right);
    const h = Math.pow(Math.max(0, Math.sin(Math.PI * a)), .8) * peakHeight;
    return { across, height: h, y: waterY + h, x: -W + 2 * W * across };
}
function animateEnemies(t, dt) {
    for (const e of foes) {
        if (!e.visible || e.userData.defeated || enemyCombat.controls(e))
            continue;
        const d = e.userData;
        d.hurt = Math.max(0, d.hurt - dt);
        if (d.kind === 'lizard') {
            const vx = st.x - e.position.x, vz = st.z - e.position.z, dist = Math.hypot(vx, vz);
            const chase = run && !dy && !cv && dist < 15 && Math.abs(st.z - d.z) < 15 && Math.abs(st.y - e.position.y) < 3.5;
            d.intent = chase ? 'alert' : 'patrol';
            d.attackT = (d.attackT || 0) + dt;
            d.attackCool = Math.max(0, (d.attackCool || 0) - dt);
            if (!chase && d.attackState !== 'recover')
                d.attackState = 'patrol';
            if (d.hurt > .05) {
                d.attackState = 'recover';
                d.attackT = 0;
                d.attackCool = .65;
            }
            if (chase && dist < 4.2 && d.attackCool <= 0 && (!d.attackState || d.attackState === 'patrol')) {
                d.attackState = 'windup';
                d.attackT = 0;
            }
            if (d.attackState === 'windup' && d.attackT > .32) {
                d.attackState = 'lunge';
                d.attackT = 0;
            }
            if (d.attackState === 'lunge' && d.attackT > .40) {
                d.attackState = 'recover';
                d.attackT = 0;
                d.attackCool = 1.1;
            }
            if (d.attackState === 'recover' && d.attackT > .50) {
                d.attackState = 'patrol';
                d.attackT = 0;
            }
            const wind = d.attackState === 'windup', lunge = d.attackState === 'lunge', recover = d.attackState === 'recover';
            const targetX = chase ? st.x : d.x + Math.sin(t * d.speed * .85 + d.phase) * d.am;
            const targetZ = chase ? st.z : d.z + Math.sin(t * .44 + d.phase) * .6;
            const dx = targetX - e.position.x, dz = targetZ - e.position.z, rem = Math.hypot(dx, dz);
            if (rem > .08) {
                const moveSpeed = wind ? 0 : recover ? .75 : lunge ? 8.1 : chase ? 3.7 + (d.speed - .75) * 1.6 : 1.25;
                const step = Math.min(rem, moveSpeed * dt * (d.hurt > .35 ? .12 : 1));
                const xx = e.position.x + dx / rem * step, zz = e.position.z + dz / rem * step;
                if (Math.abs(zz - d.z) < 11.5 && Math.abs(xx) < wp(zz) - .72 && pitF(xx, zz) < .065) {
                    e.position.x = xx;
                    e.position.z = zz;
                }
                e.rotation.y = Math.atan2(dx, dz);
            }
            e.position.y = gh(e.position.x, e.position.z) + .04;
            d.gy = e.position.y;
            const speedAnim = lunge ? 23 : chase ? 17 : 10;
            d.legs.forEach((l, i) => { l.rotation.x = Math.sin(t * speedAnim + i * Math.PI * .83 + d.phase) * (chase ? .66 : .35); });
            d.tail.rotation.y = Math.sin(t * (chase ? 11 : 4) + d.phase) * (chase ? .5 : .3);
            d.head.rotation.z = Math.sin(t * (chase ? 7 : 2) + d.phase) * .055;
            d.head.rotation.x = chase ? -.11 : 0;
            d.model.position.y = lunge ? Math.abs(Math.sin(t * 23 + d.phase)) * .1 : chase ? Math.abs(Math.sin(t * 16 + d.phase)) * .06 : 0;
        }
        else if (d.kind === 'beetle') {
            const ph = t * d.speed + d.phase, xx = d.x + Math.sin(ph) * d.am;
            const direction = Math.cos(ph) >= 0 ? 1 : -1;
            e.position.x = xx;
            e.position.y = gh(xx, d.z) + .04;
            e.position.z = d.z;
            d.gy = e.position.y;
            d.model.scale.x = direction;
            d.dung.rotation.z -= dt * 5 * direction;
            d.legs.forEach((l, i) => l.rotation.z = Math.sin(t * 18 + i * 2.4) * .4);
            d.model.position.y = Math.abs(Math.sin(t * 12 + d.phase)) * .05;
        }
        else if (d.kind === 'bear') {
            const vx = st.x - e.position.x, vz = st.z - e.position.z, dist = Math.hypot(vx, vz), sm = u => { u = Math.max(0, Math.min(1, u)); return u * u * (3 - 2 * u); };
            const chase = run && !dy && !cv && dist < 13 && Math.abs(st.z - d.z) < 14 && Math.abs(st.y - e.position.y) < 3.6;
            d.ct += dt;
            d.cool = Math.max(0, d.cool - dt);
            d.reach = 0;
            let mvx = 0;
            if (d.hurt > .05 && d.at !== 'walk') {
                d.at = 'walk';
                d.cool = .8;
            }
            if (d.at === 'walk') {
                const tX = chase ? st.x : d.x + Math.sin(t * d.speed + d.phase) * d.am, tZ = chase ? st.z : d.z + Math.sin(t * .3 + d.phase) * .45, dx = tX - e.position.x, dz = tZ - e.position.z, rem = Math.hypot(dx, dz);
                if (rem > .06) {
                    const ms = chase ? (dist < 3.5 ? 4.4 : 3.8) : 1.05, step = Math.min(rem, ms * dt * (d.hurt > .25 ? .2 : 1)), xx = e.position.x + dx / rem * step, zz = e.position.z + dz / rem * step;
                    if (Math.abs(zz - d.z) < 14 && Math.abs(xx) < wp(zz) - .8 && pitF(xx, zz) < .06) {
                        e.position.x = xx;
                        e.position.z = zz;
                        mvx = 1;
                    }
                    e.rotation.y = Math.atan2(dx, dz);
                }
                if (chase && dist < 3.3 && d.hurt <= 0 && d.cool <= 0) {
                    d.at = 'wind';
                    d.ct = 0;
                    snd(120, .4, 'sawtooth', 70, .1);
                }
            }
            else if (d.at === 'wind') {
                e.rotation.y = Math.atan2(vx, vz);
                if (d.ct > .55) {
                    d.at = 'swipe';
                    d.ct = 0;
                    d.hit = 0;
                }
            }
            else if (d.at === 'swipe') {
                e.rotation.y = Math.atan2(vx, vz);
                const xx = e.position.x + Math.sin(e.rotation.y) * 5 * dt, zz = e.position.z + Math.cos(e.rotation.y) * 5 * dt;
                if (Math.abs(xx) < wp(zz) - .8 && pitF(xx, zz) < .06) {
                    e.position.x = xx;
                    e.position.z = zz;
                }
                if (d.ct > .05 && d.ct < .26)
                    d.reach = 2.5;
                if (!d.hit && d.ct > .1) {
                    d.hit = 1;
                    snd(180, .14, 'square', 60, .1);
                    fx({ x: e.position.x + Math.sin(e.rotation.y) * 1.6, y: e.position.y + .5, z: e.position.z + Math.cos(e.rotation.y) * 1.6 }, 0xffffff, 5, 3);
                }
                if (d.ct > .3) {
                    d.at = 'recover';
                    d.ct = 0;
                }
            }
            else if (d.ct > .7) {
                d.at = 'walk';
                d.cool = 1.3;
            }
            e.position.y = gh(e.position.x, e.position.z) + .03;
            d.gy = e.position.y;
            const ph = t * (chase ? 9 : 5) + d.phase, at = d.at, spd = at === 'swipe' ? 30 : 14, sl = (o, ax, v) => o.rotation[ax] += (v - o.rotation[ax]) * Math.min(1, dt * spd);
            let tx = chase ? .12 : 0, ax = 0, az = 0, fa = 0, hx = 0, jw = chase ? .12 + Math.sin(t * 14) * .08 : 0;
            if (at === 'wind') {
                const u = sm(d.ct / .5);
                tx = -.55 * u;
                ax = -2.7 * u;
                az = .5 * u;
                fa = -.9 * u;
                hx = -.4 * u;
                jw = .7 * u;
            }
            else if (at === 'swipe') {
                const u = sm(d.ct / .22);
                tx = -.55 + .9 * u;
                ax = -2.7 + 3.2 * u;
                az = .5 - .3 * u;
                fa = -.9 * (1 - u);
                hx = -.4 + .7 * u;
                jw = .5;
            }
            else if (at === 'recover') {
                const u = sm(d.ct / .6);
                tx = .35 * (1 - u);
                ax = .5 * (1 - u);
                az = .2 * (1 - u);
                hx = .3 * (1 - u);
                jw = .3 * (1 - u);
            }
            else {
                ax = Math.sin(ph + Math.PI) * .35;
                fa = -.25 - Math.sin(ph) * .2;
                az = .08;
            }
            if (d.hurt > .05)
                hx = Math.sin(t * 40) * .2;
            sl(d.tor, 'x', tx + Math.sin(t * 1.8 + d.phase) * .015);
            sl(d.tor, 'z', at === 'walk' && mvx ? Math.sin(ph) * .07 : 0);
            d.arms.forEach((a, i) => { sl(a, 'x', at === 'walk' ? ax * (i ? 1 : -1) : ax); sl(a, 'z', (i ? 1 : -1) * az); });
            d.fore.forEach(f => sl(f, 'x', fa));
            sl(d.head, 'x', hx);
            sl(d.jaw, 'x', jw);
            d.legs.forEach((l, i) => sl(l, 'x', at === 'walk' && mvx ? Math.sin(ph + i * Math.PI) * (chase ? .65 : .4) : at === 'wind' ? -.15 : 0));
            d.model.position.y = (at === 'walk' && mvx ? Math.abs(Math.sin(ph)) * .07 : 0) - (at === 'wind' ? sm(d.ct / .5) * .12 : 0);
        }
        else if (d.kind === 'bear_old') {
            const vx = st.x - e.position.x, vz = st.z - e.position.z, dist = Math.hypot(vx, vz);
            const chase = run && !dy && !cv && dist < 13 && Math.abs(st.z - d.z) < 14 && Math.abs(st.y - e.position.y) < 3.6;
            const targetX = chase ? st.x : d.x + Math.sin(t * d.speed + d.phase) * d.am;
            const targetZ = chase ? st.z : d.z + Math.sin(t * .3 + d.phase) * .45;
            const dx = targetX - e.position.x, dz = targetZ - e.position.z, rem = Math.hypot(dx, dz);
            if (rem > .06) {
                const moveSpeed = chase ? (dist < 3.5 ? 6.0 : 3.8) : 1.05;
                const step = Math.min(rem, moveSpeed * dt * (d.hurt > .25 ? .2 : 1));
                const xx = e.position.x + dx / rem * step, zz = e.position.z + dz / rem * step;
                if (Math.abs(zz - d.z) < 14 && Math.abs(xx) < wp(zz) - .8 && pitF(xx, zz) < .06) {
                    e.position.x = xx;
                    e.position.z = zz;
                }
                e.rotation.y = Math.atan2(dx, dz);
            }
            e.position.y = gh(e.position.x, e.position.z) + .03;
            d.gy = e.position.y;
            const ph = t * (chase ? 10 : 5.5) + d.phase;
            d.legs.forEach((l, i) => l.rotation.x = Math.sin(ph + i * .9) * (chase ? .6 : .35));
            d.arms.forEach((a, i) => { a.rotation.x = Math.sin(ph + i * Math.PI) * .35; a.rotation.z = i ? -.1 : .1; });
            d.head.rotation.x = chase ? -.1 : Math.sin(t * 2 + d.phase) * .04;
            d.model.position.y = Math.abs(Math.sin(t * (chase ? 11 : 6) + d.phase)) * .06;
        }
        else if (d.kind === 'piranha') {
            // One clean lateral jump between riverbanks. The entire body is above the
            // bridge + rails while traversing the planked corridor, never inside it.
            const clock = t + d.phase, cycle = Math.floor(clock / d.period), elapsed = clock - cycle * d.period;
            const forward = ((cycle + d.flip) % 2) === 0;
            const bank = forward ? -1 : 1;
            const u = Math.min(1, Math.max(0, elapsed / d.L));
            const airborne = elapsed < d.L;
            const warn = !airborne && elapsed > d.period - .40;
            d.attackActive = airborne;
            d.warn = warn;
            d.jumpU = u;
            const fromX = bank * d.W, toX = -bank * d.W;
            if (airborne) {
                // Pontes mantêm exatamente o movimento original. Nas plataformas móveis,
                // o animal ganha altura ANTES de ocupar a área de deslocamento da madeira.
                const motion = d.movingPlatform ? movingPiranhaJump(u, d.W, d.wl, d.H) : null;
                const x = motion ? (forward ? motion.x : -motion.x) : fromX + (toX - fromX) * u;
                const height = motion ? motion.height : 4 * u * (1 - u) * d.H;
                const y = d.wl + height;
                e.position.set(x, y, d.z);
                d.gy = y;
                e.rotation.y = forward ? 0 : Math.PI;
                // Derivada do arco para orientar a piranha durante a subida e a descida.
                const rise = motion ? (Math.cos(Math.PI * u) * d.H * 2.0) : 4 * (1 - 2 * u) * d.H;
                e.rotation.z = Math.atan2(rise, 2 * d.W);
                d.model.visible = true; // A reação de dano permanece visível durante o pulinho.
                if (d.cy !== cycle) {
                    d.cy = cycle;
                    d.landed = false;
                    if (Math.abs(st.z - d.z) < 24) {
                        fx({ x: fromX, y: d.wl, z: d.z }, 0xcfeeff, 6, 2);
                    }
                }
            }
            else {
                // Rest just BELOW the actual water surface; don't teleport 80 units down.
                e.position.set(toX, d.wl - (warn ? .10 : .65), d.z);
                d.gy = e.position.y;
                e.rotation.z = 0;
                e.rotation.y = forward ? 0 : Math.PI;
                d.model.visible = warn;
                if (!d.landed) {
                    d.landed = true;
                    if (Math.abs(st.z - d.z) < 24)
                        fx({ x: toX, y: d.wl, z: d.z }, 0xcfeeff, 8, 2);
                }
            }
            d.tail.rotation.y = Math.sin(t * 22 + d.phase) * .6;
            d.jaw.rotation.z = .25 + Math.sin(t * 12 + d.phase) * .28;
            // Do not play a pitched sine note for every jump, every cycle: with many
            // piranhas those repeating notes sounded like a second background song.
        }
        else if (d.kind === 'fish') {
            const ph = t * d.speed + d.phase, jump = Math.max(0, Math.sin(ph));
            e.position.x = d.x + Math.sin(ph * .5) * .18;
            e.position.z = d.z + Math.cos(ph * .7) * .35;
            e.position.y = d.baseY + jump * d.leap;
            d.gy = e.position.y;
            e.rotation.z = .9 - jump * 1.8;
            d.tail.rotation.y = Math.sin(t * 22 + d.phase) * .7;
            d.model.position.y = Math.abs(Math.sin(t * 18 + d.phase)) * .03;
        }
        if (d.kind !== 'piranha')
            d.model.visible = true; // A reação de dano permanece visível durante o pulinho.
    }
}
function hitEnemy(e, comboHit = false) {
    const d = e.userData;
    if ((d.hurt > 0 && !comboHit) || !e.visible || d.defeated || enemyCombat.launched(e))
        return;
    const strike = comboHit ? playerCombat.strikeFor(e) : {damage:1,finisher:false};
    d.hp = Math.max(0, d.hp - strike.damage);
    d.hurt = .85;
    const color = d.kind === 'lizard' ? 0x85dd4b : d.kind === 'beetle' ? 0xa1733e : d.kind === 'bear' ? 0x8b5c32 : d.kind === 'piranha' ? 0xd23a2a : 0x5ab7ff;
    fx(e.position, color, d.hp > 0 ? 8 : 15, 4);
    snd(d.hp > 0 ? 260 : 600, .16, 'square', d.hp > 0 ? 180 : 940);
    shake = .16;
    if (d.hp <= 0) {
        d.defeated = true;
        d.defeatT = 0;
        d.hurt = 0;
        addFr(d.kind === 'lizard' ? 6 : d.kind === 'bear' ? 10 : (d.kind === 'fish' || d.kind === 'piranha') ? 5 : 3);
        hud();
        fx(e.position, 0xffe14a, 8, 4);
    }
    if (strike.finisher) enemyCombat.launch(e, strike.heading);
    else if (strike.opening || !comboHit) {
        // Giro e pisão afastam de Bunnyck; no mesmo ponto, usa a direção dele.
        const dx=e.position.x-st.x,dz=e.position.z-st.z;
        const radial=Math.hypot(dx,dz)>.001?Math.atan2(dx,dz):(strike.heading??body.rotation.y);
        const away = !comboHit || playerCombat.state.step === 1 ? radial : strike.heading;
        enemyCombat.recoil(e, away);
    }
    enemyCombat.hurt(e, strike.heading ?? Math.atan2(e.position.x-st.x,e.position.z-st.z), !!strike.finisher);
}
// V23 — Composição planejada em vez de sorteio. Pontos seguros entre saltos,
// áreas de conversa e encontros; caixas e cenouras são montadas no módulo global.
const authoredHazards = [-33, -79, -129, -178, -229, -278, -326, -384, -437, -485, -537, -593, -657, -718, -778, -843, -914, -951];
for (let i = 0; i < authoredHazards.length; i++) {
    const z = authoredHazards[i];
    if (pitF(0, z) > .025)
        continue;
    const gz = hp(z), side = i % 2 ? 1 : -1, w = wp(z);
    if (i % 4 === 1) {
        const n = 3, g = new T.Group();
        for (let k = 0; k < n; k++)
            g.add(mesh(new T.ConeGeometry(.28, .9, 6), 0xadb5b4, [(k - 1) * .87, .45, 0]));
        g.add(mesh(B(2.9, .1, .8), 0x57635e, [0, .05, 0]));
        g.position.set(side * 2.2, gz, z);
        g.userData = { hw: 1.68 };
        S.add(g);
        spikes.push(g);
    }
    else if (i % 7 === 3 && z > -350) {
        const width = Math.max(1.5, w * .42), wall = treeWall(width);
        wall.position.set(side * (w - width / 2), gz, z);
        wall.userData = { hx: width / 2, hz: .7, gy: gz };
        S.add(wall);
        walls.push(wall);
    }
}
// Inimigos feitos à mão, animados e com dificuldade gradual.
[-39, -103, -149, -192, -242, -300, -329, -355, -379].forEach((z, i) => spawnLizard(z, (i % 3 - 1) * 1.35));
[-20, -62, -123, -169, -214, -255, -282, -323, -347, -372].forEach((z, i) => spawnBeetle(z, i % 2 ? .5 : -.5));
// Extensao da fase 2: selva longa com riachos, ursos, peixes e mais vida.
[-438, -492, -548, -604, -662, -721, -781, -846, -910].forEach((z, i) => spawnLizard(z, (i % 3 - 1) * 1.8));
[-420, -470, -517, -570, -628, -689, -750, -812, -874, -938].forEach((z, i) => spawnBeetle(z, i % 2 ? 1.05 : -1.05));
// Sem urso no buraco com água z=-771; vizinho do buraco pequeno deslocado para terreno firme.
[-91, -183, -273, -377, -455, -535, -615, -695, -775, -855, -935].forEach((z, i) => {
    if (z === -775)
        return; // Este urso estava dentro da cava profunda.
    spawnBear(z, i % 2 ? 1.45 : -1.45);
});
// Caixas e cenouras tardias agora são distribuídas no sistema global.
// Placas e arcos de madeira para lembrar o concept art da floresta.
for (const z of [-482, -642, -802, -962]) {
    const w = wp(z), side = (Math.sin(z) > 0 ? 1 : -1), x = side * (w - .8), y = gh(x, z), g = new T.Group();
    g.add(mesh(B(.18, 2.3, .18), 0x6f4a28, [0, 1.15, 0]));
    g.add(mesh(B(1.55, .4, .18), 0xbe8f54, [-side * .45, 1.95, 0]));
    g.position.set(x, y, z);
    S.add(g);
}
for (const arr of [boxes, spikes, logs, walls, fruits])
    for (let i = arr.length - 1; i >= 0; i--)
        if (sPits.some(([a, b]) => arr[i].position.z < a + 3 && arr[i].position.z > b - 3)) {
            S.remove(arr[i]);
            arr.splice(i, 1);
        }
// V23: inimigos longe das rotinas dos NPCs. Nao altera a IA, a quantidade nem os modelos.
// Ajusta apenas faixas dos inimigos terrestres que dividiam a mesma faixa do NPC.
const calmNPCSpots = [[-43, -1.8], [-115, 1.6], [-213, -1.8], [-336, 1.5], [-448, -1.7], [-576, 1.6], [-669, -1.75], [-793, 1.55], [-944, -1.5]];
for (const e of foes) {
    const d = e.userData;
    if (!['lizard', 'beetle', 'bear'].includes(d.kind))
        continue;
    const near = calmNPCSpots.find(([z, x]) => Math.abs(d.z - z) < 6.5 && Math.abs(d.x - x) < 3);
    if (!near)
        continue;
    const nextX = -Math.sign(near[1]) * Math.min(2.6, Math.max(1.85, wp(d.z) - 1.4));
    if (Math.abs(nextX) < wp(d.z) - .72 && pitF(nextX, d.z) < .025) {
        d.x = nextX;
        e.position.x = nextX;
        d.am = Math.max(.3, Math.min(d.am, wp(d.z) - 1.5 - Math.abs(nextX)));
    }
}
// @ts-nocheck
// BUNNY HAVOC | Enemy Animation Overhaul V2
// Camada visual independente: nao reescreve hitboxes, progresso nem saltos das piranhas.
// Estados: patrol/alert/windup/attack/recover/hurt/defeated (+ submerge para piranhas).
const enemyAnimator = (() => {
    const smooth = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * Math.max(0, Math.min(dt, .06))));
    const clamp = (v, lo = 0, hi = 1) => Math.min(hi, Math.max(lo, v));
    const ease = u => { u = clamp(u); return u * u * (3 - 2 * u); };
    const existingStates = new Set(['patrol', 'alert', 'windup', 'attack', 'recover', 'hurt', 'defeated', 'submerge']);
    function get(e) {
        const d = e.userData;
        if (!d._enemyAnim) {
            const danger = new T.Group();
            const warning = new T.Mesh(new T.OctahedronGeometry(.18), new T.MeshBasicMaterial({ color: 0xffd66e, transparent: true, opacity: .95, depthWrite: false }));
            warning.rotation.z = Math.PI / 4;
            danger.add(warning);
            const pulse = new T.Mesh(new T.RingGeometry(.25, .36, 12), new T.MeshBasicMaterial({ color: 0xffe3a8, transparent: true, opacity: .48, side: T.DoubleSide, depthWrite: false }));
            pulse.rotation.x = -Math.PI / 2;
            danger.add(pulse);
            danger.position.set(0, d.kind === 'bear' ? 3.5 : d.kind === 'piranha' ? .65 : 1.9, 0);
            danger.visible = false;
            e.add(danger);
            d._enemyAnim = { state: 'patrol', age: 0, prevState: '', danger, warning, pulse, weight: 0, lastScale: d.model.scale.y || 1 };
        }
        return d._enemyAnim;
    }
    function stateFor(e) {
        const d = e.userData;
        if (d.defeated)
            return 'defeated';
        if (d.hurt > .05)
            return 'hurt';
        if (d.kind === 'lizard') {
            if (d.attackState === 'windup')
                return 'windup';
            if (d.attackState === 'lunge')
                return 'attack';
            if (d.attackState === 'recover')
                return 'recover';
            return d.intent === 'alert' ? 'alert' : 'patrol';
        }
        if (d.kind === 'bear') {
            if (d.at === 'wind')
                return 'windup';
            if (d.at === 'swipe')
                return 'attack';
            if (d.at === 'recover')
                return 'recover';
            const dist = Math.hypot(st.x - e.position.x, st.z - e.position.z);
            return run && !dy && !cv && !cs && dist < 13 ? 'alert' : 'patrol';
        }
        if (d.kind === 'beetle') {
            const a = Math.abs(Math.cos(tickTime * d.speed + d.phase));
            const near = run && !dy && !cv && !cs && Math.hypot(st.x - e.position.x, st.z - e.position.z) < 4.1;
            return a < .2 ? 'windup' : near ? 'alert' : 'patrol';
        }
        if (d.kind === 'piranha') {
            if (d.warn)
                return 'windup';
            if (d.attackActive)
                return 'attack';
            return 'submerge';
        }
        return 'patrol';
    }
    let tickTime = 0;
    function update(t, dt) {
        tickTime = t;
        for (const e of foes) {
            const d = e.userData;
            if (!e.visible || enemyCombat.controls(e))
                continue;
            const anim = get(e), state = stateFor(e);
            if (!existingStates.has(state))
                continue;
            if (anim.state !== state) {
                anim.prevState = anim.state;
                anim.state = state;
                anim.age = 0;
            }
            else
                anim.age += dt;
            d.animationState = state;
            const w = ease(anim.age / .18);
            const warning = state === 'windup' && (d.kind === 'piranha' || d.kind === 'lizard' || d.kind === 'bear');
            anim.danger.visible = warning;
            anim.danger.position.y = (d.kind === 'bear' ? 3.6 : d.kind === 'piranha' ? .65 : 1.8) + Math.sin(t * 12 + d.phase) * .07;
            anim.warning.scale.setScalar(.88 + Math.sin(t * 15 + d.phase) * .22);
            anim.pulse.scale.setScalar(.92 + Math.sin(t * 10 + d.phase) * .14);
            anim.warning.material.opacity = warning ? .76 + .16 * Math.sin(t * 16) : 0;
            const model = d.model;
            if (state === 'defeated') {
                d.defeatT = (d.defeatT || 0) + dt;
                const a = clamp(d.defeatT / .57);
                model.visible = true;
                model.position.y = smooth(model.position.y, Math.sin(a * Math.PI) * .55 - a * .3, 14, dt);
                model.rotation.z = smooth(model.rotation.z, Math.PI * .68 * a, 13, dt);
                model.scale.set(1 + .12 * Math.sin(a * Math.PI), Math.max(.03, 1 - .96 * ease(a)), 1 + .12 * Math.sin(a * Math.PI));
                anim.danger.visible = false;
                if (a >= 1)
                    e.visible = false;
                continue;
            }
            // Flash de dano e squash, sem deslocar o hitbox.
            if (state === 'hurt') {
                const pulse = Math.sin(t * 35 + d.phase) * .14;
                model.rotation.z = smooth(model.rotation.z, pulse, 18, dt);
                model.scale.set(1 + .08 * Math.abs(pulse), .91, 1 + .08 * Math.abs(pulse));
            }
            else {
                model.rotation.z = smooth(model.rotation.z, 0, 8, dt);
                // Escala X do besouro e invertida pelo controlador legado de direcao; manter sinal.
                const face = d.kind === 'beetle' ? Math.sign(model.scale.x || 1) : 1;
                const breath = Math.sin(t * 2.4 + d.phase) * .015;
                const crouch = state === 'windup' ? .82 : state === 'recover' ? .93 : 1;
                const stretch = state === 'attack' ? 1.09 : 1;
                model.scale.set(face * (1 + (state === 'windup' ? .08 : 0)), smooth(model.scale.y, crouch * stretch + breath, 10, dt), 1 + (state === 'attack' ? .08 : 0));
            }
            if (d.kind === 'lizard') {
                const charge = state === 'windup' ? ease(anim.age / .34) : 0;
                d.head.rotation.x = smooth(d.head.rotation.x, (state === 'attack' ? -.24 : state === 'windup' ? .16 : state === 'alert' ? -.12 : 0), 12, dt);
                d.head.rotation.z = smooth(d.head.rotation.z, state === 'hurt' ? Math.sin(t * 40) * .19 : Math.sin(t * 3 + d.phase) * .045, 9, dt);
                d.snout.rotation.x = smooth(d.snout.rotation.x, state === 'alert' || state === 'windup' ? .24 : state === 'attack' ? .35 : 0, 10, dt);
                d.brows.forEach((b, i) => { b.rotation.z = smooth(b.rotation.z, (i ? 1 : -1) * (state === 'alert' || state === 'windup' ? .21 : .04), 11, dt); });
                d.tail.rotation.z = smooth(d.tail.rotation.z, Math.sin(t * (state === 'attack' ? 14 : 5) + d.phase) * .19 + (state === 'windup' ? -.20 : 0), 10, dt);
                d.tail.rotation.x = smooth(d.tail.rotation.x, state === 'attack' ? .24 : 0, 10, dt);
                d.legs.forEach((l, i) => { l.rotation.z = smooth(l.rotation.z, charge * (i % 2 ? .15 : -.15), 12, dt); });
                model.rotation.x = smooth(model.rotation.x, state === 'windup' ? .12 : state === 'attack' ? -.11 : 0, 11, dt);
            }
            else if (d.kind === 'beetle') {
                const strain = state === 'windup' ? 1 : state === 'alert' ? .45 : .18;
                d.shell.scale.y = smooth(d.shell.scale.y, .70 - (state === 'windup' ? .12 : 0), 10, dt);
                d.feelers.forEach((f, i) => { f.rotation.x = smooth(f.rotation.x, Math.sin(t * 7 + d.phase + i * 2) * .30, 12, dt); f.rotation.z = smooth(f.rotation.z, (i ? 1 : -1) * (.20 + strain * .18), 9, dt); });
                d.legs.forEach((l, i) => { l.rotation.x = smooth(l.rotation.x, Math.sin(t * 14 + d.phase + i * 1.6) * (.12 + strain * .2), 11, dt); });
                model.rotation.z = smooth(model.rotation.z, (state === 'windup' ? .17 : state === 'alert' ? .08 : 0) * Math.sign(model.scale.x), 11, dt);
                d.dung.rotation.x = Math.sin(t * 4 + d.phase) * .065;
            }
            else if (d.kind === 'bear') {
                const prep = state === 'windup' ? ease(d.ct / .55) : 0, swipe = state === 'attack' ? ease(d.ct / .3) : 0;
                d.shoulders.forEach((s, i) => { s.scale.y = smooth(s.scale.y, state === 'windup' ? 1.15 : 1, 12, dt); s.rotation.z = (i ? -.1 : .1) * prep; });
                d.head.rotation.z = smooth(d.head.rotation.z, state === 'hurt' ? Math.sin(t * 33) * .18 : state === 'windup' ? .11 * Math.sin(t * 9) : state === 'attack' ? -.12 : Math.sin(t * 1.6 + d.phase) * .03, 10, dt);
                d.model.rotation.x = smooth(d.model.rotation.x, state === 'windup' ? .055 : state === 'attack' ? -.12 : state === 'recover' ? .08 : 0, 12, dt);
                d.model.position.y += (state === 'windup' ? -.025 * prep : state === 'attack' ? .025 * swipe : 0);
                d.jaw.rotation.z = smooth(d.jaw.rotation.z, state === 'windup' ? .09 : state === 'attack' ? .18 : 0, 10, dt);
            }
            else if (d.kind === 'piranha') {
                // O trajeto x/y/z vem EXCLUSIVAMENTE da logica antiga; nao alteramos arcos.
                d.dorsal.rotation.z = smooth(d.dorsal.rotation.z, state === 'windup' ? -.25 : state === 'attack' ? .15 : 0, 12, dt);
                d.brows.forEach((b, i) => { b.rotation.z = smooth(b.rotation.z, (i ? 1 : -1) * (state === 'windup' ? .3 : .08), 12, dt); });
                const tailSpeed = state === 'attack' ? 24 : state === 'windup' ? 15 : 8;
                d.tail.rotation.x = Math.sin(t * tailSpeed + d.phase) * .12;
                d.jaw.rotation.z = smooth(d.jaw.rotation.z, state === 'windup' ? .60 : state === 'attack' ? .45 + Math.sin(t * 15) * .19 : .14, 12, dt);
                model.scale.set(smooth(model.scale.x, state === 'windup' ? 1.1 : 1, 12, dt), smooth(model.scale.y, state === 'windup' ? .85 : state === 'attack' ? 1.07 : 1, 12, dt), 1);
                if (state === 'windup')
                    model.visible = true;
            }
        }
    }
    function reset() {
        for (const e of foes) {
            const d = e.userData;
            if (d._enemyAnim) {
                d._enemyAnim.state = 'patrol';
                d._enemyAnim.age = 0;
                d._enemyAnim.danger.visible = false;
            }
            d.animationState = 'patrol';
            d.defeated = false;
            d.defeatT = 0;
            d.attackState = 'patrol';
            d.attackCool = 0;
            d.attackT = 0;
            d.hurt = 0;
            if (d.kind === 'bear') {
                d.at = 'walk';
                d.ct = 0;
                d.cool = 0;
                d.reach = 0;
            }
            if (d.kind === 'piranha') {
                d.attackActive = false;
                d.warn = false;
            }
            d.hp = d.maxHp;
            e.visible = true;
            d.model.scale.set(1, 1, 1);
            d.model.rotation.set(0, 0, 0);
            d.model.position.set(0, 0, 0);
            d.model.visible = d.kind !== 'piranha';
            if (d.kind === 'beetle')
                d.shell.scale.y = .7;
        }
    }
    return { update, reset, states: [...existingStates] };
})();
// @ts-nocheck
// V23 — Sistema global de caixas do Bosque e da Selva.
// Geometria original do bonus V22: madeira com reforcos em X. Nenhuma tecla nova.
const authoredCrates = (() => {
    const STAGE = 2;
    const nodes = [-15, -36, -73, -88, -124, -146, -176, -197, -225, -248, -276, -298, -332, -349, -381, -398, -429, -451, -482, -505, -537, -566, -591, -621, -662, -682, -714, -746, -783, -813, -856, -877, -908, -942];
    const npcZ = [-43, -115, -213, -336, -448, -576, -669, -793, -944];
    const enemyZ = STAGE === 1 ? [-39, -103, -149, -192, -242, -300, -329, -355, -379] : [-91, -183, -273, -377, -455, -535, -615, -695, -855, -935, -438, -492, -548, -604, -662, -721, -781, -846, -910];
    const palette = { normal: 0x9d6231, carrot: 0xb47736, armored: 0x6d7486, spring: 0x9d6231, tnt: 0xc72e20, nitro: 0x2b9e68 };
    const faceLabel = { carrot: '🥕', armored: '2x', tnt: 'TNT', nitro: 'N!', spring: '↑' };
    const inventory = [];
    const blastEffects = [];
    const labels = new Map();
    const mat = c => new T.MeshLambertMaterial({ color: c, flatShading: true });
    const meshPart = (b, g, c, x, y, z) => { const m = new T.Mesh(g, mat(c)); m.position.set(x, y, z); b.add(m); return m; };
    const iconTex = (label, bg) => {
        const key = label + bg;
        if (labels.has(key))
            return labels.get(key);
        const cv = document.createElement('canvas');
        cv.width = cv.height = 128;
        const g = cv.getContext('2d');
        g.fillStyle = bg;
        g.fillRect(0, 0, 128, 128);
        g.strokeStyle = '#f7dca7';
        g.lineWidth = 8;
        g.strokeRect(7, 7, 114, 114);
        g.font = label === 'TNT' ? '900 41px system-ui' : '900 48px system-ui';
        g.textAlign = 'center';
        g.textBaseline = 'middle';
        g.fillStyle = '#fff8de';
        g.fillText(label, 64, 65);
        const tx = new T.CanvasTexture(cv);
        tx.magFilter = T.NearestFilter;
        labels.set(key, tx);
        return tx;
    };
    function style(b, kind) {
        b.clear();
        b.scale.set(1, 1, 1);
        b.material = mat(palette[kind]);
        const isExplosive = kind === 'tnt' || kind === 'nitro', light = isExplosive ? 0xf7dba3 : 0xe5b779;
        for (const side of [-1, 1]) {
            meshPart(b, B(1.25, .095, 1.27), light, 0, side * .56, 0);
            meshPart(b, B(1.27, 1.10, .105), kind === 'nitro' ? 0x9bdd93 : 0xd4a06e, 0, 0, side * .59);
            meshPart(b, B(.095, 1.11, 1.27), light, side * .59, 0, 0);
        }
        // Quatro frentes/cantos em baixo relevo, inspirados nas diagonais do bonus aprovado.
        if (kind === 'normal' || kind === 'carrot' || kind === 'armored' || kind === 'spring') {
            for (const side of [-1, 1]) {
                for (const turn of [-1, 1]) {
                    const rail = meshPart(b, B(.105, 1.22, .10), 0x704524, turn * .06, 0, side * .69);
                    rail.rotation.z = turn * .72;
                }
            }
        }
        if (kind !== 'normal') {
            const bg = kind === 'tnt' ? '#b72720' : kind === 'nitro' ? '#15885e' : kind === 'armored' ? '#455268' : kind === 'spring' ? '#9b6234' : '#b87335';
            const tex = iconTex(faceLabel[kind], bg);
            for (const face of [-1, 1]) {
                const plate = new T.Mesh(new T.PlaneGeometry(.83, .79), new T.MeshBasicMaterial({ map: tex, transparent: true, side: T.DoubleSide }));
                plate.position.set(0, .01, face * .703);
                plate.rotation.y = face === 1 ? 0 : Math.PI;
                b.add(plate);
            }
        }
        if (isExplosive) {
            meshPart(b, B(1.21, .10, 1.22), kind === 'tnt' ? 0xffbf4b : 0x9bfcca, 0, .6, 0);
            for (const xx of [-.38, .38])
                for (const zz of [-.38, .38])
                    meshPart(b, B(.105, 1.12, .1), kind === 'tnt' ? 0xe9b35e : 0xc1e8b1, xx, 0, zz);
            meshPart(b, new T.CylinderGeometry(.11, .13, .2, 6), 0x493c34, 0, .7, 0);
        }
        const sp = { kind, hits: 0, maxHits: kind === 'armored' ? 2 : 1, cool: 0, fuse: 0, flash: 0 };
        b.userData.special = sp;
        b.userData.baseX = b.position.x;
        inventory.push(b);
        return b;
    }
    function safePlacement(z, x, guard = 3.4) {
        if (z < GOAL + 24 || pitF(x, z) > .02)
            return false;
        if (Math.abs(x) > wp(z) - 1.65)
            return false;
        if (npcZ.some(v => Math.abs(v - z) < 6.5))
            return false;
        if (enemyZ.some(v => Math.abs(v - z) < guard))
            return false;
        if (foes.some(e => Math.hypot(e.position.x - x, e.position.z - z) < 3))
            return false;
        if (walls.some(w => Math.hypot(w.position.x - x, w.position.z - z) < 2.2))
            return false;
        if (spikes.some(s => Math.hypot(s.position.x - x, s.position.z - z) < 2.5))
            return false;
        if (boxes.some(b => Math.hypot(b.position.x - x, b.position.z - z) < 1.8))
            return false;
        return true;
    }
    function spawn(z, x, kind) {
        if (!safePlacement(z, x, kind === 'tnt' || kind === 'nitro' ? 4 : 3.2))
            return null;
        const y = hp(z);
        const b = mesh(B(1.17, 1.16, 1.17), palette[kind], [x, y + .68, z]);
        b.userData = { gy: y };
        S.add(b);
        boxes.push(b);
        style(b, kind);
        return b;
    }
    // Recria a composicao com distribuicao previsivel. Nenhuma TNT aparece junto a NPC.
    for (let i = 0; i < nodes.length; i++) {
        const z = nodes[i], w = wp(z), side = i % 2 === 0 ? -1 : 1;
        const x = side * Math.min(2.4, Math.max(1.85, w - 2.0));
        const kind = i % 9 === 2 ? 'tnt' : i % 13 === 8 ? 'nitro' : i % 6 === 1 ? 'carrot' : i % 11 === 5 ? 'armored' : i % 17 === 6 ? 'spring' : 'normal';
        if (!spawn(z, x, kind)) {
            // no lugar de criar caixas atravessando buracos, busca um trecho seguro proximo
            for (const shift of [-3, 3, -6, 6, -9, 9])
                if (spawn(z + shift, x, kind))
                    break;
        }
        // Cenouras indicam a direcao, sem espalhar centenas de itens ao acaso.
        if (i % 2 === 0) {
            const cz = z - 4.5, cx = -side * .7;
            if (pitF(cx, cz) < .025 && npcZ.every(n => Math.abs(n - cz) > 4)) {
                for (let k = 0; k < 3; k++)
                    carrot([cx, gh(cx, cz - k * .85) + 1.45 + (k === 1 ? .35 : 0), cz - k * .85]);
            }
        }
    }
    // Pequenos conjuntos de duas caixas para explorar explosoes em cadeia; acessiveis e sinalizados.
    const safeClusters = STAGE === 1 ? [-119, -200, -291] : [-157, -391, -682];
    for (const z of safeClusters) {
        const x = 0.75;
        if (!safePlacement(z, x, 3.0) || !safePlacement(z + 2.0, x, 3.0))
            continue;
        const a = spawn(z, x, 'tnt'), b = spawn(z + 2.0, x, 'normal');
        if (!a || !b) {
            if (a) {
                S.remove(a);
                boxes.splice(boxes.indexOf(a), 1);
                inventory.splice(inventory.indexOf(a), 1);
            }
        }
    }
    // A cada conjunto de TNT, coloca uma caixa vizinha em distancia alcançável,
    // para ensinar visualmente o efeito dominó. Evita obstáculos e NPCs.
    let demoPairs = 0;
    for (const tnt of inventory.filter(b => b.userData.special.kind === 'tnt')) {
        if (demoPairs >= 2)
            break;
        for (const offset of [-2.35, 2.35, -2.9, 2.9]) {
            const z = tnt.position.z + offset, x = tnt.position.x;
            if (safePlacement(z, x, 3)) {
                if (spawn(z, x, 'normal')) {
                    demoPairs++;
                    break;
                }
            }
        }
    }
    function debris(p, color, n = 15) { fx(p, color, n, 5); }
    function breakBox(b, reward = 5) {
        if (!b.visible)
            return false;
        b.visible = false;
        broken++;
        if (reward > 0)
            addFr(reward);
        hud();
        debris(b.position, 0xdda36c, 11);
        snd(220, .13, 'square', 440, .045);
        return true;
    }
    function blast(center) {
        if (!run || dy || cs || secretSystems?.bonus?.active)
            return;
        const radius = 4.45;
        const origin = new T.Vector3(center.x, center.y, center.z);
        const queue = [origin], visited = new Set();
        // a onda alcanca inimigos, caixas, outras TNT/Nitro e o jogador.
        while (queue.length) {
            const p = queue.shift();
            debris(p, 0xffa439, 23);
            debris(p, 0x514237, 9);
            snd(135, .38, 'sawtooth', 45, .26);
            shake = .65;
            const ring = new T.Mesh(new T.RingGeometry(.5, radius, 28), new T.MeshBasicMaterial({ color: 0xffb146, transparent: true, opacity: .75, side: T.DoubleSide, depthWrite: false }));
            ring.rotation.x = -Math.PI / 2;
            ring.position.copy(p);
            ring.position.y += .15;
            S.add(ring);
            blastEffects.push({ m: ring, age: 0 });
            for (const e of foes) {
                if (!e.visible || e.userData.defeated)
                    continue;
                if (e.position.distanceTo(p) > radius + 0.6)
                    continue;
                e.userData.hp = 0;
                e.userData.hurt = 0;
                e.userData.defeated = true;
                e.userData.defeatT = 0;
                e.userData.attackActive = false;
                debris(e.position, 0xffd15c, 14);
            }
            for (const b of inventory) {
                if (!b.visible || visited.has(b))
                    continue;
                if (b.position.distanceTo(p) > radius)
                    continue;
                visited.add(b);
                const explosive = ['tnt', 'nitro'].includes(b.userData.special.kind);
                if (breakBox(b, 0) && explosive)
                    queue.push(b.position.clone());
            }
            if (st && Math.hypot(st.x - p.x, st.z - p.z, st.y + .9 - p.y) < radius + 0.45 && run && !dy && !cv && !cs)
                die('explosion', { position: p });
        }
    }
    const api = {
        hit(b) {
            if (!b?.visible)
                return;
            const sp = b.userData.special;
            if (!sp)
                return breakBox(b, 5);
            if (sp.cool > 0 || sp.fuse > 0)
                return;
            if (sp.kind === 'spring') {
                sp.cool = .25;
                sp.flash = .28;
                snd(630, .12, 'sine', 1100);
                return;
            }
            if (sp.kind === 'tnt') {
                sp.fuse = 1.1;
                sp.flash = 1.1;
                snd(700, .12, 'square', 900);
                return;
            }
            if (sp.kind === 'nitro') {
                blast(b.position.clone());
                return;
            }
            if (sp.kind === 'armored') {
                sp.cool = .28;
                sp.hits++;
                sp.flash = .26;
                snd(310, .14, 'square', 220);
                if (sp.hits < 2)
                    return;
                breakBox(b, 7);
                return;
            }
            breakBox(b, sp.kind === 'carrot' ? 15 : 5);
        },
        stomp(b) { this.hit(b); return b.userData.special?.kind === 'spring' ? 16.5 : 8; },
        update(t, dt) {
            for (const b of inventory) {
                const sp = b.userData.special;
                if (!sp)
                    continue;
                sp.cool = Math.max(0, sp.cool - dt);
                sp.flash = Math.max(0, sp.flash - dt);
                if (!b.visible)
                    continue;
                if (sp.kind === 'tnt' && sp.fuse > 0) {
                    sp.fuse -= dt;
                    if (sp.fuse <= 0) {
                        blast(b.position.clone());
                        continue;
                    }
                    b.material.emissive?.setHex(Math.floor(sp.fuse * 10) % 2 ? 0x000000 : 0xff6c3c);
                    b.material.emissiveIntensity = .45;
                }
                else if (sp.kind === 'tnt')
                    b.material.emissive?.setHex(0x000000);
                const spring = sp.kind === 'spring' && sp.flash > 0 ? .76 + Math.sin(t * 35) * .08 : 1;
                b.scale.y += (spring - b.scale.y) * Math.min(1, dt * 17);
            }
            for (let i = blastEffects.length - 1; i >= 0; i--) {
                const v = blastEffects[i];
                v.age += dt;
                v.m.scale.setScalar(1 + v.age * 1.2);
                v.m.material.opacity = Math.max(0, .75 - v.age * 2.3);
                if (v.age > .35) {
                    S.remove(v.m);
                    blastEffects.splice(i, 1);
                }
            }
        },
        playerContact() {
            if (!st || !run || dy || cs || cv)
                return;
            for (const b of inventory) {
                const s = b.userData.special;
                if (!b.visible || s.kind !== 'nitro')
                    continue;
                if (Math.abs(st.x - b.position.x) < 1.06 && Math.abs(st.z - b.position.z) < 1.06 && Math.abs(st.y + .85 - b.position.y) < 1.3) {
                    blast(b.position.clone());
                    break;
                }
            }
        },
        reset() {
            for (const b of inventory) {
                const sp = b.userData.special;
                b.visible = true;
                sp.hits = 0;
                sp.cool = 0;
                sp.flash = 0;
                sp.fuse = 0;
                b.scale.set(1, 1, 1);
                b.material.emissive?.setHex(0x000000);
            }
            for (const x of blastEffects)
                S.remove(x.m);
            blastEffects.length = 0;
        },
        explode: blast, boxes: inventory
    };
    return api;
})();
// @ts-nocheck
// Bunny Havoc — Caixas, Tocas Bônus e Segredos V4 | Sistema independente por fase.
// Sem copiar recursos de outros jogos: modelos e desafios originais feitos por geometria.
const secretSystems = (() => {
    const STAGE = 2;
    const decorated = [], secretItems = [], particles = [];
    const mat = (c, em = 0) => new T.MeshLambertMaterial({ color: c, emissive: em, emissiveIntensity: .22 });
    const block = (parent, w, h, d, c, x, y, z) => { const o = new T.Mesh(B(w, h, d), mat(c)); o.position.set(x, y, z); parent.add(o); return o; };
    const sign = (label, bg, fg = 0xffffff) => { const cv = document.createElement('canvas'); cv.width = 256; cv.height = 96; const ctx = cv.getContext('2d'); ctx.fillStyle = bg; ctx.fillRect(0, 0, 256, 96); ctx.lineWidth = 8; ctx.strokeStyle = '#fff4cb'; ctx.strokeRect(5, 5, 246, 86); ctx.fillStyle = fg; ctx.font = '900 33px system-ui'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, 128, 49); const tx = new T.CanvasTexture(cv); tx.magFilter = T.NearestFilter; return tx; };
    const crates = authoredCrates;
    // Entrada de bônus em local seguro, afastada das armadilhas/caixas presentes.
    const candidates = STAGE === 1 ? [-118, -149, -197, -225, -282] : [-365, -430, -559, -625, -706];
    const safeAt = (x, z, r = 3) => pitF(x, z) < .025 && boxes.every(b => Math.hypot(x - b.position.x, z - b.position.z) > r) && spikes.every(s => Math.hypot(x - s.position.x, z - s.position.z) > r) && foes.every(e => Math.hypot(x - e.position.x, z - e.position.z) > r + 1) && walls.every(w => Math.hypot(x - w.position.x, z - w.position.z) > r + 1) && logs.every(l => Math.hypot(x - l.position.x, z - l.position.z) > r + 1);
    const getSafe = (zs, side) => { for (const z of zs) {
        for (const s of [side, -side]) {
            const x = s * (wp(z) - 1.25);
            if (safeAt(x, z, 2.1))
                return { x, z };
        }
    } const z = zs[0]; return { x: 0, z }; };
    const spot = { x: 5000, z: 5000 }, portal = new T.Group(); /* V27: entrada da toca bonus desativada */
    portal.position.set(spot.x, gh(spot.x, spot.z), spot.z);
    const mound = new T.Mesh(new T.SphereGeometry(1.55, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(0x8b643d));
    mound.position.set(0, .18, 0);
    mound.scale.set(1.2, .72, .95);
    portal.add(mound);
    block(portal, 2.55, .22, 1.7, 0x6a472a, 0, .05, 0);
    const rim = new T.Mesh(new T.TorusGeometry(.74, .11, 6, 18), mat(0xa57c4b));
    rim.position.set(0, .34, .05);
    rim.rotation.x = Math.PI / 2;
    portal.add(rim);
    const burrow = new T.Mesh(new T.CylinderGeometry(.68, .86, 1.18, 14, 1, true), new T.MeshBasicMaterial({ color: 0x090705, side: T.DoubleSide }));
    burrow.position.set(0, .34, .05);
    burrow.rotation.x = Math.PI / 2;
    portal.add(burrow);
    for (const side of [-1, 1])
        block(portal, .16, 1.42, .16, 0x7f5c35, side * .88, 1.18, .36);
    block(portal, 2.22, .30, .26, 0x714926, 0, 1.88, .36);
    const label = new T.Mesh(new T.PlaneGeometry(2.02, .62), new T.MeshBasicMaterial({ map: sign('TOCA BÔNUS', '#6b4425'), side: T.DoubleSide }));
    label.position.set(0, 1.88, .56);
    portal.add(label);
    const glow = new T.Mesh(new T.RingGeometry(.42, .68, 18), new T.MeshBasicMaterial({ color: 0xffdf8b, transparent: true, opacity: .9, side: T.DoubleSide }));
    glow.position.set(0, .26, .07);
    glow.rotation.x = -Math.PI / 2;
    portal.add(glow);
    const carrotMarker = new T.Group();
    carrotMarker.position.set(0, 1.05, .52);
    const carrotBody = new T.Mesh(new T.ConeGeometry(.14, .38, 5), mat(0xff9b22));
    carrotBody.rotation.z = Math.PI;
    carrotMarker.add(carrotBody);
    for (let j = 0; j < 3; j++) {
        const sprout = new T.Mesh(new T.ConeGeometry(.06, .18, 4), mat(0x4fbd4a));
        sprout.position.set((j - 1) * .07, .22, 0);
        sprout.rotation.z = (j - 1) * .5;
        carrotMarker.add(sprout);
    }
    portal.add(carrotMarker);
    S.add(portal);
    // Cenouras douradas: três segredos independentes, encontrados perto da trilha.
    const zs = STAGE === 1 ? [-71, -239, -347] : [-185, -515, -887];
    zs.forEach((z, i) => {
        let pos = getSafe([z, z - 5, z + 5, z - 9], i % 2 ? -1 : 1);
        let x = pos.x, zp = pos.z;
        const g = new T.Group();
        g.position.set(x, gh(x, zp) + 1.13, zp);
        const gold = new T.Mesh(new T.OctahedronGeometry(.53, 0), new T.MeshLambertMaterial({ color: 0xffc835, emissive: 0xd68908, emissiveIntensity: .32 }));
        gold.scale.set(.7, 1.3, .7);
        g.add(gold);
        for (let j = 0; j < 3; j++)
            block(g, .12, .4, .11, 0x41de83, (j - 1) * .19, .79, 0);
        const ring = new T.Mesh(new T.TorusGeometry(.65, .055, 5, 18), new T.MeshBasicMaterial({ color: 0xffffad, transparent: true, opacity: .77 }));
        ring.rotation.x = Math.PI / 2;
        g.add(ring);
        S.add(g);
        secretItems.push({ g, y: g.position.y, collected: false, ring, phase: i * 2.3 });
    });
    // Toca bônus V21: percurso lateral 2.5D, caixas + cenouras, sem bomba, cronômetro ou medalha.
    // A geometria e os itens são originais do Bunny Havoc; a estrutura lateral referencia o gênero PS1.
    const arenaY = 18, arenaZ = 820, arena = new T.Group(), pads = [], tokens = [], bonusBoxes = [];
    const deckColor = STAGE === 1 ? 0x986a43 : 0x70787a;
    const edgeColor = STAGE === 1 ? 0x6c452e : 0x474e53;
    const xCenters = [0, 9.5, 18, 26.5, 35, 43.5, 52, 61.5];
    const elevations = STAGE === 1 ? [0, 0, .45, .15, .75, .20, .45, 0] : [0, .35, .10, .75, .25, .85, .45, 0];
    const padWidths = [10, 7, 7, 7, 7, 7, 7, 9.5];
    for (let i = 0; i < xCenters.length; i++) {
        const p = { index: i, x: xCenters[i], y: arenaY + elevations[i], z: arenaZ, w: padWidths[i], type: i === 0 ? 'start' : i === 7 ? 'finish' : 'stable', down: 0, stress: 0 };
        const g = new T.Group();
        g.position.set(p.x, 0, p.z);
        const top = block(g, p.w, .55, 3.1, deckColor, 0, p.y - .29, 0);
        for (const side of [-1, 1]) {
            block(g, p.w, .12, .28, edgeColor, 0, p.y - .02, side * 1.4);
            if (i !== 7)
                block(g, .28, .52, .28, edgeColor, side * (p.w / 2 - .2), p.y - .06, 0);
        }
        for (let d = -1; d <= 1; d++) {
            const nail = block(g, .10, .025, .10, 0xd8b987, d * (p.w / 3), p.y + .01, .75);
            nail.rotation.y = .15;
        }
        p.group = g;
        p.deck = top;
        p.wx = p.w / 2;
        p.wz = 1.5;
        pads.push(p);
        arena.add(g);
        if (i > 0 && i < 7) {
            const mark = new T.Mesh(new T.PlaneGeometry(1.25, .31), new T.MeshBasicMaterial({ map: sign(i % 2 ? 'SALTE' : 'CAIXAS', i % 2 ? '#506c48' : '#745234'), side: T.DoubleSide }));
            mark.position.set(-p.w / 2 + .95, p.y + 2, arenaZ - 1.55);
            arena.add(mark);
        }
    }
    // Toca subterrânea: paredes de terra, raízes e cristais ao fundo.
    const farWall = block(arena, 88, 13, .45, 0x5b463c, 28, arenaY + 4.4, arenaZ - 12);
    const shadowWall = new T.Mesh(new T.PlaneGeometry(86, 11), new T.MeshBasicMaterial({ color: 0x211612, transparent: true, opacity: .28, side: T.DoubleSide }));
    shadowWall.position.set(28, arenaY + 4.7, arenaZ - 11.7);
    arena.add(shadowWall);
    block(arena, 90, 1.2, 16, 0x3a2a22, 28, arenaY + 10.2, arenaZ - 2.8);
    block(arena, 90, 1.8, 7.8, 0x6a5548, 28, arenaY - 3.0, arenaZ - 2.2);
    block(arena, 2.2, 12, 12, 0x60473d, -8, arenaY + 4.6, arenaZ - 2.1);
    block(arena, 2.2, 12, 12, 0x60473d, 70, arenaY + 4.6, arenaZ - 2.1);
    for (let i = 0; i < 18; i++) {
        const x = -4 + i * 4.35, z = arenaZ - 8.2 - (i % 3) * 1.25;
        const crystal = new T.Mesh(new T.OctahedronGeometry(.36 + (i % 3) * .08, 0), new T.MeshLambertMaterial({ color: i % 2 ? 0x77dfff : 0xffcf6a, emissive: i % 2 ? 0x2a6f88 : 0x8a5b12, emissiveIntensity: .28 }));
        crystal.position.set(x, arenaY - 1.2 + (i % 2) * .22, z);
        crystal.scale.set(.9, 1.5, .9);
        arena.add(crystal);
    }
    for (let i = 0; i < 14; i++) {
        const root = new T.Mesh(new T.CylinderGeometry(.09, .12, 2.2, 5), mat(0x5b3d2d));
        root.position.set(-2 + i * 4.9, arenaY + 8.6 - (i % 2) * .25, arenaZ - 7.2 - (i % 4) * .75);
        root.rotation.z = .45 - ((i % 3) * .22);
        arena.add(root);
    }
    for (let i = 0; i < 6; i++) {
        block(arena, .14, 2.2, .14, 0x7f624f, 3 + i * 10.6, arenaY + 1.9, arenaZ - 9.8);
        const lamp = new T.Mesh(new T.OctahedronGeometry(.16, 0), new T.MeshLambertMaterial({ color: 0xffd78d, emissive: 0xa56a15, emissiveIntensity: .42 }));
        lamp.position.set(3 + i * 10.6, arenaY + 3.15, arenaZ - 9.8);
        arena.add(lamp);
    }
    // Cenouras em arcos modestos: seguir pulando é mais interessante que pegar tudo automaticamente.
    const carrotLayout = STAGE === 1 ? [[-.5, 1.7], [6.9, 1.3], [10.1, 2.6], [15.8, 1.4], [19.2, 2.6], [24.6, 2.5], [29, 1.3], [35.2, 2.9], [39.6, 2.4], [45.5, 1.5], [52, 2.8], [58, 1.7], [63, 1.7]]
        : [[-.5, 1.7], [7.1, 2.0], [10.9, 2.8], [17.5, 1.6], [20.7, 2.7], [26.8, 3.1], [34.8, 2.4], [37.9, 3.3], [45.4, 1.7], [50.7, 2.7], [58.1, 2], [63, 1.7]];
    for (let i = 0; i < carrotLayout.length; i++) {
        const [x, rise] = carrotLayout[i];
        const ground = pads.find(p => Math.abs(p.x - x) < p.w / 2)?.y || arenaY;
        const g = new T.Group();
        g.position.set(x, ground + rise, arenaZ);
        const root = new T.Mesh(new T.OctahedronGeometry(.28, 0), mat(0xffa12d));
        root.scale.set(.73, 1.25, .72);
        g.add(root);
        block(g, .09, .24, .1, 0x4ca54d, 0, .42, 0);
        arena.add(g);
        tokens.push({ mesh: g, x, y: ground + rise, found: false });
    }
    // Caixas simples, caixas de cenouras e uma caixa de impulso; nenhuma explosiva.
    const boxLayout = STAGE === 1 ? [[2, 'normal'], [11.1, 'carrot'], [19, 'normal'], [28.1, 'bounce'], [35.3, 'normal'], [45, 'carrot'], [52.1, 'normal'], [61, 'normal']]
        : [[2, 'normal'], [10.2, 'carrot'], [18.6, 'bounce'], [26.3, 'normal'], [36, 'normal'], [43.4, 'carrot'], [53, 'bounce'], [61, 'normal']];
    for (const [x, type] of boxLayout) {
        const pad = pads.find(p => Math.abs(p.x - x) < p.w / 2);
        if (!pad)
            continue;
        const y = pad.y + .65;
        const b = new T.Group();
        b.position.set(x, y, arenaZ);
        block(b, 1.16, 1.18, 1.12, type === 'carrot' ? 0xd68c33 : type === 'bounce' ? 0x9cbb69 : 0xa67342, 0, 0, 0);
        for (const side of [-1, 1]) {
            block(b, 1.22, .12, 1.22, 0xf3d3a1, 0, side * .53, 0);
            block(b, .12, 1.05, .14, 0xe6c092, side * .52, 0, .58);
        }
        const label = type === 'carrot' ? '?' : type === 'bounce' ? '↑' : '▣';
        const texture = sign(label, type === 'carrot' ? '#ae631f' : type === 'bounce' ? '#4e7938' : '#7a512e');
        const face = new T.Mesh(new T.PlaneGeometry(.67, .54), new T.MeshBasicMaterial({ map: texture, side: T.DoubleSide }));
        face.position.z = .59;
        b.add(face);
        arena.add(b);
        bonusBoxes.push({ mesh: b, x, y, top: pad.y + 1.24, type, broken: false, pad });
    }
    const entrance = new T.Group();
    entrance.position.set(-3.4, arenaY, arenaZ - 1.05);
    const startMound = new T.Mesh(new T.SphereGeometry(1.75, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(0x84624a));
    startMound.position.set(0, .22, 0);
    startMound.scale.set(1.1, .75, .9);
    entrance.add(startMound);
    const startRim = new T.Mesh(new T.TorusGeometry(.78, .12, 6, 18), mat(0x9a7648));
    startRim.position.set(0, .48, .05);
    startRim.rotation.x = Math.PI / 2;
    entrance.add(startRim);
    const startHole = new T.Mesh(new T.CylinderGeometry(.74, .88, 1.18, 14, 1, true), new T.MeshBasicMaterial({ color: 0x090705, side: T.DoubleSide }));
    startHole.position.set(0, .48, .05);
    startHole.rotation.x = Math.PI / 2;
    entrance.add(startHole);
    arena.add(entrance);
    const exit = new T.Group();
    exit.position.set(64, arenaY, arenaZ);
    for (const side of [-1, 1])
        block(exit, .34, 2.6, .42, 0x84572f, side * .99, 1.3, 0);
    block(exit, 2.35, .44, .5, 0xba884e, 0, 2.65, 0);
    const flag = new T.Mesh(new T.PlaneGeometry(1.9, .65), new T.MeshBasicMaterial({ map: sign('SAÍDA', '#2e7844'), side: T.DoubleSide }));
    flag.position.set(0, 2.67, .29);
    exit.add(flag);
    arena.add(exit);
    const backdrop = block(arena, 90, .40, 22, STAGE === 1 ? 0x4f7055 : 0x475e61, 28, arenaY - 9, arenaZ - 3);
    arena.visible = false;
    S.add(arena);
    const el = document.createElement('div');
    el.style.cssText = 'position:fixed;bottom:14%;left:50%;transform:translateX(-50%);padding:9px 16px;border:2px solid #ebd69e;border-radius:8px;background:#1b271ddd;color:#fff3cc;z-index:12;font:800 14px system-ui;text-align:center;max-width:94vw;pointer-events:none;display:none;text-shadow:0 1px 2px #000';
    document.body.append(el);
    const counter = document.createElement('div');
    counter.style.cssText = 'position:fixed;top:48px;right:13px;color:#ffe5a0;background:#273c34bc;padding:6px 10px;border-radius:10px;font:800 13px system-ui;z-index:2;pointer-events:none';
    counter.textContent = '✨ Segredos 0/3';
    document.body.append(counter);
    const bonus = { active: false, used: false, saved: null, score: 0, crates: 0, failures: 0, lastPad: -1, springCooldown: 0, messageTime: 0, medal: null, transition: null, rewardCard: 0 };
    const bonusStatus = document.createElement('div');
    bonusStatus.style.cssText = 'position:fixed;left:50%;top:9%;transform:translateX(-50%);padding:9px 15px;background:#192c23e5;border:2px solid #ffe08b;border-radius:9px;z-index:15;color:#ffecba;font:800 13px system-ui;text-align:center;display:none;max-width:94vw;pointer-events:none';
    document.body.append(bonusStatus);
    const bonusOverlay = document.createElement('div');
    bonusOverlay.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;flex-direction:column;gap:10px;z-index:1002;background:radial-gradient(circle at center, rgba(255,229,150,.10) 0%, rgba(30,18,10,.82) 36%, rgba(7,6,4,.96) 100%);color:#ffe6a6;text-align:center;font-family:system-ui,sans-serif;pointer-events:none';
    const bonusOverlayTitle = document.createElement('div');
    bonusOverlayTitle.style.cssText = 'font-size:clamp(24px,5vw,40px);font-weight:900;letter-spacing:4px;text-shadow:0 4px 0 #503415';
    const bonusOverlaySub = document.createElement('div');
    bonusOverlaySub.style.cssText = 'font-size:14px;max-width:560px;line-height:1.5;padding:0 20px;color:#fff5cf;font-weight:700';
    bonusOverlay.append(bonusOverlayTitle, bonusOverlaySub);
    document.body.append(bonusOverlay);
    const setBonusOverlay = (title = '', sub = '') => {
        bonusOverlay.style.display = title ? 'flex' : 'none';
        bonusOverlayTitle.textContent = title;
        bonusOverlaySub.textContent = sub;
    };
    const wipeBonus = () => {
        bonus.score = 0;
        bonus.crates = 0;
        bonus.springCooldown = 0;
        bonus.lastPad = -1;
        tokens.forEach(c => { c.found = false; c.mesh.visible = true; });
        bonusBoxes.forEach(b => { b.broken = false; b.mesh.visible = true; });
        Object.assign(st, { x: -3.3, y: arenaY, z: arenaZ, vy: 0, mx: 0, mz: 0, g: true, runJump: false });
        jumpHeld = false;
        keys.Space = 0;
        spin = 0;
    };
    const beginBonusRun = () => {
        bonus.active = true;
        bonus.failures = 0;
        bonus.medal = null;
        arena.visible = true;
        wipeBonus();
        C.position.set(1, arenaY + 5, arenaZ + 18);
        C.lookAt(4, arenaY + 1.6, arenaZ);
        cameraRails.reset();
        el.style.display = 'block';
        el.textContent = 'TOCA BÔNUS · ESPAÇO: PULAR · SHIFT/J: GIRAR · K/CTRL: CORRER · E: VOLTAR';
        bonusStatus.style.display = 'block';
        setBonusOverlay();
        snd(540, .15, 'sine', 850, .05);
    };
    const exitBonus = (success) => {
        if (!bonus.active)
            return;
        bonus.active = false;
        arena.visible = false;
        bonusStatus.style.display = 'none';
        if (success) {
            const baseReward = bonus.score;
            const crateBonus = bonus.crates * 2;
            const perfectBonus = bonus.crates >= bonusBoxes.length ? 25 : 0;
            const reward = baseReward + crateBonus + perfectBonus;
            bonus.used = true;
            addFr(reward);
            hud();
            snd(750, .3, 'sine', 1200, .10);
            el.innerHTML = `TOCA CONCLUÍDA!<br>🥕 ${baseReward} + 📦 ${crateBonus}${perfectBonus ? ` + ⭐ ${perfectBonus}` : ''} = <b>${reward}</b>`;
            el.style.display = 'block';
            bonus.messageTime = 4.4;
            bonus.rewardCard = 2.8;
            setBonusOverlay('RECOMPENSA DA TOCA', `Cenouras: ${baseReward} · Bônus das caixas: ${crateBonus}${perfectBonus ? ` · Perfeito: ${perfectBonus}` : ''} · Total: ${reward}`);
        }
        else {
            el.textContent = 'SAÍDA DA TOCA · Você pode entrar novamente.';
            el.style.display = 'block';
            bonus.messageTime = 2.5;
        }
        if (bonus.saved) {
            Object.assign(st, bonus.saved);
            for (let i = 0; i < 10; i++)
                fx({ x: st.x + (Math.random() - .5) * .8, y: st.y + 1.1 + Math.random() * .6, z: st.z + (Math.random() - .5) * .8 }, 0xffd869, 18, 4);
            bonus.saved = null;
        }
        st.mx = st.mz = st.vy = 0;
        st.g = true;
        st.runJump = false;
        jumpHeld = false;
        keys.Space = 0;
        spin = 0;
        cameraRails.reset();
    };
    const enterBonus = () => {
        if (bonus.active || bonus.used || bonus.transition || !run || dy || cs || cv)
            return false;
        if (Math.hypot(st.x - spot.x, st.z - spot.z) > 2.3)
            return false;
        bonus.saved = { ...st };
        bonus.transition = { time: 0, fx: 0 };
        setBonusOverlay('ENTRANDO NA TOCA...', 'Bunnyck está descendo para o subsolo.');
        snd(420, .10, 'sine', 180, .12);
        return true;
    };
    addEventListener('keydown', e => { if (e.code === 'KeyE' && !e.repeat) {
        if (bonus.transition) {
            e.preventDefault();
            return;
        }
        if (bonus.active)
            exitBonus(false);
        else
            enterBonus();
    } });
    function update(t, dt) {
        crates.update(t, dt);
        if (bonus.transition) {
            const tr = bonus.transition;
            tr.time += dt;
            st.mx = st.mz = st.vy = 0;
            jumpHeld = false;
            keys.Space = 0;
            st.x += (spot.x - st.x) * Math.min(1, dt * 9);
            st.z += (spot.z - st.z) * Math.min(1, dt * 9);
            const holeY = gh(spot.x, spot.z);
            const p = Math.min(1, tr.time / 1.1);
            st.y = holeY - Math.max(0, (p - .28) / .72) * 1.45;
            C.position.lerp(new T.Vector3(spot.x + 1.25, holeY + 2.2, spot.z + 3.8), Math.min(1, dt * 5));
            C.lookAt(spot.x, holeY + .25, spot.z);
            setBonusOverlay('ENTRANDO NA TOCA...', 'Bunnyck está descendo para o subsolo.');
            if (t - tr.fx > .06) {
                tr.fx = t;
                fx({ x: spot.x + (Math.random() - .5) * .45, y: holeY + .22, z: spot.z + (Math.random() - .5) * .45 }, 0xffe08a, 4, 1.5);
            }
            if (p >= 1) {
                bonus.transition = null;
                beginBonusRun();
            }
            return;
        }
        if (bonus.rewardCard > 0) {
            bonus.rewardCard -= dt;
            if (bonus.rewardCard <= 0 && !bonus.active)
                setBonusOverlay();
        }
        for (const a of secretItems) {
            if (a.collected)
                continue;
            const p = a.g;
            p.rotation.y += dt * 1.8;
            p.position.y = a.y + Math.sin(t * 2 + a.phase) * .22;
            a.ring.rotation.z += dt * .8;
            if (run && !dy && !cs && !cv && !bonus.active && Math.hypot(st.x - p.position.x, st.z - p.position.z) < 1 && Math.abs(st.y - p.position.y) < 1.9) {
                a.collected = true;
                p.visible = false;
                addFr(25);
                hud();
                snd(900, .25, 'sine', 1500, .10);
                fx(p.position, 0xffe652, 17, 4);
                counter.textContent = `✨ Segredos ${secretItems.filter(o => o.collected).length}/3`;
            }
        }
        glow.rotation.z = t * .85;
        glow.scale.setScalar(1 + Math.sin(t * 4) * .10);
        if (bonus.active) {
            tokens.forEach((c, i) => { if (c.found)
                return; c.mesh.rotation.y += dt * 1.4; c.mesh.position.y = c.y + Math.sin(t * 2 + i) * .09; });
            bonusStatus.textContent = `TOCA BÔNUS ${STAGE === 1 ? 'DO BOSQUE' : 'DOS PINHEIROS'} · 🥕 ${bonus.score} · 📦 ${bonus.crates}/${bonusBoxes.length} · sem tempo limite`;
            el.textContent = 'TOCA BÔNUS · ESPAÇO: PULAR · SHIFT/J: GIRAR · E: VOLTAR';
            el.style.display = 'block';
        }
        else if (bonus.messageTime > 0) {
            bonus.messageTime -= dt;
            if (bonus.messageTime <= 0)
                el.style.display = 'none';
        }
        else if (!bonus.used && run && !cs && !cv && !dy && Math.hypot(st.x - spot.x, st.z - spot.z) < 3.15) {
            el.textContent = 'TOCA BÔNUS · PRESSIONE E';
            el.style.display = 'block';
        }
        else
            el.style.display = 'none';
    }
    const breakBonusBox = b => {
        if (b.broken || b.type === 'bounce')
            return;
        b.broken = true;
        b.mesh.visible = false;
        bonus.crates++;
        const reward = b.type === 'carrot' ? 5 : 2;
        bonus.score += reward;
        snd(245, .12, 'square', 450, .05);
        for (let i = 0; i < 3; i++)
            fx({ x: b.x, y: b.y, z: arenaZ }, 0xe6b070, 2, 1);
    };
    function bonusStep(dt, t) {
        if (!bonus.active)
            return;
        bonus.springCooldown = Math.max(0, bonus.springCooldown - dt);
        const left = !!(keys.ArrowLeft || keys.KeyA), right = !!(keys.ArrowRight || keys.KeyD);
        const axis = (right ? 1 : 0) - (left ? 1 : 0);
        const speed = (keys.KeyK || keys.ControlLeft || keys.ControlRight) ? 9.2 : 6.5;
        const oldX = st.x, oldY = st.y;
        st.mx += (axis * speed - st.mx) * Math.min(1, dt * 15);
        st.x = Math.max(-4, Math.min(65.2, st.x + st.mx * dt));
        st.z = arenaZ;
        st.mz = 0;
        sprinting = !!(axis && (keys.KeyK || keys.ControlLeft || keys.ControlRight));
        mv = axis ? 1 : 0;
        coy = st.g ? .12 : coy - dt;
        if (keys.Space && !jumpHeld && coy > 0) {
            st.vy = 11.4;
            st.g = false;
            coy = 0;
            jumpHeld = true;
            snd(440, .12, 'square', 710, .04);
        }
        st.vy -= 25 * dt;
        st.y += st.vy * dt;
        let standing = null;
        if (st.vy <= 0)
            for (const p of pads) {
                if (st.x > p.x - p.w / 2 + .13 && st.x < p.x + p.w / 2 - .13 && st.y <= p.y + .20 && oldY >= p.y - .28) {
                    standing = p;
                    break;
                }
            }
        // Caixas funcionam como obstáculo, dão impulso por cima e podem ser quebradas com giro.
        for (const b of bonusBoxes) {
            if (b.broken)
                continue;
            if (spin > 0 && Math.abs(st.x - b.x) < 1.35 && Math.abs(st.y - b.y) < 1.5) {
                if (b.type === 'bounce') {
                    if (bonus.springCooldown <= 0) {
                        st.vy = 13.5;
                        st.g = false;
                        standing = null;
                        bonus.springCooldown = .55;
                        snd(700, .2, 'sine', 1080, .08);
                    }
                }
                else
                    breakBonusBox(b);
                continue;
            }
            if (st.vy <= 0 && oldY >= b.top - .18 && st.y <= b.top + .15 && Math.abs(st.x - b.x) < .65) {
                st.y = b.top;
                st.vy = b.type === 'bounce' ? 13.5 : 9.8;
                st.g = false;
                standing = null;
                if (b.type === 'bounce') {
                    if (bonus.springCooldown > .0)
                        st.vy = 9.8;
                    bonus.springCooldown = .65;
                }
                else
                    breakBonusBox(b);
                snd(480, .11, 'square', 690, .06);
            }
            else if (st.y < b.top - .25 && st.y > b.pad.y - .20 && Math.abs(st.x - b.x) < .95) {
                st.x = oldX;
                st.mx = 0;
            }
        }
        if (standing) {
            st.y = standing.y;
            st.vy = 0;
            st.g = true;
            bonus.lastPad = standing.index;
        }
        else {
            st.g = false;
            bonus.lastPad = -1;
        }
        if (st.y < arenaY - 7) {
            bonus.failures++;
            wipeBonus();
            el.textContent = 'TENTE NOVAMENTE! NENHUMA VIDA PERDIDA.';
            bonus.messageTime = .9;
            snd(180, .15, 'triangle', 110, .05);
            return;
        }
        for (const c of tokens) {
            if (c.found)
                continue;
            if (Math.abs(st.x - c.x) < .75 && Math.abs(st.y + 1.1 - c.mesh.position.y) < 1.25) {
                c.found = true;
                c.mesh.visible = false;
                bonus.score++;
                snd(870, .07, 'sine', 1200, .04);
            }
        }
        if (st.x >= 63.6 && st.y >= arenaY - .3) {
            exitBonus(true);
            return;
        }
    }
    function bonusCamera(dt) {
        if (!bonus.active)
            return;
        const follow = Math.max(1, Math.min(58, st.x + 2.4));
        const dest = new T.Vector3(follow, arenaY + 5.2, arenaZ + 18);
        C.position.lerp(dest, Math.min(1, dt * 8));
        C.fov += (55 - C.fov) * Math.min(1, dt * 5);
        C.updateProjectionMatrix();
        C.lookAt(follow + 1, arenaY + 1.75, arenaZ);
    }
    function reset() {
        setBonusOverlay();
        crates.reset();
        bonus.active = false;
        bonus.used = false;
        bonus.saved = null;
        bonus.messageTime = 0;
        bonus.medal = null;
        bonus.transition = null;
        bonus.rewardCard = 0;
        arena.visible = false;
        el.style.display = 'none';
        bonusStatus.style.display = 'none';
        tokens.forEach(c => { c.found = false; c.mesh.visible = true; });
        bonusBoxes.forEach(b => { b.broken = false; b.mesh.visible = true; });
        for (const a of secretItems) {
            a.collected = false;
            a.g.visible = true;
            a.g.position.y = a.y;
        }
        counter.textContent = '✨ Segredos 0/3';
    }
    return { crates, bonus: { get active() { return bonus.active || !!bonus.transition; }, get used() { return bonus.used; }, get medal() { return null; },
            get platforms() { return pads.map(p => ({ index: p.index, type: p.type, x: p.x, z: p.z, y: p.y, down: 0, stress: 0 })); },
            get boxes() { return bonusBoxes.map(b => ({ x: b.x, type: b.type, broken: b.broken })); },
            tryEnter: enterBonus, debugEnter: () => { if (!run || dy || cs || cv)
                return false; st.x = spot.x; st.z = spot.z; st.y = gh(st.x, st.z); return enterBonus(); }, update: bonusStep, camera: bonusCamera, leave: exitBonus },
        update, reset, stats: { crates: boxes.length, secrets: secretItems.length, bonusTokens: tokens.length, platforms: pads.length, specialPads: 0 } };
})();
// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
// ---- Bunnyck
const P = new T.Group(), body = new T.Group();
P.add(body);
body.rotation.y = Math.PI;
S.add(P);
const bun = new T.Group();
bun.scale.setScalar(.8);
body.add(bun);
const bx = (w, h, d, c, x, y, z, rz, par) => { const m = mesh(B(w, h, d), c, [x, y, z]); if (rz)
    m.rotation.z = rz; (par || bun).add(m); return m; };
const PU = 0x7a2fe0, PD2 = 0x4f1fa8, WH = 0xf4f4f8, BK = 0x1a1a22, PK = 0xff7aa8;
const mk = (x, y, z) => { const g = new T.Group(); g.position.set(x, y, z); bun.add(g); return g; }, legs = [], arms = [], ears = [];
for (const s of [-1, 1]) {
    const lg = mk(s * .22, .78, 0);
    bx(.42, .12, .64, BK, 0, -.72, .08, 0, lg);
    bx(.4, .2, .58, WH, 0, -.56, .08, 0, lg);
    bx(.3, .45, .3, PD2, 0, -.23, 0, 0, lg);
    legs.push(lg);
    const am = mk(s * .47, 1.28, 0);
    bx(.2, .4, .24, BK, 0, -.23, 0, 0, am);
    bx(.26, .26, .26, WH, s * .07, -.52, .04, 0, am);
    arms.push(am);
    const ear = mk(s * .26, 2.15, 0);
    ear.rotation.z = -s * .1;
    bx(.26, .85, .16, PU, 0, .43, 0, 0, ear);
    bx(.13, .62, .04, PK, 0, .41, .09, 0, ear);
    ears.push(ear);
    bx(.15, .22, .03, BK, s * .2, 1.76, .465);
    bx(.06, .07, .03, WH, s * .2 + .02, 1.82, .485);
    bx(.1, .06, .03, PK, s * .31, 1.58, .465);
}
bx(.74, .62, .44, BK, 0, 1.02, 0);
bx(.26, .6, .02, WH, 0, 1.02, .23);
bx(.7, .18, .42, PD2, 0, .68, 0);
bx(.98, .88, .88, PU, 0, 1.78, 0);
bx(.74, .52, .04, WH, 0, 1.68, .44);
bx(.12, .09, .06, PK, 0, 1.62, .47);
bx(.16, .03, .03, BK, 0, 1.52, .46);
const tail = mk(0, .78, -.3);
bx(.22, .22, .22, WH, 0, 0, 0, 0, tail);
const swoosh = new T.Mesh(new T.RingGeometry(1, 1.7, 28), new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .45, side: T.DoubleSide }));
swoosh.rotation.x = -Math.PI / 2;
swoosh.visible = false;
S.add(swoosh);
// ---- fx / audio
const parts = [];
let shake = 0, AC, mv = 0;
function snd(f, d, ty, sl, gv) { try {
    if ((window.parent?.BunnyHavocSettings?.get?.()?.sfx ?? 1) <= 0)
        return;
    AC = AC || new AudioContext();
    const o = AC.createOscillator(), g = AC.createGain(), n = AC.currentTime;
    o.type = ty || 'square';
    o.frequency.setValueAtTime(f, n);
    o.frequency.exponentialRampToValueAtTime(sl || f * 1.6, n + d);
    g.gain.setValueAtTime((gv || .12) * (window.parent?.BunnyHavocSettings?.get?.()?.sfx ?? 1), n);
    g.gain.exponentialRampToValueAtTime(.001, n + d);
    o.connect(g);
    g.connect(AC.destination);
    o.start();
    o.stop(n + d);
}
catch (e) { } }
function fx(p, c, n, sp) { for (let i = 0; i < n; i++) {
    const m = mesh(B(.15, .15, .15), c, [p.x, p.y + .5, p.z]);
    m.userData = { v: new T.Vector3((Math.random() - .5) * (sp || 5), Math.random() * 5 + 2, (Math.random() - .5) * (sp || 5)), l: .8 };
    S.add(m);
    parts.push(m);
} }
const dizzy = new T.Group();
for (let k = 0; k < 3; k++)
    dizzy.add(mesh(B(.22, .22, .22), 0xffe14a, [Math.cos(k * 2.1) * .7, 0, Math.sin(k * 2.1) * .7]));
dizzy.visible = false;
S.add(dizzy);
const LINES = ['Bibibunn não vai fugir pra sempre...', 'Essa selva de pinheiros é enorme!', 'Tem riachos, ursos e peixes por toda parte...', 'Tenho que alcançar a Bibibunn!', 'Bunnyldu, aguenta firme!'], dlg = $('dlg'), dv = new T.Vector3();
const addFr = n => { const o = fr; fr += n; if (Math.floor(fr / 100) > Math.floor(o / 100)) {
    lives++;
    snd(600, .4, 'square', 1600);
} }, boom = b => secretSystems.crates.hit(b);
const squish = e => { e.visible = false; fr += 3; hud(); fx(e.position, 0xd23a2a, 10); snd(500, .15, 'square', 900); };
// ---- state
let st, fr = 0, lives = 3, broken = 0, run = false, keys = {}, spin = 0, coy = 0, dy = null, cp = 8, bump = 0, dl = null, lastLine = -1, sprinting = false, jumpHeld = false, cs = null, ended = 0;
// Fonte compartilhada pelas duas fases. Vida da tentativa e combo inicial.
const playerCombat = (() => {
    const durations = [.30, .26, .32], names = ['Giro', 'Soco', 'Soco final'];
    let health = 3, immunity = 0, stagger = 0, step = 0, age = 0, queued = 0, grace = 0, heading = Math.PI, serial = 0;
    let struck = new WeakSet(), previousAge = 0, impact = 0, cachedShape = null, shapeKey = '';
    let poseOwned = false, hitStop = 0, impactUsed = false, travelled = 0;
    const reachByStep = [0, 1.0, 1.30], stepDistance = [0, .22, .28];
    // Conjunto fixo de efeitos. Os socos usam duas partes curtas do braço e uma
    // esteira de movimento, sem o braço-mola comprido das versões anteriores.
    const cartoon = new T.Group(), punch = new T.Group(), glove = new T.Group(), sleeve = [], burst = new T.Group(), ribbons = new T.Group(), streaks = [];
    cartoon.name = 'BunnyckComboEffects';cartoon.visible=false;S.add(cartoon);cartoon.add(punch,ribbons);punch.add(glove,burst);
    const armMaterial = new T.MeshLambertMaterial({color:BK}), gloveMaterial = new T.MeshLambertMaterial({color:WH}), cuffMaterial = new T.MeshLambertMaterial({color:PD2});
    const cube = new T.BoxGeometry(1,1,1);
    function piece(parent,size,material,pos){const m=new T.Mesh(cube,material);m.scale.set(...size);m.position.set(...pos);parent.add(m);return m;}
    for(let i=0;i<2;i++)sleeve.push(piece(punch,[.19,.20,1],armMaterial,[0,0,0]));
    piece(glove,[.67,.59,.65],gloveMaterial,[0,0,0]);
    for(let i=0;i<3;i++)piece(glove,[.22,.24,.22],gloveMaterial,[-.23+i*.23,.16,.33]);
    piece(glove,[.26,.32,.34],gloveMaterial,[.37,-.13,-.02]);
    piece(glove,[.43,.40,.18],cuffMaterial,[0,-.02,-.37]);
    const effectMaterial=(color,opacity)=>new T.MeshBasicMaterial({color,transparent:true,opacity,side:T.DoubleSide,depthWrite:false});
    const white=effectMaterial(0xf4f4ff,.75),purple=effectMaterial(0x933dff,.80),pink=effectMaterial(0xff80c8,.75),golden=effectMaterial(0xffdf70,.9);
    for(let i=0;i<3;i++){
        const ring=new T.Mesh(new T.RingGeometry(1.10+i*.06,1.20+i*.06,24,1,i*.9,Math.PI*1.45),i===1?purple:white);
        ring.position.y=.48+i*.37;ring.rotation.x=-Math.PI/2+(i-1)*.12;ribbons.add(ring);
    }
    const halo=new T.Group();punch.add(halo);
    for(let i=0;i<2;i++){const ring=new T.Mesh(new T.RingGeometry(.35+i*.09,.41+i*.09,18,1,i*.7,Math.PI*1.65),i?white:purple);halo.add(ring);}
    for(let i=0;i<6;i++)streaks.push(piece(punch,[.035,.045,.65],i%2?white:purple,[0,0,0]));
    for(let i=0;i<8;i++){const angle=i*Math.PI/4,ray=piece(burst,[.055,i%2?.28:.38,.04],i%3?white:golden,[Math.sin(angle)*.49,Math.cos(angle)*.49,0]);ray.rotation.z=-angle;}
    for(let i=0;i<4;i++){const ray=piece(burst,[.07,.30,.04],pink,[Math.sin(i*Math.PI/2)*.24,Math.cos(i*Math.PI/2)*.24,.025]);ray.rotation.z=-i*Math.PI/2;}
    const startPoint=new T.Vector3(),elbow=new T.Vector3(),endPoint=new T.Vector3(),segment=new T.Vector3(),forwardAxis=new T.Vector3(0,0,1);
    for(const hint of document.querySelectorAll('#ov p'))if(hint.textContent.includes('Shift/J: giro'))hint.textContent=hint.textContent.replace('Shift/J: giro','Shift/J repetido: giro → soco → soco');
    const strip = document.createElement('div');
    strip.id = 'playerStatus'; strip.setAttribute('aria-label', 'Saúde e combo de Bunnyck');
    strip.innerHTML = '<span id="playerHearts" role="status" aria-live="polite"></span><small id="playerCombo"></small>';
    const style = document.createElement('style');
    style.textContent = '#playerStatus{position:fixed;top:62px;left:14px;z-index:6;pointer-events:none;font:800 23px monospace;text-shadow:2px 2px #25132c}#playerHearts{color:#ff5d7c;white-space:nowrap}#playerCombo{display:block;color:#ffe6a4;font:700 12px monospace;margin-top:5px}.cinematic #playerStatus{display:none}@media(max-width:550px){#playerStatus{top:53px;font-size:21px}}';
    document.head.append(style); document.body.append(strip);
    function paint() {
        const hearts = document.getElementById('playerHearts');
        hearts.textContent = '♥'.repeat(health) + '♡'.repeat(3 - health);
        hearts.setAttribute('aria-label', health + ' de 3 corações');
        document.getElementById('playerCombo').textContent = step ? step + '/3 · ' + names[step - 1] : 'J / Shift · giro → soco → soco';
    }
    function hidePunch(){cartoon.visible=false;punch.visible=false;ribbons.visible=false;arms.forEach(a=>a.visible=true);}
    function releasePose(){if(!poseOwned)return;body.scale.set(1,1,1);body.position.set(0,0,0);body.rotation.x=body.rotation.z=0;
        [...arms,...legs].forEach(a=>a.rotation.set(0,0,0));ears.forEach((e,i)=>e.rotation.set(0,0,i?-.1:.1));poseOwned=false;}
    function clearAttack() { hidePunch();releasePose();if(step)body.rotation.y=heading;step = 0; age = 0; queued = 0; grace = 0; spin = 0; previousAge=0;impact=0;hitStop=0;cachedShape=null;shapeKey='';struck = new WeakSet(); paint(); }
    function reset() { health = 3; immunity = 0; stagger = 0; clearAttack();travelled=0;P.visible = true; }
    function canAct() { return run && !dy && !cv && !cs && !window.__bhBonusTutorialOpen && stagger <= 0; }
    function begin(next) {
        hidePunch();releasePose();step = next; age = 0; previousAge=0; grace = 0; impact=0;hitStop=0;impactUsed=false;shapeKey='';struck = new WeakSet(); serial++;if(next===1)travelled=0;
        if (next === 1) heading = Math.hypot(st.mx, st.mz) > .5 ? Math.atan2(st.mx, st.mz) : body.rotation.y;
        else {
            const dx=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+Math.max(-1,Math.min(1,keys.tx||0));
            const dz=(keys.KeyS||keys.ArrowDown?1:0)-(keys.KeyW||keys.ArrowUp?1:0)+Math.max(-1,Math.min(1,keys.tz||0));
            if(Math.hypot(dx,dz)>.2)heading=Math.atan2(dx,dz);
            body.rotation.y = heading;
        }
        spin = next === 1 ? durations[0] : 0;
        snd(next === 1 ? 300 : next === 2 ? 390 : 250, next===3?.15:.11, next === 1 ? 'sawtooth' : 'triangle', next === 1 ? 900 : 120);
        paint();
    }
    function press() {
        if (!canAct()) return false;
        if (!step) { begin(1); return true; }
        if (age >= durations[step - 1]) {
            if (step < 3 && grace > 0) begin(step + 1);
            return true;
        }
        queued = Math.min(3 - step, queued + 1);
        return true;
    }
    function update(dt, active) {
        if (!active) { if (step) clearAttack(); if (!dy) P.visible = true; return; }
        immunity = Math.max(0, immunity - dt); stagger = Math.max(0, stagger - dt);
        impact = Math.max(0,impact-dt);shapeKey='';
        P.visible = immunity <= 0 || Math.floor(immunity * 18) % 2 === 0;
        if (!step) return;
        const duration = durations[step - 1];
        if (age < duration) {
            previousAge=age;
            const held=Math.min(dt,hitStop);hitStop-=held;age = Math.min(duration, age + dt-held);
            if(step>1)advanceStep(stepDistance[step-1]*(stepProgress(age/duration)-stepProgress(previousAge/duration)));
            if (step === 1) { spin = Math.max(0, duration - age); body.rotation.y = heading + age / duration * Math.PI * 2; }
            if (age >= duration) {
                spin = 0; body.rotation.y = heading;
                if (queued && step < 3) { queued--; begin(step + 1); }
                else grace = step < 3 ? .38 : .14;
            }
        } else { grace -= dt; if (grace <= 0) clearAttack(); }
    }
    function activeHit() { return step > 0 && age >= (step===1?0:durations[step-1]*(step===2?.25:.31)) && age < (step === 1 ? .26 : durations[step-1]*.84); }
    const smooth=u=>{u=Math.max(0,Math.min(1,u));return u*u*(3-2*u);};
    function stepProgress(u){return smooth((u-.22)/.36);}
    function advanceStep(distance){
        // Apenas um passo curto em chão contínuo. Nunca empurra para um buraco,
        // degrau alto, caixa ou parede e não altera a trajetória de um salto.
        if(distance<=0||!st.g||Math.abs(st.y-gh(st.x,st.z))>.18||secretSystems.bonus.active)return;
        const dx=Math.sin(heading),dz=Math.cos(heading),n=Math.ceil(distance/.035),stride=distance/n;
        for(let i=0;i<n;i++){
            const x=st.x+dx*stride,z=st.z+dz*stride;
            if(z<ZMIN||z>ZMAX||Math.abs(x)>wp(z)-.55||pitF(x,z)>=.07||Math.abs(gh(x,z)-gh(st.x,st.z))>.18)break;
            if(walls.some(w=>w.visible&&st.y-w.userData.gy<2.6&&st.y>w.userData.gy-1&&Math.abs(x-w.position.x)<w.userData.hx+.43&&Math.abs(z-w.position.z)<w.userData.hz+.43))break;
            if(boxes.some(b=>b.visible&&Math.abs(st.y-b.userData.gy)<1.2&&Math.abs(x-b.position.x)<.97&&Math.abs(z-b.position.z)<.97))break;
            st.x=x;st.z=z;travelled+=stride;
        }
    }
    function extension(u){
        const wind=step===3?.25:.18;
        if(u<wind)return 0;
        if(u<.52){const t=(u-wind)/(.52-wind);return 1-Math.pow(1-t,3);}
        if(u<.64)return 1;
        return 1-smooth((u-.64)/.36);
    }
    function clearReach(maximum){
        const dx=Math.sin(heading),dz=Math.cos(heading),height=st.y+1.05;
        let limit=maximum;
        for(const wall of walls){
            const d=wall.userData;if(!wall.visible||height<d.gy||height>d.gy+2.7)continue;
            let near=0,far=limit;
            for(const [origin,direction,center,half] of [[st.x,dx,wall.position.x,d.hx+.58],[st.z,dz,wall.position.z,d.hz+.58]]){
                if(Math.abs(direction)<1e-6){if(Math.abs(origin-center)>half){far=-1;break;}}
                else{let a=(center-half-origin)/direction,b=(center+half-origin)/direction;if(a>b)[a,b]=[b,a];near=Math.max(near,a);far=Math.min(far,b);}
            }
            if(far>=near)limit=Math.min(limit,Math.max(0,near));
        }
        // O braço pode passar sobre buracos, mas para nas paredes e no terreno alto.
        for(let d=.4;d<limit;d+=.25){const x=st.x+dx*d,z=st.z+dz*d;
            if(Math.abs(x)>wp(z)-.15||(pitF(x,z)<.12&&gh(x,z)>height-.22)){limit=Math.max(0,d-.25);break;}
        }
        return limit;
    }
    function strikeShape(){
        if(step<2||age>=durations[step-1])return null;
        const key=[st.x,st.y,st.z,step,age,previousAge,heading].join(':');
        if(shapeKey===key)return cachedShape;
        const amount=extension(age/durations[step-1]),prior=extension(previousAge/durations[step-1]);
        const limit=clearReach(.60+reachByStep[step-1]),reach=Math.min(limit,.60+reachByStep[step-1]*amount);
        cachedShape={reach,sweep:Math.min(limit,Math.max(reach,.60+reachByStep[step-1]*prior)),limit,amount,width:step===2?.66:.82,side:step===2?1:-1};shapeKey=key;
        return cachedShape;
    }
    function canHit(target, radius) {
        if (!activeHit() || struck.has(target)) return false;
        const dx = target.position.x - st.x, dz = target.position.z - st.z, distance = Math.hypot(dx, dz);
        if(step===1)return distance<=radius;
        const shape=strikeShape();if(!shape)return false;
        const along=dx*Math.sin(heading)+dz*Math.cos(heading),across=dx*Math.cos(heading)-dz*Math.sin(heading);
        return along>=-.15&&along<=shape.sweep+.40&&along<=shape.limit+.40&&Math.abs(across)<=shape.width;
    }
    function claim(target) { struck.add(target);if(step>1){impact=step===3?.12:.08;if(!impactUsed){hitStop=step===3?.032:.012;impactUsed=true;snd(step===3?170:240,.07,'triangle',90,.045);}} }
    function strikeFor(target) { const finisher=step===3&&activeHit()&&struck.has(target);return {damage:finisher?2:1,finisher,opening:step>0&&step<3&&activeHit()&&struck.has(target),heading}; }
    function damage(kind, source, amount = 1) {
        if (!run || dy || cs || cv || (kind !== 'pit' && immunity > 0)) return false;
        const loss = Number.isFinite(amount) ? Math.max(1, Math.floor(amount)) : 1;
        health = kind === 'pit' ? 0 : Math.max(0, health - loss); clearAttack(); paint();
        if (health === 0) return true;
        immunity = 1.25; stagger = .22; shake = .18;
        snd(180, .14, 'square', 100); fx(st, 0xffb1bf, 7, 3);
        // Reação curta, sem reposicionar Bunnyck ou disputar o salto atual.
        st.mx *= -.25; st.mz *= -.25;
        return false;
    }
    function pose(t) {
        hidePunch();
        if (dy || cs || cv || !run) return;
        if(!step||age>=durations[step-1]){releasePose();return;}
        poseOwned=true;cartoon.visible=P.visible;cartoon.position.set(st.x,st.y,st.z);cartoon.rotation.set(0,heading,0);
        const u=age/durations[step-1],wave=Math.sin(u*Math.PI);
        if(step===1){
            ribbons.visible=true;ribbons.rotation.y=u*Math.PI*2;swoosh.visible=false;
            body.rotation.y=heading+u*Math.PI*2;body.rotation.x=.10*wave;body.rotation.z=Math.sin(u*Math.PI*2)*.10;
            body.position.y=.07*wave;body.scale.set(1+.04*wave,1-.07*wave,1+.04*wave);
            arms.forEach((a,i)=>{a.rotation.set(-.25,0,(i?1:-1)*1.30);});
            legs.forEach((l,i)=>l.rotation.set((i?-.40:.52)*wave,0,(i?.18:-.18)*wave));
            ears.forEach((e,i)=>{e.rotation.x=-.18*wave;e.rotation.z=(i?-.1:.1)+Math.sin(u*Math.PI*2+(i?1:0))*.12;});
        }else{
            const shape=strikeShape(),drive=shape.amount,side=shape.side,arm=step===2?1:0,load=Math.sin(Math.min(1,u/(step===3?.25:.18))*Math.PI)*(1-drive),force=step===3?1:.75;
            punch.visible=shape.limit>.23;arms[arm].visible=!punch.visible;
            body.rotation.y=heading+side*(.24*load-.24*drive)*force;
            body.rotation.x=.08*load-.18*drive*force;body.rotation.z=-side*.09*drive;
            body.position.y=st.g?-.07*load+.035*drive:0;body.scale.set(1+.045*load,1-.07*load+.035*drive,1+.025*load);
            punch.position.set(0,1.02+body.position.y,0);
            arms[arm].rotation.set(-.45-drive*1.2,0,side*.06);arms[1-arm].rotation.set(-1.1-.20*load,side*.15,-side*.25);
            if(st.g){legs[arm].rotation.set(-.46*drive+.18*load,0,side*.14);legs[1-arm].rotation.set(.36*drive-.15*load,0,-side*.14);}
            ears.forEach((e,i)=>{e.rotation.x=.15*load-.28*drive;e.rotation.z=(i?-.1:.1)+side*.06*drive;});
            const size=.43+drive*(step===2?.16:.22),fistReach=Math.min(.36+drive*(step===2?.62:.79),Math.max(.02,shape.limit-.18));
            glove.position.set(side*(.38-.10*drive),.04*drive,fistReach);glove.scale.set(side*size*(1+.08*drive),size*(1-.08*drive),size*(1+.14*drive));glove.rotation.set(0,0,-side*.12*drive);
            startPoint.set(side*.37,0,0);elbow.set(side*(.44-.13*drive),-.12+.13*drive,fistReach*.43);endPoint.copy(glove.position);endPoint.z-=.12;
            for(let i=0;i<2;i++){const a=i?elbow:startPoint,b=i?endPoint:elbow,m=sleeve[i];segment.subVectors(b,a);m.position.copy(a).add(b).multiplyScalar(.5);m.scale.set(.19,.20,Math.max(.03,segment.length()+.04));m.quaternion.setFromUnitVectors(forwardAxis,segment.normalize());}
            halo.visible=drive>.20;halo.position.set(side*.24,.08,shape.reach);halo.rotation.z=side*(u*Math.PI*.8);halo.scale.setScalar((step===3?1.28:.82)*(.65+.35*drive));
            streaks.forEach((m,i)=>{m.visible=drive>.25;const spread=(i%2?1:-1)*(.20+Math.floor(i/2)*.13);m.position.set(spread,((i%3)-1)*.13,shape.reach*.48);m.scale.z=shape.reach*.9*drive;});
            burst.visible=impact>0;burst.position.copy(halo.position);burst.scale.setScalar(step===3?1.12:.68);burst.rotation.z=side*.18;
            if(step===3&&impact>0)shake=Math.max(shake,.18);
        }
        if (stagger > 0) body.rotation.x = -.17 * Math.sin(stagger / .22 * Math.PI);
    }
    paint();
    return {reset, press, update, pose, canHit, claim, strikeFor, damage, clearAttack,
        get attacking() { return step > 0 && age < durations[step - 1]; },
        get effects(){return cartoon;},
        get state() { const shape=strikeShape();return {health, maxHealth:3, immunity, stagger, step, age, queued, grace, serial, heading, activeHit:activeHit(),reach:shape?.reach||0,reachLimit:shape?.limit||0,punchVisible:cartoon.visible&&punch.visible,spinVisible:cartoon.visible&&ribbons.visible,travelled,hitStop}; }};
})();
window.BunnyHavocPlayer = playerCombat;

// Camada visual de dano: não desloca colisões nem altera a duração do recuo.
const enemyDamage=(()=>{
    const reacting=new Map(),cache=new WeakMap(),flashColor=new T.Color(0xfff1df);
    function rig(enemy){
        if(cache.has(enemy))return cache.get(enemy);
        const d=enemy.userData,nodes=[...new Set([d.model,d.head,d.snout,d.jaw,d.tail,d.shell,...(d.arms||[]),...(d.legs||[]),...(d.feelers||[]),...(d.brows||[])].filter(Boolean))];
        const poses=nodes.map(node=>({node,position:node.position.clone(),rotation:node.rotation.clone(),scale:node.scale.clone()})),materials=[];
        // Materiais de flash são próprios deste alvo e reutilizados nos próximos
        // acertos. Materiais compartilhados com o cenário nunca são modificados.
        d.model.traverse(node=>{if(!node.isMesh)return;const original=node.material,list=Array.isArray(original)?original:[original];
            const copies=list.map(m=>m.clone());materials.push({node,original,list,copies});});
        const result={poses,materials};cache.set(enemy,result);return result;
    }
    function restore(s){
        if(!s.applied)return;
        for(const p of s.rig.poses){p.node.position.copy(p.position);p.node.rotation.copy(p.rotation);p.node.scale.copy(p.scale);}
        for(const m of s.rig.materials)m.node.material=m.original;
        s.applied=false;
    }
    function hurt(enemy,heading,strong=false){
        const previous=reacting.get(enemy);if(previous)restore(previous);
        reacting.set(enemy,{age:0,duration:.34,heading,strong,rig:rig(enemy),applied:false});
    }
    function update(dt,active){
        for(const [enemy,s] of reacting){
            restore(s);
            if(active)s.age+=dt;
            if(!enemy.visible||s.age>=s.duration)reacting.delete(enemy);
        }
    }
    function pose(){
        for(const [enemy,s] of reacting){
            if(!enemy.visible)continue;
            restore(s);
            for(const p of s.rig.poses){p.position.copy(p.node.position);p.rotation.copy(p.node.rotation);p.scale.copy(p.node.scale);}
            const d=enemy.userData,m=d.model,t=s.age,u=Math.min(1,t/s.duration),force=s.strong?1.2:1;
            const kick=Math.exp(-t*11)*(1-u),shake=Math.sin(t*83)*Math.exp(-t*13)*(1-u),relative=s.heading-enemy.rotation.y;
            m.scale.x*=1+.14*kick*force;m.scale.y*=1-.20*kick*force;m.scale.z*=1+.09*kick*force;
            m.rotation.x+=Math.cos(relative)*.28*kick*force;m.rotation.z-=Math.sin(relative)*.25*kick*force;
            m.position.x+=shake*.045;m.position.y+=Math.sin(u*Math.PI)*.035;
            if(d.head){d.head.rotation.x-=.25*kick*force;d.head.rotation.z+=shake*.24;}
            if(d.snout)d.snout.rotation.x+=.26*kick;
            if(d.jaw)d.jaw.rotation.z+=.32*kick;
            if(d.tail)d.tail.rotation.z+=shake*.25;
            (d.arms||[]).forEach((arm,i)=>{arm.rotation.x-=.45*kick;arm.rotation.z+=(i?1:-1)*.30*kick;});
            (d.legs||[]).forEach((leg,i)=>{leg.rotation.x+=(i%2?1:-1)*.30*kick;});
            (d.feelers||[]).forEach((feeler,i)=>{feeler.rotation.z+=(i?1:-1)*.50*kick;});
            if(d.shell)d.shell.rotation.z+=shake*.18;
            (d.brows||[]).forEach((brow,i)=>{brow.rotation.z+=(i?1:-1)*.20*kick;});
            const flash=Math.max(0,1-t/.07)*.28;
            if(flash>0)for(const entry of s.rig.materials){
                entry.copies.forEach((copy,i)=>{const source=entry.list[i];if(copy.color)copy.color.copy(source.color).lerp(flashColor,flash);
                    if(copy.emissive){copy.emissive.copy(source.emissive).lerp(flashColor,flash*.30);copy.emissiveIntensity=source.emissiveIntensity;}});
                entry.node.material=Array.isArray(entry.original)?entry.copies:entry.copies[0];
            }
            s.applied=true;
        }
    }
    function reset(){for(const s of reacting.values())restore(s);reacting.clear();}
    function state(enemy){const s=reacting.get(enemy);return s?{age:s.age,duration:s.duration,strong:s.strong}:null;}
    return {hurt,update,pose,reset,state,get activeCount(){return reacting.size;}};
})();

// Mortes próprias do besouro e do urso. A trajetória física vem de enemyCombat.
const enemyDeath=(()=>{
    const cache=new WeakMap(),cube=new T.BoxGeometry(1,1,1),offset=new T.Vector3();
    const clamp=v=>Math.max(0,Math.min(1,v)),ease=v=>{v=clamp(v);return v*v*(3-2*v);};
    const supports=kind=>kind==='beetle'||kind==='bear';
    function effects(enemy){
        if(cache.has(enemy))return cache.get(enemy);
        const cloud=new T.Group(),material=new T.MeshBasicMaterial({color:0xd9c9a5,transparent:true,opacity:0,depthWrite:false});
        cloud.name='EnemyDeathDust';cloud.visible=false;S.add(cloud);
        for(let i=0;i<8;i++)cloud.add(new T.Mesh(cube,material));
        const ball=new T.Group();ball.name='BeetleDeathBall';ball.visible=false;S.add(ball);
        const fx={cloud,material,ball};cache.set(enemy,fx);return fx;
    }
    function begin(enemy,heading){
        const d=enemy.userData;if(!d.defeated||!supports(d.kind))return null;
        const fx=effects(enemy),nodes=[...new Set([d.head,d.jaw,d.tor,d.shell,...(d.legs||[]),...(d.arms||[]),...(d.fore||[]),...(d.feelers||[])].filter(Boolean))];
        const poses=nodes.map(node=>({node,rotation:node.rotation.clone(),scale:node.scale.clone()}));
        const death={fx,poses,land:d.kind==='bear'?.52:.36,poof:d.kind==='bear'?.28:.24,box:new T.Box3(),pivot:new T.Vector3(),impact:false};
        if(d.kind==='beetle'){
            const ball=d.dung;death.ball={parent:ball.parent,position:ball.position.clone(),rotation:ball.rotation.clone(),scale:ball.scale.clone()};
            ball.updateWorldMatrix(true,false);ball.getWorldPosition(fx.ball.position);ball.getWorldQuaternion(fx.ball.quaternion);ball.getWorldScale(fx.ball.scale);
            fx.ball.add(ball);ball.position.set(0,0,0);ball.rotation.set(0,0,0);ball.scale.set(1,1,1);fx.ball.visible=true;
            const bx=fx.ball.position.x-enemy.position.x,bz=fx.ball.position.z-enemy.position.z,length=Math.hypot(bx,bz);
            death.ballMotion={dx:length>.01?bx/length:Math.sin(heading+Math.PI/2),dz:length>.01?bz/length:Math.cos(heading+Math.PI/2),radius:.57,height:1.1,aquatic:false,baseY:fx.ball.position.y,offset:Math.max(.57,fx.ball.position.y-gh(fx.ball.position.x,fx.ball.position.z)),blocked:false};
        }
        // O centro é medido sem a bola, para o besouro virar sobre o próprio corpo.
        d.model.updateWorldMatrix(true,true);death.box.setFromObject(d.model).getCenter(death.pivot);d.model.worldToLocal(death.pivot);
        return death;
    }
    function restore(enemy,death){
        if(!death)return;
        for(const p of death.poses){p.node.rotation.copy(p.rotation);p.node.scale.copy(p.scale);}
        if(death.ball){const b=enemy.userData.dung,o=death.ball;o.parent.add(b);b.position.copy(o.position);b.rotation.copy(o.rotation);b.scale.copy(o.scale);}
        death.fx.ball.visible=false;death.fx.cloud.visible=false;death.fx.material.opacity=0;
    }
    function pose(enemy,s,move,dt){
        const d=enemy.userData,death=s.death,m=d.model,age=s.age-(death.onset||0),flight=death.flight??s.duration,u=flight>0?clamp(age/flight):1,land=clamp((age-flight)/death.land),tail=Math.max(0,age-flight-death.land),poof=clamp(tail/death.poof);
        const face=s.face;
        for(const p of death.poses){p.node.rotation.copy(p.rotation);p.node.scale.copy(p.scale);}
        m.visible=tail===0;m.position.set(0,0,0);m.scale.set(face,1,1);m.rotation.set(0,0,0);
        if(d.kind==='beetle'){
            m.rotation.z=face*(Math.PI*ease(u)+Math.sin(land*18)*.12*(1-land));
            m.rotation.x=Math.sin(u*Math.PI)*.12;
            d.legs.forEach((leg,i)=>{const kick=Math.sin(age*24+i*1.7)*(1-land*.70);leg.rotation.x=kick*.65;leg.rotation.z=(i<2?-1:1)*(.38+kick*.20);});
            d.feelers.forEach((f,i)=>{f.rotation.z=(i?1:-1)*(.42+Math.sin(age*15)*.16)*(1-land*.5);});
            move(death.fx.ball,death.ballMotion,dt*.42*(1-poof));death.fx.ball.position.y=death.ballMotion.baseY;
            d.dung.rotation.z=-age*3.4;death.fx.ball.visible=tail===0;
        }else{
            const fall=ease(land/.75),knees=Math.sin(Math.min(1,land/.50)*Math.PI);
            m.rotation.z=face*(.12*ease(u)+1.43*fall);m.rotation.x=-.18*Math.sin(u*Math.PI)+.08*knees;
            m.scale.y=1-.06*knees;m.position.y=-.08*knees;
            d.legs.forEach((leg,i)=>leg.rotation.x=-.45*(1-fall)+.25*fall+(i?1:-1)*.10*knees);
            d.arms.forEach((arm,i)=>{arm.rotation.x=-.75*(1-fall)-.70*fall;arm.rotation.z=(i?-1:1)*(.35+.75*fall);});
            (d.fore||[]).forEach(arm=>arm.rotation.x=-.30-.30*fall);
            d.head.rotation.x=-.20*(1-fall);d.head.rotation.z=.12*Math.sin(age*13)*(1-fall);d.jaw.rotation.z=.23*(1-land*.5);
        }
        // Rota em torno do centro e assenta o volume real no chão ao tombar.
        offset.copy(death.pivot).multiply(m.scale).applyEuler(m.rotation);
        m.position.x+=death.pivot.x*face-offset.x;m.position.y+=death.pivot.y-offset.y;m.position.z+=death.pivot.z-offset.z;
        enemy.updateWorldMatrix(true,true);death.box.setFromObject(m);
        const floor=gh(enemy.position.x,enemy.position.z)+.025,grounding=ease(land/.65);
        const correction=(floor-death.box.min.y)/Math.max(.01,Math.abs(enemy.scale.y));
        if(correction>0||land>0)m.position.y+=correction>0?correction:correction*grounding;
        d.animationState=tail>0?'death-poof':land>0?(d.kind==='bear'?'death-fall':'death-upturned'):'death-air';
        const impactAt=d.kind==='bear'?.62:.1;
        if(land>=impactAt)death.impact=true;
        const impactAge=Math.max(0,age-flight-death.land*impactAt),dust=death.impact?clamp(impactAge/.5):0;
        const cloud=death.fx.cloud;cloud.position.set(enemy.position.x,floor,enemy.position.z);
        cloud.visible=death.impact&&(dust<1||tail>0);death.fx.material.opacity=tail>0?.48*(1-poof):.35*(1-dust);
        for(let i=0;i<cloud.children.length;i++){
            const p=cloud.children[i],a=i*Math.PI/4,spread=(d.kind==='bear'?.45:.25)+(tail>0?poof:dust)*(d.kind==='bear'?1.05:.65);
            p.position.set(Math.sin(a)*spread,.12+Math.sin((tail>0?poof:dust)*Math.PI)*.35,Math.cos(a)*spread);
            const size=(d.kind==='bear'?.30:.20)*(tail>0?1+poof*.8:1-dust*.6);p.scale.setScalar(size);p.rotation.set(i*.3,age*.8,i*.2);
        }
        return tail>=death.poof;
    }
    return {supports,begin,pose,restore};
})();

// Pulinho para trás ao tomar dano; a finalização mantém seu arremesso forte.
const enemyCombat=(()=>{
    const flying=new Map(),origins=new Map(),pivotOffset=new T.Vector3();
    const shadows=new WeakMap(),shadowGeometry=new T.CircleGeometry(1,12),shadowMaterial=new T.MeshBasicMaterial({color:0x27352b,transparent:true,opacity:.19,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1});
    function hopShadow(enemy){
        if(!shadows.has(enemy)){const shadow=new T.Mesh(shadowGeometry,shadowMaterial);shadow.name='EnemyDamageHopShadow';shadow.rotation.x=-Math.PI/2;shadow.visible=false;S.add(shadow);shadows.set(enemy,shadow);}
        return shadows.get(enemy);
    }
    function controls(enemy){return flying.has(enemy);}
    function launched(enemy){const s=flying.get(enemy);return !!s&&!s.recoil;}
    function restorePose(enemy){const m=enemy.userData.model,face=Math.sign(m.scale.x)||1;m.position.set(0,0,0);m.rotation.set(0,0,0);m.scale.set(face,1,1);m.visible=true;}
    function launch(enemy,heading,recoil=false){
        const d=enemy.userData;if(!enemy.visible||launched(enemy))return;
        const previous=flying.get(enemy);
        if(previous){if(previous.shadow)previous.shadow.visible=false;restorePose(enemy);flying.delete(enemy);}
        if(!origins.has(enemy))origins.set(enemy,{x:d.x,z:d.z,position:enemy.position.clone(),rotation:enemy.rotation.clone()});
        const heavy=d.kind==='bear',aquatic=d.kind==='fish'||d.kind==='piranha';
        // Ao encadear golpes no ar, conserva a altura atual e o chão de origem:
        // não soma a altura do pulo à próxima aterrissagem nem teleporta o alvo.
        const baseY=previous?.baseY??enemy.position.y,startLift=Math.max(0,enemy.position.y-baseY);
        const death=enemyDeath.begin(enemy,heading);
        flying.set(enemy,{age:0,recoil,duration:recoil?.30:.62,settle:recoil?.16:.18,dx:Math.sin(heading),dz:Math.cos(heading),distance:recoil?(heavy?.26:.38):(heavy?2.15:3.20),
            lift:recoil?(heavy?.32:.46):(heavy?.85:1.25),radius:heavy?.80:aquatic?.35:.55,height:heavy?2.5:1.3,pivot:aquatic?0:heavy?1.15:.55,aquatic,
            baseY,startLift,death,offset:previous?.offset??Math.max(0,Math.min(.16,enemy.position.y-gh(enemy.position.x,enemy.position.z))),shadow:(recoil||death)&&!aquatic?hopShadow(enemy):null,
            progress:0,blocked:false,face:Math.sign(d.model.scale.x)||1});
        d.animationState=recoil?'hurt':'launched';d.hurt=Math.max(d.hurt,.85);d.reach=0;d.attackActive=false;d.attackState='recover';d.attackT=0;
        if(d.kind==='bear'){d.at='walk';d.ct=0;d.cool=Math.max(d.cool,.5);}
        if(d._enemyAnim)d._enemyAnim.danger.visible=false;
        restorePose(enemy);
    }
    function move(enemy,s,distance){
        if(s.blocked||distance<=0)return;
        const n=Math.ceil(distance/.04),stride=distance/n;
        for(let i=0;i<n;i++){
            const x=enemy.position.x+s.dx*stride,z=enemy.position.z+s.dz*stride,ground=gh(x,z);
            if(z<ZMIN||z>ZMAX||Math.abs(x)>wp(z)-s.radius-.10||(!s.aquatic&&(pitF(x,z)>=.08||Math.abs(ground-gh(enemy.position.x,enemy.position.z))>.25))){s.blocked=true;break;}
            if(walls.some(w=>{const u=w.userData;return w.visible&&s.baseY<u.gy+2.7&&s.baseY+s.height>u.gy&&Math.abs(x-w.position.x)<u.hx+s.radius&&Math.abs(z-w.position.z)<u.hz+s.radius;})) {s.blocked=true;break;}
            if(boxes.some(b=>b.visible&&s.baseY<b.userData.gy+1.6&&s.baseY+s.height>b.userData.gy&&Math.abs(x-b.position.x)<.65+s.radius&&Math.abs(z-b.position.z)<.65+s.radius)) {s.blocked=true;break;}
            enemy.position.x=x;enemy.position.z=z;if(!s.aquatic)s.baseY=ground+s.offset;
        }
    }
    function finish(enemy,s){
        if(s.shadow)s.shadow.visible=false;
        enemyDeath.restore(enemy,s.death);
        const d=enemy.userData;flying.delete(enemy);restorePose(enemy);
        if(d.defeated){enemy.visible=false;d.animationState='defeated';return;}
        enemy.position.y=s.baseY;d.gy=s.baseY;d.x=enemy.position.x;d.z=enemy.position.z;
        d.hurt=Math.max(d.hurt,.15);d.animationState='hurt';d.attackState='patrol';d.attackCool=Math.max(d.attackCool||0,.35);
        if(d._enemyAnim){d._enemyAnim.state='hurt';d._enemyAnim.age=0;}
    }
    function update(dt,active){
        enemyDamage.update(dt,active);
        // TNT/Nitro marcam a derrota diretamente. Também recebem a morte própria,
        // inclusive se a explosão acertar um alvo já arremessado e ainda vivo.
        for(const enemy of foes){
            const d=enemy.userData;if(!enemy.visible||!d.defeated||!enemyDeath.supports(d.kind))continue;
            const s=flying.get(enemy),heading=Math.atan2(enemy.position.x-st.x,enemy.position.z-st.z);
            if(!s)launch(enemy,heading,true);
            else if(!s.death){s.death=enemyDeath.begin(enemy,heading);s.death.onset=s.age;s.death.flight=Math.max(0,s.duration-s.age);s.shadow??=hopShadow(enemy);}
        }
        if(!active)return;
        for(const [enemy,s] of flying){
            const d=enemy.userData;
            if(!enemy.visible){if(s.shadow)s.shadow.visible=false;enemyDeath.restore(enemy,s.death);flying.delete(enemy);restorePose(enemy);continue;}
            s.age+=dt;d.hurt=Math.max(0,d.hurt-dt);d.reach=0;d.attackActive=false;
            const u=Math.min(1,s.age/s.duration),progress=1-(1-u)*(1-u);
            move(enemy,s,(progress-s.progress)*s.distance);s.progress=progress;
            const arc=s.recoil?4*u*(1-u):Math.sin(u*Math.PI);
            enemy.position.y=s.baseY+arc*s.lift+(1-u)*s.startLift;d.gy=enemy.position.y;
            if(s.shadow){s.shadow.visible=true;s.shadow.position.set(enemy.position.x,gh(enemy.position.x,enemy.position.z)+.025,enemy.position.z);s.shadow.scale.setScalar(s.radius*(1-.25*Math.min(1,(enemy.position.y-s.baseY)/s.lift)));}
            if(s.death){if(enemyDeath.pose(enemy,s,move,dt))finish(enemy,s);continue;}
            const m=d.model;m.visible=true;
            m.rotation.x=-(s.recoil?.12:.30)*Math.sin(u*Math.PI);m.rotation.z=(s.recoil?.12:(d.defeated?Math.PI*1.6:.62))*Math.sin(u*Math.PI/2);
            const shrink=d.defeated?1-.50*Math.max(0,(u-.78)/.22):1;m.scale.set(s.face*shrink,shrink,shrink);
            if(u===1){
                if(d.defeated){finish(enemy,s);continue;}
                const settle=Math.min(1,(s.age-s.duration)/s.settle);d.animationState='landing';
                m.rotation.x=0;m.rotation.z=(s.recoil?.12:.62)*(1-settle);m.scale.set(s.face*(1+.06*Math.sin(settle*Math.PI)),1-(s.recoil?.14:.10)*Math.sin(settle*Math.PI),1);
                if(settle===1){finish(enemy,s);continue;}
            }
            // Gira ao redor do corpo, mantendo o modelo acima do chão mesmo
            // quando está de cabeça para baixo. O hitbox acompanha o voo real.
            pivotOffset.set(0,s.pivot*m.scale.y,0).applyQuaternion(m.quaternion);
            m.position.set(-pivotOffset.x,s.pivot-pivotOffset.y,-pivotOffset.z);
        }
    }
    function reset(){
        enemyDamage.reset();
        for(const [enemy,s] of flying){if(s.shadow)s.shadow.visible=false;enemyDeath.restore(enemy,s.death);}
        for(const [enemy,origin] of origins){const d=enemy.userData;d.x=origin.x;d.z=origin.z;enemy.position.copy(origin.position);enemy.rotation.copy(origin.rotation);restorePose(enemy);}
        flying.clear();origins.clear();
    }
    function state(enemy){const s=flying.get(enemy);return s?{age:s.age,recoil:s.recoil,airborne:s.age<s.duration,blocked:s.blocked,distance:s.distance,lift:s.lift}:null;}
    return {launch,recoil:(enemy,heading)=>launch(enemy,heading,true),hurt:enemyDamage.hurt,pose:enemyDamage.pose,damageState:enemyDamage.state,controls,launched,update,reset,state,get activeCount(){return flying.size;}};
})();
window.BunnyHavocEnemies=enemyCombat;

const sprintTag = $('sprintTag'), npcBubble = $('npcBubble');
const reset = () => { playerCombat.reset(); enemyCombat.reset(); if (globalThis.__bhForestOutro && typeof globalThis.__bhForestOutro.abort === 'function')
    globalThis.__bhForestOutro.abort(); document.body.classList.remove('cinematic'); enemyAnimator.reset(); foes.forEach(e => { const d = e.userData; e.visible = true; d.hp = d.maxHp; d.hurt = 0; if (d.kind === 'fish') {
    e.position.set(d.x, d.baseY, d.z);
    e.rotation.set(0, 0, 0);
}
else if (d.kind === 'piranha') {
    e.position.set(-d.W, d.wl - .65, d.z);
    e.rotation.set(0, 0, 0);
    delete d.cy;
    delete d.landed;
}
else {
    e.position.set(d.x, hp(d.z), d.z);
    e.rotation.y = 0;
} if (d.model)
    d.model.visible = d.kind !== 'piranha'; }); st = { x: 0, y: hp(cp), z: cp, vy: 0, g: true, mx: 0, mz: 0, runJump: false }; sprinting = false; jumpHeld = false; sprintTag.style.display = 'none'; P.position.set(0, st.y, cp); P.rotation.set(0, 0, 0); P.scale.set(1, 1, 1); P.visible = true; bunnyckAnimator.reset(); body.scale.set(1, 1, 1); body.position.set(0, 0, 0); body.rotation.set(0, Math.PI, 0); legs.forEach(l => l.rotation.set(0, 0, 0)); arms.forEach(a => a.rotation.set(0, 0, 0)); ears.forEach(e => e.rotation.set(0, 0, 0)); tail.rotation.set(0, 0, 0); dizzy.visible = false; cs = null; ended = 0; bibi.visible = false; cage.visible = false; bl.visible = false; bl.position.set(0, by0, -398); bl.rotation.set(0, 0, 0); if (bl.userData.core) {
    bl.userData.core.position.set(0, 0, 0);
    bl.userData.core.rotation.set(0, 0, 0);
} if (bibi.userData.core) {
    bibi.userData.core.position.set(0, 0, 0);
    bibi.userData.core.rotation.set(0, 0, 0);
} ; };
const hud = () => { $('f').textContent = '🥕 ' + fr; $('l').textContent = '🐰 × ' + lives; $('c').textContent = '📦 ' + broken; };
const die = (k, src, amount = src?.userData.damage ?? 1) => {
    if (dy)
        return;
    sprintTag.style.display = 'none';
    sprinting = false;
    dl = null;
    bump = 0;
    k = k || 'hit';
    if (!playerCombat.damage(k, src, amount)) return;
    if (k == 'pit' && pits.some(([a, b]) => st.z < a + 1.5 && st.z > b - 1.5))
        k = 'drown';
    dy = { k, t: 0, vx: src ? (st.x >= src.position.x ? 4 : -4) : 0, b: st.y, fy: hp(st.z) - 8.5 };
    spin = 0;
    shake = (k == 'pit' || k == 'drown') ? 0 : .4;
    if (k == 'explosion') {
        st.vy = 10.5;
        st.g = false;
        snd(105, .46, 'sawtooth', 35, .27);
        fx(st, 0xff9c24, 25, 6);
        fx(st, 0x4b4a48, 13, 5);
    }
    else if (k == 'hit') {
        st.vy = 9;
        st.g = false;
        snd(200, .3, 'sawtooth', 60);
    }
    else if (k == 'spike')
        snd(250, .3, 'sawtooth', 80);
    else if (k == 'crush')
        snd(150, .3, 'square', 40);
    else
        snd(700, 1, 'sine', 90);
    if (k != 'pit' && k != 'drown')
        fx(st, 0xffffff, 8);
};
function dieAnim(dt) {
    const d = dy, k = d.k;
    d.t += dt;
    const t = d.t;
    if (k == 'drown') {
        if (d.wl === undefined)
            d.wl = hp(st.z) - 1.7;
        if (!d.l) {
            st.vy -= 30 * dt;
            st.y += st.vy * dt;
            P.rotation.z = Math.sin(t * 30) * .2;
            arms.forEach((a, i) => { a.rotation.x = -2.6 + Math.sin(t * 30 + i * 3) * .6; });
            legs.forEach((l, i) => { l.rotation.x = Math.sin(t * 25 + i * 3) * .7; });
            if (st.y <= d.wl) {
                st.y = d.wl;
                d.l = t;
                st.vy = 0;
                fx(st, 0xbfefff, 18, 6);
                fx(st, 0xffffff, 8, 3);
                snd(260, .4, 'sine', 60);
                snd(900, .15, 'square', 300);
                shake = .25;
            }
        }
        else {
            const u = t - d.l;
            st.y = d.wl - Math.min(u, 1.6) * 1.1;
            P.rotation.z = Math.sin(u * 9) * .5;
            P.rotation.y = u * 3;
            arms.forEach((a, i) => { a.rotation.x = -2.8 + Math.sin(u * 14 + i * 2) * .8; a.rotation.z = (i ? -1 : 1) * (.5 + Math.sin(u * 10) * .4); });
            legs.forEach((l, i) => { l.rotation.x = Math.sin(u * 16 + i * 3) * .9; });
            if ((d.bb = (d.bb || 0) + dt) > .18) {
                d.bb = 0;
                fx({ x: st.x, y: d.wl - .2, z: st.z }, 0xe2fbff, 1, 1.5);
            }
            if (u > 1.9)
                fin();
        }
    }
    else if (k == 'explosion') {
        st.vy -= 23 * dt;
        st.y += st.vy * dt;
        st.x += d.vx * dt * .6;
        P.rotation.z += dt * 16;
        P.rotation.x += dt * 7;
        arms.forEach((a, i) => { a.rotation.x = Math.sin(t * 15 + i * Math.PI) * 1.1 - 1; });
        legs.forEach((l, i) => { l.rotation.x = Math.sin(t * 13 + i * Math.PI) * 1.2; });
        ears.forEach((e, i) => { e.rotation.z = Math.sin(t * 22 + i) * .48; });
        P.scale.setScalar(t < .2 ? 1.08 : Math.max(.15, 1 - (t - .2) * .47));
        P.visible = t < .6 || Math.floor(t * 18) % 2 === 0;
        if (t > 1.65)
            fin();
    }
    else if (k == 'pit') {
        if (t < .55) {
            st.vy = 0;
            P.rotation.z = Math.sin(t * 45) * .18;
            arms.forEach((a, i) => { a.rotation.x = -2.5 + Math.sin(t * 40 + i * 3) * .7; });
            legs.forEach((l, i) => { l.rotation.x = Math.sin(t * 35 + i * 3) * .8; });
            if (!d.h) {
                d.h = 1;
                snd(450, .45, 'sine', 950);
            }
        }
        else if (!d.l) {
            st.vy -= 45 * dt;
            st.y += st.vy * dt;
            P.rotation.z = 0;
            P.scale.set(.8, 1.25, .8);
            if (!d.w) {
                d.w = 1;
                snd(1000, .8, 'sine', 140);
            }
            const fl = gh(st.x, st.z);
            if (st.y <= fl) {
                st.y = fl;
                d.l = t;
                fx(st, 0x9a6a3a, 18, 7);
                fx(st, 0xffe14a, 6, 5);
                snd(90, .3, 'square', 40);
                shake = .35;
                dizzy.visible = true;
            }
        }
        else {
            const u = t - d.l, k2 = Math.max(0, 1 - u * 5);
            P.scale.set(1 + .4 * k2, 1 - .5 * k2, 1 + .4 * k2);
            dizzy.position.set(st.x, st.y + 2.2, st.z);
            dizzy.rotation.y += dt * 6;
            P.rotation.z = Math.sin(u * 6) * .12;
            if (u > 1.5)
                fin();
        }
    }
    else if (k == 'spike') {
        if (t < .3) {
            st.y = d.b + Math.sin(t / .3 * Math.PI) * 1.3;
            P.rotation.z = Math.sin(t * 60) * .25;
        }
        else {
            if (!d.s) {
                d.s = 1;
                fx(st, 0xffe14a, 8, 4);
                shake = .2;
            }
            st.y = d.b + .35;
            P.rotation.z = 0;
            P.rotation.x = Math.max(-1.3, P.rotation.x - dt * 6);
        }
        P.visible = t < 1.2 || Math.floor(t * 14) % 2 == 0;
        if (t > 1.8)
            fin();
    }
    else if (k == 'crush') {
        const sy = Math.max(.1, 1 - t * 8), sx = 1 + (1 - sy) * .7;
        P.scale.set(sx, sy, sx);
        if (!d.s && t > .12) {
            d.s = 1;
            fx(st, 0xcccccc, 10, 5);
            shake = .25;
        }
        P.visible = t < 1.1 || Math.floor(t * 14) % 2 == 0;
        if (t > 1.7)
            fin();
    }
    else {
        if (!d.l) {
            st.vy -= 24 * dt;
            st.y += st.vy * dt;
            st.x = Math.max(-wp(st.z) + .5, Math.min(wp(st.z) - .5, st.x + d.vx * dt));
            st.z = Math.min(ZMAX, st.z + 2.5 * dt);
            P.rotation.z += dt * 14;
            const gg = gh(st.x, st.z);
            if (st.y <= gg && t > .1) {
                st.y = gg + .25;
                d.l = t;
                fx(st, 0xffe14a, 8, 4);
                snd(120, .2, 'square', 60);
                shake = .2;
                P.rotation.z = Math.PI / 2;
            }
        }
        else {
            P.visible = t - d.l < .6 || Math.floor(t * 14) % 2 == 0;
            if (t - d.l > 1)
                fin();
        }
        if (t > 3)
            fin();
    }
    P.position.set(st.x, st.y, st.z);
}
const fin = () => { if (!dy)
    return; dy = null; dizzy.visible = false; lives--; if (lives <= 0) {
    over('GAME OVER', 'Você fez ' + fr + ' cenouras.');
    return;
} reset(); hud(); };
function over(t, s) { document.body.classList.remove('cinematic'); C.fov = 60; C.updateProjectionMatrix(); run = false; sprintTag.style.display = 'none'; npcBubble.style.display = 'none'; hint.style.display = 'none'; dl = null; cv = null; bump = 0; dizzy.visible = false; cs = null; ended = 0; bibi.visible = false; cage.visible = false; bgm.pause(); bgm.currentTime = 0; $('ov').innerHTML = '<h1>' + t + '</h1><p>' + s + '</p><p><b>Clique para jogar de novo</b></p>'; $('ov').style.display = 'flex'; lives = 3; fr = 0; broken = 0; cp = 8; hud(); reset(); boxes.forEach(b => b.visible = true); fruits.forEach(f => f.visible = true); secretSystems.reset(); foes.forEach(f => { f.visible = true; f.userData.hp = f.userData.maxHp; f.userData.hurt = 0; f.userData.defeated = false; f.userData.model.visible = f.userData.kind !== 'piranha'; }); }
addEventListener('keydown', e => {
    keys[e.code] = 1;
    if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ControlLeft', 'ControlRight'].includes(e.code))
        e.preventDefault();
    if (run && !cv && !dy && !e.repeat && (e.code == 'ShiftLeft' || e.code == 'ShiftRight' || e.code == 'KeyJ')) {
        playerCombat.press();
    }
});
addEventListener('keyup', e => { keys[e.code] = 0; if (e.code === 'Space')
    jumpHeld = false; });
addEventListener('keydown', e => { if (!run && !cs && e.code == 'Enter')
    $('ov').onclick(); if ((run || cv) && e.code == 'Enter' && !e.repeat) {
    cv ? cvNext() : interactWithCitizen();
} if (e.code == 'KeyM')
    window.parent?.BunnyHavocAudio?.toggleMute?.(); });
document.addEventListener('visibilitychange', () => { if (document.hidden)
    bgm.pause();
else if (run)
    bgm.play().catch(() => { }); });
$('ov').onclick = () => { $('ov').style.display = 'none'; run = true; window.parent?.BunnyHavocAudio?.refreshVolume?.(); bgm.play().catch(() => { }); };
let tx = null;
addEventListener('touchstart', e => { if (cv) {
    cvNext();
    return;
} for (const t of e.changedTouches) {
    if (t.clientX > innerWidth / 2) {
        if (t.clientY < innerHeight * .34) {
            playerCombat.press();
        }
        else if (t.clientY < innerHeight * .7) {
            keys.Space = 1;
            setTimeout(() => { keys.Space = 0; jumpHeld = false; }, 170);
        }
        else {
            keys.KeyK = 1;
            setTimeout(() => keys.KeyK = 0, 900);
        }
    }
    else if (!tx)
        tx = [t.clientX, t.clientY, t.identifier];
} });
addEventListener('touchmove', e => { for (const t of e.touches)
    if (tx && t.identifier == tx[2]) {
        keys.tx = (t.clientX - tx[0]) / 40;
        keys.tz = (t.clientY - tx[1]) / 40;
    } });
addEventListener('touchend', e => { for (const t of e.changedTouches)
    if (tx && t.identifier == tx[2]) {
        tx = null;
        keys.tx = keys.tz = 0;
    } });
addEventListener('resize', fit);
function talkStart() { let i; do {
    i = Math.floor(Math.random() * LINES.length);
} while (i == lastLine); lastLine = i; dl = { line: LINES[i], idx: 0, acc: 0, hold: 0, sh: -1 }; dlg.style.display = 'block'; }
function dlgUpdate(dt) {
    if (!dl) {
        dlg.style.display = 'none';
        return;
    }
    const d = dl;
    d.acc += dt;
    while (d.acc > .045 && d.idx < d.line.length) {
        d.acc -= .045;
        d.idx++;
        if (d.line[d.idx - 1] != ' ') {
            const f = 560 + (d.idx * 37 % 6) * 55;
            snd(f, .08, 'triangle', f * 1.2, .06);
        }
    }
    if (d.idx >= d.line.length) {
        d.hold += dt;
        if (d.hold > 2.6) {
            dl = null;
            dlg.style.display = 'none';
            return;
        }
    }
    if (d.sh != d.idx) {
        d.sh = d.idx;
        dlg.innerHTML = d.line.slice(0, d.idx) + '<span style="visibility:hidden">' + d.line.slice(d.idx) + '</span>';
    }
    dv.set(st.x, st.y + 2.9, st.z).project(C);
    dlg.style.left = ((dv.x * .5 + .5) * innerWidth) + 'px';
    dlg.style.top = ((-dv.y * .5 + .5) * innerHeight) + 'px';
}
// @ts-nocheck
// Bunny Havoc | Animator V1: exclusivamente visual, sem alterar física ou hitboxes.
// O controlador só assume o Bunnyck durante jogabilidade. A cutscene e as mortes
// continuam usando suas animações originais, sem disputa pelos mesmos grupos.
const bunnyckAnimator = (() => {
    const damp = (current, target, rate, dt) => current + (target - current) * (1 - Math.exp(-rate * Math.max(0, dt)));
    const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
    const angleDelta = (a, b) => Math.atan2(Math.sin(b - a), Math.cos(b - a));
    const ease = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
    let stride = 0, wasGrounded = true, fallSpeed = 0, jumpAge = 1, landAge = 1, landWeight = 0;
    let previousSpeed = 0, heading = Math.PI, spinWasActive = false;
    let blinkClock = 1.8, blinkRemaining = 0, breath = 0;
    let state = 'idle', lastState = 'idle';
    const eyelids = [];
    for (const side of [-1, 1]) {
        // Pálpebras na frente dos olhos geométricos; visíveis somente durante a piscada.
        const lid = mesh(B(.165, .195, .046), 0x7a2fe0, [side * .2, 1.76, .515]);
        lid.visible = false;
        bun.add(lid);
        eyelids.push(lid);
    }
    const pose = (obj, axis, value, rate, dt) => { obj.rotation[axis] = damp(obj.rotation[axis], value, rate, dt); };
    function reset() {
        stride = 0;
        wasGrounded = true;
        fallSpeed = 0;
        jumpAge = 1;
        landAge = 1;
        landWeight = 0;
        previousSpeed = 0;
        heading = Math.PI;
        spinWasActive = false;
        blinkClock = 1.8;
        blinkRemaining = 0;
        breath = 0;
        state = 'idle';
        lastState = 'idle';
        eyelids.forEach(e => e.visible = false);
        body.position.set(0, 0, 0);
        body.rotation.set(0, Math.PI, 0);
        body.scale.set(1, 1, 1);
        for (const limb of [...arms, ...legs, ...ears])
            limb.rotation.set(0, 0, 0);
        ears.forEach((e, i) => e.rotation.z = i === 0 ? .1 : -.1);
        tail.rotation.set(0, 0, 0);
        tail.scale.set(1, 1, 1);
    }
    function update(t, dt, st, run, sprinting, spin, mv) {
        dt = clamp(dt || 0, 0, .05);
        if (!st)
            return;
        const speed = Math.hypot(st.mx, st.mz), grounded = !!st.g, spinning = spin > 0;
        const moving = run && speed > .55 && !!mv && grounded;
        const dash = !!sprinting && moving;
        const startedJump = wasGrounded && !grounded && st.vy > 0;
        const landed = !wasGrounded && grounded;
        if (startedJump)
            jumpAge = 0;
        if (!grounded)
            jumpAge += dt;
        if (landed) {
            landAge = 0;
            landWeight = clamp((-fallSpeed - 2) / 13, .28, 1);
        }
        if (grounded)
            landAge += dt;
        const landedPose = grounded ? Math.pow(1 - ease(landAge / .26), 1.35) * landWeight : 0;
        const launching = !grounded && jumpAge < .16;
        const airborne = run && !grounded;
        lastState = state;
        state = !run ? 'idle' : spinning ? 'spin' : airborne ? (st.vy > 1.1 ? 'rise' : 'fall') : landedPose > .06 ? 'land' : moving ? (dash ? 'sprint' : 'run') : (speed > 1.3 ? 'brake' : 'idle');
        const pace = clamp(speed / 10.3, 0, 1.15);
        stride += dt * (moving ? (dash ? 18.8 : 13.4) * (.45 + pace * .55) : 3.2);
        breath += dt;
        const foot = Math.sin(stride), offFoot = Math.sin(stride + Math.PI);
        const cycle = moving ? Math.pow(Math.abs(Math.sin(stride)), 1.15) : 0;
        const airRise = airborne ? clamp(st.vy / 12, -1, 1) : 0;
        const startPose = launching ? (1 - ease(jumpAge / .16)) : 0;
        const slowing = grounded && !moving && previousSpeed > 1.0 ? clamp(previousSpeed / 10, 0, .9) : 0;
        const braking = clamp((previousSpeed - speed) / 6, 0, 1) * slowing;
        // O giro altera o eixo Y em 08_loop; não disputar com a animação de ataque.
        // Ao terminar, normalizar o ângulo equivalente evita acumular voltas sem limite.
        if (spinWasActive && !spinning) {
            body.rotation.y = Math.atan2(Math.sin(body.rotation.y), Math.cos(body.rotation.y));
        }
        if (!spinning) {
            const wantsTurn = run && speed > 1.1;
            if (wantsTurn) {
                const target = Math.atan2(st.mx, st.mz);
                const delta = angleDelta(heading, target);
                heading += delta * (1 - Math.exp(-dt * (dash ? 11 : 14)));
            }
            const yawError = angleDelta(body.rotation.y, heading);
            body.rotation.y += yawError * (1 - Math.exp(-dt * 15));
        }
        const headingLean = run && speed > 1 ? clamp(angleDelta(body.rotation.y, Math.atan2(st.mx, st.mz)), -.55, .55) : 0;
        pose(body, 'x', airborne ? (st.vy > 0 ? -.13 : .16) : dash ? -.17 : moving ? -.075 : braking ? .17 : 0, 10, dt);
        pose(body, 'z', spinning ? .06 * Math.sin(t * 30) : (-headingLean * .3 + Math.sin(stride) * .025 * pace), 12, dt);
        const idleBob = (Math.sin(breath * 2.1) * .022 + Math.sin(breath * .91) * .015);
        const runBob = (moving ? (cycle * .095 * (dash ? 1.65 : 1)) : 0);
        const leapBob = startPose * (-.055) + (!grounded ? .015 : 0);
        body.position.y = damp(body.position.y, landedPose * (-.10) + runBob + idleBob + leapBob, 18, dt);
        const launchStretch = airborne ? (st.vy > 0 ? .09 : -.045) : 0;
        const sy = 1 + launchStretch + startPose * (-.15) + landedPose * (-.18) + Math.sin(breath * 2.2) * .008;
        const sx = 1 / Math.sqrt(Math.max(.7, sy));
        body.scale.x = damp(body.scale.x, sx, 16, dt);
        body.scale.y = damp(body.scale.y, sy, 16, dt);
        body.scale.z = damp(body.scale.z, sx, 16, dt);
        // Pernas com contato mais forte e recuperação da passada.
        const strideAmp = moving ? (dash ? 1.18 : .82) * clamp(pace * .8 + .2, .3, 1) : 0;
        for (let i = 0; i < 2; i++) {
            let rx = moving ? Math.sin(stride + i * Math.PI) * strideAmp : 0;
            if (airborne)
                rx = st.vy > 0 ? (i === 0 ? -.45 : .73) : (i === 0 ? .5 : -.35);
            if (spinning)
                rx = (i === 0 ? -.33 : .37);
            if (landedPose > .04)
                rx = (i === 0 ? -.65 : .65) * landedPose;
            pose(legs[i], 'x', rx, airborne ? 14 : 22, dt);
            pose(legs[i], 'z', spinning ? (i === 0 ? -.32 : .32) : landedPose * (i === 0 ? -.12 : .12), 16, dt);
        }
        // Braços exagerados em sprint, giro e saltos; mantém a silhueta expressiva.
        for (let i = 0; i < 2; i++) {
            let ax = moving ? -Math.sin(stride + i * Math.PI) * strideAmp * (dash ? 1.05 : .95) : Math.sin(breath * 1.3 + i * 2.5) * .055;
            if (airborne)
                ax = st.vy > 0 ? -2.1 : (i === 0 ? -1.0 : -2.35);
            if (spinning)
                ax = -.36;
            if (landedPose > .04)
                ax = landedPose * (i === 0 ? .9 : -.9);
            pose(arms[i], 'x', ax, 20, dt);
            pose(arms[i], 'z', spinning ? (i === 0 ? -1.4 : 1.4) : airborne ? (i === 0 ? -.36 : .36) : dash ? (i === 0 ? -.1 : .1) : .05 * (i ? 1 : -1), 19, dt);
        }
        // Orelhas com arrasto e recuperação, mas sem exagerar a ponto de atravessar o rosto.
        for (let i = 0; i < 2; i++) {
            const side = i === 0 ? -1 : 1;
            const earDrag = airborne ? clamp(-st.vy * .055, -.7, .67) : moving ? (-.18 - .32 * pace + .15 * Math.sin(stride * .52 + i * 1.1)) : Math.sin(breath * 2.2 + i) * .07;
            const earTarget = spinning ? -.48 + Math.sin(t * 22 + i) * .19 : earDrag + landedPose * .34;
            pose(ears[i], 'x', earTarget, 11, dt);
            pose(ears[i], 'z', -side * (.10 + (dash ? .08 : 0)) + Math.sin(breath * 2.3 + i * 2.1) * .045 + (spinning ? side * .18 : 0), 9, dt);
        }
        const tailS = spinning ? 1.65 : dash ? 1.08 : 1;
        tail.scale.x = damp(tail.scale.x, tailS, 17, dt);
        tail.scale.y = damp(tail.scale.y, tailS, 17, dt);
        tail.scale.z = damp(tail.scale.z, spinning ? 2.7 : 1, 17, dt);
        pose(tail, 'y', spinning ? Math.sin(t * 36) * .35 : Math.sin(stride * .65) * .19, 15, dt);
        pose(tail, 'x', dash ? -.16 : airborne ? .16 : 0, 12, dt);
        // Piscadas espaçadas sem gerar novas geometrias por quadro.
        blinkClock -= dt;
        if (blinkClock <= 0) {
            blinkRemaining = .12;
            blinkClock = 2.6 + 1.15 * (.5 + .5 * Math.sin(t * 1.3));
        }
        blinkRemaining = Math.max(0, blinkRemaining - dt);
        eyelids.forEach(l => l.visible = blinkRemaining > 0 && !spinning);
        if (!run) {
            body.rotation.y += dt * .2;
            heading = body.rotation.y;
        }
        previousSpeed = speed;
        fallSpeed = st.vy;
        wasGrounded = grounded;
        spinWasActive = spinning;
    }
    return { update, reset, get state() { return state; }, get previousState() { return lastState; } };
})();
// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
// ---- NPCs: Vixxo (raposa) e Bunnyldu
const K = 0x151515;
function mkFox() {
    const g = new T.Group(), a = (w, h, d, c, x, y, z) => g.add(mesh(B(w, h, d), c, [x, y, z])), OR = 0xe8731c, WT = 0xf4ecdc, BR = 0x5a3320, GR = 0x4aa83a;
    for (const s of [-1, 1]) {
        a(.36, .22, .62, WT, s * .24, .11, .1);
        a(.3, .4, .3, BR, s * .24, .42, 0);
        a(.32, .4, .32, OR, s * .24, .82, 0);
        a(.24, .55, .26, OR, s * .55, 1.35, 0);
        a(.3, .3, .3, BR, s * .55, .98, .03);
        a(.3, .85, .16, OR, s * .32, 2.75, 0);
        a(.3, .32, .16, BR, s * .32, 3.2, 0);
        a(.14, .5, .04, WT, s * .32, 2.7, .09);
        a(.2, .24, .03, WT, s * .22, 2.3, .47);
        a(.1, .17, .03, K, s * .22, 2.3, .49);
    }
    a(.78, .9, .48, OR, 0, 1.4, 0);
    a(.42, .65, .02, WT, 0, 1.35, .25);
    a(.9, .2, .56, GR, 0, 1.95, 0);
    a(.22, .26, .14, BR, .45, 1.0, .2);
    a(1, .8, .9, OR, 0, 2.4, 0);
    a(.4, .28, .2, WT, 0, 2.15, .5);
    a(.12, .1, .08, K, 0, 2.22, .62);
    a(.45, .45, .8, OR, 0, .95, -.6);
    a(.5, .5, .5, WT, 0, 1.0, -1.1);
    g.scale.setScalar(.85);
    return g;
}
function mkBig() {
    const g=new T.Group(),core=new T.Group();g.name='Bunnyldu';g.add(core);
    const fur=0x34333b,light=0x44434c,shadow=0x24232a,white=0xf6f4f5;
    const gray=0xd2d0d4,pink=0xf77f94,pale=0xffa6b2;
    const legs=[],arms=[],ears=[];
    // Porte forte em caixas chanfradas, com a grande barriga branca da concept.
    const torso=bhCharBlock(core,[1.48,1.10,.83],fur,[0,1.85,0],.10);
    // Tronco largo no peito, estreitando em direcao aos quadris.
    const vertices=torso.geometry.getAttribute('position');
    for(let i=0;i<vertices.count;i++)vertices.setX(i,vertices.getX(i)*(.87+.13*(vertices.getY(i)/1.10+.5)));
    vertices.needsUpdate=true;torso.geometry.computeVertexNormals();
    bhCharBlock(core,[1.08,.29,.69],shadow,[0,1.22,0],.045);
    bhCharBlock(core,[.56,.29,.59],fur,[0,2.36,0],.03);
    bhCharPrism(core,[[-.28,2.20],[.28,2.20],[.34,1.77],[.29,1.36],[-.29,1.36],[-.34,1.77]],.07,white,[0,0,.437]);
    bhCharPrism(core,[[-.326,1.91],[.326,1.91],[.34,1.77],[.322,1.62],[-.322,1.62],[-.34,1.77]],.016,0xe6e4e7,[0,0,.479]);
    bhCharPrism(core,[[-.322,1.62],[.322,1.62],[.29,1.36],[-.29,1.36]],.016,gray,[0,0,.479]);
    for(const s of [-1,1]) {
        const leg=new T.Group();leg.position.set(s*.34,.94,0);core.add(leg);
        const thigh=bhCharBlock(leg,[.39,.56,.44],fur,[s*.055,-.11,0],.04);thigh.rotation.z=s*.20;
        bhCharBlock(leg,[.40,.32,.44],light,[s*.11,-.47,0],.035);
        bhCharBlock(leg,[.49,.25,.50],shadow,[s*.11,-.58,.015],.02);
        // Tenis grandes em degraus: branco, sem cadarcos ou acessorios metalicos.
        bhCharBlock(leg,[.52,.18,.55],white,[s*.11,-.665,.14],.025);
        bhCharBlock(leg,[.63,.23,.83],white,[s*.11,-.80,.16],.025);
        bhCharBlock(leg,[.65,.10,.86],gray,[s*.11,-.89,.16],.008);
        legs.push(leg);
        const arm=new T.Group();arm.position.set(s*1.02,1.72,0);core.add(arm);
        bhCharBlock(arm,[.63,.48,.64],light,[-s*.04,.30,0],.085);
        const bicep=bhCharBlock(arm,[.49,.48,.50],fur,[s*.015,-.11,0],.06);bicep.rotation.z=s*.13;
        const forearm=bhCharBlock(arm,[.51,.33,.51],light,[s*.04,-.455,.025],.055);forearm.rotation.z=s*.10;
        bhCharBlock(arm,[.53,.14,.54],shadow,[s*.04,-.64,.025],.014);
        bhCharBlock(arm,[.51,.39,.52],white,[s*.04,-.86,.06],.055);
        bhCharBlock(arm,[.18,.23,.28],white,[-s*.21,-.87,.21],.03);
        arms.push(arm);
        const ear=new T.Group();ear.position.set(s*.3,3.74,0);ear.rotation.z=-s*.17;core.add(ear);
        bhCharBlock(ear,[.33,1.05,.23],fur,[0,-.025,0],.014);
        bhCharBlock(ear,[.19,.81,.025],pink,[0,-.045,.129]);
        bhCharBlock(ear,[.30,.065,.22],light,[0,.46,0],.006);
        ears.push(ear);
    }
    const head=new T.Group();head.position.set(0,2.85,0);core.add(head);
    bhCharBlock(head,[1.26,.83,.99],fur,[0,.025,0],.06);
    bhCharBlock(head,[1.14,.30,.92],fur,[0,-.28,.025],.035);
    bhCharBlock(head,[1.16,.28,.25],white,[0,-.215,.495],.025);
    for(const s of [-1,1]) {
        bhCharBlock(head,[.25,.23,.27],white,[s*.575,-.20,.405],.018);
        bhCharBlock(head,[.11,.22,.24],shadow,[s*.67,-.195,.30],.014);
    }
    const face={brows:[],eyes:[],pupils:[]};
    for(const s of [-1,1]) {
        face.eyes.push(bhCharBlock(head,[.30,.30,.03],white,[s*.28,.105,.514],.006));
        const pupil=new T.Group();pupil.position.set(s*.255,.085,.542);head.add(pupil);
        bhCharBlock(pupil,[.135,.23,.025],shadow,[0,0,0],.005);
        bhCharBlock(pupil,[.028,.045,.012],0xfdfbff,[-.028,.070,.019]);face.pupils.push(pupil);
        const brow=bhCharBlock(head,[.36,.10,.075],shadow,[s*.28,.275,.55],.008);face.brows.push(brow);
    }
    bhCharBlock(head,[.18,.105,.09],pink,[0,-.045,.642],.009);
    bhCharBlock(head,[.14,.025,.015],pale,[0,-.004,.691],.003);
    const mouth=new T.Group();mouth.position.set(0,-.252,.635);head.add(mouth);
    const smile=new T.Group(),gasp=new T.Group(),frown=new T.Group(),open=new T.Group();mouth.add(smile,gasp,frown,open);
    bhCharPrism(smile,[[-.15,.025],[-.11,-.004],[0,-.019],[.10,.002],[.15,.045],[.13,.003],[.10,-.022],[0,-.043],[-.12,-.025]],.025,shadow,[0,0,0]);
    bhCharPrism(gasp,[[-.066,.045],[-.04,.085],[.04,.085],[.066,.045],[.066,-.04],[.035,-.08],[-.035,-.08],[-.066,-.04]],.025,0x2b1319,[0,0,0]);
    bhCharBlock(gasp,[.075,.023,.012],0xd95260,[0,-.050,.022],.006);
    bhCharPrism(frown,[[-.145,-.025],[-.08,.002],[0,.012],[.08,.002],[.145,-.025],[.08,.023],[0,.035],[-.08,.023]],.025,shadow,[0,0,0]);
    bhCharPrism(open,[[-.17,.055],[-.07,.030],[.06,.037],[.17,.070],[.14,-.015],[.08,-.075],[0,-.090],[-.09,-.065],[-.15,-.01]],.025,0x2b1319,[0,0,0]);
    bhCharPrism(open,[[-.135,.047],[-.065,.035],[.065,.041],[.135,.058],[.11,.025],[-.09,.020]],.012,white,[0,0,.022]);
    bhCharBlock(open,[.12,.025,.012],0xd95260,[.005,-.06,.022],.008);
    Object.assign(face,{mouth,smile,gasp,frown,open});
    bhCharBlock(head,[.20,.14,.20],fur,[0,.46,-.035],.012);
    bhCharBlock(head,[.12,.095,.14],light,[0,.57,-.035],.008);
    const tail=new T.Group();tail.position.set(0,1.05,-.45);core.add(tail);
    bhCharBlock(tail,[.30,.29,.30],white,[0,0,-.055],.025);
    g.scale.setScalar(.8);g.userData={core,legs,arms,ears,head,tail,face,modelVersion:32};
    bhBigExpression(g,'smug');return g;
}

function bhBigExpression(model,style,t=0,talking=false) {
    const f=model.userData.face,panic=style==='panic',angry=style==='angry';
    f.brows.forEach((b,i)=>{const s=i===0?-1:1;b.position.y=panic?.335:angry?.235:.275;b.rotation.z=s*(panic?-.08:angry?.40:.25);});
    f.eyes.forEach(e=>e.scale.y=panic?1.10:angry?.88:1);
    f.pupils.forEach(e=>{e.scale.x=panic?.80:1;e.scale.y=panic?.92:1;});
    f.smile.visible=!panic&&!angry&&!talking;f.gasp.visible=panic;f.frown.visible=angry&&!talking;f.open.visible=talking&&!panic;
    f.mouth.scale.set(1,talking?.75+Math.abs(Math.sin(t*17))*.45:1,1);
}

function mkBibi() {
    const g = new T.Group(), core = new T.Group();
    g.name = 'Bibibunn'; g.add(core);
    const white=0xfff6fa, shade=0xe5dce5, pink=0xf62a91, pale=0xff9bc9;
    const plum=0x332432, dark=0x211d29, facet=0x473444, deepPink=0xa51c62;
    const legs=[], arms=[], ears=[], hair=[];
    // Concept: blocos largos, corpete angular e abas divididas, sem cabelo longo.
    bhCharBody(core, [[1.13,.40,.27],[1.31,.29,.23],[1.52,.29,.24],[1.73,.44,.31],[1.88,.47,.29],[1.98,.33,.23]], dark);
    // Decote em coracao: duas placas facetadas integradas ao corpete.
    for(const s of [-1,1]) {
        const shoulder=bhCharBlock(core,[.23,.18,.28],white,[s*.47,1.88,-.015],.015);shoulder.rotation.z=-s*.30;
        const panel=bhCharPrism(core, [[s*.025,1.78],[s*.24,1.95],[s*.43,1.87],[s*.40,1.64],[s*.17,1.61]], .12, facet, [0,0,.235]);
        panel.rotation.y=s*.09;
        bhCharPrism(core, [[s*.015,1.82],[s*.23,2.00],[s*.44,1.90],[s*.43,1.82],[s*.24,1.91],[s*.02,1.73]], .045, pink, [0,0,.335]);
        bhCharPrism(core, [[s*.28,1.39],[s*.35,1.26],[s*.48,1.21],[s*.34,1.12],[s*.24,1.23]], .045, pink, [0,0,.27]);
    }
    bhCharPrism(core, [[-.12,1.30],[.12,1.30],[.085,1.58],[.17,1.76],[0,1.66],[-.17,1.76],[-.085,1.58]], .04, pink, [0,0,.285]);
    bhCharDiamond(core, [.15,.19,.065], pink, [0,1.84,.39]);
    bhCharBody(core, [[.98,.22,.23],[1.12,.39,.28],[1.26,.43,.27]], plum);
    bhCharBlock(core,[.30,.15,.29],white,[0,2.02,-.015],.018);
    bhCharBlock(core,[.36,.085,.33],dark,[0,2.035,-.015],.008);
    // Abas laterais e traseiras com borda rosa: a silhueta da folha de referencia.
    for(const s of [-1,1]) {
        const flap=new T.Group(); flap.rotation.y=-s*.20; core.add(flap);
        bhCharPrism(flap, [[s*.32,1.30],[s*.53,1.22],[s*.86,.52],[s*.53,.69],[s*.32,.94]], .105, deepPink, [0,0,-.10]);
        bhCharPrism(flap, [[s*.36,1.27],[s*.52,1.20],[s*.83,.56],[s*.52,.72],[s*.35,.94]], .025, pink, [0,0,-.027]);
        bhCharPrism(flap, [[s*.40,1.21],[s*.49,1.17],[s*.73,.68],[s*.54,.80],[s*.41,.97]], .02, plum, [0,0,-.002]);
        bhCharPrism(core, [[s*.025,1.27],[s*.37,1.27],[s*.53,.58],[s*.10,.76]], .09, deepPink, [0,0,-.32]);
        bhCharPrism(core, [[s*.065,1.22],[s*.33,1.22],[s*.46,.69],[s*.14,.82]], .025, plum, [0,0,-.38]);
        const leg=new T.Group();leg.position.set(s*.27,.83,0);core.add(leg);
        bhCharBlock(leg,[.34,.39,.36],white,[0,.025,0],.025);
        bhCharBlock(leg,[.37,.105,.39],pink,[0,-.115,0],.008);
        bhCharBlock(leg,[.39,.48,.43],dark,[0,-.40,0],.025);
        bhCharBlock(leg,[.40,.12,.45],facet,[0,-.25,.005],.018);
        bhCharBlock(leg,[.43,.16,.47],plum,[0,-.59,.01],.022);
        bhCharBlock(leg,[.46,.255,.65],dark,[0,-.725,.10],.035);
        bhCharBlock(leg,[.48,.065,.68],pink,[0,-.835,.10],.008);
        bhCharBlock(leg,[.29,.12,.075],facet,[0,-.72,.426],.01);
        bhCharPrism(leg,[[-.12,-.82],[.12,-.82],[0,-.73]],.018,deepPink,[0,0,.444]);
        leg.children.forEach(part=>part.position.x+=s*.03);
        legs.push(leg);
        const arm=new T.Group();arm.position.set(s*.76,1.6,0);core.add(arm);
        const upper=bhCharBlock(arm,[.28,.38,.31],white,[-s*.065,.12,0],.022);upper.rotation.z=-s*.35;
        bhCharBlock(arm,[.37,.10,.38],pink,[0,-.065,.005],.008);
        bhCharBlock(arm,[.38,.39,.39],plum,[0,-.31,.005],.035);
        bhCharBlock(arm,[.39,.12,.42],dark,[0,-.50,.015],.016);
        bhCharBlock(arm,[.43,.28,.44],dark,[0,-.67,.04],.032);
        bhCharBlock(arm,[.15,.20,.25],facet,[-s*.215,-.61,.11],.02);
        bhCharBlock(arm,[.30,.14,.025],facet,[0,-.64,.272],.012);
        arms.push(arm);
        const ear=new T.Group();ear.position.set(s*.3,2.84,0);ear.rotation.z=-s*.19;core.add(ear);
        bhCharBlock(ear,[.32,1.03,.23],white,[0,.50,0],.022);
        bhCharBlock(ear,[.19,.78,.025],pale,[0,.48,.127]);
        bhCharBlock(ear,[.055,.78,.028],0xf37fae,[-s*.067,.48,.132]);
        ears.push(ear);
    }
    const head=new T.Group();head.position.set(0,2.38,0);core.add(head);
    bhCharBlock(head,[1.13,.78,.93],white,[0,.025,0],.045);
    bhCharBlock(head,[.92,.25,.91],white,[0,-.30,.015],.025);
    // Focinho largo em blocos; olhos e sobrancelhas continuam legiveis de longe.
    for(const s of [-1,1]) {
        bhCharBlock(head,[.36,.20,.29],white,[s*.405,-.185,.455],.012);
        bhCharBlock(head,[.19,.07,.018],shade,[s*.43,-.265,.603]);
    }
    const face={brows:[],eyes:[],pupils:[],lids:[]};
    for(const s of [-1,1]) {
        const eye=bhCharBlock(head,[.32,.255,.035],0xfffdff,[s*.29,-.015,.481],.008);face.eyes.push(eye);
        const pupil=new T.Group();pupil.position.set(s*.275,-.02,.512);head.add(pupil);
        bhCharBlock(pupil,[.12,.205,.023],deepPink,[0,0,0],.006);
        bhCharBlock(pupil,[.063,.19,.018],dark,[-s*.015,0,.016]);
        bhCharBlock(pupil,[.025,.055,.014],white,[-.024,.053,.032]);face.pupils.push(pupil);
        const lid=bhCharBlock(head,[.36,.045,.04],dark,[s*.29,.104,.516]);lid.rotation.z=s*.16;face.lids.push(lid);
        bhCharPrism(head,[[s*.42,.105],[s*.55,.135],[s*.65,.23],[s*.62,.095],[s*.55,.045],[s*.43,.035]],.035,dark,[0,0,.527]);
        bhCharPrism(head,[[s*.44,.058],[s*.57,.065],[s*.635,.13],[s*.60,.025],[s*.47,-.005]],.035,dark,[0,0,.53]);
        const brow=new T.Group();brow.position.set(s*.29,.135,.535);head.add(brow);
        bhCharPrism(brow,[[s*.18,.085],[-s*.15,-.04],[-s*.15,.055],[s*.105,.165]],.04,pink,[0,0,0]);face.brows.push(brow);
    }
    bhCharBlock(head,[.155,.085,.07],pink,[0,-.143,.586],.008);
    bhCharBlock(head,[.115,.02,.015],pale,[0,-.114,.629]);
    const mouth=new T.Group();mouth.position.set(0,-.305,.527);head.add(mouth);
    const smile=new T.Group(),gasp=new T.Group();mouth.add(smile,gasp);
    bhCharPrism(smile,[[-.17,.055],[-.08,.022],[.02,.020],[.12,.055],[.17,.08],[.14,-.015],[.095,-.068],[.025,-.088],[-.06,-.068],[-.13,-.025]],.035,0x310f22,[0,0,0]);
    bhCharPrism(smile,[[-.14,.046],[-.04,.024],[.08,.036],[.13,.063],[.08,.015],[-.045,.002]],.018,white,[0,0,.027]);
    bhCharBlock(smile,[.095,.025,.018],0xe74c83,[.025,-.060,.029],.008);
    bhCharPrism(gasp,[[-.065,.06],[-.04,.10],[.04,.10],[.065,.06],[.065,-.055],[.035,-.09],[-.035,-.09],[-.065,-.055]],.035,0x310f22,[0,0,0]);
    bhCharBlock(gasp,[.07,.026,.018],0xe74c83,[0,-.061,.029],.008);
    face.mouth=mouth;face.smile=smile;face.gasp=gasp;
    // Coroa preta com pontas largas atras do losango fuchsia.
    bhCharPrism(head,[[-.33,.405],[-.33,.61],[-.22,.58],[-.17,.82],[0,.66],[.17,.82],[.22,.58],[.33,.61],[.33,.405]],.25,dark,[0,0,.035]);
    bhCharDiamond(head,[.145,.235,.095],pink,[0,.58,.16]);
    const tail=new T.Group();tail.position.set(0,1.08,-.34);core.add(tail);
    bhCharBlock(tail,[.29,.29,.30],white,[0,0,-.17],.035);
    g.userData={core,head,legs,arms,ears,hair,tail,face,modelVersion:31};
    g.scale.setScalar(.84);
    bhBibiExpression(g,'smug');
    return g;
}

// As mesmas pecas faciais sao usadas pelo jogo e pela galeria.
function bhBibiExpression(model,style,t=0,talking=false) {
    const f=model.userData.face,panic=style==='panic',angry=style==='angry';
    f.brows.forEach((b,i)=>{const s=i===0?-1:1;b.position.y=panic?.24:angry?.10:.135;b.rotation.z=panic?-s*.28:angry?s*.12:i===0?-.08:.06;});
    f.eyes.forEach(e=>e.scale.y=panic?1.17:angry?.85:1);
    f.pupils.forEach(e=>{e.scale.y=panic?.92:1;e.scale.x=panic?.75:1;});
    f.lids.forEach((e,i)=>{e.position.y=panic?.145:.104;e.rotation.z=(i===0?-1:1)*(panic?.03:angry?.27:.16);});
    f.smile.visible=!panic;f.gasp.visible=panic;
    f.mouth.scale.set(angry?1.12:1,talking?.80+Math.abs(Math.sin(t*17))*.45:angry?1.25:1,1);
}

// Materiais compartilhados dentro de cada documento de fase; sem texturas externas.
const bhCharMaterials=new Map();
function bhCharMaterial(color) {
    if(!bhCharMaterials.has(color)) bhCharMaterials.set(color,new T.MeshLambertMaterial({color}));
    return bhCharMaterials.get(color);
}
function bhCharMesh(parent,geometry,color,position) {
    // r128 usa Lambert por vertice. Normais separadas preservam as facetas sem
    // depender da opcao flatShading, ausente nesse material nessa versao.
    const flat=geometry.index?geometry.toNonIndexed():geometry;
    flat.computeVertexNormals();
    const m=new T.Mesh(flat,bhCharMaterial(color)); m.position.set(...position); parent.add(m); return m;
}
function bhCharPrism(parent,points,depth,color,position) {
    const shape=new T.Shape();shape.moveTo(...points[0]);
    points.slice(1).forEach(p=>shape.lineTo(...p));shape.closePath();
    const geo=new T.ExtrudeGeometry(shape,{depth,bevelEnabled:false,steps:1,curveSegments:1});
    geo.translate(0,0,-depth/2);
    return bhCharMesh(parent,geo,color,position);
}
function bhCharDiamond(parent,radii,color,position) {
    const m=bhCharMesh(parent,new T.OctahedronGeometry(1),color,position);
    m.scale.set(...radii);return m;
}
function bhCharBlock(parent,size,color,position,bevel=0) {
    const [w,h,d]=size;
    if(!bevel) return bhCharMesh(parent,new T.BoxGeometry(w,h,d),color,position);
    const b=Math.min(bevel,w*.24,h*.24,d*.24), shape=new T.Shape();
    const x=w/2-b,y=h/2-b;
    shape.moveTo(-x,-y);shape.lineTo(x,-y);shape.lineTo(x,y);shape.lineTo(-x,y);shape.closePath();
    const geo=new T.ExtrudeGeometry(shape,{depth:d-2*b,bevelEnabled:true,bevelThickness:b,bevelSize:b,bevelSegments:1,steps:1,curveSegments:1});
    geo.translate(0,0,-(d-2*b)/2);
    return bhCharMesh(parent,geo,color,position);
}
function bhCharOval(parent,radii,color,position) {
    const m=bhCharMesh(parent,new T.SphereGeometry(1,8,6),color,position);m.scale.set(...radii);return m;
}
function bhCharBody(parent,rings,color,position=[0,0,0]) {
    const vertices=[],indices=[],segments=8;
    for(const [y,rx,rz] of rings) for(let i=0;i<segments;i++) {
        const a=i/segments*Math.PI*2;vertices.push(Math.sin(a)*rx,y,Math.cos(a)*rz);
    }
    for(let j=0;j<rings.length-1;j++) for(let i=0;i<segments;i++) {
        const a=j*segments+i,b=j*segments+(i+1)%segments,c=a+segments,d=b+segments;
        indices.push(a,b,c,b,d,c);
    }
    for(let i=1;i<segments-1;i++) {indices.push(0,i+1,i);const o=(rings.length-1)*segments;indices.push(o,o+i,o+i+1);}
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals();
    return bhCharMesh(parent,geo,color,position);
}

function mkCage() {
    const g = new T.Group();
    const base = mesh(B(2.6, .18, 2.6), 0x60656f, [0, .09, 0]);
    g.add(base);
    g.add(mesh(B(2.7, .12, 2.7), 0x8f6a35, [0, -.02, 0]));
    for (const sx of [-1, 1])
        for (const sz of [-1, 1])
            g.add(mesh(B(.16, 4.2, .16), 0xaeb4be, [sx * 1.16, 2.1, sz * 1.16]));
    for (const sx of [-1, 1])
        for (let i = -1; i <= 1; i++)
            g.add(mesh(B(.1, 3.7, .1), 0xcdd2d9, [sx * 1.16, 2.0, i * .58]));
    for (const sz of [-1, 1])
        for (let i = -1; i <= 1; i++)
            g.add(mesh(B(.1, 3.7, .1), 0xcdd2d9, [i * .58, 2.0, sz * 1.16]));
    g.add(mesh(B(2.6, .14, 2.6), 0x525761, [0, 4.18, 0]));
    g.add(mesh(B(2.9, .14, .18), 0x404552, [0, 4.5, 0]));
    g.add(mesh(B(.18, .14, 2.9), 0x404552, [0, 4.5, 0]));
    g.add(mesh(B(.4, .16, .22), 0xdeb34b, [0, 4.52, 1.33]));
    g.visible = false;
    return g;
}
const vix = mkFox(), bl = mkBig(), bibi = mkBibi(), cage = mkCage(), vy0 = hp(-10), by0 = hp(-398);
vix.position.set(2.4, vy0, -10);
bl.position.set(0, by0, -398);
bibi.visible = false;
bibi.position.set(7, by0, -396);
S.add(vix, bl, bibi, cage);
reset();
// Expressive low-poly facial rigs: brows, mouth and eye highlights, integrated into each model
function makeFace(target, eyeX, ey, ez, browColor, mouthColor, scale = 1) {
    const group = new T.Group();
    target.add(group);
    const brows = [];
    for (const sign of [-1, 1]) {
        const br = mesh(B(.29 * scale, .075 * scale, .065 * scale), browColor, [sign * eyeX, ey + .2 * scale, ez]);
        group.add(br);
        brows.push(br);
    }
    const mouth = mesh(B(.28 * scale, .065 * scale, .07 * scale), mouthColor, [0, ey - .28 * scale, ez + .01]);
    group.add(mouth);
    return { brows, mouth };
}
const faces = {
    ck: makeFace(bun, .20, 1.76, .51, 0x31144b, 0x29162d, 1),
    ld: bl.userData.face,
    bibi: bibi.userData.face
};
function faceAct(w, style, t, dt, active) {
    if (w === 'ld') { bhBigExpression(bl, style, t, active); return; }
    if (w === 'bibi') { bhBibiExpression(bibi, style, t, active); return; }
    const r = faces[w];
    if (!r)
        return;
    const isTalking = active, furious = style === 'angry', panic = style === 'panic', smug = style === 'smug', hurt = style === 'hurt';
    r.mouth.scale.y = 1 + (isTalking ? (1.5 + Math.abs(Math.sin(t * 17)) * 4) : panic ? 3.2 : hurt ? 1.8 : .2);
    r.mouth.scale.x = panic ? .60 : smug ? 1.3 : 1;
    r.brows[0].rotation.z = panic ? .42 : furious ? -.36 : smug ? -.28 : hurt ? .25 : .07 * Math.sin(t * 3);
    r.brows[1].rotation.z = panic ? -.42 : furious ? .36 : smug ? -.16 : hurt ? -.25 : -.07 * Math.sin(t * 3);
    r.brows.forEach(b => b.position.y = (w === 'ck' ? 1.97 : w === 'ld' ? .30 : .1) + (panic ? .10 : furious ? -.08 : 0));
}
// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
// ---- bichos antropomórficos passeando e comentando sobre a rotina e Bunnyldu
function mkCitizen(opts) {
    const g = new T.Group(), core = new T.Group();
    g.add(core);
    const a = (w, h, d, c, x, y, z, p = core) => { const m = mesh(B(w, h, d), c, [x, y, z]); p.add(m); return m; };
    const fur = opts.fur, face = opts.face, tip = opts.tip || fur, dark = opts.dark || 0x2b2020;
    const legs = [], arms = [];
    for (const sd of [-1, 1]) {
        const leg = new T.Group();
        leg.position.set(sd * .22, .75, 0);
        core.add(leg);
        a(.27, .5, .29, opts.pants || 0x424253, 0, -.27, 0, leg);
        a(.35, .18, .47, opts.boot || 0x58402f, 0, -.58, .08, leg);
        legs.push(leg);
        const arm = new T.Group();
        arm.position.set(sd * .45, 1.5, 0);
        core.add(arm);
        a(.23, .55, .27, fur, 0, -.26, 0, arm);
        a(.25, .18, .29, face, 0, -.57, .03, arm);
        arms.push(arm);
    }
    a(.81, .8, .5, opts.shirt || fur, 0, 1.15, 0);
    a(.56, .4, .055, face, 0, 1.26, .28);
    const head = new T.Group();
    head.position.set(0, 2.04, 0);
    core.add(head);
    a(.83, .67, .64, fur, 0, 0, 0, head);
    a(.63, .28, .18, face, 0, -.18, .36, head);
    for (const sd of [-1, 1]) {
        a(.135, .18, .07, 0xffffff, sd * .22, .06, .338, head);
        a(.075, .13, .045, dark, sd * .22, .045, .38, head);
        a(.25, opts.kind === 'deer' ? .7 : .39, .17, tip, sd * .3, .51, 0, head);
        if (opts.kind === 'cat')
            a(.14, .13, .05, face, sd * .3, .54, .10, head);
    }
    a(.12, .10, .085, dark, 0, -.18, .49, head);
    if (opts.kind === 'deer')
        for (const sd of [-1, 1]) {
            a(.06, .5, .08, 0x805227, sd * .24, .91, 0, head);
            a(.3, .07, .07, 0x805227, sd * .37, 1.03, 0, head);
        }
    if (opts.kind === 'raccoon') {
        for (const sd of [-1, 1])
            a(.28, .18, .035, 0x4c4b54, sd * .2, .07, .355, head);
    }
    if (opts.kind === 'hedgehog') {
        for (let i = -2; i <= 2; i++)
            a(.19, .32, .26, 0x76513a, i * .17, .36, -.27, head);
    }
    if (opts.kind === 'dog')
        a(.14, .3, .21, tip, -.5, .11, 0, head);
    const tail = new T.Group();
    tail.position.set(0, .87, -.35);
    core.add(tail);
    if (opts.kind === 'squirrel' || opts.kind === 'fox') {
        a(.43, .8, .44, fur, 0, .17, -.3, tail);
        a(.36, .36, .4, tip, 0, .53, -.47, tail);
    }
    else if (opts.kind === 'raccoon') {
        a(.35, .48, .35, fur, 0, -.06, -.29, tail);
        a(.36, .15, .36, dark, 0, -.2, -.31, tail);
    }
    else
        a(.27, .27, .38, tip, 0, .03, -.22, tail);
    if (opts.accessory === 'scarf') {
        a(.85, .17, .62, opts.accent, 0, 1.7, 0);
        a(.2, .5, .08, opts.accent, .25, 1.46, .31);
    }
    if (opts.accessory === 'vest')
        a(.86, .64, .54, opts.accent, 0, 1.22, 0);
    if (opts.accessory === 'bag') {
        a(.4, .42, .2, opts.accent, .42, 1.03, .24);
    }
    g.scale.setScalar(opts.scale || .9);
    g.userData = { ...opts, legs, arms, head, tail, core };
    return g;
}
// ---- NPCs vivos: cada bichinho tem sua própria rotina, detalhes e animações
const CIT_ACT = { Nina: { act: 'gather', roam: .2, period: 11 }, Rufus: { act: 'rummage', roam: .2, period: 10 }, Luna: { act: 'sit', roam: 0, period: 12 }, Otto: { act: 'sweep', roam: .7, period: 9 }, Pip: { act: 'study', roam: 0, period: 10 }, Max: { act: 'jog', roam: 1.3, period: 9 }, Fiona: { act: 'talk', roam: .3, period: 10 }, Bento: { act: 'sleep', roam: 0, period: 10 }, Mel: { act: 'dance', roam: .25, period: 10 } };
function citizenDeco(n) {
    const d = n.userData, h = d.head, dk = d.dark || 0x2b2020, add = (p, w, hh, dd, c, x, y, z) => { const m = mesh(B(w, hh, dd), c, [x, y, z]); p.add(m); return m; }, R = d.arms[1], L = d.arms[0];
    d.lids = [-1, 1].map(s => { const m = add(h, .16, .21, .04, d.fur, s * .22, .06, .347); m.scale.y = .001; return m; });
    for (const s of [-1, 1]) {
        const b = add(h, .17, .045, .05, dk, s * .22, .21, .35);
        b.rotation.z = s * .12;
        add(h, .1, .07, .03, 0xff9aa8, s * .34, -.1, .34);
    }
    if (d.kind === 'cat' || d.kind === 'raccoon' || d.kind === 'squirrel')
        for (const s of [-1, 1])
            for (let i = 0; i < 3; i++) {
                const w = add(h, .3, .02, .02, 0xffffff, s * .5, -.12 + i * .06, .42);
                w.rotation.z = s * (i - 1) * .18;
            }
    add(n.userData.core, .84, .1, .52, 0x3a2a22, 0, .77, 0);
    add(n.userData.core, .14, .12, .04, 0xe0b84a, 0, .77, .27);
    const prop = (arm, y) => { const g = new T.Group(); arm.add(g); g.position.set(0, y, .12); return g; };
    switch (d.name) {
        case 'Nina': {
            for (const s of [-1, 1])
                add(h, .07, .11, .04, 0xffffff, s * .06, -.29, .5);
            const bk = new T.Group();
            bk.position.set(-.9, 0, .3);
            n.add(bk);
            add(bk, .5, .3, .5, 0x9a6a3a, 0, .15, 0);
            for (let i = 0; i < 5; i++)
                add(bk, .15, .15, .18, 0x6b4423, (i % 3 - 1) * .14, .36 + (i > 2 ? .12 : 0), i < 3 ? -.1 : .12);
            break;
        }
        case 'Rufus': {
            d.prop = prop(R, -.62);
            add(d.prop, .2, .2, .07, 0xffd23a, 0, 0, 0);
            d.prop.visible = false;
            break;
        }
        case 'Luna': {
            const cu = new T.Group();
            cu.position.set(0, 0, -.2);
            n.add(cu);
            add(cu, 1.1, .3, 1.1, 0xf49ac9, 0, .15, 0);
            add(cu, .9, .12, .9, 0xffc7e4, 0, .34, 0);
            add(h, .14, .14, .06, 0xff7ac2, .3, .62, .12);
            break;
        }
        case 'Otto': {
            d.prop = prop(R, -.6);
            add(d.prop, .07, 1.7, .07, 0x805227, 0, .2, 0);
            add(d.prop, .5, .14, .2, 0xd8b24a, 0, -.7, 0);
            d.prop.rotation.x = .9;
            break;
        }
        case 'Pip': {
            d.prop = prop(R, -.6);
            add(d.prop, .06, .6, .06, 0x805227, 0, .2, 0);
            const r = add(d.prop, .34, .34, .05, 0xbfe8ff, 0, .62, 0);
            r.material.transparent = true;
            r.material.opacity = .6;
            add(d.prop, .4, .06, .07, 0x805227, 0, .44, 0);
            const bk = new T.Group();
            bk.position.set(.9, 0, .2);
            n.add(bk);
            for (let i = 0; i < 3; i++) {
                add(bk, .1, .25, .1, 0xf0e6cc, i * .28 - .28, .12, 0);
                add(bk, .28, .12, .28, 0xe03a3a, i * .28 - .28, .3, 0);
            }
            break;
        }
        case 'Max': {
            add(h, .88, .1, .7, 0xe84a4a, 0, .26, 0);
            add(h, .5, .1, .06, 0xffffff, 0, .26, .35);
            d.tongue = add(h, .1, .2, .04, 0xff6f8a, 0, -.34, .52);
            break;
        }
        case 'Fiona': {
            d.prop = prop(L, -.62);
            add(d.prop, .45, .12, .12, 0xeed9a8, 0, 0, 0);
            add(d.prop, .12, .14, .14, 0xc0392b, .2, 0, 0);
            for (const s of [-1, 1]) {
                const gl = add(h, .22, .22, .03, 0x3a2a2a, s * .22, .05, .37);
                gl.material.transparent = true;
                gl.material.opacity = .3;
            }
            break;
        }
        case 'Bento': {
            const cap = mesh(new T.ConeGeometry(.38, .8, 6), 0x4a6fb5, [.05, .75, 0]);
            cap.rotation.z = -.5;
            h.add(cap);
            cap.add(mesh(new T.SphereGeometry(.1, 5, 4), 0xffffff, [0, .42, 0]));
            d.zz = new T.Group();
            n.add(d.zz);
            for (let i = 0; i < 3; i++) {
                const z = new T.Group();
                for (const [w, hh, x, y, rz] of [[.3, .06, 0, .17, 0], [.3, .06, 0, -.17, 0], [.3, .06, 0, 0, .8]]) {
                    const m = mesh(B(w, hh, .04), 0xdff3ff, [x, y, 0]);
                    m.rotation.z = rz;
                    z.add(m);
                }
                z.visible = false;
                d.zz.add(z);
            }
            break;
        }
        case 'Mel': {
            add(h, .7, .15, .04, 0x111111, 0, .06, .37);
            add(h, .14, .14, .06, 0xffd23a, -.34, -.02, .2);
            add(h, .14, .14, .06, 0xff7ac2, .3, .62, .12);
            break;
        }
    }
}
function citizenLife(n, t, dt, ph) {
    const d = n.userData, u = d.u || (d.u = { px: n.position.x, pz: n.position.z, bl: 0, bn: 2, w: 0 });
    const dxp = st.x - n.position.x, dzp = st.z - n.position.z, near = Math.hypot(dxp, dzp), spd = Math.hypot(n.position.x - u.px, n.position.z - u.pz) / Math.max(dt, .001);
    u.px = n.position.x;
    u.pz = n.position.z;
    const k = ((t + d.phase * 2) % d.period) / d.period, win = (a, b, r = .06) => Math.max(0, Math.min(1, (k - a) / r, (b - k) / r)), sm = (o, ax, v, s = 12) => { o.rotation[ax] += (v - o.rotation[ax]) * Math.min(1, dt * s); }, wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
    const A = d.arms, Lg = d.legs, H = d.head, C = d.core;
    let crouch = 0, bend = 0, la = 0, ra = 0, laz = 0, raz = 0, lg = Math.min(.55, spd * .45), lf = 9, hx = 0, hy = 0, hz = Math.sin(t * 1.3 + d.phase) * .05, tl = Math.sin(t * 2 + d.phase) * .16, tz = 0, sit = 0, sleep = 0, bounce = 0, roty = 0, cz = 0, base = Math.cos(ph) >= 0 ? Math.PI * .42 : -Math.PI * .42, gw = 1;
    switch (d.act) {
        case 'gather': {
            const b = win(.08, .4), e = win(.45, .78);
            crouch = .3 * b;
            bend = .45 * b;
            la = (-.4 - Math.sin(t * 9) * .7) * b - 2 * e;
            ra = (-.4 + Math.sin(t * 9) * .7) * b - 2 * e;
            hx = .4 * b + Math.sin(t * 16) * .1 * e;
            tl += Math.sin(t * 10) * .3 * e;
            base = .9;
            break;
        }
        case 'rummage': {
            const b = win(.05, .5), e = win(.55, .85);
            crouch = .35 * b;
            bend = .4 * b;
            la = (-.9 + Math.sin(t * 14) * .8) * b;
            ra = (-.9 - Math.sin(t * 14) * .8) * b - 2.5 * e;
            raz = .3 * e;
            hy = Math.sin(t * 3) * .4 * e;
            hx = .3 * b - .1 * e;
            if (d.prop)
                d.prop.visible = e > .1;
            base = -.9;
            break;
        }
        case 'sit': {
            const s = win(.7, .92, .1);
            sit = 1;
            la = -.35 - 2.6 * s;
            ra = -.35 - 2.6 * s;
            hx = -.12 + Math.sin(t * .7) * .05 - .3 * s;
            tl = Math.sin(t * 1.5) * .5;
            tz = Math.sin(t * 1.5) * .2;
            lg = 0;
            base = .25;
            break;
        }
        case 'sweep': {
            const sw = Math.sin(t * 3.2 + d.phase), w2 = win(.75, .92);
            la = -1 * (1 - w2) - .2 * w2;
            ra = -1 * (1 - w2) - 2.7 * w2;
            laz = sw * .35 * (1 - w2);
            raz = sw * .35 * (1 - w2) + .2 * w2;
            roty = sw * .25 * (1 - w2);
            hx = -.2 * w2;
            if (w2 > .1)
                lg = 0;
            break;
        }
        case 'study': {
            const sc = near < 3.2 ? 1 : 0;
            crouch = .4 + .15 * sc;
            bend = .4 + .2 * sc;
            ra = -1.4 + Math.sin(t * 1.7) * .15 - sc * .2;
            raz = Math.sin(t * 1.1) * .2;
            la = -.5 - sc * .9;
            hx = .35 + Math.sin(t * 2.4) * .1 + sc * .35;
            hy = Math.sin(t * 1.3) * .3 * (1 - sc);
            hz += Math.sin(t * 30) * .03 * sc;
            lg = 0;
            base = .6;
            if (sc)
                gw = 0;
            break;
        }
        case 'jog': {
            const s = win(.72, .92, .05);
            lf = 10.5;
            lg = .7 * (1 - s);
            la = Math.sin(t * 10) * .9 * (1 - s) - 3 * s;
            ra = -Math.sin(t * 10) * .9 * (1 - s) - 3 * s;
            bounce = Math.abs(Math.sin(t * 10)) * .12 * (1 - s);
            tz = Math.sin(t * 14) * .5;
            tl = Math.sin(t * 14) * .1;
            hx = Math.sin(t * 20) * .05;
            if (d.tongue)
                d.tongue.visible = Math.sin(t * 12) > -.3;
            break;
        }
        case 'talk': {
            const ga = Math.sin(t * 3.1), p = win(.7, .95);
            la = -.8 + ga * .5;
            ra = -1 - ga * .5 * (1 - p) - .6 * p;
            laz = .3 + ga * .2;
            raz = (.3 + ga * .2) * (1 - p) + .1 * p;
            hx = Math.sin(t * 6.2) * .08;
            hy = Math.sin(t * .9) * .35;
            tl = Math.sin(t * 2.5) * .3;
            tz = Math.sin(t * 2.5) * .25;
            base = 0;
            break;
        }
        case 'sleep': {
            u.w = Math.max(0, Math.min(1, u.w + (near < 3.2 ? dt * 3 : -dt * .5)));
            const s = 1 - u.w;
            sleep = s;
            sit = .6 * s;
            hx = .55 * s + Math.sin(t * 1.2) * .04 * s - .3 * u.w;
            la = -.3 * s - 2.8 * u.w * (.85 + Math.sin(t * 3) * .15);
            ra = la;
            lg = 0;
            gw = u.w > .6 ? 1 : 0;
            C.scale.y = 1 + Math.sin(t * 1.6) * .02 * s;
            if (d.zz)
                d.zz.visible = s > .7;
            base = -.2;
            break;
        }
        case 'dance': {
            const q = Math.sin(t * 5);
            bounce = Math.abs(q) * .1;
            cz = q * .08;
            la = -1.8 + q * .9;
            ra = -1.8 - q * .9;
            laz = .5;
            raz = .5;
            hy = Math.sin(t * 2.5) * .3;
            hz = q * .12;
            tl = q * .4;
            tz = q * .3;
            lg = .45;
            base = .3;
            break;
        }
    }
    const g = Math.max(0, Math.min(1, (5.2 - near) / 1.2)) * gw;
    if (g > .5) {
        ra = -2.7;
        raz = .45 + Math.sin(t * 9) * .4;
        crouch *= .3;
        bend *= .3;
    }
    const ry = (near < 6.5 && sleep < .5) ? Math.atan2(dxp, dzp) : base;
    n.rotation.y += wrap(ry - n.rotation.y) * Math.min(1, dt * 6);
    n.position.y = gh(n.position.x, n.position.z) + bounce;
    const cs = Math.min(1, dt * 12);
    C.position.y += ((-crouch * .9 - sit * .5) - C.position.y) * cs;
    C.rotation.x += (bend + sit * .1 - C.rotation.x) * cs;
    C.rotation.y += (roty - C.rotation.y) * cs;
    C.rotation.z += (cz - C.rotation.z) * cs;
    if (d.act !== 'sleep')
        C.scale.y += (1 - C.scale.y) * cs;
    Lg.forEach((l, i) => sm(l, 'x', -sit * 1.35 - crouch * .9 + Math.sin(t * lf + i * Math.PI) * lg));
    sm(A[0], 'x', la);
    sm(A[1], 'x', ra);
    sm(A[0], 'z', -laz);
    sm(A[1], 'z', raz);
    sm(H, 'x', hx);
    sm(H, 'y', hy);
    sm(H, 'z', hz);
    sm(d.tail, 'x', tl);
    sm(d.tail, 'z', tz);
    u.bn -= dt;
    if (u.bn < 0) {
        u.bn = 2.5 + Math.random() * 3;
        u.bl = .13;
    }
    u.bl = Math.max(0, u.bl - dt);
    const cl = (sleep > .5 || u.bl > 0) ? 1 : .001;
    if (d.lids)
        d.lids.forEach(m => m.scale.y = cl);
    if (d.zz) {
        d.zz.children.forEach((z, i) => { const w = ((t * .45 + i / 3) % 1); z.position.set(.35 + w * .35, 2.5 + w * .9, .2); z.scale.setScalar(.45 + w * .5); z.rotation.z = Math.sin(t * 2 + i) * .1; z.visible = sleep > .7 && w < .95; });
        d.zz.rotation.y = -n.rotation.y;
    }
}
const citizens = [];
const CITIZENS = [
    { name: 'Nina', kind: 'squirrel', fur: 0xc77930, face: 0xf9e2bb, tip: 0xf9edc9, shirt: 0x68a85b, pants: 0x66533e, accent: 0xecc563, accessory: 'scarf', z: -43, x: -1.8,
        lines: ['O silêncio acabou quando a Bibibunn passou voando com uma jaula!', 'Ouvi os pássaros seguindo o vale. Tenha cuidado com a água!'] },
    { name: 'Rufus', kind: 'raccoon', fur: 0x827c87, face: 0xe6ded7, tip: 0x56515b, shirt: 0x447d9b, pants: 0x364354, accent: 0xe3a840, accessory: 'bag', z: -115, x: 1.6,
        lines: ['Estou consertando as coisas que os ursos quebraram na trilha.', 'Se uma piranha começar a se agitar, espere o salto antes de atravessar.'] },
    { name: 'Luna', kind: 'cat', fur: 0xc3a5da, face: 0xf8e4ee, tip: 0x8b6bb2, shirt: 0x74438c, pants: 0x55416a, accent: 0xfa92cf, accessory: 'scarf', z: -213, x: -1.8,
        lines: ['Aqui nas montanhas eu observo as nuvens e os pássaros.', 'Vi a Bibibunn levar uma jaula enorme na direção das ruínas!'] },
    { name: 'Otto', kind: 'deer', fur: 0xa26f46, face: 0xf0cfa3, tip: 0xb48d65, shirt: 0x6a8c4d, pants: 0x695039, accent: 0xd6bb72, accessory: 'vest', z: -336, x: 1.5, scale: .98,
        lines: ['As pontes antigas precisam de manutenção. Pisa com cuidado!', 'Há partes da floresta onde correr e saltar faz toda a diferença.'] },
    { name: 'Pip', kind: 'hedgehog', fur: 0xa68557, face: 0xf0d4a6, tip: 0x77533f, shirt: 0xc65750, pants: 0x71533e, accent: 0x5d6938, accessory: 'bag', z: -448, x: -1.7, scale: .77,
        lines: ['Estou catalogando cogumelos raros dos pinheiros!', 'Não é só a água que é perigosa: tem ursos rondando as margens.'] },
    { name: 'Max', kind: 'dog', fur: 0xd6b47d, face: 0xf4e4c7, tip: 0x845c3d, shirt: 0x499eac, pants: 0x555870, accent: 0xb65c3a, accessory: 'scarf', z: -576, x: 1.6,
        lines: ['Corro por aqui todos os dias, mas aqueles ursos me assustam!', 'A Bibibunn foi para o fundo da selva. Não desista do Bunnyldu!'] },
    { name: 'Fiona', kind: 'fox', fur: 0xe76f32, face: 0xffe4c0, tip: 0xf5e2bd, shirt: 0x7e76c2, pants: 0x664655, accent: 0xf4bc6c, accessory: 'vest', z: -669, x: -1.75,
        lines: ['Estou desenhando um mapa das montanhas para os viajantes.', 'A jaula da Bibibunn passou por essa trilha. Estamos tentando ajudar!'] },
    { name: 'Bento', kind: 'raccoon', fur: 0x626b73, face: 0xd7dce0, tip: 0x434751, shirt: 0x6f9a6c, pants: 0x4d474b, accent: 0xe5b35d, accessory: 'bag', z: -793, x: 1.55,
        lines: ['Eu dormia em paz até ouvir uma jaula batendo nas pedras.', 'Vai atrás do seu irmão, Bunnyck. Mas me deixa tirar uma soneca!'] },
    { name: 'Mel', kind: 'cat', fur: 0xebcba0, face: 0xffede0, tip: 0xb88b69, shirt: 0xd17c9f, pants: 0x725f71, accent: 0x6e4d7d, accessory: 'scarf', z: -944, x: -1.5,
        lines: ['A rockeira Bibibunn passou com uma jaula gigante!', 'O caminho adiante é difícil. Estamos torcendo pelo Bunnyldu!'] }
];
for (const opts of CITIZENS) {
    const npc = mkCitizen(opts);
    npc.position.set(opts.x, gh(opts.x, opts.z), opts.z);
    npc.userData.homeX = opts.x;
    npc.userData.homeZ = opts.z;
    npc.userData.phase = rr(0, 7);
    npc.userData.walkspeed = rr(.4, .8);
    Object.assign(npc.userData, CIT_ACT[opts.name] || { act: 'talk', period: 10, roam: .5 });
    citizenDeco(npc);
    S.add(npc);
    citizens.push(npc);
}
let nearCitizen = null, lastCitizen = null, lastCitizenBubble = -1;
function updateCitizens(t, dt) {
    let near = null, dist = 3.6, bubble = null, bubbleDist = 6.2;
    for (const n of citizens) {
        const d = n.userData, ph = t * d.walkspeed + d.phase, xx = d.homeX + Math.sin(ph) * (d.roam ?? .74), zz = d.homeZ + Math.cos(ph * .7) * (d.roam ?? .74) * .84;
        if (pitF(xx, zz) < .12) {
            n.position.x = xx;
            n.position.z = zz;
            n.position.y = gh(xx, zz) + Math.abs(Math.sin(t * 4 + d.phase)) * .035;
        }
        citizenLife(n, t, dt, ph);
        const dd = Math.hypot(st.x - n.position.x, st.z - n.position.z);
        if (dd < dist) {
            near = n;
            dist = dd;
        }
        if (dd < bubbleDist) {
            bubble = n;
            bubbleDist = dd;
        }
    }
    nearCitizen = near;
    if (run && !cv && !dy && bubble && bubbleDist < 6.2) {
        const d = bubble.userData;
        if (bubble !== lastCitizen || Math.floor(t / 6) !== lastCitizenBubble) {
            lastCitizen = bubble;
            lastCitizenBubble = Math.floor(t / 6);
            npcBubble.textContent = d.name + ': ' + d.lines[lastCitizenBubble % d.lines.length];
        }
        const sp = dv.set(bubble.position.x, bubble.position.y + 2.9, bubble.position.z).project(C);
        npcBubble.style.left = ((sp.x * .5 + .5) * innerWidth) + 'px';
        npcBubble.style.top = ((-sp.y * .5 + .5) * innerHeight) + 'px';
        npcBubble.style.display = sp.z < 1 ? 'block' : 'none';
    }
    else {
        npcBubble.style.display = 'none';
        lastCitizen = null;
    }
}
function interactWithCitizen() {
    if (nearV)
        startCv(vixL, null, false, vix);
    else if (nearCitizen) {
        const d = nearCitizen.userData;
        const l = npcEcosystem.dialogueFor(nearCitizen) || [[d.name, d.lines[0]], [d.name, d.lines[1]], ['Bunnyck', 'Valeu pela dica!']];
        npcEcosystem.hide();
        startCv(l, null, false, nearCitizen);
    }
}
// @ts-nocheck
// Bunny Havoc — Ecossistema de NPCs V6.
// Cenas locais e atividades em duplas, sem colisao, quests obrigatorias ou audio adicional.
const npcEcosystem = (() => {
    const isPine = true;
    const settings = isPine ? [
        { lead: 'Rufus', mate: 'Duna', kind: 'raccoon', fur: 0xb6a68f, face: 0xf4e0c5, shirt: 0xa5764c, accent: 0xe8b35b, activity: 'repair',
            lines: [['Rufus', 'Segura essa tábua aí, Duna!'], ['Duna', 'Segurando! Mas ouvi um urso rugindo perto da ponte...'], ['Rufus', 'Bunnyck, espere a piranha saltar antes de atravessar!']],
            chat: ['Rufus: aperta esse parafuso!', 'Duna: essa ponte precisa de carinho...'] },
        { lead: 'Pip', mate: 'Basil', kind: 'hedgehog', fur: 0x8d7959, face: 0xeedeb8, shirt: 0x568875, accent: 0x7ba8d0, activity: 'study',
            lines: [['Pip', 'Basil, você viu esses fungos nos pinheiros?'], ['Basil', 'Vi! Mas a jaula que passou voando era bem mais estranha.'], ['Bunnyck', 'Vocês viram meu irmão?'], ['Basil', 'Siga para as ruínas e fique longe das margens!']],
            chat: ['Pip: anota a cor do cogumelo!', 'Basil: parecem brilhar à noite.'] },
        { lead: 'Fiona', mate: 'Arlo', kind: 'dog', fur: 0xbe9774, face: 0xf5dcc5, shirt: 0x405b8e, accent: 0xdbb66a, activity: 'map',
            lines: [['Fiona', 'Arlo, nosso mapa precisa mostrar o caminho seguro.'], ['Arlo', 'A vilã atravessou o cânion com a jaula!'], ['Fiona', 'Bunnyck, a trilha segue pelo lado dos pinheiros maiores.']],
            chat: ['Fiona: falta desenhar o penhasco...', 'Arlo: e marcar onde os ursos rondam!'] },
        { lead: 'Mel', mate: 'Kira', kind: 'fox', fur: 0xa47a56, face: 0xffe2bd, shirt: 0x725a9e, accent: 0xf0bb62, activity: 'signal',
            lines: [['Mel', 'Kira, acenda a sinalização para Bunnyck!'], ['Kira', 'Vai com tudo! Nós vimos a Bibibunn passar!'], ['Mel', 'Você já está perto das ruínas. Não desiste do seu irmão!']],
            chat: ['Mel: ele já está chegando!', 'Kira: que o caminho esteja livre.'] },
    ] : [
        { lead: 'Nina', mate: 'Tico', kind: 'squirrel', fur: 0x99653d, face: 0xf5ddae, shirt: 0x6ca8a3, accent: 0xf1b752, activity: 'market',
            lines: [['Nina', 'Tico, segura minha cesta! As nozes estão caindo!'], ['Tico', 'Eu seguro! Só espero que o besouro não passe por aqui...'], ['Nina', 'Bunnyck, seu irmão foi para o fim do bosque. Boa sorte!']],
            chat: ['Nina: quantas nozes você achou?', 'Tico: achei sete! Quer dizer... seis.'] },
        { lead: 'Otto', mate: 'Brisa', kind: 'deer', fur: 0xc5a16c, face: 0xf4dfbe, shirt: 0x6f9b85, accent: 0xf3c877, activity: 'sweep',
            lines: [['Otto', 'Brisa, vamos limpar o caminho para os viajantes.'], ['Brisa', 'Pode deixar! Só não varro os cogumelos do Pip.'], ['Otto', 'Bunnyck, nos saltos longos use a corrida!']],
            chat: ['Otto: cuidado com as raízes!', 'Brisa: já tirei três pedras da trilha.'] },
        { lead: 'Fiona', mate: 'Miro', kind: 'raccoon', fur: 0x999aa0, face: 0xf1e2d6, shirt: 0x42697c, accent: 0xdec07e, activity: 'map',
            lines: [['Fiona', 'Miro, marca a clareira aqui no mapa.'], ['Miro', 'Marquei! Aqui vai ser um bom ponto de encontro.'], ['Fiona', 'Bunnyck, cuidado com os perigos do caminho!']],
            chat: ['Miro: essa trilha vai para onde?', 'Fiona: para o grande encontro!'] },
        { lead: 'Mel', mate: 'Puca', kind: 'fox', fur: 0xc9815b, face: 0xf6d9b8, shirt: 0xa94e73, accent: 0xe6c461, activity: 'music',
            lines: [['Mel', 'Puca, começa a música que o Bunnyck está chegando!'], ['Puca', 'Sem som alto! O grandalhão preto está preocupado ali na frente.'], ['Mel', 'Força, Bunnyck! Esperamos ver os dois irmãos juntos de novo!']],
            chat: ['Mel: um, dois, três, dança!', 'Puca: eu errei o passo de novo!'] }
    ];
    const bubble = document.createElement('div');
    bubble.id = 'citizenDuoBubble';
    bubble.style.cssText = 'position:fixed;z-index:11;max-width:270px;pointer-events:none;display:none;transform:translate(-50%,-100%);background:#fff8deed;border:2px solid #7a553a;border-radius:12px;padding:6px 9px;color:#352b34;font:bold 12px system-ui,sans-serif;box-shadow:0 3px 0 #523b3b66;text-align:center';
    document.body.append(bubble);
    const scenes = [];
    const add = (parent, w, h, d, color, x, y, z) => { const m = mesh(B(w, h, d), color, [x, y, z]); parent.add(m); return m; };
    function buildDecor(scene) {
        const g = new T.Group();
        const side = Math.sign(scene.lead.userData.homeX) || 1;
        const x = side * (wp(scene.lead.userData.homeZ) + 1.65);
        const z = scene.lead.userData.homeZ - 1.1;
        g.position.set(x, gh(x, z), z);
        const dark = isPine ? 0x54606a : 0x80613f, plank = isPine ? 0x91a4ad : 0xbd9660;
        // Bancada e objetos manuseados, somente decorativos, fora do corredor de jogo.
        add(g, 1.75, .16, .86, plank, 0, .9, 0);
        for (const s of [-1, 1])
            add(g, .17, .85, .18, dark, s * .7, .46, -.28);
        if (scene.activity === 'market') {
            add(g, .57, .3, .56, 0xb07a42, -.37, 1.18, 0);
            for (let i = 0; i < 4; i++)
                add(g, .16, .13, .15, 0x77502d, -.63 + i * .2, 1.4, (i % 2) * .18);
        }
        else if (scene.activity === 'repair' || scene.activity === 'sweep') {
            add(g, .58, .08, .36, 0x7a6146, 0, 1.08, 0);
            add(g, .23, .08, .1, 0xc2b177, .4, 1.19, .1);
        }
        else if (scene.activity === 'map') {
            const paper = add(g, .85, .055, .52, 0xf2e0aa, 0, 1.07, 0);
            paper.rotation.y = .13;
            add(g, .08, .15, .08, 0x694d45, .34, 1.13, .2);
        }
        else if (scene.activity === 'study') {
            for (let i = 0; i < 3; i++) {
                add(g, .15, .28, .13, 0xf4dfc0, (i - 1) * .42, 1.12, 0);
                add(g, .32, .13, .29, i % 2 ? 0xd46858 : 0x8dad7e, (i - 1) * .42, 1.3, 0);
            }
        }
        else if (scene.activity === 'music') {
            add(g, .56, .12, .45, 0x6a4b7f, 0, 1.07, 0);
            add(g, .12, .15, .1, 0xe7b75b, -.29, 1.2, .02);
        }
        else if (scene.activity === 'signal') {
            const pole = add(g, .11, 2.5, .11, 0x89725b, 0, 1.6, 0);
            const flag = add(g, .85, .48, .06, 0xe7c46b, .48, 2.5, 0);
            scene.flag = flag;
        }
        S.add(g);
        scene.propGroup = g;
    }
    for (const opt of settings) {
        const lead = citizens.find(n => n.userData.name === opt.lead);
        if (!lead)
            continue;
        const side = Math.sign(lead.userData.homeX) || 1;
        const friendX = lead.userData.homeX + side * 1.75, friendZ = lead.userData.homeZ - .48;
        const config = { name: opt.mate, kind: opt.kind, fur: opt.fur, face: opt.face, tip: opt.face, shirt: opt.shirt, accent: opt.accent, pants: 0x575360, accessory: 'scarf', scale: opt.kind === 'hedgehog' ? .81 : .84 };
        const friend = mkCitizen(config);
        friend.position.set(friendX, gh(friendX, friendZ), friendZ);
        friend.userData.homeX = friendX;
        friend.userData.homeZ = friendZ;
        friend.userData.phase = opt.lead.length * .61;
        friend.userData.walkspeed = .4;
        Object.assign(friend.userData, { act: opt.activity === 'music' ? 'dance' : opt.activity === 'study' ? 'study' : 'talk', period: 10, roam: .22, lines: [opt.lines[1][1], opt.lines[2][1]] });
        citizenDeco(friend);
        // Adereços distintos dos personagens principais: boné, medalha, chapéu etc.
        const head = friend.userData.head;
        if (opt.activity === 'repair') {
            add(head, .74, .14, .5, 0x765c3f, 0, .63, 0);
            add(head, .55, .08, .8, 0xcfae65, 0, .58, .3);
        }
        if (opt.activity === 'map') {
            add(head, .66, .12, .52, 0x3a6381, 0, .64, 0);
        }
        if (opt.activity === 'music') {
            add(head, .23, .12, .11, 0xebce52, .21, .54, .12);
        }
        if (opt.activity === 'study') {
            add(head, .39, .1, .41, 0x567d65, 0, .69, 0);
        }
        friend.userData.ecoGuest = true;
        const scene = { ...opt, lead, friend, phase: settings.indexOf(opt) * 1.37 + 1.1, flag: null };
        S.add(friend);
        citizens.push(friend);
        scenes.push(scene);
        buildDecor(scene);
    }
    const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
    const lerpAngle = (current, desired, p) => current + wrap(desired - current) * Math.min(1, p);
    function faceTo(n, target, dt) { const a = Math.atan2(target.position.x - n.position.x, target.position.z - n.position.z); n.rotation.y = lerpAngle(n.rotation.y, a, dt * 4.5); }
    function hide() { bubble.style.display = 'none'; }
    function update(t, dt) {
        if (!run || cv || cs || dy || secretSystems.bonus.active) {
            hide();
            return;
        }
        let selected = null, minDist = 12;
        for (const sc of scenes) {
            const a = sc.lead, b = sc.friend, dist = Math.hypot(st.x - a.position.x, st.z - a.position.z);
            const cycle = (t * .15 + sc.phase) % 1;
            const chatting = cycle < .72;
            // Os NPCs conversam entre si e param para observar Bunnyck.
            if (dist < 5.2) {
                faceTo(a, P, dt);
                faceTo(b, P, dt);
                b.userData.arms[1].rotation.x += Math.sin(t * 4 + sc.phase) * .07;
            }
            else if (chatting) {
                faceTo(a, b, dt);
                faceTo(b, a, dt);
                a.userData.head.rotation.y += Math.sin(t * 2 + sc.phase) * .06;
                b.userData.head.rotation.x += Math.sin(t * 2.3 + sc.phase) * .08;
            }
            if (sc.activity === 'music') {
                a.userData.tail.rotation.z += Math.sin(t * 4.7) * .09;
                b.userData.core.position.y += Math.abs(Math.sin(t * 4.7)) * .04;
            }
            if (sc.activity === 'map') {
                a.userData.arms[1].rotation.x += Math.sin(t * 2.4) * .16;
            }
            if (sc.activity === 'repair' || sc.activity === 'sweep') {
                b.userData.core.rotation.z += Math.sin(t * 3.5 + sc.phase) * .04;
            }
            if (sc.flag) {
                sc.flag.rotation.z = Math.sin(t * 2.2) * .12;
            }
            if (chatting && dist < minDist && dist > 3.1) {
                selected = sc;
                minDist = dist;
            }
        }
        if (selected) {
            npcBubble.style.display = 'none';
            const sc = selected, idx = Math.floor((t * .15 + sc.phase) * 2) % sc.chat.length;
            bubble.textContent = sc.chat[idx];
            const mid = new T.Vector3((sc.lead.position.x + sc.friend.position.x) * .5, Math.max(sc.lead.position.y, sc.friend.position.y) + 3.15, (sc.lead.position.z + sc.friend.position.z) * .5).project(C);
            if (mid.z > -1 && mid.z < 1 && Math.abs(mid.x) < 1.3 && Math.abs(mid.y) < 1.3) {
                bubble.style.left = ((mid.x * .5 + .5) * innerWidth) + 'px';
                bubble.style.top = ((-mid.y * .5 + .5) * innerHeight) + 'px';
                bubble.style.display = 'block';
            }
            else
                hide();
        }
        else
            hide();
    }
    function dialogueFor(n) {
        const sc = scenes.find(s => s.lead === n || s.friend === n);
        return sc ? sc.lines : null;
    }
    return { update, hide, dialogueFor, stats: { duos: scenes.length, extras: scenes.length }, scenes };
})();
// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
const stat = [];
pits.forEach(([a, b], i) => {
    const g = new T.Group(), ms = [], ad = (w, h, d, x, y, z) => { const m = mesh(B(w, h, d), 0x8d9099, [x, y, z]); g.add(m); ms.push(m); };
    ad(1.1, .35, 1.1, 0, .17, 0);
    ad(.7, .7, .5, 0, .7, 0);
    ad(.6, .55, .55, 0, 1.35, 0);
    ad(.18, .7, .1, -.16, 1.95, 0);
    ad(.18, .7, .1, .16, 1.95, 0);
    ad(.2, .2, .2, 0, .8, -.35);
    const z = b - 3.5, sd = i % 2 ? 1 : -1;
    g.position.set(sd * (wp(z) - 1.3), hp(z), z);
    g.rotation.y = -sd * .4;
    g.userData = { cpz: b - 3, on: false, ms };
    S.add(g);
    stat.push(g);
});
const hint = document.createElement('div');
hint.style.cssText = 'position:fixed;bottom:12%;left:50%;transform:translateX(-50%);background:#fff;color:#2a1450;border:3px solid #4a1f7a;border-radius:14px;padding:6px 14px;font:700 16px system-ui;display:none;cursor:pointer';
hint.textContent = 'ENTER: conversar';
hint.onpointerdown = e => { e.stopPropagation(); if (!cv)
    interactWithCitizen(); };
document.body.append(hint);
const VO = { Bunnyck: [560, 'triangle', .06, 55], Vixxo: [820, 'square', .04, 70], Bunnyldu: [120, 'sawtooth', .07, 14], Bibibunn: [250, 'sawtooth', .06, 40] }, vixL = [['Vixxo', 'Bunnyck! A Bibibunn fugiu pela Selva de Pinheiros!'], ['Vixxo', 'Essa fase é bem maior: quase 1 km de trilha, desfiladeiros e riachos!'], ['Vixxo', 'Segure K ou CTRL para correr e ganhar impulso nos saltos longos.'], ['Vixxo', 'Fique esperto com os peixes que saltam nos riachos e com os ursos!'], ['Vixxo', 'Os lagartos e besouros ainda aparecem por aqui, então usa bem o giro!'], ['Vixxo', 'Pegue cenouras, quebre caixas e siga até o fim da floresta!']], cutIntro = [['Bunnyldu', 'Bunnyck! Você chegou... escuta bem: a Bibibunn me quer por causa da minha força.'], ['Bunnyldu', 'Ela quer ter uma ninhada de coelhos soldados comigo e dominar o mundo!'], ['Bunnyldu', 'O plano dela é deixar só os coelhos vivos e acabar com todos os outros animais!'], ['Bunnyck', 'Que loucura! Então a gente vai sair daqui agora mesmo!']], cutTaunt = [['Bibibunn', 'Aw... que reencontro fofinho. Obrigada por trazer o Bunnyldu até mim, Bunnyck.'], ['Bibibunn', 'Com ele, meu império de coelhos vai finalmente começar!']], cutAfterCage = [['Bunnyldu', 'Bunnyck! Cuidado! Ela é mais forte do que parece!'], ['Bunnyck', 'Larga ele, Bibibunn!']], cutFinal = [['Bibibunn', 'Tarde demais, coelhinho. O Bunnyldu vem comigo.'], ['Bibibunn', 'Se quiser seu irmão de volta, tente me alcançar na próxima fase!'], ['Bunnyck', 'BIBIBUNN! Eu vou atrás de vocês!']];
let cv = null, nearV = false;
function vc(w, i) { const [b, ty, v, m] = VO[w] || [650, 'triangle', .045, 41], f = b + (i * 37 % 6) * m; snd(f, .08, ty, f * 1.15, v); }
function startCv(l, end, auto, anchor) { cv = { l, i: 0, idx: 0, acc: 0, hold: 0, end, auto, anchor, sh: -1 }; dl = null; mv = 0; spin = 0; st.mx = 0; st.mz = 0; sprinting = false; sprintTag.style.display = 'none'; dlg.style.display = 'block'; hint.style.display = 'none'; npcBubble.style.display = 'none'; }
function cvNext() { const c = cv; if (!c)
    return; const n = c.l[c.i][1].length; if (c.idx < n) {
    c.idx = n;
    return;
} c.i++; c.idx = 0; c.acc = 0; c.hold = 0; c.sh = -1; if (c.i >= c.l.length) {
    cv = null;
    dlg.style.display = 'none';
    c.end && c.end();
} }
function cvUpdate(dt) {
    let c = cv;
    if (!c)
        return;
    let [who, line] = c.l[c.i];
    c.acc += dt;
    while (c.acc > .032 && c.idx < line.length) {
        c.acc -= .032;
        c.idx++;
        if (line[c.idx - 1] != ' ' && c.idx % 2 === 0)
            vc(who, c.idx);
    }
    if (c.idx >= line.length) {
        c.hold += dt;
        if (c.auto && c.hold > Math.max(1.6, Math.min(2.8, line.length * .035)))
            cvNext();
    }
    c = cv;
    if (!c)
        return;
    [who, line] = c.l[c.i];
    if (c.sh !== c.idx) {
        c.sh = c.idx;
        const shown = line.slice(0, c.idx);
        const remain = line.slice(c.idx);
        if (cs) {
            const ink = who === 'Bibibunn' ? '#ff73bc' : who === 'Bunnyldu' ? '#b8bdcf' : '#dbb2ff';
            dlg.innerHTML = '<span class="speaker" style="color:' + ink + '">' + who.toUpperCase() + '</span><div class="line">' + shown + '<span style="visibility:hidden">' + remain + '</span></div><div class="next">ENTER / CLIQUE para avançar</div>';
        }
        else
            dlg.innerHTML = shown + '<span style="visibility:hidden">' + remain + '</span>';
    }
    if (cs) {
        dlg.style.left = '50%';
        dlg.style.top = 'auto';
        return;
    }
    const [pos, h] = who === 'Vixxo' ? [vix.position, 3.4] : who === 'Bunnyldu' ? [bl.position, 4] : who === 'Bunnyck' ? [P.position, 2.9] : who === 'Bibibunn' ? [bibi.position, 3.4] : c.anchor ? [c.anchor.position, 3] : [P.position, 2.9];
    dv.set(pos.x, pos.y + h, pos.z).project(C);
    dlg.style.left = ((dv.x * .5 + .5) * innerWidth) + 'px';
    dlg.style.top = ((-dv.y * .5 + .5) * innerHeight) + 'px';
}
// Grips swing below the floating cage so Bibibunn's raised hands appear to support the weight.
// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
const cageHandles = new T.Group();
for (const sign of [-1, 1]) {
    cageHandles.add(mesh(B(.14, 1.38, .14), 0xb7bdc7, [sign * .62, -.72, .18]));
    cageHandles.add(mesh(B(.38, .16, .26), 0xe6c45b, [sign * .62, -1.37, .18]));
}
cage.add(cageHandles);
cageHandles.visible = false;
const impactRing = new T.Mesh(new T.RingGeometry(.45, 1.07, 32), new T.MeshBasicMaterial({ color: 0xffb7e8, side: T.DoubleSide, transparent: true, opacity: .86, depthWrite: false }));
impactRing.visible = false;
S.add(impactRing);
const lerp = (a, b, t) => a + (b - a) * t, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const ease = p => { p = clamp(p, 0, 1); return p * p * (3 - 2 * p); };
const slow = (obj, axis, value, dt, speed = 12) => obj.rotation[axis] = lerp(obj.rotation[axis], value, Math.min(1, dt * speed));
const spinTrails = new T.Group();
for (let i = 0; i < 3; i++) {
    const ring = new T.Mesh(new T.TorusGeometry(1.16 + i * .12, .065, 4, 28), new T.MeshBasicMaterial({ color: i % 2 ? 0xffffff : 0xff3caa, transparent: true, opacity: .78, side: T.DoubleSide, depthWrite: false }));
    ring.rotation.set(Math.PI * .40 + i * .17, .2 + i * .55, .28);
    spinTrails.add(ring);
}
spinTrails.visible = false;
S.add(spinTrails);
// Orientacao cinematografica no eixo real do modelo (+Z), em coordenadas locais.
// O caminho angular mais curto evita giros completos ao cruzar -PI/PI.
function faceCinematicActor(actor, target, dt, snap = false) {
    const origin = actor.getWorldPosition(new T.Vector3());
    const local = new T.Vector3(target.x, origin.y, target.z);
    if (actor.parent)
        actor.parent.worldToLocal(local);
    const dx = local.x - actor.position.x, dz = local.z - actor.position.z;
    if (Math.hypot(dx, dz) < .0001)
        return;
    const yaw = Math.atan2(dx, dz);
    const error = Math.atan2(Math.sin(yaw - actor.rotation.y), Math.cos(yaw - actor.rotation.y));
    actor.rotation.y = snap ? yaw : actor.rotation.y + error * (1 - Math.exp(-Math.min(dt, .05) * 9));
}
function actCk(mode, t, dt) {
    const talk = mode === 'talk', panic = mode === 'panic', hurt = mode === 'hurt', rise = mode === 'rise';
    const phase = t * (panic ? 12 : talk ? 8 : 5);
    if (talk) {
        body.position.y = Math.sin(phase) * .045;
        slow(arms[0], 'x', -.8 + Math.sin(phase) * .35, dt);
        slow(arms[1], 'x', -.22 - Math.sin(phase) * .28, dt);
        slow(arms[0], 'z', -.16, dt);
        slow(arms[1], 'z', .22, dt);
        slow(legs[0], 'x', .1, dt);
        slow(legs[1], 'x', -.1, dt);
        P.rotation.z = lerp(P.rotation.z, 0, dt * 9);
        body.rotation.z = Math.sin(phase * .5) * .08;
    }
    else if (panic) {
        body.position.y = Math.abs(Math.sin(phase)) * .06;
        slow(arms[0], 'x', -1.1, dt);
        slow(arms[1], 'x', -.9, dt);
        slow(arms[0], 'z', -.6, dt);
        slow(arms[1], 'z', .6, dt);
        body.rotation.z = -.12 + Math.sin(phase) * .045;
        legs.forEach((l, i) => slow(l, 'x', Math.sin(phase + i * Math.PI) * .15, dt));
    }
    else if (hurt) {
        body.position.y = 0;
        arms.forEach((a, i) => { slow(a, 'x', -1.8, dt); slow(a, 'z', i ? .4 : -.4, dt); });
        legs.forEach((l, i) => slow(l, 'x', i ? -.8 : .9, dt));
        body.rotation.z = -.12;
    }
    else if (rise) {
        body.position.y = -.08;
        arms.forEach((a, i) => { slow(a, 'x', i ? -1.1 : -1.7, dt); slow(a, 'z', i ? .3 : -.4, dt); });
        legs.forEach((l, i) => slow(l, 'x', i ? -.4 : .4, dt));
        body.rotation.z = .06;
    }
    else {
        body.position.y = 0;
        body.rotation.z *= .88;
        arms.forEach(a => { slow(a, 'x', 0, dt); slow(a, 'z', 0, dt); });
        legs.forEach(l => slow(l, 'x', 0, dt));
    }
    ears.forEach((e, i) => { slow(e, 'x', panic ? -.75 + Math.sin(phase + i) * .1 : hurt ? .6 : rise ? -.35 : talk ? Math.sin(phase * .5 + i) * .2 : .04, dt); });
    tail.rotation.y = Math.sin(t * 7) * .18;
    faceAct('ck', panic ? 'panic' : hurt ? 'hurt' : mode === 'angry' ? 'angry' : 'normal', t, dt, talk);
}
function actLd(mode, t, dt) {
    const u = bl.userData, talk = mode === 'talk', panic = mode === 'panic', struggle = mode === 'trapped', phase = t * (struggle ? 20 : panic ? 12 : talk ? 8 : 4);
    if (talk) {
        u.core.position.y = Math.sin(phase) * .05;
        u.arms.forEach((a, i) => { slow(a, 'x', i ? .45 : -.7 + Math.sin(phase) * .4, dt); slow(a, 'z', i ? .15 : -.15, dt); });
        u.head.rotation.z = Math.sin(phase * .65) * .09;
    }
    else if (panic) {
        u.core.position.y = Math.abs(Math.sin(phase)) * .08;
        u.arms.forEach((a, i) => { slow(a, 'x', -1.4 + Math.sin(phase + i * Math.PI) * .25, dt); slow(a, 'z', i ? .44 : -.44, dt); });
        u.head.rotation.z = Math.sin(phase) * .11;
    }
    else if (struggle) {
        u.core.position.y = Math.abs(Math.sin(phase)) * .13;
        u.arms.forEach((a, i) => { slow(a, 'x', -1.45 + Math.sin(phase + i * 1.8) * .43, dt); slow(a, 'z', i ? .48 : -.48, dt); });
        u.legs.forEach((l, i) => slow(l, 'x', Math.sin(phase + i * Math.PI) * .58, dt));
        u.head.rotation.y = Math.sin(phase * .58) * .2;
        u.head.rotation.z = Math.sin(phase * .8) * .1;
    }
    else {
        u.core.position.y = 0;
        u.arms.forEach((a, i) => { slow(a, 'x', 0, dt); slow(a, 'z', 0, dt); });
        u.head.rotation.z *= .9;
        u.head.rotation.y *= .9;
    }
    u.ears.forEach((e, i) => slow(e, 'x', struggle ? -.75 + Math.sin(phase + i) * .1 : panic ? -.45 : Math.sin(phase * .35 + i) * .08, dt));
    if (!struggle)
        u.legs.forEach((l, i) => slow(l, 'x', 0, dt));
    u.tail.rotation.y = Math.sin(t * 6) * .14;
    faceAct('ld', struggle || panic ? 'panic' : 'normal', t, dt, talk);
}
function actBibi(mode, t, dt) {
    const u = bibi.userData, strut = mode === 'walk', talk = mode === 'talk', spin = mode === 'spin', lift = mode === 'lift', carry = mode === 'carry';
    const ph = t * (spin ? 24 : carry ? 13 : strut ? 10 : 7);
    if (strut || carry) {
        u.core.position.y = Math.abs(Math.sin(ph * .5)) * .07;
        u.legs.forEach((l, i) => slow(l, 'x', Math.sin(ph + i * Math.PI) * (carry ? .55 : .75), dt, 18));
        u.arms.forEach((a, i) => { slow(a, 'x', carry ? 2.8 : Math.sin(ph + (i + 1) * Math.PI) * .5, dt); slow(a, 'z', carry ? (i ? .4 : -.4) : (i ? .2 : -.2), dt); });
    }
    else if (talk) {
        u.core.position.y = Math.sin(ph) * .04;
        u.legs.forEach(l => slow(l, 'x', 0, dt));
        u.arms.forEach((a, i) => { slow(a, 'x', i ? .5 : -.3 + Math.sin(ph) * .35, dt); slow(a, 'z', i ? .4 : -.32, dt); });
        u.head.rotation.z = -.12 + Math.sin(ph * .6) * .1;
    }
    else if (spin) {
        u.core.position.y = .06 + Math.abs(Math.sin(ph)) * .09;
        u.arms[0].rotation.z = -1.45;
        u.arms[1].rotation.z = 1.45;
        u.arms.forEach(a => slow(a, 'x', -.18, dt));
        u.legs.forEach((l, i) => slow(l, 'x', i ? -.8 : .8, dt));
        u.head.rotation.z = Math.sin(ph) * .12;
    }
    else if (lift) {
        u.core.position.y = -Math.sin(Math.PI * clamp((cs?.t || 0) / 1.2, 0, 1)) * .2;
        u.legs.forEach((l, i) => slow(l, 'x', i ? .2 : -.2, dt));
        u.arms.forEach((a, i) => { slow(a, 'x', 2.8, dt); slow(a, 'z', i ? .38 : -.38, dt); });
        u.head.rotation.z = .05;
    }
    else {
        u.core.position.y = 0;
        u.legs.forEach(l => slow(l, 'x', 0, dt));
        u.arms.forEach((a, i) => { slow(a, 'x', i ? .3 : -.5, dt); slow(a, 'z', i ? .3 : -.3, dt); });
    }
    if (!spin)
        u.core.rotation.y = lerp(u.core.rotation.y, 0, Math.min(1, dt * 9));
    u.ears.forEach((e, i) => slow(e, 'x', spin ? -.9 + Math.sin(ph + i) * .3 : Math.sin(ph * .35 + i) * .13, dt));
    u.tail.rotation.y = Math.sin(t * 7) * .22;
    u.hair.forEach((h, i) => h.rotation.z = Math.sin(t * 8 + i) * .07);
    faceAct('bibi', talk ? 'smug' : spin ? 'angry' : 'smug', t, dt, talk);
}
// V18 — FASE 2 SOMENTE: cutscene 3D em tempo real no final da Selva.
// Usa o Bunnyck e a Fiona ORIGINAL da fase. Nada aqui troca geometria do heroi,
// movimentacao, hitboxes, shaders, cenarios permanentes ou trilha da fase.
const forestOutro = globalThis.__bhForestOutro = (() => {
    const set = new T.Group();
    set.visible = false;
    S.add(set);
    const mat = c => new T.MeshLambertMaterial({ color: c, flatShading: true });
    const wood = mat(0x76523c), darkWood = mat(0x4b372b), stone = mat(0x677b82), moss = mat(0x426a53);
    const foam = new T.MeshBasicMaterial({ color: 0xd1f8fa, transparent: true, opacity: .68, depthWrite: false, side: T.DoubleSide });
    const water = new T.MeshLambertMaterial({ color: 0x428fa0, transparent: true, opacity: .82, depthWrite: false, side: T.DoubleSide });
    const scar = new T.MeshBasicMaterial({ color: 0xda5aaf, transparent: true, opacity: .8, depthWrite: false, side: T.DoubleSide });
    const x0 = 1.0, z0 = GOAL - 13, ground = gh(x0, z0);
    function put(geo, mt, x, y, z) { let m = new T.Mesh(geo, mt); m.position.set(x, y, z); set.add(m); return m; }
    // A pista visual fica alem do portal original: sem bloquear o corredor jogavel.
    const river = put(new T.PlaneGeometry(11, 20), water, 1.6, ground + .16, GOAL - 15);
    river.rotation.x = -Math.PI / 2;
    const currents = [];
    for (let i = 0; i < 8; i++) {
        const l = put(new T.PlaneGeometry(1.2 + (i % 3) * .65, .12), foam, -2.7 + (i % 4) * 2.35, ground + .19, GOAL - 8.5 - Math.floor(i / 4) * 5.4);
        l.rotation.x = -Math.PI / 2;
        currents.push({ m: l, base: l.position.z, phase: i * .85 });
    }
    for (let i = 0; i < 11; i++) {
        const side = i % 2 ? -1 : 1, x = 1.6 + side * (6.6 + (i % 3) * .6), z = GOAL - 8 - Math.floor(i / 2) * 2.6;
        let rock = put(new T.DodecahedronGeometry(1.1 + (i % 3) * .4, 0), stone, x, ground + .55, z);
        rock.scale.set(1.2, .8, 1.0);
        rock.rotation.y = i * .6;
    }
    const beam = put(new T.BoxGeometry(5.3, .36, .44), wood, 1.15, ground + .55, GOAL - 9.3);
    beam.rotation.z = .24;
    beam.rotation.y = .2;
    const support = put(new T.BoxGeometry(.5, 2.9, .48), darkWood, 5.0, ground + 1.2, GOAL - 10.1);
    support.rotation.z = -.52;
    const splinter = put(new T.BoxGeometry(2.0, .24, .25), wood, 4.5, ground + .35, GOAL - 11.1);
    splinter.rotation.y = .6;
    const evidence = put(new T.PlaneGeometry(1.5, .9), scar, 1.25, ground + .86, GOAL - 9.02);
    evidence.rotation.x = -Math.PI / 2.35;
    const sign = new T.Group();
    set.add(sign);
    sign.position.set(-5.7, ground, GOAL - 7.5);
    sign.rotation.z = -.22;
    function signMesh(g, c, x, y, z) { let m = new T.Mesh(g, mat(c)); m.position.set(x, y, z); sign.add(m); return m; }
    signMesh(new T.BoxGeometry(.3, 2.7, .33), 0x73533f, 0, 1.25, 0);
    signMesh(new T.BoxGeometry(3.6, .88, .24), 0x9a7555, .65, 2.55, 0);
    const cvSign = document.createElement('canvas');
    cvSign.width = 512;
    cvSign.height = 128;
    const cc = cvSign.getContext('2d');
    cc.fillStyle = '#e7dbac';
    cc.font = 'bold 45px system-ui';
    cc.textAlign = 'center';
    cc.textBaseline = 'middle';
    cc.fillText('BARRAGEM  →', 256, 66);
    let lettering = new T.Mesh(new T.PlaneGeometry(3.28, .76), new T.MeshBasicMaterial({ map: new T.CanvasTexture(cvSign), transparent: true, side: T.DoubleSide }));
    lettering.position.set(.65, 2.55, .135);
    sign.add(lettering);
    const fox = citizens.find(n => n.userData.name === 'Fiona');
    const cam = new T.Vector3(), aim = new T.Vector3();
    const targetCam = new T.Vector3(), targetLook = new T.Vector3(), viewDirection = new T.Vector3();
    // Os planos usam alturas relativas ao palco. O final da selva fica a ~17.5
    // unidades de altitude; usar os offsets como Y absoluto enterrava a camera.
    const stageY = Math.max(gh(-2.2, GOAL + 6.6), gh(3.05, GOAL + 3.7));
    let lastAspect = C.aspect;
    let started = false, foxOrigin = null, done = false, markerWasVisible = true;
    const shots = [
        // O alvo baixo reserva a faixa inferior para as legendas mais longas.
        // Os dois atores permanecem visiveis e do mesmo lado do eixo.
        { p: [.4, 5.6, GOAL + 18.5], l: [.4, -.8, GOAL + 4], fov: 55 },
        { p: [-3.8, 4.1, GOAL + 14], l: [.2, -.8, GOAL + 5], fov: 52 },
        { p: [3.4, 4.0, GOAL + 14], l: [.5, -.8, GOAL + 5], fov: 54 },
        { p: [-1.8, 5.0, GOAL + 16], l: [.6, -.8, GOAL + 4], fov: 54 },
        { p: [.7, 5.6, GOAL + 18.5], l: [.7, -.8, GOAL + 3], fov: 56 }
    ];
    function frameShot(sh) {
        targetCam.set(sh.p[0], stageY + sh.p[1], sh.p[2]);
        targetLook.set(sh.l[0], stageY + sh.l[1], sh.l[2]);
        // Em retrato, manter a camera no corredor ao recuar, longe dos pinheiros.
        if (C.aspect < 1)
            targetCam.x = targetLook.x + (targetCam.x - targetLook.x) * C.aspect;
        // Recuar em telas estreitas, sem cortar os atores nem mudar os modelos.
        viewDirection.copy(targetCam).sub(targetLook);
        const distance = viewDirection.length();
        const minimum = 4.4 / (Math.tan(sh.fov * Math.PI / 360) * Math.min(1, C.aspect / 1.25));
        if (distance < minimum)
            targetCam.copy(targetLook).addScaledVector(viewDirection, minimum / distance);
        targetCam.y = Math.max(targetCam.y, gh(targetCam.x, targetCam.z) + 2);
    }
    const lines = [
        ['Bunnyck', 'Essas árvores... a correnteza arrancou tudo! O que aconteceu aqui?'],
        ['Fiona', 'Bunnyck! Alguém sabotou as comportas da barragem. O rio está inundando a vila dos animais!'],
        ['Bunnyck', 'A Bibibunn passou com o Bunnyldu. Será que ela causou isso?'],
        ['Fiona', 'Encontrei marcas de energia rosa nessas tábuas. A jaula seguiu rio abaixo, rumo às Corredeiras!'],
        ['Bunnyck', 'Então vou até a barragem! Preciso ajudar a vila e encontrar meu irmão!']
    ];
    function start() {
        if (started || cs || secretSystems.bonus.active || dy)
            return;
        started = true;
        done = false;
        set.visible = true;
        markerWasVisible = forestExitMarker.visible;
        forestExitMarker.visible = false;
        ended = 1;
        run = false;
        cs = { kind: 'forestOutro', phase: 'reveal', t: 0, shot: 0 };
        document.body.classList.add('cinematic');
        keys = {};
        spin = 0;
        mv = 0;
        sprinting = false;
        jumpHeld = false;
        sprintTag.style.display = 'none';
        hint.style.display = 'none';
        npcBubble.style.display = 'none';
        $('pineProgress').style.visibility = 'hidden';
        st.x = -2.2;
        st.z = GOAL + 6.6;
        st.y = gh(st.x, st.z);
        st.vy = 0;
        st.g = true;
        st.mx = 0;
        st.mz = 0;
        P.position.set(st.x, st.y, st.z);
        P.rotation.set(0, 0, 0);
        P.scale.set(1, 1, 1);
        if (fox) {
            foxOrigin = { position: fox.position.clone(), rotation: fox.rotation.clone() };
            fox.position.set(3.05, gh(3.05, GOAL + 3.7), GOAL + 3.7);
            fox.visible = true;
            faceCinematicActor(body, fox.position, 0, true);
            faceCinematicActor(fox, P.position, 0, true);
        }
        frameShot(shots[0]);
        cam.copy(targetCam);
        aim.copy(targetLook);
        lastAspect = C.aspect;
        C.fov = shots[0].fov;
        C.updateProjectionMatrix();
        C.position.copy(cam);
        C.lookAt(aim);
        C.updateMatrixWorld();
        // Fade da trilha no proprio corte, sem iniciar nenhuma outra musica.
        bgm.pause();
    }
    function finish() {
        if (done)
            return;
        done = true;
        set.visible = false;
        forestExitMarker.visible = markerWasVisible;
        document.body.classList.remove('cinematic');
        $('pineProgress').style.visibility = '';
        if (fox && foxOrigin) {
            fox.position.copy(foxOrigin.position);
            fox.rotation.copy(foxOrigin.rotation);
            foxOrigin = null;
        }
        cv = null;
        dlg.style.display = 'none';
        cs = null;
        // Disparar UMA unica conclusao, APOS o ultimo quadro da cutscene.
        window.parent.postMessage({ type: 'bunny-havoc-fase2-concluida', carrots: fr, hearts: playerCombat.state.health, lives, boxes: broken }, '*');
        over('FASE 2 COMPLETA! 🌲', 'Bunnyck descobriu a sabotagem da barragem e segue para as Corredeiras.');
    }
    function update(t, dt) {
        if (!cs || cs.kind !== 'forestOutro')
            return;
        const c = cs;
        c.t += dt;
        if (c.phase === 'reveal' && c.t > 2.1) {
            c.phase = 'dialogue';
            startCv(lines, finish, true, fox);
        }
        const i = c.phase === 'dialogue' && cv ? Math.min(shots.length - 1, cv.i) : 0;
        const sh = shots[i];
        frameShot(sh);
        if (lastAspect !== C.aspect) {
            // Uma mudanca de orientacao precisa reenquadrar antes do proximo quadro.
            cam.copy(targetCam);
            aim.copy(targetLook);
            lastAspect = C.aspect;
        }
        cam.lerp(targetCam, 1 - Math.exp(-dt * 1.8));
        aim.lerp(targetLook, 1 - Math.exp(-dt * 1.8));
        C.fov += (sh.fov - C.fov) * (1 - Math.exp(-dt * 2.4));
        C.updateProjectionMatrix();
        C.position.copy(cam);
        C.position.y = Math.max(C.position.y, gh(C.position.x, C.position.z) + 2);
        C.lookAt(aim);
        // Atores mantem seus modelos originais: animacao facial / orelhas / gestos.
        const speaking = cv?.l[cv.i]?.[0] || '';
        actCk(speaking === 'Bunnyck' ? 'talk' : 'panic', t, dt);
        if (fox)
            faceCinematicActor(body, i === 4 ? evidence.position : fox.position, dt);
        if (fox) {
            let d = fox.userData, phase = t * 7;
            d.core.position.y = Math.sin(phase) * .035;
            d.head.rotation.z = (speaking === 'Fiona' ? Math.sin(phase * .65) * .11 : .02);
            d.head.rotation.x = speaking === 'Fiona' ? -.08 : .05;
            d.arms[0].rotation.x = speaking === 'Fiona' ? -.58 + Math.sin(phase) * .24 : .15;
            d.arms[1].rotation.x = speaking === 'Fiona' ? -.72 + Math.sin(phase * .83) * .22 : .15;
            d.tail.rotation.x = Math.sin(t * 2.5) * .12;
            faceCinematicActor(fox, P.position, dt);
        }
        evidence.material.opacity = .5 + .35 * Math.sin(t * 2.5);
        for (let j = 0; j < currents.length; j++) {
            const it = currents[j];
            it.m.position.z = it.base + ((t * .8 + it.phase) % 3.3) - 1.65;
            it.m.material = foam;
        }
    }
    function abort() {
        if (!started)
            return;
        set.visible = false;
        forestExitMarker.visible = markerWasVisible;
        started = false;
        done = false;
        if (fox && foxOrigin) {
            fox.position.copy(foxOrigin.position);
            fox.rotation.copy(foxOrigin.rotation);
            foxOrigin = null;
        }
        cv = null;
        cs = null;
        dlg.style.display = 'none';
        $('pineProgress').style.visibility = '';
        document.body.classList.remove('cinematic');
    }
    return { start, update, abort, get active() { return !!cs && cs.kind === 'forestOutro'; }, get props() { return set; }, get dialog() { return lines; } };
})();
// The cinematic director owns all actor poses and camera placement.
function setCPhase(name) { if (!cs)
    return; cs.phase = name; cs.t = 0; cs.fired = false; cs.hit = false; }
function stageGround(obj, x, z, yExtra = 0) { obj.position.set(x, gh(x, z) + yExtra, z); }
function stageCage(yExtra = 0) { cage.position.set(bl.position.x, gh(bl.position.x, bl.position.z) + .02 + yExtra, bl.position.z); }
function startEndingCutscene() {
    if (cs)
        return;
    ended = 1;
    cs = { phase: 'intro', t: 0, cam: new T.Vector3(0, by0 + 5, -384.8), look: new T.Vector3(.2, by0 + 2.15, -394.5), fired: false, hit: false };
    document.body.classList.add('cinematic');
    C.fov = 64;
    C.updateProjectionMatrix();
    cv = null;
    dl = null;
    keys = {};
    spin = 0;
    mv = 0;
    sprinting = false;
    jumpHeld = false;
    hint.style.display = 'none';
    npcBubble.style.display = 'none';
    sprintTag.style.display = 'none';
    st.x = -2.2;
    st.z = -392.8;
    st.y = gh(st.x, st.z);
    st.vy = 0;
    st.mx = 0;
    st.mz = 0;
    st.g = true;
    P.position.set(st.x, st.y, st.z);
    P.scale.set(1, 1, 1);
    P.rotation.set(0, 0, 0);
    body.scale.set(1, 1, 1);
    body.position.set(0, 0, 0);
    body.rotation.set(0, .8, 0);
    dizzy.visible = false;
    bl.visible = true;
    stageGround(bl, 1.45, -395.35);
    bl.rotation.set(0, -.65, 0);
    bl.scale.setScalar(.8);
    bibi.visible = false;
    stageGround(bibi, 5.5, -394.25);
    bibi.rotation.set(0, -1, 0);
    bibi.userData.core.rotation.set(0, 0, 0);
    bl.userData.core.rotation.set(0, 0, 0);
    bl.userData.core.position.y = 0;
    cage.visible = false;
    cage.scale.set(1, 1, 1);
    cageHandles.visible = false;
    impactRing.visible = false;
    stageCage();
    spinTrails.visible = false;
    startCv(cutIntro, () => setCPhase('arrival'), true);
}
function finishEndingCutscene() {
    document.body.classList.remove('cinematic');
    C.fov = 60;
    C.updateProjectionMatrix();
    spinTrails.visible = false;
    cageHandles.visible = false;
    impactRing.visible = false;
    cs = null;
    ended = 0;
    dlg.style.cssText = '';
    bibi.visible = false;
    cage.visible = false;
    over('FASE 1 COMPLETA! 🎉', 'Bibibunn levou Bunnyldu! Cenouras: ' + fr + ' · Caixas: ' + broken + ' · Continua...');
}
function cutsceneUpdate(t, dt) {
    if (cs?.kind === 'forestOutro') {
        forestOutro.update(t, dt);
        return;
    }
    if (!cs)
        return;
    const c = cs;
    c.t += dt;
    const time = c.t, ph = c.phase;
    st.mx = 0;
    st.mz = 0;
    st.vy = 0;
    st.g = true;
    const who = cv?.l[cv.i]?.[0] || '';
    let targetX = .2, targetZ = -394.25, camHeight = 5.25, camDistance = 11.0, side = 0;
    // Maintain a wide enough field of view on portrait screens too.
    const vHalf = 7.6;
    camDistance = Math.max(camDistance, vHalf / (Math.tan(C.fov * Math.PI / 360) * C.aspect) + 1.8);
    if (ph === 'intro') {
        body.rotation.y = .77;
        bl.rotation.y = -.67;
        actLd(who === 'Bunnyldu' ? 'talk' : 'panic', t, dt);
        actCk(who === 'Bunnyck' ? 'talk' : 'panic', t, dt);
        bibi.visible = false;
        stageCage();
        cage.visible = false;
        targetX = -.3;
        camHeight = 4.9;
    }
    else if (ph === 'arrival') {
        bibi.visible = true;
        const a = ease(time / 1.6);
        stageGround(bibi, lerp(5.5, 4.35, a), -394.25);
        bibi.rotation.y = -1.05;
        actBibi('walk', t, dt);
        actLd('panic', t, dt);
        actCk('panic', t, dt);
        targetX = .75;
        if (time >= 1.75 && !c.fired) {
            c.fired = true;
            setCPhase('taunt');
            startCv(cutTaunt, () => setCPhase('trap'), true);
        }
    }
    else if (ph === 'taunt') {
        stageGround(bibi, 4.35, -394.25);
        bibi.rotation.y = -1.1;
        actBibi('talk', t, dt);
        actLd('panic', t, dt);
        actCk('panic', t, dt);
        targetX = .85;
        camHeight = 5.25;
    }
    else if (ph === 'trap') {
        // A cage rises AROUND Bunnyldu; it never slams into either actor.
        stageGround(bibi, 4.35, -394.25);
        bibi.rotation.y = -1.05;
        actBibi('talk', t, dt);
        const a = ease(time / .95);
        cage.visible = true;
        cageHandles.visible = false;
        cage.scale.y = Math.max(.02, a);
        stageCage();
        actLd(time > .85 ? 'trapped' : 'panic', t, dt);
        actCk('panic', t, dt);
        targetX = 1.05;
        camHeight = 5.3;
        if (time > .90 && !c.fired) {
            c.fired = true;
            fx({ x: bl.position.x, y: bl.position.y + .5, z: bl.position.z }, 0xff83d7, 18, 5);
            snd(190, .3, 'square', 95);
            shake = .25;
        }
        if (time > 1.3 && !c.spoken) {
            c.spoken = true;
            setCPhase('trappedDialogue');
            startCv(cutAfterCage, () => setCPhase('windup'), true);
        }
    }
    else if (ph === 'trappedDialogue') {
        cage.visible = true;
        cage.scale.y = 1;
        stageCage();
        stageGround(bibi, 4.35, -394.25);
        bibi.rotation.y = -1.05;
        actLd('trapped', t, dt);
        actCk(who === 'Bunnyck' ? 'talk' : 'panic', t, dt);
        actBibi('talk', t, dt);
        targetX = .7;
    }
    else if (ph === 'windup') {
        cage.visible = true;
        cage.scale.y = 1;
        stageCage();
        actLd('trapped', t, dt);
        const a = ease(time / .85), x = lerp(4.35, -1.0, a), z = lerp(-394.25, -392.95, a);
        stageGround(bibi, x, z);
        bibi.rotation.y = -1.2 + time * 19;
        bibi.userData.core.rotation.y += dt * 20;
        actBibi('spin', t, dt);
        spinTrails.visible = true;
        spinTrails.position.set(x, bibi.position.y + 1.25, z);
        spinTrails.rotation.y += dt * 16;
        spinTrails.rotation.z += dt * 5;
        spinTrails.scale.setScalar(1 + Math.sin(t * 22) * .06);
        actCk('panic', t, dt);
        targetX = -.5;
        camHeight = 5.4;
        if (time > .76 && !c.fired) {
            c.fired = true;
            shake = .55;
            snd(155, .24, 'sawtooth', 60);
            fx({ x: st.x, y: st.y + .8, z: st.z }, 0xffa5eb, 22, 7);
            impactRing.visible = true;
            impactRing.position.set(st.x, st.y + 1, st.z);
            setCPhase('knockdown');
        }
    }
    else if (ph === 'knockdown') {
        // Bunnyck's tumble remains INSIDE the cinematic frame, not behind the camera.
        spinTrails.visible = false;
        impactRing.visible = time < .65;
        impactRing.scale.setScalar(1 + time * 3.8);
        impactRing.material.opacity = Math.max(0, .86 - time * 1.4);
        const a = ease(time / .85);
        st.x = lerp(-2.2, -3.55, a);
        st.z = lerp(-392.8, -391.85, a);
        st.y = gh(st.x, st.z) + Math.sin(a * Math.PI) * .85;
        P.position.set(st.x, st.y, st.z);
        P.rotation.z = lerp(.05, 1.42, a);
        actCk('hurt', t, dt);
        actLd('trapped', t, dt);
        const b = ease(time / .75);
        stageGround(bibi, lerp(-1.0, 3.85, b), lerp(-392.95, -394.1, b));
        bibi.rotation.y = -.85;
        actBibi('walk', t, dt);
        targetX = -.3;
        camHeight = 4.9;
        if (time > .98 && !c.fired) {
            c.fired = true;
            setCPhase('aftermath');
            startCv(cutFinal, () => setCPhase('lift'), true);
        }
    }
    else if (ph === 'aftermath') {
        cage.visible = true;
        stageCage();
        actLd('trapped', t, dt);
        stageGround(bibi, 3.85, -394.15);
        bibi.rotation.y = -1.0;
        actBibi('talk', t, dt);
        st.x = -3.55;
        st.z = -391.85;
        st.y = gh(st.x, st.z);
        P.position.set(st.x, st.y, st.z);
        const a = ease(time / 4.5);
        P.rotation.z = lerp(1.42, .24, a);
        body.rotation.y = .8;
        actCk(time < 2.1 ? 'hurt' : time < 5 ? 'rise' : who === 'Bunnyck' ? 'talk' : 'panic', t, dt);
        targetX = -.1;
        targetZ = -393.5;
        camHeight = 4.95;
        camDistance += 1;
    }
    else if (ph === 'lift') {
        // Bibibunn walks UNDER the cage, plants her feet, then raises it with both hands.
        cageHandles.visible = true;
        const a = ease(time / .8), b = ease((time - .75) / 1.15);
        stageGround(bibi, lerp(3.85, 1.45, a), lerp(-394.15, -395.20, a));
        bibi.rotation.y = .05;
        actBibi(time < .75 ? 'walk' : 'lift', t, dt);
        bl.position.set(bibi.position.x, gh(bibi.position.x, bibi.position.z) + b * 3.35, bibi.position.z - .13);
        bl.rotation.y = .12;
        actLd('trapped', t, dt);
        cage.visible = true;
        stageCage(b * 3.35);
        P.rotation.z = .12;
        actCk('panic', t, dt);
        targetX = .35;
        camHeight = 6.3;
        camDistance += 2;
        if (time > 2.15 && !c.fired) {
            c.fired = true;
            setCPhase('escape');
        }
    }
    else if (ph === 'escape') {
        // Preserve the animation to the horizon while keeping Bunnyck visible until the end.
        cageHandles.visible = true;
        const a = ease(time / 3.5), x = lerp(1.45, 2.8, a), z = lerp(-395.2, -402.3, a);
        stageGround(bibi, x, z);
        bibi.rotation.y = Math.PI;
        actBibi('carry', t, dt);
        bl.position.set(x, gh(x, z) + 3.35, z - .13);
        actLd('trapped', t, dt);
        stageCage(3.35);
        cage.visible = true;
        st.x = lerp(-3.55, -1.65, ease(time / 2.7));
        st.z = lerp(-391.85, -394.0, ease(time / 2.7));
        st.y = gh(st.x, st.z);
        P.position.set(st.x, st.y, st.z);
        P.rotation.z = lerp(.24, 0, ease(time / 1.4));
        body.rotation.y = Math.PI;
        actCk('panic', t, dt);
        targetX = lerp(0, 1.2, a);
        targetZ = lerp(-393.5, -396.9, a);
        camHeight = 6.5;
        camDistance += 4;
        if (time > 3.55 && !c.fired) {
            c.fired = true;
            finishEndingCutscene();
            return;
        }
    }
    // A bounded director camera: no chasing an off-screen speaker during dialogue.
    const ground = gh(targetX, targetZ), wantCam = new T.Vector3(targetX + side, ground + camHeight, targetZ + camDistance);
    const wantLook = new T.Vector3(targetX, ground + 2.15, targetZ);
    c.cam.lerp(wantCam, Math.min(1, dt * 3));
    c.look.lerp(wantLook, Math.min(1, dt * 3));
    C.position.copy(c.cam);
    C.position.x += (Math.random() - .5) * shake * .5;
    C.position.y += (Math.random() - .5) * shake * .32;
    C.lookAt(c.look);
}
// @ts-nocheck
// Migração de preservação: código original Three.js. Evoluir gradualmente para TypeScript tipado.
function npcUpdate(t, dt) {
    if (secretSystems.bonus.active) {
        npcEcosystem.hide();
        nearV = false;
        nearCitizen = null;
        hint.style.display = 'none';
        npcBubble.style.display = 'none';
        dlg.style.display = 'none';
        return;
    }
    if (cs) {
        npcEcosystem.hide();
        nearV = false;
        nearCitizen = null;
        hint.style.display = 'none';
        npcBubble.style.display = 'none';
        if (cv)
            spin = 0;
        cv ? cvUpdate(dt) : dlgUpdate(dt);
        stat.forEach(s => { const u = s.userData, on = cp <= u.cpz; if (on != u.on) {
            u.on = on;
            u.ms.forEach(m => m.material.color.setHex(on ? 0x9b5cff : 0x8d9099));
            if (on) {
                fx(s.position, 0xcfa8ff, 10, 4);
                snd(660, .25, 'sine', 1320, .1);
            }
        } });
        return;
    }
    vix.position.y = vy0 + Math.abs(Math.sin(t * 2)) * .05;
    bl.position.y = by0 + Math.abs(Math.sin(t * 1.5)) * .04;
    const dV = Math.hypot(st.x - vix.position.x, st.z - vix.position.z), dB = Math.hypot(st.x - bl.position.x, st.z - bl.position.z);
    if (dV < 9)
        vix.rotation.y = Math.atan2(st.x - vix.position.x, st.z - vix.position.z);
    if (dB < 14)
        bl.rotation.y = Math.atan2(st.x - bl.position.x, st.z - bl.position.z);
    updateCitizens(t, dt);
    npcEcosystem.update(t, dt);
    nearV = run && !dy && !cv && !cs && dV < 3.6;
    const canChat = run && !dy && !cv && !cs && (nearV || nearCitizen);
    hint.textContent = nearV ? 'ENTER: conversar com Vixxo' : nearCitizen ? 'ENTER: conversar com ' + nearCitizen.userData.name : '';
    hint.style.display = canChat ? 'block' : 'none';
    if (cv)
        spin = 0;
    if (run && !dy && !cv && !cs && !ended && st.z < GOAL + 8 && Math.abs(st.x) < 7) {
        forestOutro.start();
    }
    stat.forEach(s => { const u = s.userData, on = cp <= u.cpz; if (on != u.on) {
        u.on = on;
        u.ms.forEach(m => m.material.color.setHex(on ? 0x9b5cff : 0x8d9099));
        if (on) {
            fx(s.position, 0xcfa8ff, 10, 4);
            snd(660, .25, 'sine', 1320, .1);
        }
    } });
    cv ? cvUpdate(dt) : dlgUpdate(dt);
}
let last = performance.now();
function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min((now - last) / 1000, .05);
    last = now;
    const t = now / 1000;
    playerCombat.update(dt, run && !dy && !cv && !cs && !window.__bhBonusTutorialOpen);
    pineOverhaul.update(t, dt);
    secretSystems.update(t, dt);
    const progress = Math.max(0, Math.min(1000, Math.round(Math.max(0, -st.z) * 1000 / 980)));
    const sector = Math.min(7, Math.floor(progress / 125));
    const names = ['ENTRADA DOS PINHEIROS', 'TRILHAS ELEVADAS', 'PONTE DO DESFILADEIRO', 'TRONCO GIGANTE', 'CLAREIRA DA NÉVOA', 'RIACHOS SELVAGENS', 'SUBIDA DA MONTANHA', 'RUÍNAS NO CUME'];
    $('pineMeters').textContent = progress + ' / 1000 m';
    $('pineZone').textContent = '🌲 ' + names[sector];
    $('pineFill').style.width = progress / 10 + '%';
    pineSprays.forEach(o => { o.m.position.x = o.x + Math.sin(t * .19 + o.phase) * 1.8; o.m.position.z = o.z + Math.sin(t * .25 + o.phase) * 1.1; });
    pineWaterfalls.forEach((w, i) => { w.mist.scale.x = 1 + .1 * Math.sin(t * 2 + i); w.falling.material.opacity = .68 + .13 * Math.sin(t * 3 + i); });
    streams.forEach((g, i) => { g.children[0].material.opacity = .8 + .06 * Math.sin(t * 2.4 + i); const u = g.userData; if (u.rip)
        u.rip.forEach(r => { r.position.x += dt * 1.6; if (r.position.x > u.ww)
            r.position.x = -u.ww; }); });
    fruits.forEach(f => { f.userData.y ??= f.position.y; f.rotation.y += dt * 3; f.position.y = f.userData.y + Math.sin(t * 3 + f.position.z) * .12; });
    portal.rotation.z += dt * 2;
    portal.scale.setScalar(1 + Math.sin(t * 3) * .06);
    clouds.forEach(c => { c.position.x += dt * .8; if (c.position.x > 110)
        c.position.x = -110; });
    bfs.forEach(b => { const d = b.userData; b.position.set(d.x + Math.sin(t * .7 + d.p) * 3, d.h + 1.5 + Math.sin(t * 1.3 + d.p), d.z + Math.cos(t * .5 + d.p) * 3); const a = Math.sin(t * 18 + d.p) * .9; d.w1.rotation.z = a; d.w2.rotation.z = -a; });
    enemyCombat.update(dt, run && !dy && !cv && !cs && !window.__bhBonusTutorialOpen);
    animateEnemies(t, dt);
    enemyAnimator.update(t, dt);
    plats.forEach(p => { const u = p.userData, nx = Math.sin(t * 1.1 + u.p0) * u.am; u.dx = nx - p.position.x; p.position.x = nx; });
    logs.forEach(l => { const d = l.userData, nx = Math.sin(t * d.sp + d.p) * d.am; l.rotation.z -= (nx - l.position.x) * 1.8; l.position.x = nx; });
    flames.forEach(f => f.scale.setScalar(.8 + Math.random() * .5));
    birds.forEach(b => {
        const d = b.userData;
        b.position.x = d.center + Math.sin(t * d.speed + d.p) * 7;
        b.position.y = d.base + Math.sin(t * 1.6 + d.p) * .65;
        b.position.z = d.z + Math.sin(t * .45 + d.p) * 4;
        b.rotation.y = Math.cos(t * d.speed + d.p) > 0 ? Math.PI / 2 : -Math.PI / 2;
        const a = Math.sin(t * 14 + d.p) * .8;
        d.w1.rotation.z = -a;
        d.w2.rotation.z = a;
    });
    fire.position.y = Math.sin(t * .8) * .4;
    sunBall.position.set(60, 80 + st.y, st.z - 330);
    for (let i = parts.length - 1; i >= 0; i--) {
        const m = parts[i], v = m.userData.v;
        v.y -= 14 * dt;
        m.position.addScaledVector(v, dt);
        m.rotation.x += dt * 8;
        m.userData.l -= dt;
        m.scale.setScalar(Math.max(m.userData.l, 0) + .2);
        if (m.userData.l <= 0) {
            S.remove(m);
            parts.splice(i, 1);
        }
    }
    shake = Math.max(0, shake - dt);
    if (run && !dy && !cv && !cs && secretSystems.bonus.active)
        secretSystems.bonus.update(dt, t);
    if (run && !dy && !cv && !cs && !secretSystems.bonus.active) {
        let ax = (keys.ArrowRight || keys.KeyD ? 1 : 0) - (keys.ArrowLeft || keys.KeyA ? 1 : 0) + Math.max(-1, Math.min(1, keys.tx || 0));
        let az = (keys.ArrowDown || keys.KeyS ? 1 : 0) - (keys.ArrowUp || keys.KeyW ? 1 : 0) + Math.max(-1, Math.min(1, keys.tz || 0));
        {
            const nl = Math.hypot(ax, az);
            if (nl > 1) {
                ax /= nl;
                az /= nl;
            }
        }
        sprinting = !playerCombat.attacking && !!(keys.KeyK || keys.ControlLeft || keys.ControlRight) && Math.hypot(ax, az) > .1;
        const max = playerCombat.attacking ? 7 : sprinting ? 10.3 : 6.4, rate = st.g ? 10 : 5.2;
        st.mx += (ax * max - st.mx) * Math.min(1, dt * rate);
        st.mz += (az * max - st.mz) * Math.min(1, dt * rate);
        st.x += st.mx * dt;
        st.z += st.mz * dt;
        sprintTag.style.display = sprinting && mv ? 'block' : 'none';
        const wl = wp(st.z) - .55, ux = st.x, uz = st.z;
        st.x = Math.max(-wl, Math.min(wl, st.x));
        st.z = Math.max(ZMIN, Math.min(ZMAX, st.z));
        bump = (ax * (ux - st.x) > 1e-4 || az * (uz - st.z) > 1e-4) ? bump + dt : 0;
        if (bump > 5 && !dl) {
            bump = 0;
            talkStart();
        }
        mv = (ax || az) ? 1 : 0; // Rotação de direção controlada suavemente por bunnyckAnimator.
        plats.forEach(p => { if (st.g && Math.abs(st.x - p.position.x) < (p.userData.hw || 1.6) && Math.abs(st.z - p.position.z) < (p.userData.hd || 1.6) && Math.abs(st.y - p.userData.top) < .6)
            st.x = Math.max(-wl, Math.min(wl, st.x + p.userData.dx)); });
        coy = st.g ? .1 : coy - dt;
        if (keys.Space && !jumpHeld && coy > 0) {
            const launch = Math.hypot(st.mx, st.mz) > 7.6;
            st.vy = launch ? 12.8 : 10.1;
            st.g = false;
            st.runJump = launch;
            coy = 0;
            jumpHeld = true;
            snd(launch ? 510 : 400, .15, 'square', launch ? 940 : 800);
            fx(st, launch ? 0xffd343 : 0xdddddd, launch ? 7 : 4, 2);
        }
        let gd = pitF(st.x, st.z) < .12 ? gh(st.x, st.z) : null;
        plats.forEach(p => { const u = p.userData; if (Math.abs(st.x - p.position.x) < (p.userData.hw || 1.6) && Math.abs(st.z - p.position.z) < (p.userData.hd || 1.6) && st.y >= u.top - .7)
            gd = gd === null ? u.top : Math.max(gd, u.top); });
        st.vy -= 24 * dt;
        st.y += st.vy * dt;
        if (gd !== null && st.vy <= 0 && st.y <= gd + (st.g ? .45 : .05) && st.y > gd - 1) {
            st.y = gd;
            st.vy = 0;
            st.g = true;
            st.runJump = false;
        }
        else
            st.g = false;
        if (st.y < hp(st.z) - 1.5)
            die('pit');
        if (st.g)
            pits.forEach(([a, b]) => { if (st.z < b - 1 && b - 3 < cp)
                cp = b - 3; });
        const px = st.x, pz = st.z;
        fruits.forEach(f => { if (f.visible && Math.abs(f.position.x - px) < .8 && Math.abs(f.position.z - pz) < .8 && Math.abs(f.position.y - st.y - .8) < 1.2) {
            f.visible = false;
            addFr(1);
            hud();
            fx(f.position, 0xffb347, 5, 3);
            snd(880, .1, 'sine', 1500);
        } });
        boxes.forEach(b => {
            if (!b.visible)
                return;
            const yy = st.y - b.userData.gy, dx = px - b.position.x, dz = pz - b.position.z, ox = .95 - Math.abs(dx), oz = .95 - Math.abs(dz);
            if (ox > 0 && oz > 0 && yy < 1.2) {
                if (yy > .7 && st.vy <= 0) {
                    st.vy = secretSystems.crates.stomp(b);
                }
                else if (playerCombat.canHit(b, 1.8)) {
                    playerCombat.claim(b); boom(b);
                }
                else if (ox < oz)
                    st.x += Math.sign(dx) * ox;
                else
                    st.z += Math.sign(dz) * oz;
            }
            else if (playerCombat.canHit(b, 1.8) && yy < 1.2 && yy > -.6) {
                playerCombat.claim(b); boom(b);
            }
        });
        secretSystems.crates.playerContact();
        foes.forEach(e => {
            if (!e.visible || e.userData.defeated || enemyCombat.launched(e) || (e.userData.kind === 'piranha' && !e.userData.attackActive))
                return;
            const d = e.userData, yy = st.y - d.gy, dx = px - e.position.x, dz = pz - e.position.z;
            const close = Math.abs(dx) < (d.kind === 'beetle' ? 1.23 : d.kind === 'bear' ? 1.35 : (d.kind === 'fish' || d.kind === 'piranha') ? .9 : .88) && Math.abs(dz) < (d.kind === 'bear' ? 1.05 : .84) && yy < (d.kind === 'bear' ? 1.8 : 1.5) && yy > -.7 || (d.reach && Math.hypot(dx, dz) < d.reach && yy < 1.7 && yy > -.7);
            const spinHit = playerCombat.canHit(e, (d.kind === 'beetle' ? 1.9 : d.kind === 'bear' ? 2.05 : (d.kind === 'fish' || d.kind === 'piranha') ? 1.3 : 1.65)) && yy < 1.8 && yy > -.6;
            if (close || spinHit) {
                if (spinHit || (close && st.vy < -.6 && yy > .67)) {
                    if (spinHit) playerCombat.claim(e);
                    hitEnemy(e, spinHit);
                    if (close && st.vy < -.6)
                        st.vy = 9;
                }
                else if (d.hurt <= 0 && !enemyCombat.controls(e))
                    die('hit', e);
            }
        });
        walls.forEach(w => { const u = w.userData, dx = st.x - w.position.x, dz = st.z - w.position.z, ox = u.hx + .4 - Math.abs(dx), oz = u.hz + .4 - Math.abs(dz); if (ox > 0 && oz > 0 && st.y - u.gy < 2.6) {
            if (ox < oz)
                st.x += Math.sign(dx) * ox;
            else
                st.z += Math.sign(dz) * oz;
        } });
        spikes.forEach(s => { if (Math.abs(st.x - s.position.x) < s.userData.hw && Math.abs(st.z - s.position.z) < .7 && st.y - s.position.y < .7)
            die('spike'); });
        logs.forEach(l => { if (Math.abs(st.x - l.position.x) < 1.1 && Math.abs(st.z - l.position.z) < .8 && st.y - l.userData.gy < .9)
            die('crush'); });
    }
    P.position.set(st.x, st.y, st.z);
    // Animator V1 substitui o ciclo anterior de membros e não toca na física.
    // Na morte ou cutscene, o controlador NÃO disputa poses com os animadores existentes.
    if (!dy && !cs)
        bunnyckAnimator.update(t, dt, st, run, sprinting, spin, mv);
    const gg = secretSystems.bonus.active ? (st.g ? st.y : 18) : gh(st.x, st.z);
    shadow.position.set(st.x, gg + .06, st.z);
    shadow.visible = secretSystems.bonus.active || pitF(st.x, st.z) < .12;
    shadow.scale.setScalar(Math.max(.3, 1 - Math.max(0, st.y - gg) * .12));
    swoosh.visible = spin > 0 && !dy;
    swoosh.position.set(st.x, st.y + .6, st.z);
    swoosh.rotation.z += dt * 25;
    if (dy)
        dieAnim(dt);
    cutsceneUpdate(t, dt);
    finalPolish.update(t, dt, st, run, dy, cs, sprinting, mv);
    const cy = dy && dy.k == 'pit' ? (hp(st.z) + Math.max(st.y, hp(st.z) - 9)) / 2 : st.y;
    if (secretSystems.bonus.active)
        secretSystems.bonus.camera(dt);
    else
        cameraRails.camera(t, dt, st, run, cs, sprinting, cy, shake, dy);
    C.updateMatrixWorld();
    npcUpdate(t, dt);
    playerCombat.pose(t);
    enemyCombat.pose();
    if (bhVideo().psx === false) {
        R.setRenderTarget(null);
        R.render(S, C);
    }
    else {
        R.setRenderTarget(RT);
        R.render(S, C);
        R.setRenderTarget(null);
        R.render(qs, qc);
    }
}
if ($('previewBonus'))
    $('previewBonus').addEventListener('click', e => { e.stopPropagation(); if (!run)
        $('ov').onclick(); secretSystems.bonus.debugEnter(); });
if ($('previewOutro2'))
    $('previewOutro2').addEventListener('click', e => { e.stopPropagation(); if (!run)
        $('ov').onclick(); forestOutro.start(); });
if ($('previewCut'))
    $('previewCut').addEventListener('click', e => { e.stopPropagation(); if (!run)
        $('ov').onclick(); startEndingCutscene(); });
addEventListener('pointerdown', e => { if (e.pointerType === 'mouse' && cs && cv)
    cvNext(); });
hud();
requestAnimationFrame(loop);
addEventListener('message', e => { if (e.data?.type === 'bunny-havoc-preview-outro2') {
    if (!run)
        $('ov').onclick();
    forestOutro.start();
} });
