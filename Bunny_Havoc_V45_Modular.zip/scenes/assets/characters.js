
if (!window.THREE) { const error=document.getElementById('error');error.style.display='block';error.textContent='Não foi possível carregar os personagens. Verifique o acesso à internet e ao CDN do Three.js.'; }
else {
const T=THREE;
function mkBig() {
    const g=new T.Group(),core=new T.Group();g.name='Bunnyldu';g.add(core);
    const fur=0x34333b,light=0x44434c,shadow=0x24232a,white=0xf6f4f5;
    const gray=0xd2d0d4,pink=0xf77f94,pale=0xffa6b2;
    const legs=[],arms=[],ears=[];
    // Porte forte em caixas chanfradas, com a grande barriga branca da concept.
    const torso=bhCharBlock(core,[1.48,1.10,.83],fur,[0,1.85,0],.10);
    // Tronco largo no peito, estreitando em direcao aos quadris.
    const vertices=torso.geometry.getAttribute('position');
    for(let i=0;i<vertices.count;i++)vertices.setX(i,vertices.getX(i)*(.87+.13*(vertices.getY(i)/1.10+.5)));
    vertices.needsUpdate=true;torso.geometry.computeVertexNormals();
    bhCharBlock(core,[1.08,.29,.69],shadow,[0,1.22,0],.045);
    bhCharBlock(core,[.56,.29,.59],fur,[0,2.36,0],.03);
    bhCharPrism(core,[[-.28,2.20],[.28,2.20],[.34,1.77],[.29,1.36],[-.29,1.36],[-.34,1.77]],.07,white,[0,0,.437]);
    bhCharPrism(core,[[-.326,1.91],[.326,1.91],[.34,1.77],[.322,1.62],[-.322,1.62],[-.34,1.77]],.016,0xe6e4e7,[0,0,.479]);
    bhCharPrism(core,[[-.322,1.62],[.322,1.62],[.29,1.36],[-.29,1.36]],.016,gray,[0,0,.479]);
    for(const s of [-1,1]) {
        const leg=new T.Group();leg.position.set(s*.34,.94,0);core.add(leg);
        const thigh=bhCharBlock(leg,[.39,.56,.44],fur,[s*.055,-.11,0],.04);thigh.rotation.z=s*.20;
        bhCharBlock(leg,[.40,.32,.44],light,[s*.11,-.47,0],.035);
        bhCharBlock(leg,[.49,.25,.50],shadow,[s*.11,-.58,.015],.02);
        // Tenis grandes em degraus: branco, sem cadarcos ou acessorios metalicos.
        bhCharBlock(leg,[.52,.18,.55],white,[s*.11,-.665,.14],.025);
        bhCharBlock(leg,[.63,.23,.83],white,[s*.11,-.80,.16],.025);
        bhCharBlock(leg,[.65,.10,.86],gray,[s*.11,-.89,.16],.008);
        legs.push(leg);
        const arm=new T.Group();arm.position.set(s*1.02,1.72,0);core.add(arm);
        bhCharBlock(arm,[.63,.48,.64],light,[-s*.04,.30,0],.085);
        const bicep=bhCharBlock(arm,[.49,.48,.50],fur,[s*.015,-.11,0],.06);bicep.rotation.z=s*.13;
        const forearm=bhCharBlock(arm,[.51,.33,.51],light,[s*.04,-.455,.025],.055);forearm.rotation.z=s*.10;
        bhCharBlock(arm,[.53,.14,.54],shadow,[s*.04,-.64,.025],.014);
        bhCharBlock(arm,[.51,.39,.52],white,[s*.04,-.86,.06],.055);
        bhCharBlock(arm,[.18,.23,.28],white,[-s*.21,-.87,.21],.03);
        arms.push(arm);
        const ear=new T.Group();ear.position.set(s*.3,3.74,0);ear.rotation.z=-s*.17;core.add(ear);
        bhCharBlock(ear,[.33,1.05,.23],fur,[0,-.025,0],.014);
        bhCharBlock(ear,[.19,.81,.025],pink,[0,-.045,.129]);
        bhCharBlock(ear,[.30,.065,.22],light,[0,.46,0],.006);
        ears.push(ear);
    }
    const head=new T.Group();head.position.set(0,2.85,0);core.add(head);
    bhCharBlock(head,[1.26,.83,.99],fur,[0,.025,0],.06);
    bhCharBlock(head,[1.14,.30,.92],fur,[0,-.28,.025],.035);
    bhCharBlock(head,[1.16,.28,.25],white,[0,-.215,.495],.025);
    for(const s of [-1,1]) {
        bhCharBlock(head,[.25,.23,.27],white,[s*.575,-.20,.405],.018);
        bhCharBlock(head,[.11,.22,.24],shadow,[s*.67,-.195,.30],.014);
    }
    const face={brows:[],eyes:[],pupils:[]};
    for(const s of [-1,1]) {
        face.eyes.push(bhCharBlock(head,[.30,.30,.03],white,[s*.28,.105,.514],.006));
        const pupil=new T.Group();pupil.position.set(s*.255,.085,.542);head.add(pupil);
        bhCharBlock(pupil,[.135,.23,.025],shadow,[0,0,0],.005);
        bhCharBlock(pupil,[.028,.045,.012],0xfdfbff,[-.028,.070,.019]);face.pupils.push(pupil);
        const brow=bhCharBlock(head,[.36,.10,.075],shadow,[s*.28,.275,.55],.008);face.brows.push(brow);
    }
    bhCharBlock(head,[.18,.105,.09],pink,[0,-.045,.642],.009);
    bhCharBlock(head,[.14,.025,.015],pale,[0,-.004,.691],.003);
    const mouth=new T.Group();mouth.position.set(0,-.252,.635);head.add(mouth);
    const smile=new T.Group(),gasp=new T.Group(),frown=new T.Group(),open=new T.Group();mouth.add(smile,gasp,frown,open);
    bhCharPrism(smile,[[-.15,.025],[-.11,-.004],[0,-.019],[.10,.002],[.15,.045],[.13,.003],[.10,-.022],[0,-.043],[-.12,-.025]],.025,shadow,[0,0,0]);
    bhCharPrism(gasp,[[-.066,.045],[-.04,.085],[.04,.085],[.066,.045],[.066,-.04],[.035,-.08],[-.035,-.08],[-.066,-.04]],.025,0x2b1319,[0,0,0]);
    bhCharBlock(gasp,[.075,.023,.012],0xd95260,[0,-.050,.022],.006);
    bhCharPrism(frown,[[-.145,-.025],[-.08,.002],[0,.012],[.08,.002],[.145,-.025],[.08,.023],[0,.035],[-.08,.023]],.025,shadow,[0,0,0]);
    bhCharPrism(open,[[-.17,.055],[-.07,.030],[.06,.037],[.17,.070],[.14,-.015],[.08,-.075],[0,-.090],[-.09,-.065],[-.15,-.01]],.025,0x2b1319,[0,0,0]);
    bhCharPrism(open,[[-.135,.047],[-.065,.035],[.065,.041],[.135,.058],[.11,.025],[-.09,.020]],.012,white,[0,0,.022]);
    bhCharBlock(open,[.12,.025,.012],0xd95260,[.005,-.06,.022],.008);
    Object.assign(face,{mouth,smile,gasp,frown,open});
    bhCharBlock(head,[.20,.14,.20],fur,[0,.46,-.035],.012);
    bhCharBlock(head,[.12,.095,.14],light,[0,.57,-.035],.008);
    const tail=new T.Group();tail.position.set(0,1.05,-.45);core.add(tail);
    bhCharBlock(tail,[.30,.29,.30],white,[0,0,-.055],.025);
    g.scale.setScalar(.8);g.userData={core,legs,arms,ears,head,tail,face,modelVersion:32};
    bhBigExpression(g,'smug');return g;
}

function bhBigExpression(model,style,t=0,talking=false) {
    const f=model.userData.face,panic=style==='panic',angry=style==='angry';
    f.brows.forEach((b,i)=>{const s=i===0?-1:1;b.position.y=panic?.335:angry?.235:.275;b.rotation.z=s*(panic?-.08:angry?.40:.25);});
    f.eyes.forEach(e=>e.scale.y=panic?1.10:angry?.88:1);
    f.pupils.forEach(e=>{e.scale.x=panic?.80:1;e.scale.y=panic?.92:1;});
    f.smile.visible=!panic&&!angry&&!talking;f.gasp.visible=panic;f.frown.visible=angry&&!talking;f.open.visible=talking&&!panic;
    f.mouth.scale.set(1,talking?.75+Math.abs(Math.sin(t*17))*.45:1,1);
}

function mkBibi() {
    const g = new T.Group(), core = new T.Group();
    g.name = 'Bibibunn'; g.add(core);
    const white=0xfff6fa, shade=0xe5dce5, pink=0xf62a91, pale=0xff9bc9;
    const plum=0x332432, dark=0x211d29, facet=0x473444, deepPink=0xa51c62;
    const legs=[], arms=[], ears=[], hair=[];
    // Concept: blocos largos, corpete angular e abas divididas, sem cabelo longo.
    bhCharBody(core, [[1.13,.40,.27],[1.31,.29,.23],[1.52,.29,.24],[1.73,.44,.31],[1.88,.47,.29],[1.98,.33,.23]], dark);
    // Decote em coracao: duas placas facetadas integradas ao corpete.
    for(const s of [-1,1]) {
        const shoulder=bhCharBlock(core,[.23,.18,.28],white,[s*.47,1.88,-.015],.015);shoulder.rotation.z=-s*.30;
        const panel=bhCharPrism(core, [[s*.025,1.78],[s*.24,1.95],[s*.43,1.87],[s*.40,1.64],[s*.17,1.61]], .12, facet, [0,0,.235]);
        panel.rotation.y=s*.09;
        bhCharPrism(core, [[s*.015,1.82],[s*.23,2.00],[s*.44,1.90],[s*.43,1.82],[s*.24,1.91],[s*.02,1.73]], .045, pink, [0,0,.335]);
        bhCharPrism(core, [[s*.28,1.39],[s*.35,1.26],[s*.48,1.21],[s*.34,1.12],[s*.24,1.23]], .045, pink, [0,0,.27]);
    }
    bhCharPrism(core, [[-.12,1.30],[.12,1.30],[.085,1.58],[.17,1.76],[0,1.66],[-.17,1.76],[-.085,1.58]], .04, pink, [0,0,.285]);
    bhCharDiamond(core, [.15,.19,.065], pink, [0,1.84,.39]);
    bhCharBody(core, [[.98,.22,.23],[1.12,.39,.28],[1.26,.43,.27]], plum);
    bhCharBlock(core,[.30,.15,.29],white,[0,2.02,-.015],.018);
    bhCharBlock(core,[.36,.085,.33],dark,[0,2.035,-.015],.008);
    // Abas laterais e traseiras com borda rosa: a silhueta da folha de referencia.
    for(const s of [-1,1]) {
        const flap=new T.Group(); flap.rotation.y=-s*.20; core.add(flap);
        bhCharPrism(flap, [[s*.32,1.30],[s*.53,1.22],[s*.86,.52],[s*.53,.69],[s*.32,.94]], .105, deepPink, [0,0,-.10]);
        bhCharPrism(flap, [[s*.36,1.27],[s*.52,1.20],[s*.83,.56],[s*.52,.72],[s*.35,.94]], .025, pink, [0,0,-.027]);
        bhCharPrism(flap, [[s*.40,1.21],[s*.49,1.17],[s*.73,.68],[s*.54,.80],[s*.41,.97]], .02, plum, [0,0,-.002]);
        bhCharPrism(core, [[s*.025,1.27],[s*.37,1.27],[s*.53,.58],[s*.10,.76]], .09, deepPink, [0,0,-.32]);
        bhCharPrism(core, [[s*.065,1.22],[s*.33,1.22],[s*.46,.69],[s*.14,.82]], .025, plum, [0,0,-.38]);
        const leg=new T.Group();leg.position.set(s*.27,.83,0);core.add(leg);
        bhCharBlock(leg,[.34,.39,.36],white,[0,.025,0],.025);
        bhCharBlock(leg,[.37,.105,.39],pink,[0,-.115,0],.008);
        bhCharBlock(leg,[.39,.48,.43],dark,[0,-.40,0],.025);
        bhCharBlock(leg,[.40,.12,.45],facet,[0,-.25,.005],.018);
        bhCharBlock(leg,[.43,.16,.47],plum,[0,-.59,.01],.022);
        bhCharBlock(leg,[.46,.255,.65],dark,[0,-.725,.10],.035);
        bhCharBlock(leg,[.48,.065,.68],pink,[0,-.835,.10],.008);
        bhCharBlock(leg,[.29,.12,.075],facet,[0,-.72,.426],.01);
        bhCharPrism(leg,[[-.12,-.82],[.12,-.82],[0,-.73]],.018,deepPink,[0,0,.444]);
        leg.children.forEach(part=>part.position.x+=s*.03);
        legs.push(leg);
        const arm=new T.Group();arm.position.set(s*.76,1.6,0);core.add(arm);
        const upper=bhCharBlock(arm,[.28,.38,.31],white,[-s*.065,.12,0],.022);upper.rotation.z=-s*.35;
        bhCharBlock(arm,[.37,.10,.38],pink,[0,-.065,.005],.008);
        bhCharBlock(arm,[.38,.39,.39],plum,[0,-.31,.005],.035);
        bhCharBlock(arm,[.39,.12,.42],dark,[0,-.50,.015],.016);
        bhCharBlock(arm,[.43,.28,.44],dark,[0,-.67,.04],.032);
        bhCharBlock(arm,[.15,.20,.25],facet,[-s*.215,-.61,.11],.02);
        bhCharBlock(arm,[.30,.14,.025],facet,[0,-.64,.272],.012);
        arms.push(arm);
        const ear=new T.Group();ear.position.set(s*.3,2.84,0);ear.rotation.z=-s*.19;core.add(ear);
        bhCharBlock(ear,[.32,1.03,.23],white,[0,.50,0],.022);
        bhCharBlock(ear,[.19,.78,.025],pale,[0,.48,.127]);
        bhCharBlock(ear,[.055,.78,.028],0xf37fae,[-s*.067,.48,.132]);
        ears.push(ear);
    }
    const head=new T.Group();head.position.set(0,2.38,0);core.add(head);
    bhCharBlock(head,[1.13,.78,.93],white,[0,.025,0],.045);
    bhCharBlock(head,[.92,.25,.91],white,[0,-.30,.015],.025);
    // Focinho largo em blocos; olhos e sobrancelhas continuam legiveis de longe.
    for(const s of [-1,1]) {
        bhCharBlock(head,[.36,.20,.29],white,[s*.405,-.185,.455],.012);
        bhCharBlock(head,[.19,.07,.018],shade,[s*.43,-.265,.603]);
    }
    const face={brows:[],eyes:[],pupils:[],lids:[]};
    for(const s of [-1,1]) {
        const eye=bhCharBlock(head,[.32,.255,.035],0xfffdff,[s*.29,-.015,.481],.008);face.eyes.push(eye);
        const pupil=new T.Group();pupil.position.set(s*.275,-.02,.512);head.add(pupil);
        bhCharBlock(pupil,[.12,.205,.023],deepPink,[0,0,0],.006);
        bhCharBlock(pupil,[.063,.19,.018],dark,[-s*.015,0,.016]);
        bhCharBlock(pupil,[.025,.055,.014],white,[-.024,.053,.032]);face.pupils.push(pupil);
        const lid=bhCharBlock(head,[.36,.045,.04],dark,[s*.29,.104,.516]);lid.rotation.z=s*.16;face.lids.push(lid);
        bhCharPrism(head,[[s*.42,.105],[s*.55,.135],[s*.65,.23],[s*.62,.095],[s*.55,.045],[s*.43,.035]],.035,dark,[0,0,.527]);
        bhCharPrism(head,[[s*.44,.058],[s*.57,.065],[s*.635,.13],[s*.60,.025],[s*.47,-.005]],.035,dark,[0,0,.53]);
        const brow=new T.Group();brow.position.set(s*.29,.135,.535);head.add(brow);
        bhCharPrism(brow,[[s*.18,.085],[-s*.15,-.04],[-s*.15,.055],[s*.105,.165]],.04,pink,[0,0,0]);face.brows.push(brow);
    }
    bhCharBlock(head,[.155,.085,.07],pink,[0,-.143,.586],.008);
    bhCharBlock(head,[.115,.02,.015],pale,[0,-.114,.629]);
    const mouth=new T.Group();mouth.position.set(0,-.305,.527);head.add(mouth);
    const smile=new T.Group(),gasp=new T.Group();mouth.add(smile,gasp);
    bhCharPrism(smile,[[-.17,.055],[-.08,.022],[.02,.020],[.12,.055],[.17,.08],[.14,-.015],[.095,-.068],[.025,-.088],[-.06,-.068],[-.13,-.025]],.035,0x310f22,[0,0,0]);
    bhCharPrism(smile,[[-.14,.046],[-.04,.024],[.08,.036],[.13,.063],[.08,.015],[-.045,.002]],.018,white,[0,0,.027]);
    bhCharBlock(smile,[.095,.025,.018],0xe74c83,[.025,-.060,.029],.008);
    bhCharPrism(gasp,[[-.065,.06],[-.04,.10],[.04,.10],[.065,.06],[.065,-.055],[.035,-.09],[-.035,-.09],[-.065,-.055]],.035,0x310f22,[0,0,0]);
    bhCharBlock(gasp,[.07,.026,.018],0xe74c83,[0,-.061,.029],.008);
    face.mouth=mouth;face.smile=smile;face.gasp=gasp;
    // Coroa preta com pontas largas atras do losango fuchsia.
    bhCharPrism(head,[[-.33,.405],[-.33,.61],[-.22,.58],[-.17,.82],[0,.66],[.17,.82],[.22,.58],[.33,.61],[.33,.405]],.25,dark,[0,0,.035]);
    bhCharDiamond(head,[.145,.235,.095],pink,[0,.58,.16]);
    const tail=new T.Group();tail.position.set(0,1.08,-.34);core.add(tail);
    bhCharBlock(tail,[.29,.29,.30],white,[0,0,-.17],.035);
    g.userData={core,head,legs,arms,ears,hair,tail,face,modelVersion:31};
    g.scale.setScalar(.84);
    bhBibiExpression(g,'smug');
    return g;
}

// As mesmas pecas faciais sao usadas pelo jogo e pela galeria.
function bhBibiExpression(model,style,t=0,talking=false) {
    const f=model.userData.face,panic=style==='panic',angry=style==='angry';
    f.brows.forEach((b,i)=>{const s=i===0?-1:1;b.position.y=panic?.24:angry?.10:.135;b.rotation.z=panic?-s*.28:angry?s*.12:i===0?-.08:.06;});
    f.eyes.forEach(e=>e.scale.y=panic?1.17:angry?.85:1);
    f.pupils.forEach(e=>{e.scale.y=panic?.92:1;e.scale.x=panic?.75:1;});
    f.lids.forEach((e,i)=>{e.position.y=panic?.145:.104;e.rotation.z=(i===0?-1:1)*(panic?.03:angry?.27:.16);});
    f.smile.visible=!panic;f.gasp.visible=panic;
    f.mouth.scale.set(angry?1.12:1,talking?.80+Math.abs(Math.sin(t*17))*.45:angry?1.25:1,1);
}

// Materiais compartilhados dentro de cada documento de fase; sem texturas externas.
const bhCharMaterials=new Map();
function bhCharMaterial(color) {
    if(!bhCharMaterials.has(color)) bhCharMaterials.set(color,new T.MeshLambertMaterial({color}));
    return bhCharMaterials.get(color);
}
function bhCharMesh(parent,geometry,color,position) {
    // r128 usa Lambert por vertice. Normais separadas preservam as facetas sem
    // depender da opcao flatShading, ausente nesse material nessa versao.
    const flat=geometry.index?geometry.toNonIndexed():geometry;
    flat.computeVertexNormals();
    const m=new T.Mesh(flat,bhCharMaterial(color)); m.position.set(...position); parent.add(m); return m;
}
function bhCharPrism(parent,points,depth,color,position) {
    const shape=new T.Shape();shape.moveTo(...points[0]);
    points.slice(1).forEach(p=>shape.lineTo(...p));shape.closePath();
    const geo=new T.ExtrudeGeometry(shape,{depth,bevelEnabled:false,steps:1,curveSegments:1});
    geo.translate(0,0,-depth/2);
    return bhCharMesh(parent,geo,color,position);
}
function bhCharDiamond(parent,radii,color,position) {
    const m=bhCharMesh(parent,new T.OctahedronGeometry(1),color,position);
    m.scale.set(...radii);return m;
}
function bhCharBlock(parent,size,color,position,bevel=0) {
    const [w,h,d]=size;
    if(!bevel) return bhCharMesh(parent,new T.BoxGeometry(w,h,d),color,position);
    const b=Math.min(bevel,w*.24,h*.24,d*.24), shape=new T.Shape();
    const x=w/2-b,y=h/2-b;
    shape.moveTo(-x,-y);shape.lineTo(x,-y);shape.lineTo(x,y);shape.lineTo(-x,y);shape.closePath();
    const geo=new T.ExtrudeGeometry(shape,{depth:d-2*b,bevelEnabled:true,bevelThickness:b,bevelSize:b,bevelSegments:1,steps:1,curveSegments:1});
    geo.translate(0,0,-(d-2*b)/2);
    return bhCharMesh(parent,geo,color,position);
}
function bhCharOval(parent,radii,color,position) {
    const m=bhCharMesh(parent,new T.SphereGeometry(1,8,6),color,position);m.scale.set(...radii);return m;
}
function bhCharBody(parent,rings,color,position=[0,0,0]) {
    const vertices=[],indices=[],segments=8;
    for(const [y,rx,rz] of rings) for(let i=0;i<segments;i++) {
        const a=i/segments*Math.PI*2;vertices.push(Math.sin(a)*rx,y,Math.cos(a)*rz);
    }
    for(let j=0;j<rings.length-1;j++) for(let i=0;i<segments;i++) {
        const a=j*segments+i,b=j*segments+(i+1)%segments,c=a+segments,d=b+segments;
        indices.push(a,b,c,b,d,c);
    }
    for(let i=1;i<segments-1;i++) {indices.push(0,i+1,i);const o=(rings.length-1)*segments;indices.push(o,o+i,o+i+1);}
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals();
    return bhCharMesh(parent,geo,color,position);
}

const stage=document.getElementById('stage'),renderer=new T.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.setClearColor(0x191824);stage.prepend(renderer.domElement);
const scene=new T.Scene(),camera=new T.PerspectiveCamera(34,1,.05,100);
scene.add(new T.HemisphereLight(0xfff0f8,0x655778,.65));
const key=new T.DirectionalLight(0xfff0df,.80);key.position.set(-4,7,8);scene.add(key);
const fill=new T.DirectionalLight(0xa8bbff,.30);fill.position.set(5,4,-5);scene.add(fill);
const group=new T.Group(),big=mkBig(),bibi=mkBibi();scene.add(group);group.add(big,bibi);
const floor=new T.Mesh(new T.CircleGeometry(9,48),new T.MeshLambertMaterial({color:0x302a3c}));floor.rotation.x=-Math.PI/2;floor.position.y=-.055;scene.add(floor);
const rings=new T.Group();scene.add(rings);
for(const x of [-1.45,1.45]){const m=new T.Mesh(new T.RingGeometry(.75,.78,32),new T.MeshBasicMaterial({color:0x85617f,side:T.DoubleSide}));m.rotation.x=-Math.PI/2;m.position.set(x,-.035,0);rings.add(m);}
let mode='big',expression='smug',auto=false,yaw=0,zoom=1,drag=null,last=performance.now();
const target=new T.Vector3(),eye=new T.Vector3(.30,.11,1).normalize();let distance=10;
function pose(time){
    const b=big.userData,u=bibi.userData;
    b.core.position.y=Math.sin(time*1.7)*.018;b.arms[0].rotation.z=-.08;b.arms[1].rotation.z=.08;
    b.head.rotation.y=Math.sin(time*.6)*.055;
    bhBigExpression(big,expression,time);
    u.core.position.y=Math.sin(time*1.9)*.015;u.core.rotation.z=-.035;
    u.arms[1].rotation.set(-.38,0,-.65);u.arms[0].rotation.set(-.13,0,.10);u.head.rotation.z=-.025;
    u.legs[1].rotation.x=-.055;u.ears.forEach((e,i)=>e.rotation.x=-.08+Math.sin(time*1.8+i)*.04);
    u.hair.forEach((h,i)=>h.rotation.z=Math.sin(time*2+i)*.025);
    bhBibiExpression(bibi,expression,time);
}
function fit(){
    renderer.setSize(stage.clientWidth,stage.clientHeight);camera.aspect=stage.clientWidth/stage.clientHeight;camera.updateProjectionMatrix();
    group.rotation.y=0;pose(0);group.updateMatrixWorld(true);
    const box=new T.Box3();if(big.visible)box.expandByObject(big);if(bibi.visible)box.expandByObject(bibi);
    const sphere=box.getBoundingSphere(new T.Sphere());target.copy(sphere.center);
    const vertical=T.MathUtils.degToRad(camera.fov),horizontal=2*Math.atan(Math.tan(vertical/2)*camera.aspect);
    distance=sphere.radius/Math.sin(Math.min(vertical,horizontal)/2)*1.10;
    group.rotation.y=yaw;
}
function select(view){mode=view;big.visible=view!=='bibi';bibi.visible=view!=='big';
    big.position.x=view==='both'?-1.45:0;bibi.position.x=view==='both'?1.45:0;rings.visible=view==='both';
    document.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===view)));
    document.getElementById('title').textContent=view==='bibi'?'Bibibunn':view==='big'?'Bunnyldu':'Personagens';
    zoom=1;fit();setAngle('quarter');}
function setAngle(angle){
    yaw=Math.atan2(eye.x,eye.z)+({front:0,quarter:-.45,side:-Math.PI/2,back:Math.PI})[angle];
    auto=false;document.getElementById('rotate').setAttribute('aria-pressed','false');
    document.querySelectorAll('[data-angle]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.angle===angle)));
}
function setExpression(value){expression=value;document.querySelectorAll('[data-expression]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.expression===value)));}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>select(b.dataset.view));
document.querySelectorAll('[data-angle]').forEach(b=>b.onclick=()=>setAngle(b.dataset.angle));
document.querySelectorAll('[data-expression]').forEach(b=>b.onclick=()=>setExpression(b.dataset.expression));
document.getElementById('rotate').onclick=e=>{auto=!auto;e.currentTarget.setAttribute('aria-pressed',String(auto));};
stage.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;drag={x:e.clientX,yaw};stage.setPointerCapture(e.pointerId);document.querySelectorAll('[data-angle]').forEach(b=>b.setAttribute('aria-pressed','false'));});
stage.addEventListener('pointermove',e=>{if(drag)yaw=drag.yaw+(e.clientX-drag.x)*.009;});
stage.addEventListener('pointerup',()=>drag=null);stage.addEventListener('pointercancel',()=>drag=null);
stage.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(.65,Math.min(1.5,zoom+e.deltaY*.001));},{passive:false});
window.addEventListener('resize',fit);select('big');
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.05,(now-last)/1000);last=now;if(auto&&!drag)yaw+=dt*.32;group.rotation.y=yaw;pose(now/1000);camera.position.copy(target).addScaledVector(eye,distance*zoom);camera.lookAt(target);renderer.render(scene,camera);}
window.BunnyHavocGallery={scene,camera,renderer,models:{big,bibi},select,setAngle,setExpression,get mode(){return mode;},get expression(){return expression;}};
requestAnimationFrame(loop);
}
