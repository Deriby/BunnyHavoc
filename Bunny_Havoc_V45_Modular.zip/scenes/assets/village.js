/* Vila procedural independente: navegação e encenação. O launcher é dono dos saves. */
(()=>{
'use strict';
const $=id=>document.getElementById(id),fail=message=>{$('error').hidden=false;$('error').textContent=message;};
if(!window.THREE){fail('Não foi possível abrir a vila. Confira sua conexão com a internet e tente novamente.');return;}
try{
const T=THREE,Campaign=BunnyHavocCampaign,config=window.__BHVILLAGE__||{preview:true};
const save=Campaign.normalize(config.save)||Campaign.normalize({schema:9,completed:[]}),trial=!!config.trial;
const materials=new Map(),mat=color=>{if(!materials.has(color))materials.set(color,new T.MeshLambertMaterial({color}));return materials.get(color);};
const B=(w,h,d)=>new T.BoxGeometry(w,h,d),mesh=(geo,color,pos)=>{const m=new T.Mesh(geo,mat(color));if(pos)m.position.set(...pos);return m;};
const S=new T.Scene();
const sky=document.createElement('canvas');sky.width=256;sky.height=256;const skyCtx=sky.getContext('2d'),skyGradient=skyCtx.createLinearGradient(0,0,0,256);
skyGradient.addColorStop(0,'#5a9bd3');skyGradient.addColorStop(.62,'#b7deea');skyGradient.addColorStop(1,'#e9e8cb');skyCtx.fillStyle=skyGradient;skyCtx.fillRect(0,0,2,256);S.background=new T.CanvasTexture(sky);
S.fog=new T.Fog(0xc2dae2,110,250);
const hemisphere=new T.HemisphereLight(0xfff5e8,0x536f89,.70);S.add(hemisphere);const sun=new T.DirectionalLight(0xffecc8,.72);sun.position.set(-35,70,35);S.add(sun);
const bhVideo=()=>window.parent?.BunnyHavocSettings?.get?.()||{};
if(bhVideo().psx!==false)T.ShaderChunk.project_vertex += '\n gl_Position.xy=floor(gl_Position.xy/gl_Position.w*vec2(213.,120.)+.5)/vec2(213.,120.)*gl_Position.w;';
const R=new T.WebGLRenderer({antialias:false});R.shadowMap.enabled=true;R.shadowMap.type=T.PCFSoftShadowMap;R.shadowMap.autoUpdate=false;sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-78,right:78,top:65,bottom:-65,near:1,far:180});sun.shadow.bias=-.001;sun.shadow.normalBias=.07;R.setPixelRatio(1);document.body.prepend(R.domElement);
const RT = new T.WebGLRenderTarget(2, 2, { minFilter: T.NearestFilter, magFilter: T.NearestFilter }), qm = new T.ShaderMaterial({ uniforms: { t: { value: RT.texture }, res: { value: new T.Vector2(2, 2) } }, vertexShader: 'varying vec2 v;void main(){v=uv;gl_Position=vec4(position.xy,0.,1.);}', fragmentShader: `uniform sampler2D t;uniform vec2 res;varying vec2 v;
void main(){vec3 c=texture2D(t,v).rgb;vec2 p=floor(v*res);float a=mod(p.x,2.),b=mod(p.y,2.);float d=(a<.5?(b<.5?0.:3.):(b<.5?2.:1.))/4.+.125;
c=c*1.08-.02;c=mix(vec3(dot(c,vec3(.3,.59,.11))),c,1.15);c*= vec3(1.030,1.005,0.972);c=floor(c*31.+d)/31.;vec2 q=v-.5;c*=1.-dot(q,q)*.5;gl_FragColor=vec4(c,1.);}` }), qs = new T.Scene(), qc = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
qs.add(new T.Mesh(new T.PlaneGeometry(2, 2), qm));
let renderStats={calls:0,triangles:0};
const C=new T.PerspectiveCamera(45,1,.1,350),staticRoot=new T.Group();S.add(staticRoot);
const unitBox=new T.BoxGeometry(1,1,1),unitCone=new T.ConeGeometry(1,1,6),unitRock=new T.IcosahedronGeometry(1,0);
function block(parent,size,color,pos,rot=0){const m=mesh(unitBox,color,pos);m.scale.set(...size);m.rotation.y=rot;parent.add(m);return m;}
function cone(parent,radius,height,color,pos){const m=mesh(unitCone,color,pos);m.scale.set(radius,height,radius);parent.add(m);return m;}
function rock(parent,size,color,pos){const m=mesh(unitRock,color,pos);m.scale.set(...size);parent.add(m);return m;}
function cylinder(parent,rt,rb,h,color,pos,sides=10){const m=mesh(new T.CylinderGeometry(rt,rb,h,sides),color,pos);parent.add(m);return m;}
let seed=411;const random=()=>((seed=(seed*16807)%2147483647)/2147483647),range=(a,b)=>a+(b-a)*random();
const wood=0x805436,trim=0x573b2c,gold=0xe7b44b,stone=0x7e8791,path=0xb09e80,grass=0x5c9347;
const courts=Campaign.areas.map((area,i)=>({area:area.id,x:area.x+[-17,18,-17,17,19][i],z:area.z+[-2,0,3,2,3][i],r:7,theme:area.theme,court:true}));
const islands=[{x:0,z:0,r:18,theme:'central'},{x:0,z:29,r:7,theme:'entry'},{x:-20,z:27,r:10.5,theme:'market'},...Campaign.areas.map(a=>({...a,r:12})),...courts],bridges=[];
const labels=[];
const homes=[],obstacles=[],portals=[],npcs=[],guardians=[],bubbles=[],wheels=[],portalMaterials=[];
const MEOWLIN=['Primeiro','Segundo','Terceiro','Quarto','Quinto'].map((ordinal,i)=>({name:'Meowlin '+ordinal,area:i+1,robe:[0x7351ac,0x3f7ea8,0x4f895f,0xb06448,0xb3933d][i]}));
const worldY=2.18;
const lanternGlass=new T.MeshLambertMaterial({color:0xffca59,emissive:0xffa334,emissiveIntensity:.08});
const windowGlass=new T.MeshLambertMaterial({color:0xffcf67,emissive:0xffb245,emissiveIntensity:.06}),lanternSpots=[];
function label(text,parent,x,y,z,width=7,color='#fff1c7',background='#342d36'){
 const c=document.createElement('canvas'),short=text.length<=5;c.width=short?128:512;c.height=short?64:100;const ctx=c.getContext('2d');
 ctx.fillStyle=background;ctx.fillRect(0,0,c.width,c.height);ctx.strokeStyle='#c89d57';ctx.lineWidth=3;ctx.strokeRect(2,2,c.width-4,c.height-4);
 ctx.fillStyle=color;ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='bold '+(short?(text.length===1?52:30):29)+'px Trebuchet MS';ctx.fillText(text,c.width/2,c.height/2,c.width-10);
 const texture=new T.CanvasTexture(c);texture.minFilter=T.LinearFilter;const m=new T.Sprite(new T.SpriteMaterial({map:texture,depthTest:true}));m.position.set(x,y,z);m.scale.set(width,width*c.height/c.width,1);m.userData.villageCaption=text;parent.add(m);labels.push(m);return m;
}
function tree(parent,x,z,s=1,theme='forest',y=2){return villageArt.tree(parent,x,z,s,theme,y);}
const petalPositions=[];for(let i=0;i<8;i++){const a=i*Math.PI/4,b=(i+1)*Math.PI/4,ra=i%2?.095:.22,rb=(i+1)%2?.095:.22;petalPositions.push(0,.04,0,Math.cos(b)*rb,.10,Math.sin(b)*rb,Math.cos(a)*ra,.10,Math.sin(a)*ra);}
const petalGeometry=new T.BufferGeometry();petalGeometry.setAttribute('position',new T.Float32BufferAttribute(petalPositions,3));petalGeometry.computeVertexNormals();
const stemGeometry=new T.CylinderGeometry(.018,.025,.28,4),pollenGeometry=new T.CircleGeometry(.048,5);
function flower(parent,x,z,color=0xf497c6,y=2.08){
 parent.add(mesh(stemGeometry,0x4f713f,[x,y+.14,z]));parent.add(mesh(petalGeometry,color,[x,y+.26,z]));
 const pollen=mesh(pollenGeometry,0xe9c568,[x,y+.32,z]);pollen.rotation.x=-Math.PI/2;parent.add(pollen);
}
function fence(parent,ax,az,bx,bz,y=2){return villageArt.fence(parent,ax,az,bx,bz,y);}
function bridge(a,b,width=3.5){return villageArt.bridge(a,b,width);}
function lamp(parent,x,z,y=2){return villageArt.lamp(parent,x,z,y);}
// Modelos de cenário: perfis desenhados por espécie, UV de casca e massas de folhas.
// Não acrescenta colisões nem muda a topologia navegável da vila.
function createVillageNature({T,add,material}){
 const bark=material('bark',0xffffff),foliage=material('leaf',0xffffff),soil=material('earth',0xffffff),stone=material('rock',0xffffff);
 for(const m of [bark,foliage,soil,stone])m.vertexColors=true;
 // Vegetação baixa recebe sombra; não repete milhares de lâminas no shadow pass.
 const herbs=foliage.clone();herbs.name='VillageUnderstory';herbs.side=T.DoubleSide;foliage.side=T.DoubleSide;
 const trees=[],beds=[];let serial=0;
 const tint=(hex,light=1)=>new T.Color(hex).multiplyScalar(light);
 class Sculpt{
  constructor(){this.p=[];this.u=[];this.c=[];}
  tri(a,b,c,hex,uv=[[0,0],[1,0],[.5,1]]){this.p.push(...a,...b,...c);this.u.push(...uv.flat());const col=typeof hex==='number'?tint(hex):hex;for(let i=0;i<3;i++)this.c.push(col.r,col.g,col.b);}
  quad(a,b,c,d,col,uv=[[0,0],[1,0],[1,1],[0,1]]){this.tri(a,b,c,col,[uv[0],uv[1],uv[2]]);this.tri(a,c,d,col,[uv[0],uv[2],uv[3]]);}
  finish(parent,m){if(!this.p.length)return;const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(this.p,3));g.setAttribute('uv',new T.Float32BufferAttribute(this.u,2));g.setAttribute('color',new T.Float32BufferAttribute(this.c,3));g.computeVertexNormals();return add(parent,g,m);}
 }
 // Anéis orientados pela tangente: curvas e afilamento reais, sem cilindros sobrepostos.
 function limb(mesh,profile,hex,sides=6,phase=0){
  const rings=profile.map((p,j)=>{const v=new T.Vector3(...p.slice(0,3)),prev=profile[Math.max(0,j-1)],next=profile[Math.min(profile.length-1,j+1)],tangent=new T.Vector3(next[0]-prev[0],next[1]-prev[1],next[2]-prev[2]).normalize(),axis=new T.Vector3(0,0,1);if(Math.abs(tangent.z)>.9)axis.set(1,0,0);const right=new T.Vector3().crossVectors(tangent,axis).normalize(),up=new T.Vector3().crossVectors(tangent,right).normalize();return Array.from({length:sides},(_,k)=>{const a=k/sides*Math.PI*2+phase,r=p[3]*(1+.14*Math.sin(k*2.7+phase));return v.clone().addScaledVector(right,Math.cos(a)*r).addScaledVector(up,Math.sin(a)*r).toArray();});});
  for(let j=0;j<rings.length-1;j++)for(let k=0;k<sides;k++){const n=(k+1)%sides,col=tint(hex,.78+(k%3)*.11);mesh.quad(rings[j][k],rings[j][n],rings[j+1][n],rings[j+1][k],col,[[k/sides*2,j*.7],[(k+1)/sides*2,j*.7],[(k+1)/sides*2,(j+1)*.7],[k/sides*2,(j+1)*.7]]);}
 }
 // Calotas de três anéis com contorno recortado. A borda cai em lóbulos, não em esfera.
 function crown(mesh,x,y,z,rx,rz,h,hex,phase=0,pine=false){
  const n=pine?7:9,rings=[],levels=pine?3:4;
  for(let j=0;j<levels;j++){const r=(pine?[.25,1,.76]:[.35,.83,1,.68])[j],yy=(pine?[h,.20,-.14]:[h,h*.68,.08,-.28])[j];rings.push(Array.from({length:n},(_,k)=>{const a=k/n*Math.PI*2,scallop=1+.14*Math.sin(k*2.5+phase)+.07*Math.cos(k*4.1),sag=j===1?Math.sin(k*2.8+phase)*.13:0;return [x+Math.cos(a)*rx*r*scallop+(j===0?.12:0),y+yy+sag,z+Math.sin(a)*rz*r*scallop];}));}
  for(let k=0;k<n;k++){const next=(k+1)%n;mesh.tri([x+.08,y+h+.05,z],rings[0][next],rings[0][k],tint(hex,1.12));for(let j=0;j<levels-1;j++){
    const a=rings[j][k],b=rings[j][next],c=rings[j+1][next],d=rings[j+1][k],uv=v=>[(v[0]-x)/(rx*2)+.5,(v[2]-z)/(rz*2)+.5];mesh.quad(a,b,c,d,tint(hex,j===0?1+(k%3)*.045:.82),j===0?[uv(a),uv(b),uv(c),uv(d)]:[[k/n*3,j*.45],[(k+1)/n*3,j*.45],[(k+1)/n*3,(j+1)*.45],[k/n*3,(j+1)*.45]]);
   }mesh.tri([x,y-.10,z],rings[levels-1][k],rings[levels-1][next],tint(hex,.61));}
 }
 function leaf(mesh,x,y,z,length,width,angle,hex,droop=0){
  const dx=Math.cos(angle),dz=Math.sin(angle),a=[x,y,z],b=[x+dx*length*.48-dz*width,y+.10,z+dz*length*.48+dx*width],c=[x+dx*length,y+droop,z+dz*length],d=[x+dx*length*.48+dz*width,y+.10,z+dz*length*.48-dx*width];
  mesh.quad(a,b,c,d,hex);
 }
 function grass(mesh,x,y,z,height,hex,phase){
  for(let k=0;k<4;k++){const a=phase+k*2.4,dx=Math.cos(a),dz=Math.sin(a),w=.055,h=height*(.65+(k%3)*.18);mesh.tri([x-dz*w,y,z+dx*w],[x+dz*w,y,z-dx*w],[x+dx*.15,y+h,z+dz*.15],tint(hex,.83+k*.065));}
 }
 function mushroom(mesh,x,y,z,scale,hex){
  limb(mesh,[[x,y,z,.028*scale],[x+.025*scale,y+.19*scale,z,.018*scale]],0xd9c59c,4);
  for(let k=0;k<6;k++){const a=k*Math.PI/3,b=(k+1)*Math.PI/3;mesh.tri([x,y+.29*scale,z],[x+Math.cos(b)*.17*scale,y+.17*scale,z+Math.sin(b)*.17*scale],[x+Math.cos(a)*.17*scale,y+.17*scale,z+Math.sin(a)*.17*scale],tint(hex,.85+(k%2)*.15));}
 }
 function boulder(mesh,x,y,z,size,hex,phase){
  const n=7,ring=Array.from({length:n},(_,k)=>{const a=k/n*Math.PI*2,r=size*(.78+.19*Math.sin(k*2+phase));return [x+Math.cos(a)*r,y+.04+(k%2)*size*.08,z+Math.sin(a)*r*.72];}),top=ring.map((v,k)=>[x+(v[0]-x)*.66,y+size*(.49+.10*Math.sin(k*2.8)),z+(v[2]-z)*.65]);
  for(let k=0;k<n;k++){const j=(k+1)%n;mesh.quad(ring[k],ring[j],top[j],top[k],tint(hex,.78+(k%3)*.10));mesh.tri([x,y+size*.58,z],top[j],top[k],tint(hex,1.03));}
 }
 function bed(parent,x,z,theme,phase=0,scale=1){
  const g=new T.Group();g.position.set(x,2.04,z);g.scale.setScalar(scale);parent.add(g);
  const leaves=new Sculpt(),rocks=new Sculpt(),earth=new Sculpt(),wood=new Sculpt();const snow=theme==='snow',pink=theme==='sakura',dry=theme==='forge',green=snow?0x789484:dry?0x79805b:0x688d48;
  for(let k=0;k<5;k++){const a=k*Math.PI*.4,b=(k+1)*Math.PI*.4;earth.tri([0,.035,0],[Math.cos(b)*.56,-.025,Math.sin(b)*.44],[Math.cos(a)*.56,-.025,Math.sin(a)*.44],snow?0xcdd7ce:dry?0x8d8866:0x8b9867);}
  // Pedra parcialmente enterrada, com relevo concentrado nos canteiros.
  boulder(rocks,.10,-.05,-.05,.55,snow?0xc2d1cd:0x8a8d72,phase);
  for(let k=0;k<7;k++){const a=phase+k*2.39,r=.38+(k%3)*.18,xx=Math.cos(a)*r,zz=Math.sin(a)*r;grass(leaves,xx,0,zz,.24+(k%2)*.13,green,a);}
  if(!snow){
   if(!dry)for(let f=0;f<2;f++){const xx=.22+f*.20,zz=.36-f*.19,yy=.31+f*.09;
    limb(wood,[[xx,.02,zz,.012],[xx,yy,zz,.008]],0x6c854c,3);
    for(let petal=0;petal<5;petal++){const a=petal*Math.PI*.4;leaf(leaves,xx,yy,zz,.12,.048,a,pink?0xe7b0c1:f?0xe2c37c:0xd9b9a0,-.015);}
   }
   for(let k=0;k<3;k++){const xx=-.38+k*.35,zz=-.30+Math.sin(k+phase)*.20;leaf(leaves,xx,.06,zz,.34,.10,k*2.3+phase,green);leaf(leaves,xx,.10,zz,.25,.08,k*2.3+phase+1.4,tint(green,1.15));}
   if(!dry)for(let k=0;k<2;k++)mushroom(wood,-.45+k*.22,.02,.25,.65+k*.25,pink?0xb68092:0xb2774f);
   for(let k=0;k<4;k++){const a=k*2.8+phase;leaf(leaves,Math.cos(a)*.69,.025,Math.sin(a)*.63,.16,.055,a,pink?0xdca1b4:k%2?0x9e8b50:0x7c793f,-.015);}
  }
  rocks.finish(g,stone);leaves.finish(g,herbs);wood.finish(g,bark);earth.finish(g,soil);beds.push({x,z,theme});return g;
 }
 function tree(parent,x,z,s,theme,y){
  const index=serial++,variant=index%3,snow=theme==='snow',water=theme==='water',pink=theme==='sakura',dry=theme==='forge';
  const species=snow?'fir':pink?'flowering-cherry':water?(variant===0?'willow':'alder'):dry?'juniper':['oak','hornbeam','rowan'][variant];
  const g=new T.Group();g.position.set(x,y,z);g.scale.setScalar(s);g.rotation.y=(index*2.399)%6.28;parent.add(g);
  const trunk=new Sculpt(),leaves=new Sculpt(),snowcap=new Sculpt(),h=snow?4.75:s>1.8?5.4:3.55+(variant-1)*.23,lean=variant===1?-.34:.24;
  const brown=pink?0x85605b:dry?0x7e6e54:0x8d704d;
  limb(trunk,[[0,.02,0,.34],[lean*.35,.65,.06,.25],[lean,1.7,-.08,.21],[lean*.6,h*.77,.11,.15],[lean+.12,h,.07,.065]],brown,6,index*.37);
  // Raízes com contrafortes: base larga, dobra baixa e ponta enterrada.
  for(let k=0;k<4;k++){const a=k*Math.PI/2+.33,dx=Math.cos(a),dz=Math.sin(a);limb(trunk,[[lean*.16,.60,.02,.16],[dx*.31,.18,dz*.31,.16],[dx*(.77+(k%2)*.18),.015,dz*.77,.028]],brown,4,a);}
  const green=pink?[0xc983a2,0xe2a5b9,0xd798b2]:snow?[0x416956,0x5d7e68,0x718c75]:dry?[0x6c8054,0x859060,0x9b9f6e]:[0x4f7848,0x73934e,0x91a75e];
  if(snow||dry){
   for(let j=0;j<4;j++){const a=j*2.4,yy=1.7+j*.78,r=(snow?1.62:1.40)-j*.27;
    limb(trunk,[[lean*.6,yy-.25,0,.08],[Math.cos(a)*r*.75,yy,Math.sin(a)*r*.65,.025]],brown,4);
    crown(leaves,lean*.6,yy,0,r,r*.88,.65,green[j%3],j+index,true);
    if(snow)crown(snowcap,lean*.6,yy+.32,0,r*.85,r*.75,.46,0xdde7de,j+index,true);
   }
  }else{
   const spread=species==='hornbeam'?.86:species==='willow'?1.22:1.05;
   const templates=species==='hornbeam'?
    [[-.42,h-.57,.10,.99,.90,.95],[.44,h+.12,-.10,.86,.82,1.16],[-.12,h+.95,.06,.78,.73,1.04]]:
    species==='rowan'?[[-.87,h-.36,.21,1.09,.91,.87],[.85,h+.05,-.18,1.02,.92,.92],[.01,h+.65,-.05,1.10,.90,.96]]:
    [[-.72,h-.45,.12,1.25,.93,1.02],[.73,h-.08,.22,1.12,1.02,.95],[-.14,h+.62,-.26,1.25,1.0,1.08]];
   for(let j=0;j<3;j++){const [xx,yy,zz,rx,rz,ch]=templates[j],bx=xx*spread,bz=zz+(variant-1)*.12;
    limb(trunk,[[lean*.7,1.65+j*.36,0,.13-j*.02],[bx*.6,yy-.58,bz-.10,.09],[bx,yy+.12,bz,.035]],brown,5,j);
    crown(leaves,bx,yy,bz,rx*spread,rz,ch,green[j],index+j*1.9);
    // Pontas de folhas soltas quebram o contorno sem acrescentar esferas.
    for(let k=0;k<(species==='willow'?8:4);k++){const a=k*Math.PI/(species==='willow'?4:2)+index*.7;leaf(leaves,bx+Math.cos(a)*rx*.88,yy+.23,bz+Math.sin(a)*rz*.80,species==='willow'?.66:.32,.13,a,green[j],species==='willow'?-.78:-.13);}
   }
  }
  trunk.finish(g,bark);leaves.finish(g,foliage);snowcap.finish(g,foliage);
  // Lit de feuilles et jeunes pousses limité au pied, hors de la voie centrale.
  const ground=new Sculpt();for(let k=0;k<7;k++){const a=k*2.4+index,r=.42+(k%3)*.14;grass(ground,Math.cos(a)*r,.08,Math.sin(a)*r,.22,snow?0x8faba2:0x678548,a);if(k%2===0)leaf(ground,Math.cos(a)*.72,.09,Math.sin(a)*.72,.22,.08,a,pink?0xdba0b6:0xa69259,-.04);}ground.finish(g,herbs);
  trees.push({x,z,scale:s,theme,species,variant,height:h,roots:4,trunkRings:5,crownLayers:snow||dry?4:3});return g;
 }
 function border(parent,x,z,theme,index){return bed(parent,x,z,theme,index*2.4,1+(index%3)*.13);}
 function houseGarden(parent,theme,variant){
  const wood=new Sculpt(),leaves=new Sculpt(),green=theme==='sakura'?0x91a16f:0x73935e;
  if(theme!=='snow'&&theme!=='forge'){
   // Trepadeira presa à lateral da casa, com ramos curvos.
   limb(wood,[[2.09,.40,.70,.026],[2.12,1.25,.48,.022],[2.10,2.12,.76,.012],[2.13,2.85,.36,.005]],0x84734c,4);
   for(let k=0;k<8;k++){const yy=.7+k*.26,zz=.56+Math.sin(k*1.7)*.23;leaf(leaves,2.15,yy,zz,.23,.10,k*1.9,green,.04);}
  }
  // Ferragens e pequenos detalhes permanecem no volume da fachada.
  for(const yy of [.86,1.93])for(const xx of [-.48,.30]){const o=add(parent,new T.BoxGeometry(.13,.05,.025),material('stone',0x5f6359),[xx,yy,2.092]);o.rotation.z=.06;}
  if(theme!=='snow'){
   const side=variant%2?-1:1;
   for(let k=0;k<3;k++){const a=k*2.4,xx=side*2.02+Math.cos(a)*.16,zz=-.60+Math.sin(a)*.24,yy=.48+(k%3)*.11;
    limb(wood,[[side*1.95,.20,-.55,.025],[xx,yy,zz,.012]],0x837751,4);
    for(let j=0;j<3;j++)leaf(leaves,xx,yy,zz,.33,.14,a+j*2.1,green,-.06);
   }
  }
  wood.finish(parent,bark);leaves.finish(parent,herbs);
 }
 return {tree,border,houseGarden,get metrics(){return {trees:trees.map(t=>({...t})),species:[...new Set(trees.map(t=>t.species))],beds:beds.length,extraParticles:0};}};
}

// Direção de arte da vila: malhas próprias, superfícies pintadas e composição.
// O terreno lógico, personagens, portais e progresso continuam no controlador.
const villageArt=(()=>{
 const palette={
  forest:{wall:0xd6b077,roof:0xa84d42,timber:0x69412b,accent:0x688256,ground:'#65834b',dirt:'#b29769',rock:0x776f5b},
  snow:{wall:0xc8d3cb,roof:0x526b7a,timber:0x5d5143,accent:0x7196a2,ground:'#d5e3df',dirt:'#a7b5b3',rock:0x81929a},
  water:{wall:0x92b4b0,roof:0x446f82,timber:0x69533b,accent:0x567f89,ground:'#718c62',dirt:'#b2a17c',rock:0x707f80},
  forge:{wall:0xc59a76,roof:0x745049,timber:0x53483d,accent:0xaa744b,ground:'#8c8568',dirt:'#b39a7e',rock:0x78685d},
  sakura:{wall:0xe4d5b4,roof:0x5e506b,timber:0x654349,accent:0xb16e85,ground:'#799167',dirt:'#bdac8a',rock:0x8a8584},
 };
 const textures=new Map(),surfaces=new Map(),terrain=[],architecture=[],chimneys=[],decorations=[];
 let detailSeed=7109;const rand=()=>((detailSeed=Math.imul(detailSeed,1664525)+1013904223>>>0)/4294967296);
 const color=(hex,mul=1)=>new T.Color(hex).multiplyScalar(mul);
 function texture(kind){
  if(textures.has(kind))return textures.get(kind);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const c=canvas.getContext('2d'),N=128;
  c.fillStyle=kind==='wood'?'#c0af90':kind==='bark'?'#c6bda9':kind==='leaf'?'#c7c9ac':kind==='roof'?'#b6b0a3':kind==='earth'?'#b3aa91':kind==='rock'?'#c6c5b6':'#c8bfa9';c.fillRect(0,0,N,N);
  // Pigmento irregular pintado, com contraste contido para a resolução do jogo.
  for(let i=0;i<440;i++){c.fillStyle=i%3?'rgba(38,31,20,.045)':'rgba(255,251,222,.09)';c.fillRect((i*37+11)%N,(i*59+7)%N,1+i%3,kind==='bark'?5:2);}
  if(kind==='wood'||kind==='bark'){
   const bark=kind==='bark',step=bark?16:32;
   for(let x=0;x<N;x+=step){
    if(!bark){c.fillStyle='rgba(49,39,25,.38)';c.fillRect(x,0,2,N);c.fillStyle='rgba(255,241,196,.30)';c.fillRect(x+2,0,2,N);}
    for(let j=0;j<(bark?4:5);j++){c.strokeStyle=j%2?'rgba(55,43,28,.29)':'rgba(255,244,210,.24)';c.lineWidth=bark?1.5:1;c.beginPath();for(let yy=0;yy<=N;yy+=4){const xx=x+3+j*(bark?3:5)+Math.sin(yy*.055+x+j)*1.7+Math.sin(yy*.17+j)*.5;if(yy)c.lineTo(xx,yy);else c.moveTo(xx,yy);}c.stroke();}
    const kx=x+step*.54,ky=23+(x*7)%79;c.strokeStyle='rgba(65,46,29,.38)';for(let k=0;k<2;k++){c.beginPath();c.ellipse(kx,ky,2+k*1.8,5+k*3,.12,0,Math.PI*2);c.stroke();}
   }
   if(bark)for(let i=0;i<22;i++){const x=(i*47)%N,y=(i*29)%N;c.strokeStyle='rgba(57,43,30,.30)';c.beginPath();c.moveTo(x,y);c.lineTo(x-2,y+6);c.lineTo(x+1,y+12);c.stroke();}
  }else if(kind==='leaf'){
   // Folhas pintadas em leques, com sombra sob cada grupo e nervuras claras.
   for(let row=-1;row<6;row++)for(let col=-1;col<7;col++){
    const x=col*23+(row%2)*11,y=row*27;for(let k=0;k<3;k++){
     c.save();c.translate(x+k*5,y+(k%2)*5);c.rotate(-.7+k*.58);c.fillStyle=['#929b7c','#b0b797','#dce0be'][k];c.beginPath();c.moveTo(0,0);c.quadraticCurveTo(-7,-5,0,-15);c.quadraticCurveTo(8,-6,0,0);c.fill();c.strokeStyle='rgba(247,246,213,.38)';c.beginPath();c.moveTo(0,-2);c.lineTo(0,-11);c.stroke();c.restore();
    }
   }
  }else if(kind==='roof'){
   for(let row=0;row<8;row++)for(let col=-1;col<7;col++){
    const x=col*22+(row%2)*11,y=row*16,drop=(row+col+8)%3;c.fillStyle=['#b4ab99','#c0b5a1','#aaa394'][(row*3+col+9)%3];c.fillRect(x+1,y,21,15+drop);c.fillStyle='#736d61';c.fillRect(x,y+13+drop,22,2);c.fillRect(x,y,1,14);c.fillStyle='#dfd3b9';c.fillRect(x+2,y+1,18,1);c.strokeStyle='rgba(65,56,42,.22)';c.beginPath();c.moveTo(x+15,y+3);c.lineTo(x+13,y+9);c.lineTo(x+16,y+12);c.stroke();if((row*7+col+9)%11===0){c.fillStyle='rgba(117,135,88,.48)';c.fillRect(x+3,y+12,8,2);}
   }
  }else if(kind==='stone'){
   for(let y=0;y<N;y+=24)for(let x=-40;x<N;x+=40){const xx=x+(y%48?20:0);c.strokeStyle='#817968';c.lineWidth=2;c.strokeRect(xx,y,40,24);c.strokeStyle='#e0d4bb';c.lineWidth=1;c.beginPath();c.moveTo(xx+3,y+20);c.lineTo(xx+2,y+3);c.lineTo(xx+35,y+2);c.stroke();}
  }else if(kind==='earth'||kind==='rock'){
   for(let i=0;i<85;i++){const x=(i*53)%N,y=(i*31)%N;c.fillStyle=i%2?'rgba(56,55,41,.16)':'rgba(255,248,218,.20)';c.beginPath();c.moveTo(x,y);c.lineTo(x+5+i%4,y-2);c.lineTo(x+9,y+2);c.lineTo(x+2,y+5);c.closePath();c.fill();}
   if(kind==='rock'){c.strokeStyle='rgba(65,65,51,.20)';for(let i=0;i<8;i++){const y=i*17;c.beginPath();c.moveTo(0,y);c.lineTo(40,y+8);c.lineTo(85,y+3);c.lineTo(N,y+10);c.stroke();}}
  }else{
   for(let i=0;i<26;i++){c.fillStyle='rgba(98,80,52,.09)';c.fillRect((i*23)%N,(i*31)%N,5,3);}
   for(let i=0;i<4;i++){const x=14+i*31,y=21+i*22;c.strokeStyle='rgba(95,78,52,.17)';c.beginPath();c.moveTo(x,y);c.lineTo(x+2,y+6);c.lineTo(x-1,y+11);c.stroke();}
   const stain=c.createLinearGradient(0,90,0,N);stain.addColorStop(0,'rgba(70,68,41,0)');stain.addColorStop(1,'rgba(70,68,41,.13)');c.fillStyle=stain;c.fillRect(0,90,N,38);
  }
  const map=new T.CanvasTexture(canvas);map.name='VillagePainted-'+kind;map.magFilter=T.NearestFilter;map.minFilter=T.LinearMipmapLinearFilter;map.wrapS=map.wrapT=T.RepeatWrapping;
  textures.set(kind,map);return map;
 }
 function material(kind,tint){const key=kind+':'+tint;if(!surfaces.has(key)){const m=new T.MeshLambertMaterial({map:texture(kind),color:tint});m.name='Village-'+key;surfaces.set(key,m);}return surfaces.get(key);}
 function add(parent,geo,m,pos=[0,0,0]){const o=new T.Mesh(geo,m);o.position.set(...pos);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
 function piece(parent,size,m,pos,rotation=0){const o=add(parent,unitBox,m,pos);o.scale.set(...size);o.rotation.y=rotation;return o;}
 // Viga quadrangular afilada: tampas com dois triângulos, sem leques redundantes.
 const beamGeometry=(()=>{const p=[],uv=[],ring=(i,y,r)=>[Math.sin(i*Math.PI/2)*r,y,Math.cos(i*Math.PI/2)*r],tri=(a,b,c,ua=[0,0],ub=[1,0],uc=[1,1])=>{p.push(...a,...b,...c);uv.push(...ua,...ub,...uc);};
  for(let i=0;i<4;i++){const a=ring(i,-.5,1),b=ring(i+1,-.5,1),c=ring(i+1,.5,.8),d=ring(i,.5,.8);tri(a,b,c);tri(a,c,d,[0,0],[1,1],[0,1]);}
  const b=Array.from({length:4},(_,i)=>ring(i,-.5,1)),t=Array.from({length:4},(_,i)=>ring(i,.5,.8));tri(b[0],b[2],b[1]);tri(b[0],b[3],b[2]);tri(t[0],t[1],t[2]);tri(t[0],t[2],t[3]);
  const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.computeVertexNormals();return g;})();
 function beam(parent,a,b,r,m){const p=new T.Vector3(...a),q=new T.Vector3(...b),delta=q.clone().sub(p);const o=add(parent,beamGeometry,m,p.add(q).multiplyScalar(.5).toArray());o.scale.set(r,delta.length(),r);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return o;}
 // Octógono com cantos chanfrados; quatro anéis dão pés, cintura e beiral próprios.
 function bodyGeometry(w,d,h,lean=0){
  const points=[[-.5,-.38],[-.38,-.5],[.38,-.5],[.5,-.38],[.5,.38],[.38,.5],[-.38,.5],[-.5,.38]],positions=[],uv=[];
  const rings=[[0,.94],[.22,1],[h-.24,.95],[h,.97]];
  function face(a,b,c,ta,tb,tc){positions.push(...a,...b,...c);uv.push(...ta,...tb,...tc);}
  for(let band=0;band<3;band++)for(let i=0;i<8;i++){
   const j=(i+1)%8,[y0,s0]=rings[band],[y1,s1]=rings[band+1];
   const at=(n,y,s)=>[points[n][0]*w*s+lean*y/h,y,points[n][1]*d*s];
   const a=at(i,y0,s0),b=at(j,y0,s0),c=at(j,y1,s1),e=at(i,y1,s1),u0=i/2,u1=(i+1)/2;
   face(a,c,b,[u0,y0/2],[u1,y1/2],[u1,y0/2]);face(a,e,c,[u0,y0/2],[u0,y1/2],[u1,y1/2]);
  }
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.computeVertexNormals();return geo;
 }
 function roof(parent,w,d,base,height,m,style='gable',lean=0){
  const pos=[],uv=[];const shape=style==='pagoda'?[[0,1],[.32,.77],[.68,.25],[1,.06]]:style==='gambrel'?[[0,1],[.51,.87],[.83,.32],[1,0]]:[[0,1],[.38,.69],[.76,.23],[1,style==='snow'?-0.12:0]];
  for(const sign of [-1,1])for(let i=0;i<shape.length-1;i++){
   const [xa,ya]=shape[i],[xb,yb]=shape[i+1],a=[sign*xa*w/2+lean,base+ya*height,-d/2],b=[sign*xb*w/2+lean,base+yb*height,-d/2],c=[b[0],b[1],d/2],e=[a[0],a[1],d/2];
   const verts=sign>0?[a,e,c,a,c,b]:[a,b,c,a,c,e];pos.push(...verts.flat());
   uv.push(...(sign>0?[[xa*2,0],[xa*2,d*.55],[xb*2,d*.55],[xa*2,0],[xb*2,d*.55],[xb*2,0]]:[[xa*2,0],[xb*2,0],[xb*2,d*.55],[xa*2,0],[xb*2,d*.55],[xa*2,d*.55]]).flat());
  }
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.computeVertexNormals();add(parent,geo,m);
  // Tábua de borda seguindo o perfil, em vez de um bloco triangular genérico.
  const edge=material('wood',style==='pagoda'?0x73535a:0x785138);
  for(const z of [-d/2,d/2])for(const sign of [-1,1])for(let i=0;i<shape.length-1;i++){
   const [x0,y0]=shape[i],[x1,y1]=shape[i+1];beam(parent,[sign*x0*w/2+lean,base+y0*height-.06,z],[sign*x1*w/2+lean,base+y1*height-.06,z],.075,edge);
  }
  beam(parent,[lean,base+height+.04,-d/2-.12],[lean,base+height+.04,d/2+.12],.11,edge);
  for(const sign of [-1,1])beam(parent,[sign*w/2+lean,base-.06,-d/2],[sign*w/2+lean,base-.06,d/2],.085,edge);
 }
 function arch(parent,w,h,z,m,x=0,y=0){
  const shape=new T.Shape();shape.moveTo(-w/2,0);shape.lineTo(w/2,0);shape.lineTo(w/2,h-w/2);
  for(let i=0;i<=8;i++){const a=i*Math.PI/8;shape.lineTo(Math.cos(a)*w/2,h-w/2+Math.sin(a)*w/2);}shape.lineTo(-w/2,0);
  return add(parent,new T.ExtrudeGeometry(shape,{depth:.08,bevelEnabled:false,curveSegments:2}),m,[x,y,z]);
 }
 function windowFrame(parent,x,y,z,p,round=false){
  const timber=material('wood',p.timber);
  if(round){add(parent,new T.TorusGeometry(.42,.085,3,8),timber,[x,y,z]);const glass=add(parent,new T.CircleGeometry(.35,8),windowGlass,[x,y,z-.025]);glass.name='WarmWindow';}
  else{piece(parent,[1.02,1.12,.13],timber,[x,y,z-.03]);piece(parent,[.79,.86,.16],windowGlass,[x,y,z+.025]);}
  piece(parent,[.07,.86,.17],timber,[x,y,z+.13]);piece(parent,[.84,.07,.17],timber,[x,y,z+.13]);
  if(!round)for(const sign of [-1,1]){const shutter=new T.Group();shutter.position.set(x+sign*.57,y,z+.06);shutter.rotation.y=sign*.28;parent.add(shutter);piece(shutter,[.24,.94,.09],material('wood',p.accent),[0,0,0]);beam(shutter,[-.10,-.32,.065],[.10,.30,.065],.035,timber);}
  piece(parent,[1.12,.12,.48],timber,[x,y-.62,z+.12]);
 }
 const planterPetal=new T.BufferGeometry();planterPetal.setAttribute('position',new T.Float32BufferAttribute([0,.06,0, -.10,0,0, 0,0,.10, 0,.06,0, 0,0,.10, .10,0,0, 0,.06,0, .10,0,0, 0,0,-.10, 0,.06,0, 0,0,-.10, -.10,0,0],3));planterPetal.computeVertexNormals();
 function planter(parent,x,y,z,p){
  add(parent,bodyGeometry(.90,.38,.24),material('wood',p.timber),[x,y,z]);piece(parent,[.78,.025,.29],mat(0x51452e),[x,y+.24,z]);
  for(const dx of [-.26,0,.26]){beam(parent,[x+dx,y+.24,z],[x+dx,y+.48,z],.02,mat(0x4e6d3e));for(let i=0;i<4;i++){const a=i*Math.PI/2;const petal=add(parent,planterPetal,mat(p===palette.sakura?0xefadc9:dx===0?0xe7cb76:0xe1a29a),[x+dx+Math.cos(a)*.065,y+.49,z+Math.sin(a)*.065]);petal.scale.y=.5;}}
 }
 function barrel(parent,x,y,z,s=.55){
  const g=new T.Group();g.position.set(x,y,z);g.scale.setScalar(s);parent.add(g);
  const geo=new T.LatheGeometry([new T.Vector2(.48,0),new T.Vector2(.58,.2),new T.Vector2(.62,.70),new T.Vector2(.54,1.13),new T.Vector2(.48,1.22)],8);
  add(g,geo,material('wood',0x9b7850));for(const yy of [.18,.98])add(g,new T.CylinderGeometry(.58,.58,.085,8),mat(0x52544d),[0,yy,0]);add(g,new T.CylinderGeometry(.48,.48,.06,8),material('wood',0xad8a58),[0,1.21,0]);return g;
 }
 function house(parent,x,z,theme,scale,y,yaw){
  const p=palette[theme],index=homes.length,variant=index%3,g=new T.Group();g.name='VillageHome-'+theme+'-'+index;
  g.position.set(x,y,z);g.rotation.y=yaw;g.scale.setScalar(scale);parent.add(g);
  const h=theme==='snow'?2.7:theme==='sakura'?2.65:3.0+(variant===1?.25:0),lean=theme==='forest'?(variant-1)*.14:0;
  const wall=material(theme==='water'?'wood':'plaster',p.wall),timber=material('wood',p.timber),masonry=material('stone',theme==='snow'?0x8d9894:0x8c7b61);
  add(g,bodyGeometry(4.32,3.92,.48),masonry);add(g,bodyGeometry(4.12,3.7,h,lean),wall,[0,.35,0]);
  // A composição de pilares deixa o reboco e a forma da casa legíveis.
  for(const xx of [-1.86,1.86])for(const zz of [-1.65,1.65])beam(g,[xx,.35,zz],[xx+lean,h+.35,zz],.105,timber);
  piece(g,[4.16,.16,3.82],timber,[lean*.9,h+.20,0]);
  if(theme==='forest'||theme==='forge')for(const sign of [-1,1])beam(g,[sign*1.82,.7,1.85],[sign*.72,h-.1,1.85],.065,timber);
  const roofStyle=theme==='sakura'?'pagoda':theme==='water'||theme==='forge'?'gambrel':theme==='snow'?'snow':'gable';
  const rh=theme==='snow'?2.65:theme==='sakura'?1.55:theme==='water'?1.75:1.9+variant*.14;
  const rw=theme==='sakura'?5.9:theme==='snow'?5.35:5.45,rd=theme==='sakura'?5.1:4.9;
  // Fechamento do oitão com malha triangular; não deixa o telhado oco.
  for(const zz of [-1.84,1.84]){const a=[-2.03,h+.28,zz],b=[2.03,h+.28,zz],c=[lean,h+rh+.26,zz],geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute((zz>0?[a,b,c]:[a,c,b]).flat(),3));geo.setAttribute('uv',new T.Float32BufferAttribute(zz>0?[0,0,2,0,1,1]:[0,0,1,1,2,0],2));geo.computeVertexNormals();add(g,geo,wall);}
  roof(g,rw,rd,h+.3,rh,material('roof',p.roof),roofStyle,lean);
  if(theme==='snow'){
   roof(g,rw*.96,rd*.97,h+.42,rh,mat(0xe5eeea),'snow',lean);
   for(let i=0;i<5;i++)add(g,new T.ConeGeometry(.065,.34+(i%2)*.17,4),mat(0xb9dce0),[-1.8+i*.87,h+.23,rd/2-.1]).rotation.z=Math.PI;
  }
  if(theme==='sakura'){
   for(const sign of [-1,1]){beam(g,[sign*2.15,h+.56,-rd/2],[sign*3.05,h+.78,-rd/2],.075,timber);beam(g,[sign*2.15,h+.56,rd/2],[sign*3.05,h+.78,rd/2],.075,timber);}
   piece(g,[3.7,.17,1.15],timber,[0,.36,2.2]);for(const xx of [-1.7,1.7])beam(g,[xx,.45,2.35],[xx,h+.1,2.35],.09,timber);
  }
  // Entrada arqueada com soleira, moldura, maçaneta e linhas de tábuas.
  arch(g,1.30,2.24,1.88,timber,-.10,.35);arch(g,1.05,2.02,1.99,material('wood',theme==='water'?0x43646a:0x81613d),-.10,.39);
  add(g,new T.TorusGeometry(.075,.023,3,8),mat(gold),[.17,1.22,2.12]);piece(g,[1.30,.13,.64],masonry,[-.10,.26,2.18]);
  windowFrame(g,-1.29,1.95,1.91,p,theme==='water');windowFrame(g,1.22,1.95,1.91,p,theme==='water');
  planter(g,-1.29,1.10,2.10,p);if(theme!=='forge')planter(g,1.22,1.10,2.10,p);
  windowFrame(g,lean,h+.92,1.87,p,theme!=='sakura');
  if(variant===1&&theme!=='sakura'){
   const dormer=new T.Group();dormer.position.set(-.85,h+.67,.65);g.add(dormer);add(dormer,bodyGeometry(1.15,1.2,.75),wall);roof(dormer,1.5,1.5,.75,.7,material('roof',p.roof));windowFrame(dormer,0,.39,.65,p,true);
  }
  if(theme!=='sakura'&&(variant!==2||theme==='forge')){
   const cx=theme==='forge'?1.34:-1.3,cy=h+rh*.43,cz=-.7;
   add(g,bodyGeometry(theme==='forge'?.88:.62,.72,1.70),masonry,[cx,cy,cz]);piece(g,[1.05,.14,.94],timber,[cx,cy+1.72,cz]);piece(g,[.66,.035,.57],mat(0x383933),[cx,cy+1.80,cz]);
   if(chimneys.length<7){g.updateWorldMatrix(true,false);chimneys.push(new T.Vector3(cx,cy+1.94,cz).applyMatrix4(g.matrixWorld));}
  }
  // Alpendres, anexos e ferramentas diferenciam o uso, sem ampliar a colisão.
  if(variant===0&&theme!=='sakura'){roof(g,3.55,1.15,2.35,.40,material('roof',p.roof));}
  barrel(g,-1.65,.45,2.29,.35);
  if(theme==='water'){
   const net=mat(0x8a9c8b);for(let i=0;i<5;i++){beam(g,[2.13,1.1+i*.21,-.8],[2.13,1.1+i*.21,.8],.014,net);beam(g,[2.13,1.1,-.8+i*.4],[2.13,2,-.8+i*.4],.014,net);}
   for(const xx of [-1.75,1.75])beam(g,[xx,-.55,-1.5],[xx,.4,-1.5],.14,timber);
  }
  if(theme==='forge'){
   piece(g,[.76,.12,.60],mat(0x5c6665),[1.50,.95,2.29]);add(g,bodyGeometry(.34,.32,.60),mat(0x535c5b),[1.50,.36,2.29]);
   beam(g,[1.35,1.22,2.12],[1.72,1.95,2.12],.035,material('wood',0xa17b49));piece(g,[.32,.13,.14],mat(0x757a71),[1.75,1.94,2.12]);
   const furnace=new T.Group();furnace.position.set(2.02,.65,-.15);furnace.rotation.y=Math.PI/2;g.add(furnace);
   arch(furnace,1.15,1.3,0,masonry);arch(furnace,.80,1.05,.10,mat(0x343832));
   const ember=new T.MeshLambertMaterial({color:0xbf6634,emissive:0xff8b32,emissiveIntensity:.6});piece(furnace,[.66,.16,.13],ember,[0,.16,.22]);
   for(const xx of [-.24,0,.24])piece(furnace,[.045,.70,.08],mat(0x4d5048),[xx,.45,.26]);
  }
  if(theme==='snow')for(const sign of [-1,1])beam(g,[1.82+sign*.1,.5,2.1],[1.53+sign*.1,2.4,2.1],.055,material('wood',0xaa7655));
  nature.houseGarden(g,theme,variant);
  architecture.push({theme,variant,roof:roofStyle,position:[x,y,z],width:rw*scale,height:(h+rh)*scale});
  homes.push({x,z,theme,scale,y,yaw});obstacles.push({x,z,r:2.35*scale});return g;
 }
 const nature=createVillageNature({T,add,material});
 function tree(parent,x,z,s,theme,y){
  const g=nature.tree(parent,x,z,s,theme,y);obstacles.push({x,z,r:.33*s});
  decorations.push({type:'tree',theme,x,z});return g;
 }
 function border(parent,x,z,theme,index){nature.border(parent,x,z,theme,index);}
 function terrainIsland(island){
  const theme=palette[island.theme]?island.theme:'forest',p=palette[theme],n=28,points=[],positions=[],normals=[],uv=[],colors=[];
  const rings=[[2.045,1],[1.42,1.03],[-.45,.92],[-2.5,.96],[-5.9,.71]];
  for(let i=0;i<n;i++){const a=i/n*Math.PI*2,extra=(Math.sin(i*2.9+island.x)*.5+.5)*.75;points.push({x:Math.cos(a)*(island.r+extra),z:Math.sin(a)*(island.r+extra)});}
  const face=(a,b,c,tint)=>{positions.push(...a,...b,...c);uv.push(0,0,1,0,1,1);for(let k=0;k<3;k++)colors.push(tint.r,tint.g,tint.b);};
  for(let r=0;r<rings.length-1;r++)for(let i=0;i<n;i++){
   const j=(i+1)%n,[y0,s0]=rings[r],[y1,s1]=rings[r+1],origin=(idx,y,s)=>[island.x+points[idx].x*s,y,island.z+points[idx].z*s];
   const a=origin(i,y0,s0),b=origin(j,y0,s0),c=origin(j,y1,s1),d=origin(i,y1,s1),shade=color(p.rock,.76+(i%4)*.075+(r%2)*.09);
   face(a,b,c,shade);face(a,c,d,shade);
  }
  const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(positions,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.setAttribute('color',new T.Float32BufferAttribute(colors,3));geo.computeVertexNormals();
  const cliffMaterial=new T.MeshLambertMaterial({color:0xffffff,vertexColors:true,map:texture('plaster')});cliffMaterial.name='VillageCliff-'+theme;add(staticRoot,geo,cliffMaterial);
  const canvas=document.createElement('canvas');canvas.width=canvas.height=512;const ctx=canvas.getContext('2d');ctx.scale(2,2);
  const map=new T.CanvasTexture(canvas);map.name='VillageGround-'+island.theme;map.magFilter=T.NearestFilter;map.minFilter=T.LinearMipmapLinearFilter;
  const groundMaterial=new T.MeshLambertMaterial({map});groundMaterial.name='VillageTerrain-'+island.theme;
  const tp=[],tu=[];const push=(a,b,c)=>{tp.push(...a,...b,...c);for(const v of [a,b,c])tu.push(.5+(v[0]-island.x)/(island.r*2.2),.5-(v[2]-island.z)/(island.r*2.2));};
  const fractions=[0,.38,.66,.83,1];
  const at=(k,band)=>{const f=fractions[band],q=points[k],x=island.x+q.x*f,z=island.z+q.z*f;
   const nearAccess=bridges.some(b=>[b.a,b.b].some(e=>Math.hypot(e.x-x,e.z-z)<3));
   const base=band===4?2.045:band===3?2.035:2.14,relief=!island.court&&!nearAccess&&band===3?.012*Math.sin(k*2.1+island.x):0;
   return [x,base+relief,z];};
  for(let i=0;i<n;i++){const j=(i+1)%n;push(at(i,0),at(j,1),at(i,1));for(let band=1;band<4;band++){push(at(i,band),at(j,band),at(j,band+1));push(at(i,band),at(j,band+1),at(i,band+1));}}
  const top=new T.BufferGeometry();top.setAttribute('position',new T.Float32BufferAttribute(tp,3));top.setAttribute('uv',new T.Float32BufferAttribute(tu,2));top.computeVertexNormals();add(staticRoot,top,groundMaterial);
  terrain.push({island,canvas,ctx,map,p});
 }
 function paintTerrain(entry){
  const {island:i,ctx:c,map,p}=entry,px=v=>128+(v-i.x)*256/(i.r*2.2),pz=v=>128+(v-i.z)*256/(i.r*2.2),unit=256/(i.r*2.2);
  c.fillStyle=p.ground;c.fillRect(0,0,256,256);
  // Manchas pintadas são volumes de cor, sem a grade de pedras quadradas anterior.
  for(let j=0;j<220;j++){const x=rand()*256,y=rand()*256;c.fillStyle=j%3?'rgba(30,53,25,.028)':'rgba(242,228,162,.045)';c.beginPath();c.ellipse(x,y,4+rand()*13,3+rand()*7,rand()*3,0,Math.PI*2);c.fill();}
  const routes=[];
  for(const b of bridges)for(const end of [b.a,b.b])if(Math.hypot(end.x-i.x,end.z-i.z)<i.r+1)routes.push([end.x,end.z,b.width]);
  for(const h of homes)if(Math.hypot(h.x-i.x,h.z-i.z)<i.r){const front=new T.Vector3(0,0,3.15*h.scale).applyAxisAngle(new T.Vector3(0,1,0),h.yaw);routes.push([h.x+front.x,h.z+front.z,1.35]);}
  const center=i.theme==='central'?3.0:0;
  // Graminées peintes en petites colonies, pas une grille de points uniforme.
  for(let j=0;j<44;j++){const a=j*2.399,r=i.r*(.67+(j%4)*.075),x=i.x+Math.cos(a)*r,z=i.z+Math.sin(a)*r;
   if(bridges.some(b=>[b.a,b.b].some(e=>Math.hypot(e.x-x,e.z-z)<3)))continue;
   for(let k=0;k<7;k++){const xx=px(x)+Math.sin(k*4.1+j)*3,yy=pz(z)+Math.cos(k*2.7+j)*2;c.strokeStyle=k%2?'rgba(47,74,34,.28)':'rgba(202,206,142,.34)';c.lineWidth=.45;c.beginPath();c.moveTo(xx,yy);c.lineTo(xx+.45,yy-1.4-k%2);c.stroke();}
  }
  for(const [x,z,width] of routes){
   for(const layer of [0,1,2]){c.strokeStyle=layer===0?'#72744e':layer===1?p.dirt:'rgba(244,220,169,.17)';c.lineWidth=(width+(layer===0?.55:layer===1?.22:-.42))*unit;c.lineCap='round';
    const a=Math.atan2(z-i.z,x-i.x),sx=i.x+Math.cos(a)*center,sz=i.z+Math.sin(a)*center;
    c.beginPath();c.moveTo(px(sx),pz(sz));c.bezierCurveTo(px((sx+x)/2)+Math.sin(a)*unit*.8,pz((sz+z)/2)-Math.cos(a)*unit*.8,px(x),pz(z),px(x),pz(z));c.stroke();}
  }
  for(const [x,z,width] of routes){
   const a=Math.atan2(z-i.z,x-i.x),sx=i.x+Math.cos(a)*center,sz=i.z+Math.sin(a)*center,ctrlX=(sx+x)/2+Math.sin(a)*.8,ctrlZ=(sz+z)/2-Math.cos(a)*.8;
   for(let j=1;j<45;j++){const t=j/45,u=1-t,xx=u*u*u*sx+3*u*u*t*ctrlX+3*u*t*t*x+t*t*t*x,zz=u*u*u*sz+3*u*u*t*ctrlZ+3*u*t*t*z+t*t*t*z;
    for(const sign of [-1,1]){const edge=width*.5+.18+Math.sin(j*2.4)*.09,ex=xx+Math.sin(a)*edge*sign,ez=zz-Math.cos(a)*edge*sign;c.fillStyle=j%3?'rgba(104,121,65,.16)':'rgba(193,171,126,.26)';c.beginPath();c.ellipse(px(ex),pz(ez),.12*unit,.07*unit,a,0,Math.PI*2);c.fill();}
    if(j%2){c.fillStyle='rgba(102,81,49,.13)';c.fillRect(px(xx+Math.sin(a)*width*.19),pz(zz-Math.cos(a)*width*.19),.08*unit,.035*unit);}
   }
  }
  // Sombra de contato das raízes pintada no terreno, sem colisões novas.
  for(const tree of nature.metrics.trees)if(Math.hypot(tree.x-i.x,tree.z-i.z)<i.r){const radius=tree.scale*1.1*unit,g=c.createRadialGradient(px(tree.x),pz(tree.z),0,px(tree.x),pz(tree.z),radius);g.addColorStop(0,'rgba(46,48,26,.34)');g.addColorStop(1,'rgba(46,48,26,0)');c.fillStyle=g;c.fillRect(px(tree.x)-radius,pz(tree.z)-radius,radius*2,radius*2);}
  if(i.theme==='central'){c.strokeStyle=p.dirt;c.lineWidth=3.8*unit;c.beginPath();c.ellipse(128,128,4.8*unit,4.8*unit,0,0,Math.PI*2);c.stroke();}
  for(let j=0;j<650;j++){c.fillStyle=j%3?'rgba(49,53,28,.07)':'rgba(254,240,192,.13)';c.fillRect((j*67+31)%256,(j*43+17)%256,1+(j%2),1);}
  // Sombra de contato pintada sob a base das casas; acompanha a transformação real.
  for(const h of homes)if(Math.hypot(h.x-i.x,h.z-i.z)<i.r){c.save();c.translate(px(h.x),pz(h.z));c.rotate(-h.yaw);const ww=5.0*h.scale*unit,dd=4.8*h.scale*unit;const g=c.createRadialGradient(0,0,1,0,0,ww*.7);g.addColorStop(0,'rgba(27,35,28,.36)');g.addColorStop(1,'rgba(27,35,28,0)');c.fillStyle=g;c.scale(1,dd/ww);c.fillRect(-ww,-ww,ww*2,ww*2);c.restore();}
  map.needsUpdate=true;
 }
 function bridge(a,b,width){
  const g=new T.Group(),len=Math.hypot(b.x-a.x,b.z-a.z),timber=material('wood',0x9b744b),dark=material('wood',0x67503a);g.position.set(a.x,2,a.z);g.rotation.y=Math.atan2(b.x-a.x,b.z-a.z);staticRoot.add(g);
  const count=Math.ceil(len/.56);
  for(let i=0;i<=count;i++){const z=Math.min(len,i*len/count),plank=piece(g,[width,.16,.49],timber,[0,-.055+(i%3)*.009,z]);plank.rotation.y=Math.sin(i*2.1)*.009;}
  for(const sign of [-1,1]){
   beam(g,[sign*(width/2-.25),-.32,0],[sign*(width/2-.25),-.32,len],.13,dark);
   for(let z=0;z<=len;z+=2.3){beam(g,[sign*width/2,-.10,z],[sign*width/2,1.10,z],.095,dark);add(g,new T.ConeGeometry(.15,.18,4),timber,[sign*width/2,1.2,z]);}
   for(let z=0;z<len;z+=2.3){const end=Math.min(len,z+2.3),mid=(z+end)/2;beam(g,[sign*width/2,.89,z],[sign*width/2,.76,mid],.037,timber);beam(g,[sign*width/2,.76,mid],[sign*width/2,.89,end],.037,timber);}
  }
  bridges.push({a,b,width});return g;
 }
 function fence(parent,ax,az,bx,bz,y){
  const length=Math.hypot(bx-ax,bz-az),count=Math.ceil(length/1.9),timber=material('wood',0x92734c);
  for(let i=0;i<=count;i++){const x=ax+(bx-ax)*i/count,z=az+(bz-az)*i/count;beam(parent,[x,y,z],[x,y+1.06,z],.065,timber);add(parent,new T.ConeGeometry(.105,.18,4),timber,[x,y+1.16,z]);}
  for(const yy of [.40,.89])beam(parent,[ax,y+yy,az],[bx,y+yy,bz],.038,timber);
 }
 function lamp(parent,x,z,y){
  const timber=material('wood',0x705139),iron=mat(0x4b5048);
  add(parent,new T.CylinderGeometry(.24,.30,.22,6),material('stone',0x8b8972),[x,y+.10,z]);
  beam(parent,[x,y+.17,z],[x,y+2.48,z],.075,timber);beam(parent,[x-.10,y+2.52,z],[x+.54,y+2.52,z],.055,timber);
  const g=new T.Group();g.position.set(x+.39,y+2.07,z);parent.add(g);
  piece(g,[.40,.53,.37],lanternGlass,[0,0,0]);
  for(const xx of [-.22,.22])for(const zz of [-.20,.20])beam(g,[xx,-.30,zz],[xx,.30,zz],.022,iron);
  for(const yy of [-.31,.31])piece(g,[.53,.07,.49],iron,[0,yy,0]);
  add(g,new T.ConeGeometry(.40,.24,4),timber,[0,.46,0]).rotation.y=Math.PI/4;
  parent.updateWorldMatrix(true,false);lanternSpots.push(new T.Vector3(x+.39,y+.14,z).applyMatrix4(parent.matrixWorld));
 }
 function stall(x,z,tint,title){
  const g=new T.Group();g.position.set(x,2,z);staticRoot.add(g);const timber=material('wood',0xa17b4f);
  add(g,bodyGeometry(3.5,1.5,1.1),timber);piece(g,[3.8,.14,1.9],timber,[0,1.15,.10]);
  for(const sign of [-1,1])beam(g,[sign*1.65,0,-.25],[sign*1.65,3.25,-.25],.075,material('wood',0x5e4734));
  // Toldo de lona arqueado e borda recortada em tecido, com espessura visual.
  for(let j=0;j<6;j++){
   const xx=-1.86+j*.62,pos=[],uv=[];for(let k=0;k<4;k++){const z0=-.9+k*.85,z1=z0+.85,y0=3.0-Math.pow((z0+.9)/3.4,2)*.6,y1=3.0-Math.pow((z1+.9)/3.4,2)*.6;pos.push(xx,y0,z0,xx+.62,y0,z0,xx+.62,y1,z1,xx,y0,z0,xx+.62,y1,z1,xx,y1,z1);uv.push(0,0,1,0,1,1,0,0,1,1,0,1);}
   const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));geo.computeVertexNormals();const cloth=material('plaster',j%2?0xf0dbac:tint);cloth.side=T.DoubleSide;add(g,geo,cloth);
   const fringe=new T.Shape();fringe.moveTo(0,0);fringe.lineTo(.62,0);fringe.lineTo(.54,-.20);fringe.lineTo(.08,-.20);fringe.closePath();add(g,new T.ShapeGeometry(fringe),cloth,[xx,2.52,2.5]);
  }
  for(let j=0;j<3;j++){add(g,bodyGeometry(.85,.64,.22),material('wood',0x795836),[-1+j,1.25,.1]);for(let k=0;k<4;k++){const item=add(g,new T.IcosahedronGeometry(.17,0),mat(title.includes('Quitutes')?0xd5a464:k%2?0xdb983d:0x8da754),[-1+j+(k%2)*.28-.13,1.54,.1+Math.floor(k/2)*.25]);item.scale.y=title.includes('Quitutes')?.65:1;}}
  barrel(g,-2.0,0,-.55,.48);obstacles.push({x,z,r:2});decorations.push({type:'shop',x,z,title});
 }
 function court(court,area){
  const p=palette[area.theme],g=new T.Group();g.position.set(court.x,2.12,court.z);staticRoot.add(g);
  // Emblema de bairro no chão; o nome da fase continua apenas no mapa/diálogo.
  const disk=add(g,new T.CircleGeometry(1.10,10),material('stone',0xbaaa84),[0,.025,1]);disk.rotation.x=-Math.PI/2;
  for(let i=0;i<8;i++){const a=i*Math.PI/4;const rune=piece(g,[.12,.035,.35],mat(area.color),[Math.sin(a)*.84,.055,1+Math.cos(a)*.84],a);}
  for(const sign of [-1,1]){
   add(g,bodyGeometry(.55,.55,1.0),material('stone',p.rock),[sign*5.7,0,-.8]);add(g,new T.OctahedronGeometry(.24,0),mat(area.color),[sign*5.7,1.22,-.8]);
  }
 }
 function dress(){
  for(const entry of terrain)paintTerrain(entry);
  for(const area of Campaign.areas){
   court(courts[area.id-1],area);
   const p=palette[area.theme],g=new T.Group();staticRoot.add(g);
   // Vignettes de ofício na margem do bairro, fora da faixa dos acessos.
   const x=area.x+4.3,z=area.z-8.7;
   if(area.theme==='forest'){
    for(let i=0;i<3;i++)beam(g,[x+i*.32,2.15,z],[x+i*.32,2.15,z+1.5],.16,material('wood',0xa17a45));
    const hive=add(g,new T.LatheGeometry([new T.Vector2(.18,0),new T.Vector2(.47,.16),new T.Vector2(.52,.45),new T.Vector2(.34,.75),new T.Vector2(.08,.9)],8),mat(0xb99a52),[x-1,2.15,z]);
   }else if(area.theme==='snow'){
    for(let i=0;i<3;i++)piece(g,[1.5,.17,.20],material('wood',0x98674c),[x,2.2+i*.18,z+i*.45]);
    barrel(g,x+1,2.1,z,.6);
   }else if(area.theme==='water'){
    for(let i=0;i<3;i++)barrel(g,x+i*.65,2.1,z,.5);
    for(let j=0;j<4;j++)beam(g,[x-1.4,2.4,z+j*.22],[x-1.4,3.6,z+j*.22],.02,mat(0xb5ae8b));
   }else if(area.theme==='forge'){
    add(g,bodyGeometry(1.1,1.0,.7),material('stone',0x5f6561),[x,2.1,z]);piece(g,[1.5,.23,.78],mat(0x697773),[x,2.9,z]);
    for(let i=0;i<3;i++)add(g,new T.OctahedronGeometry(.24),mat(i%2?0x9b7759:0x667c77),[x+1.4+i*.2,2.28,z+.4]);
   }else{
    const archwood=material('wood',0x995e61);for(const sign of [-1,1])beam(g,[area.x+sign*3.3,2.1,area.z-5.4],[area.x+sign*3.3,5.7,area.z-5.4],.13,archwood);
    beam(g,[area.x-3.8,5.7,area.z-5.4],[area.x+3.8,5.7,area.z-5.4],.16,archwood);beam(g,[area.x-4.0,6.0,area.z-5.4],[area.x+4.0,6.0,area.z-5.4],.10,material('wood',p.timber));
   }
  }
 }
 const fallingWater=[];
 function waterfall(x,z,width){
  let map=textures.get('fall');
  if(!map){const c=document.createElement('canvas');c.width=32;c.height=64;const ctx=c.getContext('2d');ctx.fillStyle='#76cbd2';ctx.fillRect(0,0,32,64);
   for(let i=0;i<22;i++){ctx.fillStyle=i%3?'rgba(222,250,239,.48)':'rgba(51,138,162,.24)';ctx.fillRect((i*13)%32,(i*19)%64,1+i%3,12+i%21);}
   map=new T.CanvasTexture(c);map.wrapS=map.wrapT=T.RepeatWrapping;map.magFilter=T.NearestFilter;map.minFilter=T.NearestFilter;textures.set('fall',map);}
  const geo=new T.PlaneGeometry(width,7.9,3,8),pos=geo.getAttribute('position');
  for(let i=0;i<pos.count;i++)pos.setZ(i,Math.sin(pos.getY(i)*.8)*.10+Math.pow(Math.max(0,-pos.getY(i))/4,3)*.6);
  geo.computeVertexNormals();add(staticRoot,geo,new T.MeshBasicMaterial({map,side:T.DoubleSide,color:0xd1f2e8}),[x,-1.60,z+.2]);
  const lip=add(staticRoot,new T.TorusGeometry(width*.45,.11,3,12,Math.PI),mat(0xc5e9df),[x,2.25,z+.2]);lip.rotation.x=Math.PI/2;
  for(let i=0;i<2;i++){const foam=add(S,new T.TorusGeometry(width*(.55+i*.28),.045,3,16),new T.MeshBasicMaterial({color:0xd4eeeb,transparent:true,opacity:.55,depthWrite:false}),[x,-5.25,z+.45]);foam.rotation.x=-Math.PI/2;foam.scale.y=.55;fallingWater.push({mesh:foam,phase:i*.5});}
 }
 function backdrop(){
  for(let layer=0;layer<3;layer++){
   const g=new T.BufferGeometry(),positions=[],colors=[];
   for(let i=0;i<13;i++){const x=-140+i*23,h=20+Math.sin(i*2.1+layer)*10+(i%3)*7,z=-110-layer*22,base=-7;
    positions.push(x-23,base,z,x,h,z,x+23,base,z);const c=color([0x718d91,0x8d9fa1,0xa5b5b2][layer],.88+(i%3)*.06);for(let j=0;j<3;j++)colors.push(c.r,c.g,c.b);
   }
   g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('color',new T.Float32BufferAttribute(colors,3));g.computeVertexNormals();add(staticRoot,g,new T.MeshLambertMaterial({vertexColors:true,side:T.DoubleSide}));
  }
  const cloud=mat(0xe3e9db);for(let i=0;i<9;i++){const x=-86+i*22,z=-80-(i%3)*12,y=25+(i%2)*9;for(let j=0;j<3;j++){const c=add(staticRoot,new T.IcosahedronGeometry(1,0),cloud,[x+j*2,y+(j%2)*1.2,z]);c.scale.set(3.8,1.5,1.7);}}
 }
 function equip(n){
  const name=n.data.name,g=new T.Group(),arm=n.model.userData.arms[1];if(!arm)return;
  g.position.set(0,-.47,.13);arm.add(g);
  if(name==='Brasa'){beam(g,[0,-.15,0],[0,.45,0],.025,material('wood',0x9b784b));piece(g,[.26,.16,.17],mat(0x727c78),[0,.46,0]);}
  else if(name==='Otto'){beam(g,[0,-.65,0],[0,.45,0],.025,material('wood',0x99744a));for(let i=0;i<5;i++)beam(g,[(i-2)*.045,-.88,0],[0,-.52,0],.018,mat(0xc2a460));}
  else if(name==='Nina'){add(g,bodyGeometry(.27,.23,.24),mat(0x789b94),[0,-.1,0]);beam(g,[.1,.06,0],[.28,.13,0],.035,mat(0x789b94));}
  else if(['Pip','Yumi'].includes(name)){piece(g,[.36,.035,.34],mat(0xe4d6b0),[0,.0,.12]);beam(g,[-.12,.03,.04],[.13,.03,.18],.009,mat(0x668e8a));}
  else if(['Amora','Bento','Mel'].includes(name)){piece(g,[.34,.04,.28],material('wood',0x9b784b),[0,0,.12]);add(g,new T.IcosahedronGeometry(.11,0),mat(name==='Mel'?0xd5ac70:0xda9a48),[0,.10,.12]);}
 }
 function work(n,time,walking,near,paused){
  const u=n.model.userData;u.head.rotation.x=0;if(walking||near||paused)return;const t=time+n.phase;
  if(n.data.name==='Brasa'){u.arms[1].rotation.x=-.65-Math.max(0,Math.sin(t*2))*.75;u.head.rotation.x=.07;}
  if(n.data.name==='Otto'){u.arms[1].rotation.x=-.25+Math.sin(t*1.7)*.18;u.arms[1].rotation.z=.18;}
  if(n.data.name==='Nina')u.arms[1].rotation.z=-.32+Math.sin(t)*.15;
  if(['Pip','Yumi'].includes(n.data.name)){u.arms[1].rotation.x=-.50;u.head.rotation.x=.08+Math.sin(t*.6)*.04;}
 }
 let environmentTime=0;const particleCount=44,particlePositions=new Float32Array(particleCount*3),particleGeometry=new T.BufferGeometry();
 particleGeometry.setAttribute('position',new T.BufferAttribute(particlePositions,3));
 const particleCanvas=document.createElement('canvas');particleCanvas.width=particleCanvas.height=8;const pc=particleCanvas.getContext('2d');pc.fillStyle='#fff1b0';pc.fillRect(3,1,2,6);pc.fillRect(1,3,6,2);
 const particleMaterial=new T.PointsMaterial({map:new T.CanvasTexture(particleCanvas),color:0xffedbd,size:.14,transparent:true,opacity:.38,alphaTest:.1,depthWrite:false});
 const particles=new T.Points(particleGeometry,particleMaterial);particles.name='VillageAmbientMotes';particles.frustumCulled=false;S.add(particles);
 function update(dt,night,paused){
  if(paused||document.hidden)return;environmentTime+=dt;
  for(let i=0;i<particleCount;i++){const a=Campaign.areas[i%5],t=environmentTime*.16+i*2.4;particlePositions[i*3]=a.x+Math.sin(t*.71+i)*7;particlePositions[i*3+1]=2.5+((environmentTime*.12+i*.37)%3.4);particlePositions[i*3+2]=a.z+Math.cos(t*.52+i)*6;}
  particleGeometry.attributes.position.needsUpdate=true;particleMaterial.opacity=.25+night*.38;particleMaterial.size=.12+night*.035;
  const fallMap=textures.get('fall');if(fallMap)fallMap.offset.y=-environmentTime*.32;
  for(const foam of fallingWater){const u=(environmentTime*.5+foam.phase)%1;foam.mesh.scale.set(1+u*.35,.62+u*.20,1);foam.mesh.material.opacity=(1-u)*.45;}
 }
 return {house,tree,border,bridge,fence,lamp,stall,terrainIsland,dress,waterfall,backdrop,equip,work,update,chimneys,
  get metrics(){return {architecture:architecture.map(a=>({...a})),terrain:terrain.length,textures:textures.size,paintedGrounds:terrain.length,trees:decorations.filter(d=>d.type==='tree').length,shops:decorations.filter(d=>d.type==='shop').length,nature:nature.metrics,particles:particleCount,environmentTime};}};
})();

function house(parent,x,z,theme='forest',scale=1,y=2,yaw=0){return villageArt.house(parent,x,z,theme,scale,y,yaw);}
function stall(x,z,color,title){return villageArt.stall(x,z,color,title);}
// Ilha central, cinco bairros e acesso ao mercado.
for(const island of islands)villageArt.terrainIsland(island);
for(const area of Campaign.areas){const len=Math.hypot(area.x,area.z),dx=area.x/len,dz=area.z/len;bridge({x:dx*16,z:dz*16},{x:area.x-dx*9.5,z:area.z-dz*9.5});}
for(const court of courts){const area=Campaign.areas[court.area-1],dx=court.x-area.x,dz=court.z-area.z,len=Math.hypot(dx,dz);bridge({x:area.x+dx/len*9.5,z:area.z+dz/len*9.5},{x:court.x-dx/len*5,z:court.z-dz/len*5},2.7);}
bridge({x:-10,z:13.5},{x:-15,z:20});bridge({x:0,z:16},{x:0,z:24},4.2);bridge({x:0,z:34},{x:0,z:44},4.2);
// Água, correntes e cataratas entre as ilhas.
const water=new T.Mesh(new T.PlaneGeometry(600,600),new T.MeshBasicMaterial({color:0x3f90b2}));water.position.set(0,-5.4,0);water.rotation.x=-Math.PI/2;S.add(water);
for(let j=0;j<90;j++)block(staticRoot,[range(.8,2.7),.035,.09],0x8bd9e3,[range(-70,70),-5.3,range(-55,65)]);
for(const [x,z,w] of [[-39,19.5,2.7],[-30,18.9,2.1],[-34,-13.4,2.0],[31,-17.6,2.6],[26,46,1.7],[10,9.2,1.2]])villageArt.waterfall(x,z,w);
// Estátua central do coelho, jardins, bancos e caminhos de pedra.
cylinder(staticRoot,3.0,3.3,.60,0x9f906b,[0,2.4,0],12);cylinder(staticRoot,2.5,2.8,.50,0xb9a778,[0,2.95,0],10);
const statue=new T.Group();statue.position.set(0,3.2,0);staticRoot.add(statue);
rock(statue,[1.35,1.6,.95],0xcfab63,[0,1.6,0]);block(statue,[2.1,1.8,1.55],0xe0bc73,[0,3.1,0]);block(statue,[1.65,.60,.55],0xe9cc8d,[0,2.85,.85]);
for(const s of [-1,1]){const e=block(statue,[.48,2.4,.45],0xe0bc73,[s*.55,5.1,0]);e.rotation.z=-s*.12;block(statue,[.20,1.83,.07],0xa77e49,[s*.55,5.1,.26]);block(statue,[.15,.24,.06],0x5b4b36,[s*.45,3.2,.81]);rock(statue,[.5,.65,.5],0xe0bc73,[s*1.1,1.6,.3]);block(statue,[.65,.45,.9],0xd8b36c,[s*.56,.25,.3]);}
block(statue,[.20,.16,.12],0x9a7245,[0,2.93,1.16]);
obstacles.push({x:0,z:0,r:3.4});
for(let i=0;i<24;i++){const a=i/24*Math.PI*2;flower(staticRoot,Math.sin(a)*3.7,Math.cos(a)*3.7,i%2?0xff97c2:0xffeb93,2.2);}
for(const s of [-1,1])for(const z of [-9,9]){block(staticRoot,[3.1,.16,.65],wood,[s*9,2.7,z]);block(staticRoot,[3.1,.60,.13],wood,[s*9,3.1,z-.28]);for(const x of [-1,1])block(staticRoot,[.15,.65,.45],trim,[s*9+x,2.36,z]);}
for(const [x,z] of [[-12,-9],[12,-9],[-12,10],[12,10],[-3,25],[3,25],[-3,35],[3,35],[-14,24],[-24,22]])lamp(staticRoot,x,z);
for(let i=0;i<25;i++)block(staticRoot,[.65,.045,.85],i%3?0xcdb88e:0xe0cba4,[(i%3-1)*1.05,2.12,5+Math.floor(i/3)*3.4]);
// Mercado: toldos, casinhas e uma praça de convívio.
stall(-24,25,0x4b8fcd,'Frutas do Cais');stall(-18,24,0xd65e55,'Quitutes da Vila');house(staticRoot,-24,31,'forest',.72);tree(staticRoot,-28,29,1.2);tree(staticRoot,-18,34,1.0);

// Portais: três menores e o arco do chefe em cada bairro.
function portal(area,slot,lx,lz){
 const g=new T.Group();g.position.set(area.x+lx,2.18,area.z+lz);staticRoot.add(g);
 const boss=slot.boss,w=boss?1.10:.75,h=boss?2.70:1.95;
 block(g,[w*2+.48,.18,1.3],0xa79a7c,[0,.05,.1]);
 const frameColors=area.theme==='forest'?[0x916239,0xb58a4c]:area.theme==='snow'?[0x88a8b9,0xc4d9e0]:area.theme==='forge'?[0x645c58,0x887265]:area.theme==='sakura'?[0x65475c,0x987171]:[0x768e98,0x9cabb1];
 for(const s of [-1,1])for(let i=0;i<4;i++)block(g,[.31,h/4+.025,.44],frameColors[i%2],[s*(w+.12),h/8+i*h/4,0],s*.03);
 for(let i=0;i<7;i++){const a=i/6*Math.PI,xx=Math.cos(a)*(w+.12),yy=h+Math.sin(a)*w*.75;const m=block(g,[.43,.36,.46],frameColors[i%2],[xx,yy,0]);m.rotation.z=a-Math.PI/2;}
 for(const s of [-1,1]){block(g,[.17,.30,.17],gold,[s*(w+.42),.29,.4]);block(g,[.10,.30,.10],0xffce58,[s*(w+.42),.59,.4]);}
 const shape=new T.Shape();shape.moveTo(-w,.1);shape.lineTo(w,.1);shape.lineTo(w,h);for(let i=0;i<=12;i++){const a=i/12*Math.PI;shape.lineTo(Math.cos(a)*w,h+Math.sin(a)*w*.76);}shape.lineTo(-w,.1);
 const textureCanvas=document.createElement('canvas');textureCanvas.width=128;textureCanvas.height=256;const tc=textureCanvas.getContext('2d'),gradient=tc.createRadialGradient(64,150,6,64,130,150);
 gradient.addColorStop(0,'#ffffff');gradient.addColorStop(.45,'#b9ffff');gradient.addColorStop(1,'#376a97');tc.fillStyle=gradient;tc.fillRect(0,0,128,256);tc.lineWidth=2;tc.strokeStyle='#e9ffff';
 for(let i=0;i<7;i++){tc.beginPath();tc.ellipse(64,140,11+i*7,20+i*15,i*.14,0,Math.PI*1.65);tc.stroke();}
 const material=new T.MeshBasicMaterial({map:new T.CanvasTexture(textureCanvas),color:area.color,transparent:true,opacity:.66,side:T.DoubleSide,depthWrite:false});portalMaterials.push(material);
 const portalGeometry=new T.ShapeGeometry(shape),uv=portalGeometry.getAttribute('uv'),positions=portalGeometry.getAttribute('position');for(let i=0;i<uv.count;i++)uv.setXY(i,(positions.getX(i)+w)/(2*w),positions.getY(i)/(h+w*.76));uv.needsUpdate=true;
 const surface=new T.Mesh(portalGeometry,material);surface.position.set(area.x+lx,2.25,area.z+lz+.04);S.add(surface);
 const rings=new T.Group();rings.position.copy(surface.position).add(new T.Vector3(0,h*.68,.09));S.add(rings);
 for(let i=0;i<2;i++){const r=new T.Mesh(new T.TorusGeometry(w*(.48+i*.20),.025,3,14,Math.PI*1.6),new T.MeshBasicMaterial({color:0xd2ffff,transparent:true,opacity:.70,depthWrite:false}));r.scale.y=1.45;rings.add(r);}
 const emblem=block(g,[.27,.27,.10],boss?gold:area.color,[0,h+w*.85,.29]);emblem.rotation.z=Math.PI/4;
 const name=new T.Sprite(new T.SpriteMaterial());name.visible=false; // Compatibilidade; não inserido no cenário. Sem placas de fase.
 const lock=block(S,[.30,.29,.15],0xb8a994,[area.x+lx,2.18+h*.68,.24+area.z+lz]);
 const p={id:slot.id,area,slot,x:area.x+lx,z:area.z+lz,surface,rings,material,lock,label:name,frame:g};portals.push(p);
}
for(const area of Campaign.areas){
 const g=new T.Group();staticRoot.add(g);const theme=area.theme;

 // Clareira lateral: arcos menores deixam as casas e o centro da vilinha livres.
 const court=courts[area.id-1];
 [[-3.9,-1.4],[-1.3,-2.3],[1.35,-2.1],[4.15,-.8]].forEach(([x,z],i)=>portal(area,Campaign.slots[(area.id-1)*4+i],court.x-area.x+x,court.z-area.z+z));
 for(const s of [-1,1]){house(g,area.x+(theme==='sakura'&&s===-1?-9:s*6.8),area.z+(theme==='sakura'&&s===-1?-5:-7.0),theme,.70,2,s*.15);tree(g,area.x+s*10,area.z-5,.85,theme);lamp(g,area.x+s*9,area.z+4);}
 fence(g,area.x-8,area.z+7.5,area.x-4.5,area.z+7.5);fence(g,area.x+4.5,area.z+7.5,area.x+8,area.z+7.5);
 if(theme==='forest'){
  tree(g,area.x-3,area.z-8,1.9);block(g,[7,.22,4],wood,[area.x-3,7.1,area.z-8]);house(g,area.x-3,area.z-8,'forest',.65,7.25);
  for(let i=0;i<10;i++)block(g,[1.3,.15,.55],wood,[area.x-8,2.2+i*.5,area.z-4-i*.38]);
 }else if(theme==='snow'){
  house(g,area.x,area.z-9,'snow',.9,2);
  for(let i=0;i<3;i++)block(g,[2.1,.08,.36],0xd2ddd6,[area.x,2.10+i*.035,area.z-6.1-i*.32]);
 }else if(theme==='water'){
  const wh=new T.Group();wh.position.set(area.x-10,0,area.z);S.add(wh);wheels.push(wh);
  wh.rotation.y=Math.PI/2;const rim=new T.Mesh(new T.TorusGeometry(2,.19,4,12),mat(wood));wh.add(rim);
  for(let i=0;i<8;i++){const a=i/8*Math.PI*2;const spoke=block(wh,[.13,4,.13],wood,[0,0,0]);spoke.rotation.z=a;const paddle=block(wh,[.7,.45,1.0],wood,[Math.cos(a)*2,Math.sin(a)*2,0]);paddle.rotation.z=a;}
  for(let i=0;i<5;i++)block(g,[3.7,.16,.7],wood,[area.x-4,2.2,area.z+5+i*.8]);
 }else if(theme==='forge'){
  for(const s of [-1,1]){block(g,[.35,7,.35],trim,[area.x+s*8,5.5,area.z-6]);const beam=block(g,[7,.28,.35],wood,[area.x+s*5.7,8.6,area.z-6]);beam.rotation.z=s*.13;block(g,[.09,3,.09],0x554a46,[area.x+s*3.2,7.0,area.z-6]);}
  for(let i=0;i<5;i++)block(g,[.8,.8,.8],i%2?0x6d6461:wood,[area.x-8+i*.65,2.6,area.z+5]);
 }else{
  for(const s of [-1,1])tree(g,area.x+s*8,area.z+5,1.25,'sakura');
  for(const [x,z] of [[-5,7],[-1,9],[5,8]]){rock(g,[1.0,.08,.65],0x82b777,[area.x+x,-5.15,area.z+z]);flower(g,area.x+x,area.z+z,0xffb0dd,-5.05);}
 }
}
// Detalhes de vila nos limites dos bairros: quintais, casas, folhagem e calçamento.
for(const island of islands){
 if(island.court)continue;
 for(let j=0;j<9;j++){const a=j/9*Math.PI*2,r=island.r*.90,x=island.x+Math.cos(a)*r,z=island.z+Math.sin(a)*r;
  const access=bridges.some(b=>[b.a,b.b].some(e=>Math.hypot(e.x-x,e.z-z)<2.8));if(access)continue;
  villageArt.border(staticRoot,x,z,island.theme,j);
 }
}
for(const area of Campaign.areas){
 for(const s of [-1,1]){
  const outward=s===Math.sign(courts[area.id-1].x-area.x);
  house(staticRoot,area.x+s*(outward?6.6:8.7),area.z+(outward?7:2.6),area.theme,.58,2,-s*.90);
  for(const dz of [-9,6])tree(staticRoot,area.x+s*(dz===6?9.4:8.4),area.z+dz,area.theme==='forest'?1.15:.85,area.theme);
  fence(staticRoot,area.x+s*9.5,area.z+4.5,area.x+s*7.3,area.z+7.5);
 }
 if(area.theme==='forest')for(const [x,z] of [[-4,-10],[3,-9],[6,9]])tree(staticRoot,area.x+x,area.z+z,1.3,'forest');
}
for(const s of [-1,1])tree(staticRoot,s*15,0,.90,'forest');
// Flâmulas sobre o mercado e um pequeno barco junto ao cais.
for(const x of [-26,-14])block(staticRoot,[.18,4.6,.18],trim,[x,4.3,21]);
block(staticRoot,[12,.07,.07],wood,[-20,6.5,21]);for(let i=0;i<13;i++){const pennant=new T.Mesh(new T.ConeGeometry(.25,.55,3),mat([0xc85b52,0xe8bd61,0x52899c][i%3]));pennant.rotation.z=Math.PI;pennant.position.set(-25.5+i*.9,6.15-Math.sin(i/12*Math.PI)*.35,21);staticRoot.add(pennant);}
const boat=new T.Group();boat.position.set(-43,-5.0,23);boat.rotation.y=.35;staticRoot.add(boat);block(boat,[2.0,.45,4.0],wood,[0,0,0]);for(const s of [-1,1])block(boat,[.18,.6,4.2],trim,[s*.95,.2,0]);for(const z of [-1,1])block(boat,[2.0,.16,.45],0xb88752,[0,.4,z]);
// Silhuetas sobrepostas e nuvens de fundo, com profundidade atmosférica.
villageArt.backdrop();
// Personagens do jogo, reutilizados sem modificar seus modelos.
const P = new T.Group(), body = new T.Group();
P.add(body);
body.rotation.y = Math.PI;
S.add(P);
const bun = new T.Group();
bun.scale.setScalar(.8);
body.add(bun);
const bx = (w, h, d, c, x, y, z, rz, par) => { const m = mesh(B(w, h, d), c, [x, y, z]); if (rz)
    m.rotation.z = rz; (par || bun).add(m); return m; };
const PU = 0x7a2fe0, PD2 = 0x4f1fa8, WH = 0xf4f4f8, BK = 0x1a1a22, PK = 0xff7aa8;
const mk = (x, y, z) => { const g = new T.Group(); g.position.set(x, y, z); bun.add(g); return g; }, legs = [], arms = [], ears = [];
for (const s of [-1, 1]) {
    const lg = mk(s * .22, .78, 0);
    bx(.42, .12, .64, BK, 0, -.72, .08, 0, lg);
    bx(.4, .2, .58, WH, 0, -.56, .08, 0, lg);
    bx(.3, .45, .3, PD2, 0, -.23, 0, 0, lg);
    legs.push(lg);
    const am = mk(s * .47, 1.28, 0);
    bx(.2, .4, .24, BK, 0, -.23, 0, 0, am);
    bx(.26, .26, .26, WH, s * .07, -.52, .04, 0, am);
    arms.push(am);
    const ear = mk(s * .26, 2.15, 0);
    ear.rotation.z = -s * .1;
    bx(.26, .85, .16, PU, 0, .43, 0, 0, ear);
    bx(.13, .62, .04, PK, 0, .41, .09, 0, ear);
    ears.push(ear);
    bx(.15, .22, .03, BK, s * .2, 1.76, .465);
    bx(.06, .07, .03, WH, s * .2 + .02, 1.82, .485);
    bx(.1, .06, .03, PK, s * .31, 1.58, .465);
}
bx(.74, .62, .44, BK, 0, 1.02, 0);
bx(.26, .6, .02, WH, 0, 1.02, .23);
bx(.7, .18, .42, PD2, 0, .68, 0);
bx(.98, .88, .88, PU, 0, 1.78, 0);
bx(.74, .52, .04, WH, 0, 1.68, .44);
bx(.12, .09, .06, PK, 0, 1.62, .47);
bx(.16, .03, .03, BK, 0, 1.52, .46);
const tail = mk(0, .78, -.3);
bx(.22, .22, .22, WH, 0, 0, 0, 0, tail);
const swoosh = new T.Mesh(new T.RingGeometry(1, 1.7, 28), new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .45, side: T.DoubleSide }));
swoosh.rotation.x = -Math.PI / 2;
swoosh.visible = false;
S.add(swoosh);

function mkCitizen(opts) {
    const g = new T.Group(), core = new T.Group();
    g.add(core);
    const a = (w, h, d, c, x, y, z, p = core) => { const m = mesh(B(w, h, d), c, [x, y, z]); p.add(m); return m; };
    const fur = opts.fur, face = opts.face, tip = opts.tip || fur, dark = opts.dark || 0x2b2020;
    const legs = [], arms = [];
    for (const sd of [-1, 1]) {
        const leg = new T.Group();
        leg.position.set(sd * .22, .75, 0);
        core.add(leg);
        a(.27, .5, .29, opts.pants || 0x424253, 0, -.27, 0, leg);
        a(.35, .18, .47, opts.boot || 0x58402f, 0, -.58, .08, leg);
        legs.push(leg);
        const arm = new T.Group();
        arm.position.set(sd * .45, 1.5, 0);
        core.add(arm);
        a(.23, .55, .27, fur, 0, -.26, 0, arm);
        a(.25, .18, .29, face, 0, -.57, .03, arm);
        arms.push(arm);
    }
    a(.81, .8, .5, opts.shirt || fur, 0, 1.15, 0);
    a(.56, .4, .055, face, 0, 1.26, .28);
    const head = new T.Group();
    head.position.set(0, 2.04, 0);
    core.add(head);
    a(.83, .67, .64, fur, 0, 0, 0, head);
    a(.63, .28, .18, face, 0, -.18, .36, head);
    for (const sd of [-1, 1]) {
        a(.135, .18, .07, 0xffffff, sd * .22, .06, .338, head);
        a(.075, .13, .045, dark, sd * .22, .045, .38, head);
        a(.25, opts.kind === 'deer' ? .7 : .39, .17, tip, sd * .3, .51, 0, head);
        if (opts.kind === 'cat')
            a(.14, .13, .05, face, sd * .3, .54, .10, head);
    }
    a(.12, .10, .085, dark, 0, -.18, .49, head);
    if (opts.kind === 'deer')
        for (const sd of [-1, 1]) {
            a(.06, .5, .08, 0x805227, sd * .24, .91, 0, head);
            a(.3, .07, .07, 0x805227, sd * .37, 1.03, 0, head);
        }
    if (opts.kind === 'raccoon') {
        for (const sd of [-1, 1])
            a(.28, .18, .035, 0x4c4b54, sd * .2, .07, .355, head);
    }
    if (opts.kind === 'hedgehog') {
        for (let i = -2; i <= 2; i++)
            a(.19, .32, .26, 0x76513a, i * .17, .36, -.27, head);
    }
    if (opts.kind === 'dog')
        a(.14, .3, .21, tip, -.5, .11, 0, head);
    const tail = new T.Group();
    tail.position.set(0, .87, -.35);
    core.add(tail);
    if (opts.kind === 'squirrel' || opts.kind === 'fox') {
        a(.43, .8, .44, fur, 0, .17, -.3, tail);
        a(.36, .36, .4, tip, 0, .53, -.47, tail);
    }
    else if (opts.kind === 'raccoon') {
        a(.35, .48, .35, fur, 0, -.06, -.29, tail);
        a(.36, .15, .36, dark, 0, -.2, -.31, tail);
    }
    else
        a(.27, .27, .38, tip, 0, .03, -.22, tail);
    if (opts.accessory === 'scarf') {
        a(.85, .17, .62, opts.accent, 0, 1.7, 0);
        a(.2, .5, .08, opts.accent, .25, 1.46, .31);
    }
    if (opts.accessory === 'vest')
        a(.86, .64, .54, opts.accent, 0, 1.22, 0);
    if (opts.accessory === 'bag') {
        a(.4, .42, .2, opts.accent, .42, 1.03, .24);
    }
    g.scale.setScalar(opts.scale || .9);
    g.userData = { ...opts, legs, arms, head, tail, core };
    return g;
}

const CITIZENS = [
    { name: 'Nina', kind: 'squirrel', fur: 0xc77930, face: 0xf9e2bb, tip: 0xf9edc9, shirt: 0x68a85b, pants: 0x66533e, accent: 0xecc563, accessory: 'scarf', z: -33, x: -1.8,
        lines: ['Eu só queria juntar nozes em paz, mas os besouros estão empurrando... aquilo!', 'O Bunnyldu passou por aqui! Acho que ele seguiu para o fim do bosque.'] },
    { name: 'Rufus', kind: 'raccoon', fur: 0x827c87, face: 0xe6ded7, tip: 0x56515b, shirt: 0x447d9b, pants: 0x364354, accent: 0xe3a840, accessory: 'bag', z: -78, x: 1.6,
        lines: ['Meu expediente? Catar objetos brilhantes! É uma carreira honesta.', 'Ouvi dizer que os lagartos precisam de dois golpes para cair. Não subestime eles!'] },
    { name: 'Luna', kind: 'cat', fur: 0xc3a5da, face: 0xf8e4ee, tip: 0x8b6bb2, shirt: 0x74438c, pants: 0x55416a, accent: 0xfa92cf, accessory: 'scarf', z: -121, x: -1.8,
        lines: ['Eu venho aqui ver o pôr do sol. Só não gosto das bolas de cocô!', 'Viu o coelhão preto? Passou correndo em direção ao bosque profundo.'] },
    { name: 'Otto', kind: 'deer', fur: 0xa26f46, face: 0xf0cfa3, tip: 0xb48d65, shirt: 0x6a8c4d, pants: 0x695039, accent: 0xd6bb72, accessory: 'vest', z: -166, x: 1.5, scale: .98,
        lines: ['Cuido das trilhas desde pequeno. Agora aparecem buracos da noite pro dia!', 'É melhor pegar impulso antes dos vãos grandes. Segure K e depois pule!'] },
    { name: 'Pip', kind: 'hedgehog', fur: 0xa68557, face: 0xf0d4a6, tip: 0x77533f, shirt: 0xc65750, pants: 0x71533e, accent: 0x5d6938, accessory: 'bag', z: -200, x: -1.7, scale: .77,
        lines: ['Eu vendo cogumelos... quer dizer, eu estudo cogumelos. Muito diferente!', 'Bibibunn anda recrutando criaturas estranhas. Melhor ficar esperto.'] },
    { name: 'Max', kind: 'dog', fur: 0xd6b47d, face: 0xf4e4c7, tip: 0x845c3d, shirt: 0x499eac, pants: 0x555870, accent: 0xb65c3a, accessory: 'scarf', z: -239, x: 1.6,
        lines: ['Eu faço minha corrida da manhã todos os dias. Aposto que ganho de você!', 'Os besouros saíram das árvores. Nem quero imaginar o cheiro!'] },
    { name: 'Fiona', kind: 'fox', fur: 0xe76f32, face: 0xffe4c0, tip: 0xf5e2bd, shirt: 0x7e76c2, pants: 0x664655, accent: 0xf4bc6c, accessory: 'vest', z: -285, x: -1.75,
        lines: ['Meu primo Vixxo vive dando conselhos. Pelo menos desta vez ele acertou.', 'Vi um coelho enorme perto do final do bosque. Parecia preocupado.'] },
    { name: 'Bento', kind: 'raccoon', fur: 0x626b73, face: 0xd7dce0, tip: 0x434751, shirt: 0x6f9a6c, pants: 0x4d474b, accent: 0xe5b35d, accessory: 'bag', z: -329, x: 1.55,
        lines: ['Minha rotina é dormir, comer e fugir dos lagartos. Vida emocionante!', 'Bunnyldu deve estar logo adiante. Você já está chegando!'] },
    { name: 'Mel', kind: 'cat', fur: 0xebcba0, face: 0xffede0, tip: 0xb88b69, shirt: 0xd17c9f, pants: 0x725f71, accent: 0x6e4d7d, accessory: 'scarf', z: -356, x: -1.5,
        lines: ['A Bibibunn? Não confio naquela rockeira nem por um segundo.', 'O grandalhão está no fim do bosque. Tomara que esteja bem.'] }
];

P.position.set(0,worldY,24);body.rotation.y=Math.PI;
// O monumento usa uma cópia do coelho aprovado; materiais da cópia não alteram o herói.
statue.clear();const monument=bun.clone(true);monument.scale.setScalar(2.0);monument.position.y=.12;
const monumentMaterials=new Map();
monument.traverse(o=>{if(o.isMesh){const source=o.material.color.getHex();if(!monumentMaterials.has(source)){const copy=o.material.clone();copy.color.set(source===0x1a1a22?0x8c6b3f:source===0xf4f4f8?0xe3c88b:0xc3a266);monumentMaterials.set(source,copy);}o.material=monumentMaterials.get(source);}});statue.add(monument);
const fountain=mesh(new T.RingGeometry(2.54,2.95,24),0x7fb9b4,[0,2.75,0]);fountain.rotation.x=-Math.PI/2;staticRoot.add(fountain);
const shade=mesh(new T.CircleGeometry(.61,12),0x677c48,[0,worldY+.15,24]);shade.rotation.x=-Math.PI/2;S.add(shade);
const residents=[
 {name:'Lia',kind:'fox',fur:0xd58b45,face:0xffe9bc,shirt:0x5d8e7d,x:-5,z:7,lines:['Bem-vindo à Vila dos Animais! Os cinco bairros partem desta praça.','Siga a ponte até o Bosque das Copas. O primeiro portal está aceso.']},
 {name:'Tito',kind:'raccoon',fur:0x93959a,face:0xf0e8d7,shirt:0x736197,x:5,z:7,lines:['Cada bairro guarda três caminhos e um desafio de chefe.','Ao terminar uma fase, volte para a vila. O próximo portal ficará livre.']},
 {name:'Amora',kind:'squirrel',fur:0xb26e46,face:0xf6d4b2,shirt:0x9474ad,x:-20,z:29,lines:['O mercado está cheio hoje! Veja as barracas de frutas e quitutes.','Ainda estou arrumando a loja. Enquanto isso, fique à vontade para passear.']},
 {name:'Bento',kind:'raccoon',fur:0x66676c,face:0xf0e7d0,shirt:0x6d9d7b,x:-24,z:26.7,lines:['Fruta doce, direto do cais!','Ouvi dizer que o rio da floresta precisa de ajuda...']},
 {name:'Mel',kind:'cat',fur:0xe6bd83,face:0xf6e6cb,shirt:0xb56866,x:-18,z:25.7,lines:['Cheirinho de pão quentinho!','Por enquanto estou preparando a abertura da loja.']},
 {name:'Nina',kind:'squirrel',fur:0xb9804b,face:0xffe9b9,shirt:0x699d62,x:-31,z:-19,lines:['As casas nas copas são ligadas por passarelas.','Bosque Verde e Selva de Pinheiros são os primeiros caminhos desta área.']},
 {name:'Pip',kind:'deer',fur:0xb19170,face:0xf7e9cd,shirt:0x567b9a,x:24,z:-23,lines:['As trilhas geladas ainda estão sendo preparadas.','Depois do chefe do bosque, os portais deste bairro poderão ser liberados.']},
 {name:'Otto',kind:'dog',fur:0x968c7b,face:0xf0e5d6,shirt:0x427d98,x:-32,z:14,lines:['A roda do moinho nunca para!','Aqui os caminhos passam pelas cascatas e pelos cais.']},
 {name:'Brasa',kind:'fox',fur:0xb77a4e,face:0xf5dbb5,shirt:0xa46947,x:31,z:11,lines:['Bem-vindo ao distrito das forjas. Cuidado com as ferramentas!','Estamos preparando novos desafios para os portais daqui.']},
 {name:'Yumi',kind:'cat',fur:0xe9d6d5,face:0xfff1e3,shirt:0xa263a9,x:23,z:40,lines:['As lanternas deixam o jardim bonito mesmo de dia.','Os novos caminhos daqui ainda estão em preparação.']},
 {name:'Rui',kind:'fox',fur:0xb98657,face:0xf3dfbf,shirt:0x688d9d,x:6,z:-6,walk:true,lines:['Uma volta na praça sempre faz bem.']},
 {name:'Luna',kind:'cat',fur:0xc8b9a6,face:0xf6ece2,shirt:0x8d6c9e,x:-6,z:-6,walk:true,lines:['Eu gosto de conversar perto da estátua.']}
];
for(const [i,d] of residents.entries()){
 const original=CITIZENS.find(c=>c.name===d.name),appearance=original||{...d,scale:.79,tip:d.kind==='fox'?0xf7e5ce:d.fur,dark:0x302c34};
 const n=mkCitizen({...appearance,x:d.x,z:d.z,lines:d.lines});n.position.set(d.x,2.1,d.z);n.rotation.y=i%2?.6:-.7;S.add(n);
 // Moradores parados usam uma malha por cor; passantes mantêm articulações.
 villageArt.equip({model:n,data:d});prepareCitizen(n);
 npcs.push({model:n,data:d,phase:i*1.7});
 if(i<2||i===3||i===4){const bubble=label('…',S,d.x,3.55,d.z,.72,'#4a3540','#ffedbd');bubbles.push({sprite:bubble,phase:i,model:n});}
}
// Os cinco irmãos partem do mesmo gato em blocos usado pelos moradores das fases.
for(const spec of MEOWLIN){
 const court=courts[spec.area-1],d={name:spec.name,guardianArea:spec.area,robe:spec.robe,x:court.x-.4,z:court.z+2.2,
  lines:['Sou '+spec.name+'. Eu e meus quatro irmãos guardamos os portais da vila. Escolha um destino; vou confirmar com você antes da viagem.']};
 const n=mkCitizen({name:spec.name,kind:'cat',fur:0xb7aaa1,face:0xf3e9dc,tip:0x86766e,shirt:spec.robe,pants:0x3b3541,dark:0x302731,scale:.84});
 const core=n.userData.core,head=n.userData.head;
 const robe=mesh(new T.CylinderGeometry(.38,.54,.76,4,1),spec.robe,[0,1.00,0]);robe.rotation.y=Math.PI/4;core.add(robe);
 block(core,[.83,.09,.57],0xd9b56c,[0,.65,0]);block(core,[.14,.44,.05],0xe3c17a,[0,1.26,.31]);
 const brim=mesh(new T.CylinderGeometry(.59,.59,.09,6),spec.robe,[0,.40,0]);head.add(brim);
 // As orelhas despontam ao lado do chapéu, preservando a leitura de gato.
 for(const s of [-1,1]){block(head,[.20,.39,.15],0xb7aaa1,[s*.49,.51,.06]);block(head,[.10,.24,.025],0xd899a8,[s*.49,.53,.15]);}
 const hat=mesh(new T.ConeGeometry(.47,1.02,4),spec.robe,[0,.93,-.02]);hat.rotation.z=-.10;head.add(hat);
 const band=mesh(new T.CylinderGeometry(.43,.47,.11,4),0xd9b56c,[0,.49,-.02]);band.rotation.y=Math.PI/4;head.add(band);
 block(head,[.045,.17,.025],0xf1d58a,[0,.88,.28]);block(head,[.16,.045,.025],0xf1d58a,[0,.88,.28]);
 const staff=new T.Group();staff.position.set(.16,-.30,.15);n.userData.arms[1].add(staff);block(staff,[.075,1.90,.075],wood,[0,0,0]);
 staff.add(mesh(new T.OctahedronGeometry(.18),Campaign.areas[spec.area-1].color,[0,1.02,0]));
 n.position.set(d.x,2.1,d.z);n.rotation.y=-.18;S.add(n);mergeMeshes(n);
 const npc={model:n,data:d,phase:spec.area*1.6};npcs.push(npc);guardians.push(npc);
 // O nome aparece na interface ao conversar; a silhueta do gato fica livre de placas.
}
function mergeMeshes(root){
 root.updateMatrixWorld(true);const inverse=new T.Matrix4().copy(root.matrixWorld).invert(),buckets=new Map();
 root.traverse(o=>{if(!o.isMesh)return;const geo=(o.geometry.index?o.geometry.toNonIndexed():o.geometry).clone();geo.applyMatrix4(new T.Matrix4().multiplyMatrices(inverse,o.matrixWorld));const k=o.material;if(!buckets.has(k))buckets.set(k,[]);buckets.get(k).push(geo);});
 root.clear();for(const [material,geos] of buckets){const count=geos.reduce((n,g)=>n+g.getAttribute('position').array.length,0),pos=new Float32Array(count),normal=new Float32Array(count);let offset=0;
  for(const geo of geos){pos.set(geo.getAttribute('position').array,offset);normal.set(geo.getAttribute('normal').array,offset);offset+=geo.getAttribute('position').array.length;}
  const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.BufferAttribute(pos,3));geometry.setAttribute('normal',new T.BufferAttribute(normal,3));
  for(const [key,size] of [['uv',2],['color',3]]){if(!geos.some(g=>g.getAttribute(key)))continue;const data=new Float32Array(count/3*size);if(key==='color')data.fill(1);let cursor=0;for(const geo of geos){const attr=geo.getAttribute(key);if(attr)data.set(attr.array,cursor);cursor+=geo.getAttribute('position').count*size;}geometry.setAttribute(key,new T.BufferAttribute(data,size));}
  const merged=new T.Mesh(geometry,material);merged.receiveShadow=root===staticRoot;merged.castShadow=root===staticRoot&&material.name?.startsWith('Village-');root.add(merged);for(const geo of geos)geo.dispose();
 }
}
villageArt.dress();
mergeMeshes(staticRoot);
// Caminhos nas ilhas e passarelas; a borda impede caminhar sobre a água.
function onGround(x,z){
 if(islands.some(i=>Math.hypot(x-i.x,z-i.z)<i.r-.65))return true;
 return bridges.some(({a,b,width})=>{const dx=b.x-a.x,dz=b.z-a.z,den=dx*dx+dz*dz,u=Math.max(0,Math.min(1,((x-a.x)*dx+(z-a.z)*dz)/den));return Math.hypot(x-a.x-u*dx,z-a.z-u*dz)<width/2-.45;});
}
function validPosition(x,z){return Number.isFinite(x)&&Number.isFinite(z)&&onGround(x,z)&&!obstacles.some(o=>Math.hypot(x-o.x,z-o.z)<o.r+.40);}
function groundHeight(x,z){const island=islands.find(i=>Math.hypot(x-i.x,z-i.z)<i.r-.65);return island?(Math.hypot(x-island.x,z-island.z)<island.r*.67?2.18:2.07):2.03;}
const spawn=save.villagePosition;if(validPosition(spawn.x,spawn.z))P.position.set(spawn.x,2,spawn.z);
const keys=new Set(),look=new T.Vector3(),cameraEye=new T.Vector3(),focus=new T.Vector3(),clock=new T.Clock();
let overview=true,nearest=null,dialogue=null,dialogIndex=0,phase=0,disposed=false,pendingPortal=null,confirmOrigin=null,entering=false;
// Oito minutos por volta. O horário começa às 9h e só avança dentro da vila.
const villageCycle=(()=>{
 const duration=480,roomClock=window.parent?.BunnyHavocVillageClock;
 let elapsed=roomClock?.read?.()||0,lastSky=-Infinity,lastCaption='',state={};
 // Hora, céu alto/horizonte, neblina, luz ambiente/chão, luz principal, intensidades, noite.
 const keys=[
  [0,0x101c38,0x41536c,0x3c536b,0xa8bce0,0x34465b,0xa5c3ff,.49,.28,1],
  [.20,0x253455,0x7e8195,0x68768c,0xbfc8e2,0x4b5469,0xc1ccf1,.54,.28,.85],
  [.25,0x886787,0xe8ac88,0xb6a4a1,0xf4d7ca,0x65697d,0xffc18c,.62,.46,.35],
  [.32,0x5a9bd3,0xe9e8cb,0xc2dae2,0xfff5e8,0x536f89,0xffecc8,.70,.72,0],
  [.65,0x5a9bd3,0xe9e8cb,0xc2dae2,0xfff5e8,0x536f89,0xffecc8,.70,.72,0],
  [.73,0x736080,0xe5a178,0xad9291,0xf1cfbe,0x5d5871,0xffb16c,.62,.48,.35],
  [.80,0x253455,0x7e8195,0x68768c,0xbfc8e2,0x4b5469,0xc1ccf1,.54,.28,.85],
  [1,0x101c38,0x41536c,0x3c536b,0xa8bce0,0x34465b,0xa5c3ff,.49,.28,1]
 ];
 const colors=Array.from({length:6},()=>new T.Color()),keyColors=keys.map(k=>k.slice(1,7).map(c=>new T.Color(c))),waterDay=new T.Color(0x3f90b2),waterNight=new T.Color(0x25455f);
 const starPositions=Array.from({length:65},(_,i)=>({x:(i*73+19)%256,y:(i*43+7)%145,size:i%9===0?2:1}));
 const glowCanvas=document.createElement('canvas');glowCanvas.width=glowCanvas.height=64;
 const ctx=glowCanvas.getContext('2d'),gradient=ctx.createRadialGradient(32,32,2,32,32,31);
 gradient.addColorStop(0,'rgba(255,188,87,.65)');gradient.addColorStop(.45,'rgba(255,173,65,.3)');gradient.addColorStop(1,'rgba(255,173,65,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,64,64);
 const glowMaterial=new T.MeshBasicMaterial({map:new T.CanvasTexture(glowCanvas),transparent:true,opacity:0,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1});
 const poolGeometry=new T.PlaneGeometry(4.8,4.8),pools=new T.InstancedMesh(poolGeometry,glowMaterial,lanternSpots.length),poolMatrix=new T.Matrix4();
 for(const [i,spot] of lanternSpots.entries()){poolMatrix.makeRotationX(-Math.PI/2);poolMatrix.setPosition(spot);pools.setMatrixAt(i,poolMatrix);}
 pools.frustumCulled=false;S.add(pools);
 function disk(x,y,r,color){skyCtx.fillStyle=color;skyCtx.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4;const px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;i?skyCtx.lineTo(px,py):skyCtx.moveTo(px,py);}skyCtx.closePath();skyCtx.fill();}
 function paintSky(time,night){
  const g=skyCtx.createLinearGradient(0,0,0,256);g.addColorStop(0,'#'+colors[0].getHexString());g.addColorStop(1,'#'+colors[1].getHexString());skyCtx.fillStyle=g;skyCtx.fillRect(0,0,256,256);
  if(night>.25){skyCtx.globalAlpha=(night-.25)/.75;skyCtx.fillStyle='#dbe5ff';for(const s of starPositions)skyCtx.fillRect(s.x,s.y,s.size,s.size);skyCtx.globalAlpha=1;}
  const day=time>=.25&&time<.75,u=day?(time-.25)/.5:((time+.25)%1)/.5;
  disk(22+u*212,139-Math.sin(u*Math.PI)*105,day?8:6,day?'#ffe9a1':'#dbe6f8');
  S.background.needsUpdate=true;
 }
 function update(dt){
  if(!document.hidden){elapsed=roomClock?.advance?.(dt)??elapsed+Math.max(0,dt);}
  const time=(.375+elapsed/duration)%1;
  let i=0;while(i<keys.length-2&&time>keys[i+1][0])i++;
  const a=keys[i],b=keys[i+1],linear=(time-a[0])/(b[0]-a[0]),u=linear*linear*(3-2*linear);
  for(let c=0;c<6;c++)colors[c].copy(keyColors[i][c]).lerp(keyColors[i+1][c],u);
  const night=T.MathUtils.lerp(a[9],b[9],u);
  hemisphere.color.copy(colors[3]);hemisphere.groundColor.copy(colors[4]);hemisphere.intensity=T.MathUtils.lerp(a[7],b[7],u);
  sun.color.copy(colors[5]);sun.intensity=T.MathUtils.lerp(a[8],b[8],u);
  // Trajetória contínua, inclusive na troca entre o sol e a luz azul da noite.
  sun.position.set(Math.cos(time*Math.PI*2)*65,60+Math.sin(time*Math.PI*2)*12,35);
  S.fog.color.copy(colors[2]);water.material.color.copy(waterDay).lerp(waterNight,night);
  lanternGlass.emissiveIntensity=.08+night*1.1;windowGlass.emissiveIntensity=.06+night*.95;
  glowMaterial.opacity=night*.72;pools.visible=night>.03;
  const caption=time<.22||time>=.80?'☾ Noite':time<.32?'☀ Amanhecer':time<.50?'☀ Manhã':time<.69?'☀ Tarde':time<.80?'☀ Entardecer':'☾ Noite';
  if(caption!==lastCaption){$('timeOfDay').textContent=caption;lastCaption=caption;}
  // O gradiente muda devagar; não é necessário reenviar a textura a cada quadro.
  if(Math.abs(elapsed-lastSky)>=.4){paintSky(time,night);lastSky=elapsed;}
  state={elapsed,duration,time,hour:time*24,night,caption,lanternIntensity:lanternGlass.emissiveIntensity,windowIntensity:windowGlass.emissiveIntensity};
 }
 update(0);
 return {update,get state(){return {...state};}};
})();

// O jogo usa o áudio do launcher; a prévia independente tem sua própria cópia.
const villageAudio=(()=>{
 const owner=window.parent?.BunnyHavocAudio,track=owner?.getAudio('village')||$('villageMusic'),button=$('villageMusicToggle');
 if(!track){button.hidden=true;return {get state(){return {available:false};}};}
 let resume=false;
 if(!owner){track.volume=.22;track.loop=true;}
 function paint(){const audible=!track.paused&&!track.muted&&track.volume>0;
  button.textContent=track.paused?'♫ Ouvir música':track.muted?'♫ Música desligada':'♫ Música ligada';
  button.setAttribute('aria-label',track.paused?'Ouvir Village – Where the sun shines':track.muted?'Ativar música da vila':'Silenciar música da vila');
  button.setAttribute('aria-pressed',String(audible));
 }
 function play(){track.play().then(paint).catch(paint);}
 function toggle(){
  if(track.muted){if(owner)owner.toggleMute();else track.muted=false;play();}
  else if(track.paused)play();
  else if(owner)owner.toggleMute();else track.muted=true;
  paint();
 }
 button.onclick=toggle;
 addEventListener('keydown',e=>{if(e.code==='KeyM'&&!e.repeat){e.preventDefault();toggle();}});
 for(const event of ['play','pause','volumechange','error','loadedmetadata'])track.addEventListener(event,paint);
 addEventListener('pagehide',()=>{for(const event of ['play','pause','volumechange','error','loadedmetadata'])track.removeEventListener(event,paint);if(!owner)track.pause();});
 if(!owner){document.addEventListener('visibilitychange',()=>{if(document.hidden){resume=!track.paused;track.pause();}else if(resume){resume=false;play();}});play();}
 paint();
 return {get state(){return {available:true,playing:!track.paused,muted:track.muted,volume:track.volume,error:track.error?.message||null};}};
})();

// Vida cotidiana da vila: percursos locais, pausas, conversas e fauna em blocos.
function prepareCitizen(n) {
 const u=n.userData,parts=[u.head,...u.arms,...u.legs];
 for(const part of parts){part.parent.remove(part);mergeMeshes(part);}
 mergeMeshes(u.core);for(const part of parts)u.core.add(part);
}
const villageLife=(()=>{
 const routes={
  Lia:[[-5,7],[-6,6],[-5,5]],Tito:[[5,7],[6,5],[8,5],[7,7]],
  Nina:[[-31,-19],[-29,-20],[-27,-19]],Pip:[[24,-23],[26,-22],[27,-24]],
  Otto:[[-32,14],[-34,13],[-34,10],[-31,12]],Brasa:[[31,11],[33,10],[35,11]],
  Yumi:[[23,40],[22,39],[24,39]],Rui:[[6,-6],[7,0],[6,5],[9,5],[10,-3]],
  Luna:[[-6,-6],[-7,0],[-6,5],[-9,6],[-10,-3]]
 };
 const vendors=new Set(['Amora','Bento','Mel']);
 const walkers=npcs.filter(n=>!n.data.guardianArea);
 for(const [i,n] of walkers.entries()){
  n.routine={route:routes[n.data.name]||[[n.data.x,n.data.z]],index:0,wait:2+i*.45,time:0,state:vendors.has(n.data.name)?'atendendo':'observando',travelled:0};
 }
 const props=new T.Group();S.add(props);
 // Jardineiras, regadores, caixas de feira e correspondência nas casas.
 for(const [x,z] of [[-11,-11],[11,-11],[-11,12],[11,12]]){
  block(props,[1.9,.38,.85],wood,[x,2.32,z]);block(props,[1.65,.05,.65],0x594632,[x,2.53,z]);
  for(const s of [-.6,0,.6])flower(props,x+s,z,0xf5afc8,2.56);
 }
 for(const [x,z] of [[-26,23],[-16,27],[-22,32]]){
  block(props,[.78,.56,.72],0x9b6a3d,[x,2.34,z]);
  for(const s of [-1,1])block(props,[.08,.62,.78],trim,[x+s*.39,2.34,z]);
  for(let i=0;i<5;i++)rock(props,[.12,.13,.12],i%2?0xed9b39:0x94b34e,[x-.25+(i%3)*.24,2.68,z-.16+Math.floor(i/3)*.24]);
 }
 for(const a of Campaign.areas){
  const x=a.x+4.5,z=a.z+6;block(props,[.12,.9,.12],wood,[x,2.5,z]);block(props,[.48,.32,.36],0x825548,[x,3.05,z]);block(props,[.43,.035,.03],0xe8c783,[x,3.07,z+.19]);
 }
 // Varal no mercado: retalhos pequenos e facetados, fora dos caminhos.
 for(const x of [-27,-21])block(props,[.12,2.7,.12],wood,[x,3.35,34]);
 block(props,[6,.04,.04],trim,[-24,4.64,34]);
 const laundry=[];for(let i=0;i<5;i++){const cloth=block(S,[.65,.68,.045],[0xd78385,0xe6c779,0x688da8][i%3],[-26.4+i*1.15,4.28,34]);laundry.push(cloth);}
 mergeMeshes(props);
 const smoke=[];
 const smokeCanvas=document.createElement('canvas');smokeCanvas.width=smokeCanvas.height=32;const sc=smokeCanvas.getContext('2d'),sg=sc.createRadialGradient(16,16,1,16,16,15);sg.addColorStop(0,'rgba(218,218,208,.33)');sg.addColorStop(.65,'rgba(218,218,208,.15)');sg.addColorStop(1,'rgba(218,218,208,0)');sc.fillStyle=sg;sc.fillRect(0,0,32,32);
 const smokeMaterial=new T.SpriteMaterial({map:new T.CanvasTexture(smokeCanvas),transparent:true,opacity:.45,depthWrite:false});
 for(const [x,y,z] of villageArt.chimneys.map(p=>p.toArray()))for(let i=0;i<3;i++){
  const puff=new T.Sprite(smokeMaterial);puff.position.set(x,y+i*.5,z);S.add(puff);smoke.push({model:puff,x,y,z,phase:i/3});
 }
 const birds=[];
 const roofs=villageArt.metrics.architecture;
 const perches=[[-9,3.52,9],[9,3.52,-9],...[0,4,8,12,16,20].map(i=>{const h=roofs[i];return [h.position[0],h.position[1]+h.height+.35,h.position[2]];})];
 function bird(i){
  const g=new T.Group(),color=[0x526f94,0xa9784b,0x648b68,0x765b83][i%4];
  block(g,[.32,.22,.55],color,[0,0,0]);block(g,[.22,.18,.22],color,[0,.12,.22]);block(g,[.09,.08,.18],0xe7b44b,[0,.06,.42]);block(g,[.20,.07,.28],color,[0,.03,-.38]);
  for(const s of [-1,1])block(g,[.04,.055,.055],0x1c2030,[s*.12,.16,.29]);
  mergeMeshes(g);const wings=[];
  for(const s of [-1,1]){const w=new T.Group();w.position.x=s*.12;block(w,[.57,.065,.30],color,[s*.28,0,0]);g.add(w);wings.push(w);}
  const start=perches[i];g.position.set(...start);S.add(g);
  return {model:g,wings,index:i,target:(i+3)%perches.length,elapsed:0,wait:2+i*.9,state:'pousado',start:new T.Vector3(...start)};
 }
 for(let i=0;i<8;i++)birds.push(bird(i));
 const captions=[['Rui','Bom dia, Tito!'],['Luna','Oi, Lia!']].map(([name,text])=>{
  const n=walkers.find(n=>n.data.name===name),sprite=label('…',S,n.data.x,3.55,n.data.z,.65,'#4a3540','#ffedbd');
  return {npc:n,sprite,text};
 });
 function update(dt,time,night=0){
  const paused=dialogue||pendingPortal||!$('map').hidden;
  for(const n of walkers){
   const r=n.routine,u=n.model.userData,near=P.position.distanceTo(n.model.position)<3.4;
   let walking=false;
   if(!paused&&!near){
    r.time+=dt;
    if(vendors.has(n.data.name)) r.state=['atendendo','arrumando a barraca','acenando'][Math.floor(r.time/6)%3];
    else if(r.wait>0){r.wait-=dt;r.state=r.index%2?'conversando':'descansando';}
    else{
     const [x,z]=r.route[(r.index+1)%r.route.length],dx=x-n.model.position.x,dz=z-n.model.position.z,d=Math.hypot(dx,dz),step=Math.min(d,dt*.8);
     if(d<.06){r.index=(r.index+1)%r.route.length;r.wait=4+(r.index%3)*2;r.state='observando';}
     else{
      const nx=n.model.position.x+dx/d*step,nz=n.model.position.z+dz/d*step;
      if(validPosition(nx,nz)){n.model.position.set(nx,2.1,nz);r.travelled+=step;walking=true;r.state='passeando';n.model.rotation.y=Math.atan2(dx,dz);}
      else{r.index=(r.index+1)%r.route.length;r.wait=1;r.state='observando';}
     }
    }
   }
   if(near)n.model.rotation.y=Math.atan2(P.position.x-n.model.position.x,P.position.z-n.model.position.z);
   else if(r.state==='conversando'){const friend=walkers.find(other=>other!==n&&n.model.position.distanceTo(other.model.position)<4);if(friend)n.model.rotation.y=Math.atan2(friend.model.position.x-n.model.position.x,friend.model.position.z-n.model.position.z);}
   const swing=walking?Math.sin(r.time*7)*.36:0;
   u.legs.forEach((part,i)=>part.rotation.x=swing*(i?1:-1));
   u.arms.forEach((part,i)=>{part.rotation.x=walking?-swing*(i?1:-1):r.state==='arrumando a barraca'?-.45+Math.sin(r.time*3)*.15:0;part.rotation.z=!walking&&(near||r.state==='acenando')&&i===1?-.65+Math.sin(time*4)*.12:0;});
   u.head.rotation.y=near?0:!walking?Math.sin(time*.6+n.phase)*.16:0;
   villageArt.work(n,time,walking,near,paused);
   n.model.position.y=2.1+(walking?Math.abs(Math.sin(r.time*7))*.025:Math.sin(time*2+n.phase)*.012);
  }
  for(const b of birds){
   b.elapsed+=dt;
   if(b.state==='pousado'){
    if(night<.6)b.wait-=dt;b.model.rotation.x=night>=.6?-.15:Math.sin(time*4+b.index)>.7?.25:0;
    b.wings.forEach((w,i)=>w.rotation.z=(i?1:-1)*1.15);
    if(night<.6&&(b.wait<=0||P.position.distanceTo(b.model.position)<3.2)){b.state='voando';b.elapsed=0;b.start.copy(b.model.position);b.target=(b.index+3)%perches.length;}
   }else{
    const end=new T.Vector3(...perches[b.target]),duration=5+b.index%3,u=Math.min(1,b.elapsed/duration),smooth=u*u*(3-2*u);
    b.model.position.lerpVectors(b.start,end,smooth);b.model.position.y+=Math.sin(Math.PI*u)*8;
    b.model.rotation.set(0,Math.atan2(end.x-b.start.x,end.z-b.start.z),Math.sin(time*2)*.08);
    b.wings.forEach((w,i)=>w.rotation.z=(i?1:-1)*Math.sin(time*17+b.index)*.9);
    if(u===1){b.index=b.target;b.state='pousado';b.wait=4+(b.index%4);b.elapsed=0;}
   }
  }
  for(const c of captions){const n=c.npc;c.sprite.position.set(n.model.position.x,3.55,n.model.position.z);c.sprite.visible=!overview&&!paused&&P.position.distanceTo(n.model.position)<13&&n.routine.state!=='passeando'&&Math.sin(time*.7+n.phase)>.35;}
  laundry.forEach((m,i)=>m.rotation.x=Math.sin(time*1.4+i*.5)*.12);
  for(const p of smoke){const u=(time*.15+p.phase)%1;p.model.position.set(p.x+u*.65,p.y+u*2.4,p.z+Math.sin(time+u)*.12);p.model.scale.setScalar(.55+Math.sin(u*Math.PI)*.8);p.model.visible=u<.95;}
 }
 return {update,birds,walkers,smoke};
})();

// Praça habitada e três brinquedos de cenário. Sem moeda, prêmio ou progresso.
const villageDetails=(()=>{
 const fixed=new T.Group();fixed.name='VillagePlazaDetails';S.add(fixed);const interactables=[];
 const notice=$('villageNotice');let noticeTime=0,audio=null,lastSoundGain=0;
 function solid(x,z,r){obstacles.push({x,z,r});}
 function register(id,title,action,x,z,model){const item={id,title,action,x,z,model,elapsed:0,remaining:0,uses:0};interactables.push(item);return item;}
 function pot(x,z,color){
  block(fixed,[.65,.44,.65],0xa17853,[x,2.36,z]);block(fixed,[.74,.10,.74],wood,[x,2.60,z]);
  for(const dx of [-.19,0,.19])flower(fixed,x+dx,z,color,2.65);solid(x,z,.38);
 }
 // Filete e pequenas rosetas no piso delimitam o passeio circular, sem degraus.
 for(let i=0;i<40;i++){
  const a=i*Math.PI*2/40,r=5.0;
  block(fixed,[.43,.025,.19],i%5===0?0xa58d63:0xd2be94,[Math.sin(a)*r,2.19,Math.cos(a)*r],a);
 }
 // Mesa de conversa junto aos bancos existentes, fora das ligações com as pontes.
 const tx=-11.8,tz=6.1;
 block(fixed,[1.6,.14,1.05],wood,[tx,3.08,tz]);
 for(const dx of [-.58,.58])for(const dz of [-.33,.33])block(fixed,[.13,.94,.13],trim,[tx+dx,2.59,tz+dz]);
 for(const side of [-1,1]){
  block(fixed,[.63,.13,.60],0xa97c4c,[tx,2.66,tz+side*1.0]);
  for(const dx of [-.20,.20])block(fixed,[.11,.50,.38],trim,[tx+dx,2.36,tz+side*1.0]);
 }
 for(const side of [-1,1]){block(fixed,[.14,.20,.14],0xdbcaa2,[tx+side*.43,3.25,tz]);block(fixed,[.21,.035,.21],trim,[tx+side*.43,3.14,tz]);}
 block(fixed,[.43,.04,.34],0xa47562,[tx,3.18,tz]);solid(tx,tz,1.40);pot(-13.5,5.8,0xffcf83);
 // Mural de recados com papel e brasão de cenoura, sem novas missões.
 const bx=-3.8,bz=-11.7;
 for(const side of [-1,1])block(fixed,[.17,2.7,.17],trim,[bx+side*.9,3.37,bz]);
 block(fixed,[2.35,1.5,.19],wood,[bx,4.0,bz]);block(fixed,[2.12,1.26,.06],0x826449,[bx,4.0,bz+.13]);
 block(fixed,[2.65,.14,.60],trim,[bx,4.86,bz]);
 for(let i=0;i<4;i++){
  const x=bx-.73+(i%2)*1.0,z=bz+.18,y=4.25-Math.floor(i/2)*.62;
  block(fixed,[.64,.48,.035],i%2?0xd5c6a3:0xeee0bb,[x,y,z]);block(fixed,[.06,.06,.045],gold,[x,y+.17,z+.025]);
  for(let j=0;j<2;j++)block(fixed,[.32-j*.09,.025,.018],0x9a8b6d,[x,y+.04-j*.10,z+.025]);
 }
 solid(bx,bz,1.12);pot(-5.65,-11.7,0xe59aac);
 // Sino: estrutura baixa de madeira e corpo metálico facetado.
 const x=1.9,z=-11.7;
 for(const side of [-1,1]){block(fixed,[.21,3.15,.21],wood,[x+side*.79,3.62,z]);block(fixed,[.50,.16,.52],stone,[x+side*.79,2.16,z]);}
 block(fixed,[2.0,.19,.44],trim,[x,5.20,z]);
 const bell=new T.Group();bell.position.set(x,4.90,z);S.add(bell);
 block(bell,[.10,.34,.10],trim,[0,-.12,0]);cylinder(bell,.24,.47,.57,0xc9a05b,[0,-.58,0],6);cylinder(bell,.50,.50,.11,gold,[0,-.88,0],6);
 block(bell,[.075,.55,.075],wood,[0,-1.16,0]);rock(bell,[.14,.14,.14],0xa17d43,[0,-1.45,0]);mergeMeshes(bell);
 const bellItem=register('bell','Sino da praça','TOCAR O SINO',x,z,bell);solid(x,z,.96);
 // Cata-vento pequeno no gramado, longe do acesso ao bairro das neves.
 const wx=11.7,wz=-4.7;block(fixed,[.14,2.9,.14],wood,[wx,3.50,wz]);pot(12.6,-4.7,0xf3c781);
 const rotor=new T.Group();rotor.position.set(wx,4.88,wz+.13);S.add(rotor);
 for(let i=0;i<4;i++){
  const blade=new T.Group();blade.rotation.z=i*Math.PI/2;rotor.add(blade);
  block(blade,[.43,.63,.045],[0xa06470,0xe1ba65,0x648da0,0x73965b][i],[.19,.37,0]);
  const crease=block(blade,[.07,.67,.06],0xf0dcb0,[0,.34,.03]);crease.rotation.z=-.30;
 }
 rock(rotor,[.14,.14,.09],gold,[0,0,.06]);mergeMeshes(rotor);
 const windItem=register('pinwheel','Cata-vento','GIRAR',wx,wz,rotor);solid(wx,wz,.43);
 // Canteiro com regador: água e flores animadas em um conjunto fixo de malhas.
 const gx=11.2,gz=7.4;
 block(fixed,[2.3,.29,1.28],wood,[gx,2.26,gz]);block(fixed,[2.10,.035,1.08],0x65513b,[gx,2.42,gz]);
 const blooms=new T.Group();blooms.position.set(gx,2.43,gz);S.add(blooms);
 for(let i=0;i<6;i++){const fx=(i%3-1)*.67,fz=Math.floor(i/3)*.53-.26;
  block(fixed,[.055,.32,.055],0x507e42,[gx+fx,2.60,gz+fz]);
  rock(blooms,[.23,.13,.23],[0xe2a0ba,0xf5d38b,0xb9a0ce][i%3],[fx,.35,fz]);
 }mergeMeshes(blooms);
 const can=new T.Group();can.position.set(gx-1.63,2.65,gz+.33);S.add(can);
 block(can,[.48,.44,.47],0x6b9294,[0,0,0]);block(can,[.22,.14,.18],0x6b9294,[.33,.06,0]);block(can,[.13,.20,.22],0xa3babb,[.47,.14,0]);
 for(const side of [-1,1])block(can,[.07,.38,.07],0x496b72,[-.30,side*.16,0]);block(can,[.07,.07,.35],0x496b72,[-.30,.31,0]);mergeMeshes(can);
 can.name='VillageWateringCan';const drops=new T.Group();drops.name='VillageWaterDrops';S.add(drops);const droplets=[];
 for(let i=0;i<6;i++)droplets.push(block(drops,[.07,.13,.07],0xa9e2e8,[gx-.9,3,gz]));mergeMeshes(fixed);
 const gardenItem=register('garden','Canteiro da praça','REGAR',gx,gz,blooms);solid(gx,gz,1.21);
 solid(gx-1.63,gz+.33,.30);drops.visible=false;
 function message(text){notice.textContent=text;notice.hidden=false;noticeTime=3;}
 function ring(){
  const settings=bhVideo(),track=window.parent?.BunnyHavocAudio?.getAudio('village')||$('villageMusic');
  lastSoundGain=0;if(settings.muted||track?.muted)return;
  const gain=Math.max(0,Math.min(1,settings.sfx??.8))*.12;if(!gain)return;
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
  try{audio??=new AC();audio.resume().catch(()=>{});lastSoundGain=gain;
   for(const [frequency,strength] of [[660,1],[990,.28]]){const osc=audio.createOscillator(),volume=audio.createGain(),now=audio.currentTime;
    osc.type='sine';osc.frequency.value=frequency;volume.gain.setValueAtTime(gain*strength,now);volume.gain.exponentialRampToValueAtTime(.0001,now+.8);
    osc.connect(volume);volume.connect(audio.destination);osc.start(now);osc.stop(now+.85);osc.onended=()=>{osc.disconnect();volume.disconnect();};}
  }catch(_error){lastSoundGain=0;}
 }
 function use(item){
  if(!interactables.includes(item)||Math.hypot(P.position.x-item.x,P.position.z-item.z)>2.7)return false;
  if(dialogue||pendingPortal||!$('map').hidden||entering||document.hidden||item.remaining>0)return false;
  item.elapsed=0;item.remaining=item.id==='garden'?2.8:item.id==='bell'?1.8:2.4;item.uses++;
  if(item.id==='bell'){ring();message('O sino ecoa pela praça.');}
  else if(item.id==='pinwheel')message('Uma boa volta para o cata-vento!');
  else message('Um pouco de água para alegrar o canteiro.');
  return true;
 }
 function update(dt){
  const paused=document.hidden||dialogue||pendingPortal||!$('map').hidden||entering;
  if(paused)return;
  if(noticeTime>0){noticeTime=Math.max(0,noticeTime-dt);if(!noticeTime)notice.hidden=true;}
  for(const item of interactables){item.elapsed+=dt;item.remaining=Math.max(0,item.remaining-dt);}
  bell.rotation.z=bellItem.remaining>0?Math.sin(bellItem.elapsed*15)*.35*Math.pow(bellItem.remaining/1.8,2):0;
  rotor.rotation.z+=dt*(.55+(windItem.remaining>0?windItem.remaining*3:0));
  const watering=gardenItem.remaining>0;
  can.rotation.z=watering?-.55*Math.sin(Math.min(1,gardenItem.elapsed/.3)*Math.PI/2):0;
  can.position.y=2.65+(watering?.45:0);drops.visible=watering&&gardenItem.elapsed>.2&&gardenItem.remaining>.3;
  for(let i=0;i<droplets.length;i++){const u=(gardenItem.elapsed*1.7+i/6)%1;droplets[i].position.set(gx-1.08+u*.85,3.11-u*.58,gz+.10+Math.sin(i*3)*.24);}
  const bloom=watering?Math.sin(Math.min(1,gardenItem.elapsed/.45)*Math.PI/2)*Math.min(1,gardenItem.remaining/.5):0;
  blooms.scale.set(1+bloom*.13,1+bloom*.20,1+bloom*.13);
 }
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&audio)audio.suspend().catch(()=>{});});
 addEventListener('pagehide',()=>{if(audio)audio.close().catch(()=>{});});
 return {update,use,interactables,get state(){return {lastSoundGain,notice:notice.hidden?'':notice.textContent};}};
})();

// Ambiência sintetizada local: volume discreto, desbloqueio por gesto e descarte.
// Não altera os elementos nativos das músicas nem o sintetizador do sino.
const villageAmbience=(()=>{
 let audio=null,master=null,waterSource=null,elapsed=0,nextBird=4,lastHammer=-1,lastGain=0,appliedGain=-1,events=0,activeTones=0;
 function unlock(){
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
  if(audio){audio.resume().catch(()=>{});return;}
  try{
   audio=new AC();master=audio.createGain();master.gain.value=0;master.connect(audio.destination);
   const buffer=audio.createBuffer(1,audio.sampleRate*2,audio.sampleRate),data=buffer.getChannelData(0);let previous=0,noiseSeed=4011;
   for(let i=0;i<data.length;i++){noiseSeed=(Math.imul(noiseSeed,1664525)+1013904223)>>>0;previous=(previous+(noiseSeed/4294967296*2-1)*.04)/1.04;data[i]=previous;}
   waterSource=audio.createBufferSource();waterSource.buffer=buffer;waterSource.loop=true;
   const filter=audio.createBiquadFilter();filter.type='lowpass';filter.frequency.value=700;waterSource.connect(filter);filter.connect(master);waterSource.start();audio.resume().catch(()=>{});
  }catch{if(audio)audio.close().catch(()=>{});audio=null;master=null;}
 }
 function tone(frequency,duration,type,strength){
  if(!audio||audio.state!=='running'||!master)return;
  const osc=audio.createOscillator(),gain=audio.createGain(),now=audio.currentTime;
  osc.type=type;osc.frequency.setValueAtTime(frequency,now);osc.frequency.exponentialRampToValueAtTime(frequency*.72,now+duration);
  gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(strength,now+.015);gain.gain.exponentialRampToValueAtTime(.0001,now+duration);
  osc.connect(gain);gain.connect(master);osc.start();osc.stop(now+duration+.02);activeTones++;events++;
  osc.onended=()=>{activeTones--;osc.disconnect();gain.disconnect();};
 }
 function update(dt,night,paused){
  const settings=bhVideo(),track=window.parent?.BunnyHavocAudio?.getAudio('village')||$('villageMusic');
  const muted=settings.muted||track?.muted||document.hidden||paused;
  lastGain=muted?0:Math.max(0,Math.min(1,settings.sfx??.8))*.065;
  if(master&&audio&&lastGain!==appliedGain){master.gain.setTargetAtTime(lastGain,audio.currentTime,.12);appliedGain=lastGain;}
  if(muted||!audio||audio.state!=='running')return;elapsed+=dt;
  if(night<.5&&elapsed>=nextBird){nextBird=elapsed+7+(events%4);tone(2600,.13,'sine',.24);tone(3250,.20,'sine',.16);}
  const forge=Campaign.areas[3],strike=Math.floor(elapsed/3.4);
  if(Math.hypot(P.position.x-forge.x,P.position.z-forge.z)<12&&strike!==lastHammer){lastHammer=strike;tone(850,.10,'triangle',.15);}
 }
 document.addEventListener('pointerdown',unlock,{once:true});document.addEventListener('keydown',unlock,{once:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){lastGain=0;appliedGain=0;if(master&&audio)master.gain.setValueAtTime(0,audio.currentTime);}});
 addEventListener('pagehide',()=>{if(waterSource){try{waterSource.stop();}catch{}}if(audio)audio.close().catch(()=>{});});
 return {update,get state(){return {unlocked:!!audio,running:audio?.state==='running',lastGain,events,activeTones};}};
})();

const lockedColor=new T.Color(0x34475a),normalColor=new T.Color();
function status(p){return Campaign.status(save,p.id,trial);}
function portalDescription(p){const s=status(p);return s==='locked'?(p.slot.index===1?'Conclua o chefe da área anterior.':'Conclua o destino anterior para abrir este portal.')+(p.slot.payload?'':' Novo destino em preparação.'):s==='upcoming'?'O caminho foi liberado. Esta fase está em preparação.':s==='complete'?'Concluído · entre para jogar novamente.':'Portal aberto · entre para começar.';}
function updatePortals(){for(const p of portals){const state=status(p),open=state==='open'||state==='complete';p.material.color.set(p.area.color);if(!open)p.material.color.lerp(lockedColor,.55);p.material.opacity=open?.72:state==='upcoming'?.36:.28;p.rings.visible=open;p.lock.visible=!open;p.label.material.opacity=state==='locked'?.75:1;}}
updatePortals();
function setOverview(value){overview=value;$('cameraMode').textContent=overview?'Câmera de perto':'Ver vila inteira';}
$('cameraMode').onclick=()=>setOverview(!overview);
const states={locked:'Bloqueado',upcoming:'Em preparação',complete:'Concluído · rejogar',open:'Entrar na fase'};
function buildMap(){const dest=$('destinations');dest.replaceChildren();for(const area of Campaign.areas){const section=document.createElement('section');section.className='district';const title=document.createElement('h3');title.textContent=area.id+' · '+area.name;section.append(title);const row=document.createElement('div');row.className='destinations';
 for(const p of portals.filter(p=>p.area.id===area.id)){const button=document.createElement('button'),state=status(p);button.dataset.portal=p.id;button.dataset.status=state;button.disabled=state==='locked'||state==='upcoming';button.append(document.createTextNode(p.slot.boss?'Chefe':p.slot.index+' · '+p.slot.name));const small=document.createElement('small');small.textContent=states[state];button.append(small);button.title=portalDescription(p);button.onclick=()=>enterPortal(p);row.append(button);}section.append(row);dest.append(section);}}
function openMap(){keys.clear();buildMap();$('map').hidden=false;$('mapClose').focus();}function closeMap(){$('map').hidden=true;$('mapButton').focus();}
$('mapButton').onclick=openMap;$('mapClose').onclick=closeMap;
function say(n){
 keys.clear();dialogue=n;dialogIndex=0;$('dialogName').textContent=n.data.name;$('dialogText').textContent=n.data.lines[0];$('dialog').hidden=false;
 const choices=$('guardianDestinations');choices.replaceChildren();choices.hidden=!n.data.guardianArea;$('dialogNext').hidden=!!n.data.guardianArea;
 if(n.data.guardianArea){for(const p of portals.filter(p=>p.area.id===n.data.guardianArea)){const button=document.createElement('button'),state=status(p);button.dataset.guardianPortal=p.id;button.disabled=!['open','complete'].includes(state);button.textContent=(p.slot.boss?'Chefe':p.slot.name)+' · '+states[state];button.onclick=()=>enterPortal(p);choices.append(button);}$('dialogClose').focus();}
 else $('dialogNext').focus();
}
function closeDialog(){dialogue=null;$('dialog').hidden=true;$('guardianDestinations').hidden=true;$('dialogNext').hidden=false;$('action').focus();}
$('dialogClose').onclick=closeDialog;$('dialogNext').onclick=()=>{if(!dialogue)return;dialogIndex++;if(dialogIndex>=dialogue.data.lines.length)closeDialog();else $('dialogText').textContent=dialogue.data.lines[dialogIndex];};
function enterPortal(p){
 if(entering||pendingPortal)return;
 const s=status(p);if(!['open','complete'].includes(s)){showInfo(p.slot.name,portalDescription(p));return;}
 const guardian=MEOWLIN[p.area.id-1];keys.clear();pendingPortal=p;confirmOrigin=document.activeElement;
 $('guardianName').textContent=guardian.name;$('portalQuestion').textContent='Tem certeza de que quer entrar em “'+p.slot.name+'”?';
 $('portalConfirm').style.setProperty('--guardian-color','#'+guardian.robe.toString(16).padStart(6,'0'));$('portalConfirm').hidden=false;$('confirmYes').disabled=false;$('confirmCancel').focus();
}
function cancelPortal(){pendingPortal=null;$('portalConfirm').hidden=true;keys.clear();if(confirmOrigin?.isConnected)confirmOrigin.focus();else $('mapButton').focus();confirmOrigin=null;}
$('confirmCancel').onclick=cancelPortal;
$('confirmYes').onclick=()=>{
 const p=pendingPortal;if(!p||entering)return;
 if(!['open','complete'].includes(status(p))){cancelPortal();return;}
 pendingPortal=null;$('portalConfirm').hidden=true;keys.clear();
 if(config.preview){showInfo(MEOWLIN[p.area.id-1].name,'Você está na prévia da vila. Abra o jogo completo para entrar nas fases e guardar seu progresso.');return;}
 entering=true;$('confirmYes').disabled=true;
 keys.clear();const arrival=[[0,3.5],[1.5,3.5],[-1.5,3.5],[0,5]].map(([x,z])=>({x:p.x+x,z:p.z+z})).find(a=>validPosition(a.x,a.z))||{x:P.position.x,z:P.position.z};
 window.parent.postMessage({type:'bunny-havoc-village-enter',token:config.token,id:p.id,guardianArea:p.area.id,confirmed:true,position:arrival},'*');
};
function showInfo(name,text){dialogue={data:{name,lines:[text]}};dialogIndex=0;$('dialogName').textContent=name;$('dialogText').textContent=text;$('guardianDestinations').hidden=true;$('dialogNext').hidden=false;$('dialog').hidden=false;$('dialogClose').focus();}
function interact(){if(pendingPortal||entering||!$('map').hidden)return;if(dialogue){if(!dialogue.data.guardianArea)$('dialogNext').click();return;}if(!nearest)return;if(nearest.kind==='portal')enterPortal(nearest.value);else if(nearest.kind==='prop')villageDetails.use(nearest.value);else say(nearest.value);}
$('action').onclick=interact;
addEventListener('keydown',e=>{if(['Enter','Space'].includes(e.code)&&e.target.closest?.('button'))return;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','Enter','KeyE'].includes(e.code))e.preventDefault();if(e.repeat&&['Enter','KeyE','KeyV','Escape'].includes(e.code))return;
 if(pendingPortal){if(e.code==='Escape'){e.preventDefault();cancelPortal();}else if(e.code==='Tab'){e.preventDefault();(document.activeElement===$('confirmCancel')?$('confirmYes'):$('confirmCancel')).focus();}return;}
 if(e.code==='Escape'){if(dialogue)closeDialog();else if(!$('map').hidden)closeMap();else openMap();return;}
 if(e.code==='KeyV'){setOverview(!overview);return;}
 if(['KeyE','Enter'].includes(e.code)){interact();return;}if(!dialogue&&$('map').hidden)keys.add(e.code);
});addEventListener('keyup',e=>keys.delete(e.code));addEventListener('blur',()=>keys.clear());
for(const button of document.querySelectorAll('[data-key]')){button.onpointerdown=e=>{e.preventDefault();button.setPointerCapture(e.pointerId);keys.add(button.dataset.key);};button.onpointerup=button.onpointercancel=()=>keys.delete(button.dataset.key);}
function fit(){const video=bhVideo(),height=({low:168,medium:240,high:360})[video.quality]||240,width=Math.max(160,Math.round(height*innerWidth/innerHeight));R.setPixelRatio(video.psx===false?({low:.65,medium:1,high:Math.min(2,devicePixelRatio||1.5)})[video.quality]||1:1);R.setSize(innerWidth,innerHeight);RT.setSize(width,height);qm.uniforms.res.value.set(width,height);C.aspect=innerWidth/innerHeight;C.updateProjectionMatrix();}addEventListener('resize',fit);fit();
function updatePrompt(){let best=Infinity,item=null;for(const p of portals){const d=Math.hypot(P.position.x-p.x,P.position.z-p.z-1);if(d<4.2&&d<best){best=d;item={kind:'portal',value:p};}}
 for(const n of npcs){const d=P.position.distanceTo(n.model.position);if(d<2.9&&d<best){best=d;item={kind:'npc',value:n};}}for(const prop of villageDetails.interactables){const d=Math.hypot(P.position.x-prop.x,P.position.z-prop.z);if(d<2.7&&d<best){best=d;item={kind:'prop',value:prop};}}nearest=item;$('prompt').style.display=item&&!dialogue&&!pendingPortal&&$('map').hidden?'block':'none';
 $('action').disabled=false;
 if(item){const p=item.value,isPortal=item.kind==='portal';if(item.kind==='prop'){$('promptTitle').textContent=p.title;$('promptText').textContent='E / Enter para brincar';$('action').disabled=p.remaining>0;$('action').textContent=p.remaining>0?({bell:'TOCANDO…',pinwheel:'GIRANDO…',garden:'REGANDO…'}[p.id]):p.action;return;}$('promptTitle').textContent=isPortal?(p.slot.boss?'Chefe · '+p.area.name:p.slot.name):p.data.name;$('promptText').textContent=isPortal?portalDescription(p):'E / Enter para conversar';$('action').textContent=isPortal?(['open','complete'].includes(status(p))?'ENTRAR':'VER PORTAL'):'CONVERSAR';}
}
function updateCamera(dt,snap=false){
 if(overview){focus.set(0,4,3);const distance=Math.max(116,150/C.aspect);cameraEye.set(0,4+distance*.61,3+distance*.79);}
 else{focus.copy(P.position).add(new T.Vector3(0,1.1,-3));cameraEye.copy(P.position).add(new T.Vector3(0,12,16));}
 if(snap){look.copy(focus);C.position.copy(cameraEye);}else{look.lerp(focus,1-Math.exp(-5*dt));C.position.lerp(cameraEye,1-Math.exp(-4*dt));}C.lookAt(look);
 // A vista em retrato afasta a câmera: a neblina acompanha a distância para não apagar a vila.
 const distance=C.position.distanceTo(look);S.fog.near=Math.max(100,distance+25);S.fog.far=Math.max(240,distance+160);
 const far=Math.max(350,distance+240);if(Math.abs(C.far-far)>.5){C.far=far;C.updateProjectionMatrix();}
}
function loop(){if(disposed)return;requestAnimationFrame(loop);const dt=Math.min(.05,clock.getDelta());phase+=dt;
 villageCycle.update(document.hidden?0:dt);
 if(Math.floor(phase*2)!==Math.floor((phase-dt)*2))R.shadowMap.needsUpdate=true;
 const dx=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0),dz=(keys.has('KeyS')||keys.has('ArrowDown')?1:0)-(keys.has('KeyW')||keys.has('ArrowUp')?1:0),moving=(dx||dz)&&!dialogue&&!pendingPortal&&$('map').hidden;
 if(moving){if(overview)setOverview(false);const length=Math.hypot(dx,dz),speed=(keys.has('ShiftLeft')||keys.has('KeyK')?8:5.8)*dt,nx=P.position.x+dx/length*speed,nz=P.position.z+dz/length*speed;
 if(validPosition(nx,P.position.z))P.position.x=nx;if(validPosition(P.position.x,nz))P.position.z=nz;
 const angle=Math.atan2(dx,dz),delta=Math.atan2(Math.sin(angle-body.rotation.y),Math.cos(angle-body.rotation.y));body.rotation.y+=delta*(1-Math.exp(-14*dt));}
 P.position.y+=(groundHeight(P.position.x,P.position.z)-P.position.y)*(1-Math.exp(-18*dt));
 legs.forEach((l,i)=>l.rotation.x=moving?Math.sin(phase*12+i*Math.PI)*.6:0);arms.forEach((a,i)=>a.rotation.x=moving?Math.sin(phase*12+(i+1)*Math.PI)*.4:0);
 bun.position.y=moving?Math.abs(Math.sin(phase*12))*.07:Math.sin(phase*2)*.012;ears.forEach((e,i)=>e.rotation.x=Math.sin(phase*3+i)*.045);shade.position.set(P.position.x,groundHeight(P.position.x,P.position.z)+.015,P.position.z);
 for(const name of labels)name.visible=!overview&&P.position.distanceTo(name.position)<15;
 for(const p of portals){p.rings.rotation.z=phase*.35;p.material.opacity=(['open','complete'].includes(status(p))?.70:.27)+Math.sin(phase*2+p.id)*.045;p.label.visible=!overview&&P.position.distanceTo(p.surface.position)<15;}
 wheels.forEach(w=>w.rotation.z=phase*.25);
 villageLife.update(dt,phase,villageCycle.state.night);
 villageDetails.update(dt);
 villageArt.update(dt,villageCycle.state.night,dialogue||pendingPortal||!$('map').hidden||entering);
 villageAmbience.update(dt,villageCycle.state.night,dialogue||pendingPortal||!$('map').hidden||entering);
 guardians.forEach(n=>n.model.position.y=2.1+Math.sin(phase*2.3+n.phase)*.018);
 bubbles.forEach(b=>{b.sprite.position.set(b.model.position.x,3.55+Math.sin(phase*2+b.phase)*.08,b.model.position.z);b.sprite.visible=!overview&&!dialogue&&!pendingPortal&&$('map').hidden&&P.position.distanceTo(b.sprite.position)<8&&Math.sin(phase*.5+b.phase)>.1;});
 const court=courts.find(c=>Math.hypot(P.position.x-c.x,P.position.z-c.z)<c.r);
 const area=court?Campaign.areas[court.area-1]:Campaign.areas.find(a=>Math.hypot(P.position.x-a.x,P.position.z-a.z)<12);const atMarket=Math.hypot(P.position.x+20,P.position.z-27)<11;
 $('district').textContent=(area?area.name:atMarket?'Mercado da Vila':'Praça do Coelho')+' · '+save.completed.filter(Boolean).length+' / 20 destinos concluídos';
 updatePrompt();updateCamera(dt);
 if(bhVideo().psx!==false){R.setRenderTarget(RT);R.render(S,C);renderStats={...R.info.render};R.setRenderTarget(null);R.render(qs,qc);}else{R.setRenderTarget(null);R.render(S,C);renderStats={...R.info.render};}
}
$('mode').textContent=config.preview?'Prévia da vila · sem salvar':trial?'Exploração em treino · sem salvar':'Arquivo '+((config.slot||0)+1);updateCamera(0,true);
window.BunnyHavocVillage={scene:S,camera:C,renderer:R,get renderStats(){return {...renderStats};},hero:P,portals,npcs,guardians,life:villageLife,art:villageArt,ambience:villageAmbience,details:villageDetails,homes,cycle:villageCycle,audio:villageAudio,courts,islands,bridges,validPosition,get pendingPortal(){return pendingPortal?.id??null;},get overview(){return overview;},get save(){return structuredClone(save);},get state(){return {preview:!!config.preview,trial};}};
window.parent!==window&&window.parent.postMessage({type:'bunny-havoc-village-ready',token:config.token},'*');loop();
addEventListener('pagehide',()=>{disposed=true;RT.dispose();qm.dispose();R.dispose();});
}catch(error){console.error(error);fail('Não foi possível abrir a vila. Volte ao menu e tente novamente.');}
})();
