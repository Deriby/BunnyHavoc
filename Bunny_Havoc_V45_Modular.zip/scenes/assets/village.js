/* Vila procedural independente: navegação e encenação. O launcher é dono dos saves. */
(()=>{
'use strict';
const $=id=>document.getElementById(id),fail=message=>{$('error').hidden=false;$('error').textContent=message;};
if(!window.THREE){fail('Não foi possível abrir a vila. Confira sua conexão com a internet e tente novamente.');return;}
try{
const T=THREE,Campaign=BunnyHavocCampaign,config=window.__BHVILLAGE__||{preview:true};
const save=Campaign.normalize(config.save)||Campaign.normalize({schema:9,completed:[]}),trial=!!config.trial;
const materials=new Map(),mat=color=>{if(!materials.has(color))materials.set(color,new T.MeshLambertMaterial({color}));return materials.get(color);};
const B=(w,h,d)=>new T.BoxGeometry(w,h,d),mesh=(geo,color,pos)=>{const m=new T.Mesh(geo,mat(color));if(pos)m.position.set(...pos);return m;};
const S=new T.Scene();
const sky=document.createElement('canvas');sky.width=256;sky.height=256;const skyCtx=sky.getContext('2d'),skyGradient=skyCtx.createLinearGradient(0,0,0,256);
skyGradient.addColorStop(0,'#5a9bd3');skyGradient.addColorStop(.62,'#b7deea');skyGradient.addColorStop(1,'#e9e8cb');skyCtx.fillStyle=skyGradient;skyCtx.fillRect(0,0,2,256);S.background=new T.CanvasTexture(sky);
S.fog=new T.Fog(0xc2dae2,110,250);
const hemisphere=new T.HemisphereLight(0xfff5e8,0x536f89,.70);S.add(hemisphere);const sun=new T.DirectionalLight(0xffecc8,.72);sun.position.set(-35,70,35);S.add(sun);
const bhVideo=()=>window.parent?.BunnyHavocSettings?.get?.()||{};
if(bhVideo().psx!==false)T.ShaderChunk.project_vertex += '\n gl_Position.xy=floor(gl_Position.xy/gl_Position.w*vec2(213.,120.)+.5)/vec2(213.,120.)*gl_Position.w;';
const R=new T.WebGLRenderer({antialias:false});R.setPixelRatio(1);document.body.prepend(R.domElement);
const RT = new T.WebGLRenderTarget(2, 2, { minFilter: T.NearestFilter, magFilter: T.NearestFilter }), qm = new T.ShaderMaterial({ uniforms: { t: { value: RT.texture }, res: { value: new T.Vector2(2, 2) } }, vertexShader: 'varying vec2 v;void main(){v=uv;gl_Position=vec4(position.xy,0.,1.);}', fragmentShader: `uniform sampler2D t;uniform vec2 res;varying vec2 v;
void main(){vec3 c=texture2D(t,v).rgb;vec2 p=floor(v*res);float a=mod(p.x,2.),b=mod(p.y,2.);float d=(a<.5?(b<.5?0.:3.):(b<.5?2.:1.))/4.+.125;
c=c*1.08-.02;c=mix(vec3(dot(c,vec3(.3,.59,.11))),c,1.15);c*= vec3(1.030,1.005,0.972);c=floor(c*31.+d)/31.;vec2 q=v-.5;c*=1.-dot(q,q)*.5;gl_FragColor=vec4(c,1.);}` }), qs = new T.Scene(), qc = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
qs.add(new T.Mesh(new T.PlaneGeometry(2, 2), qm));
let renderStats={calls:0,triangles:0};
const C=new T.PerspectiveCamera(45,1,.1,350),staticRoot=new T.Group();S.add(staticRoot);
const unitBox=new T.BoxGeometry(1,1,1),unitCone=new T.ConeGeometry(1,1,6),unitRock=new T.IcosahedronGeometry(1,0);
function block(parent,size,color,pos,rot=0){const m=mesh(unitBox,color,pos);m.scale.set(...size);m.rotation.y=rot;parent.add(m);return m;}
function cone(parent,radius,height,color,pos){const m=mesh(unitCone,color,pos);m.scale.set(radius,height,radius);parent.add(m);return m;}
function rock(parent,size,color,pos){const m=mesh(unitRock,color,pos);m.scale.set(...size);parent.add(m);return m;}
function cylinder(parent,rt,rb,h,color,pos,sides=10){const m=mesh(new T.CylinderGeometry(rt,rb,h,sides),color,pos);parent.add(m);return m;}
let seed=411;const random=()=>((seed=(seed*16807)%2147483647)/2147483647),range=(a,b)=>a+(b-a)*random();
const wood=0x805436,trim=0x573b2c,gold=0xe7b44b,stone=0x7e8791,path=0xb09e80,grass=0x5c9347;
const courts=Campaign.areas.map((area,i)=>({area:area.id,x:area.x+[-17,18,-17,17,19][i],z:area.z+[-2,0,3,2,3][i],r:7,theme:area.theme,court:true}));
const islands=[{x:0,z:0,r:18,theme:'central'},{x:0,z:29,r:7,theme:'entry'},{x:-20,z:27,r:10.5,theme:'market'},...Campaign.areas.map(a=>({...a,r:12})),...courts],bridges=[];
const labels=[];
const homes=[],obstacles=[],portals=[],waterfalls=[],npcs=[],guardians=[],bubbles=[],wheels=[],portalMaterials=[];
const MEOWLIN=['Primeiro','Segundo','Terceiro','Quarto','Quinto'].map((ordinal,i)=>({name:'Meowlin '+ordinal,area:i+1,robe:[0x7351ac,0x3f7ea8,0x4f895f,0xb06448,0xb3933d][i]}));
const worldY=2.18;
const lanternGlass=new T.MeshLambertMaterial({color:0xffca59,emissive:0xffa334,emissiveIntensity:.08});
const windowGlass=new T.MeshLambertMaterial({color:0xffcf67,emissive:0xffb245,emissiveIntensity:.06}),lanternSpots=[];
function label(text,parent,x,y,z,width=7,color='#fff1c7',background='#342d36'){
 const c=document.createElement('canvas'),short=text.length<=5;c.width=short?128:512;c.height=short?64:100;const ctx=c.getContext('2d');
 ctx.fillStyle=background;ctx.fillRect(0,0,c.width,c.height);ctx.strokeStyle='#c89d57';ctx.lineWidth=3;ctx.strokeRect(2,2,c.width-4,c.height-4);
 ctx.fillStyle=color;ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='bold '+(short?(text.length===1?52:30):29)+'px Trebuchet MS';ctx.fillText(text,c.width/2,c.height/2,c.width-10);
 const texture=new T.CanvasTexture(c);texture.minFilter=T.LinearFilter;const m=new T.Sprite(new T.SpriteMaterial({map:texture,depthTest:true}));m.position.set(x,y,z);m.scale.set(width,width*c.height/c.width,1);parent.add(m);labels.push(m);return m;
}
function tree(parent,x,z,s=1,theme='forest',y=2){
 const g=new T.Group();g.position.set(x,y,z);g.scale.setScalar(s);parent.add(g);obstacles.push({x,z,r:.33*s});
 block(g,[.55,3.3,.55],wood,[0,1.6,0]);
 if(theme==='snow'||theme==='water')for(let i=0;i<3;i++){cone(g,1.8-i*.35,2.5,theme==='snow'?0x36574b:0x30794c,[0,2.4+i*.95,0]);if(theme==='snow')cone(g,1.75-i*.35,1.6,0xe8f4f5,[0,2.85+i*.95,0]);}
 else for(let i=0;i<4;i++)rock(g,[1.6,1.6,1.6],theme==='sakura'?[0xf596c4,0xe379bc,0xffb7d6][i%3]:[0x3e843c,0x6da443,0x89b84d][i%3],[Math.sin(i*2)*1.0,3.6+(i%2)*.7,Math.cos(i*2)*.8]);
}
function flower(parent,x,z,color=0xf497c6,y=2.08){block(parent,[.055,.30,.055],0x448b42,[x,y+.12,z]);rock(parent,[.20,.12,.20],color,[x,y+.3,z]);}
function fence(parent,ax,az,bx,bz,y=2){
 const dx=bx-ax,dz=bz-az,n=Math.ceil(Math.hypot(dx,dz)/2),yaw=Math.atan2(dx,dz);
 for(let i=0;i<=n;i++)block(parent,[.22,1.12,.22],wood,[ax+dx*i/n,y+.5,az+dz*i/n]);
 const rail=block(parent,[.12,.12,Math.hypot(dx,dz)],wood,[(ax+bx)/2,y+.9,(az+bz)/2],yaw);return rail;
}
function bridge(a,b,width=3.5){
 const dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz),g=new T.Group();g.position.set(a.x,2,a.z);g.rotation.y=Math.atan2(dx,dz);staticRoot.add(g);
 for(let i=0;i<=Math.ceil(len/.55);i++)block(g,[width,.17,.49],i%3===0?0xb5814a:0x9c6d3f,[0,-.06,Math.min(len,i*.55)]);
 for(const s of [-1,1]){
  for(let z=0;z<=len;z+=2.4){block(g,[.22,1.2,.22],trim,[s*width/2,.5,z]);if(z%4.8<.1)block(g,[.28,6,.28],trim,[s*width/2,-3,z]);}
  block(g,[.10,.10,len],wood,[s*width/2,.95,len/2]);block(g,[.10,.10,len],wood,[s*width/2,.42,len/2]);
 }
 bridges.push({a,b,width});
}
function lamp(parent,x,z,y=2){
 block(parent,[.18,2.4,.18],trim,[x,y+1.15,z]);block(parent,[.75,.13,.70],wood,[x,y+2.5,z]);
 block(parent,[.48,.64,.43],0xffca59,[x,y+2.17,z]).material=lanternGlass;block(parent,[.15,.67,.46],trim,[x,y+2.17,z]);block(parent,[.50,.08,.08],trim,[x,y+2.17,z+.23]);
 cone(parent,.53,.35,trim,[x,y+2.76,z]);
 parent.updateWorldMatrix(true,false);lanternSpots.push(new T.Vector3(x,y+.15,z).applyMatrix4(parent.matrixWorld));
}
function roofGeometry(w,d,h){
 const v=[-w/2,0,-d/2,w/2,0,-d/2,0,h,-d/2,-w/2,0,d/2,w/2,0,d/2,0,h,d/2];
 const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(v,3));geo.setIndex([0,2,1,3,4,5,0,3,5,0,5,2,1,2,5,1,5,4,0,1,4,0,4,3]);geo.computeVertexNormals();return geo.toNonIndexed();
}
// Detalhes locais das fachadas: a mesma casa em blocos, com usos e cores do bairro.
// Tudo é agregado junto ao cenário, sem acrescentar placas sobre as vilinhas.
function decorateHouse(g,theme,index){
 const accent={forest:0x638252,snow:0x668ca7,water:0x487f98,forge:0x936748,sakura:0x9a6589}[theme]||0x638252;
 block(g,[4.25,.15,.15],trim,[0,2.86,2.04]);
 for(const side of [-1,1]){
  block(g,[.28,.90,.12],accent,[side*1.92,1.7,2.12]);
  for(let j=0;j<3;j++)block(g,[.30,.035,.15],trim,[side*1.92,1.42+j*.27,2.14]);
  block(g,[.88,.17,.37],wood,[side*1.38,1.18,2.18]);
  block(g,[.72,.035,.25],0x564a34,[side*1.38,1.28,2.20]);
  for(let j=0;j<3;j++){
   const x=side*1.38+(j-1)*.23;
   block(g,[.045,.21,.045],0x507e42,[x,1.40,2.20]);
   rock(g,[.14,.10,.14],theme==='snow'?0xb6c6a1:theme==='sakura'?0xf4a6ce:j%2?0xffdf8c:0xdb9a8c,[x,1.53,2.20]);
  }
 }
 // Pequeno toldo sobre a porta, soleira e tapete; a entrada continua visível.
 block(g,[1.50,.12,.63],accent,[0,2.29,2.20]);
 for(const side of [-1,1]){const brace=block(g,[.09,.46,.09],wood,[side*.61,2.04,2.25]);brace.rotation.x=-.4;}
 block(g,[.88,.028,.48],accent,[0,.225,2.62]);
 for(const side of [-1,1])block(g,[.12,.10,.04],0xb79964,[side*.39,.98,2.075]);
 // Emblemas físicos pequenos na fachada, sem texto flutuante.
 const sign=new T.Group();sign.position.set(1.32,2.68,2.16);g.add(sign);
 block(sign,[.70,.47,.10],trim,[0,0,0]);block(sign,[.59,.36,.025],0xc5ac79,[0,0,.066]);
 if(theme==='forest'){
  const carrot=block(sign,[.13,.28,.04],0xd9903e,[0,-.01,.095]);carrot.rotation.z=-.4;
  for(const side of [-1,1]){const leaf=block(sign,[.06,.14,.035],0x537b43,[side*.05,.15,.095]);leaf.rotation.z=side*.6;}
 }else if(theme==='snow'){
  for(let i=0;i<3;i++){const ray=block(sign,[.035,.30,.03],0xe3ece8,[0,0,.095]);ray.rotation.z=i*Math.PI/3;}
 }else if(theme==='water'){
  rock(sign,[.17,.10,.04],0x4e8199,[0,0,.095]);const tail=block(sign,[.12,.13,.04],0x4e8199,[-.18,0,.095]);tail.rotation.z=Math.PI/4;
 }else if(theme==='forge'){
  block(sign,[.06,.24,.04],0x745447,[0,-.03,.095]);block(sign,[.30,.10,.04],0x596067,[0,.10,.095]);
 }else for(let i=0;i<5;i++){const a=i*Math.PI*2/5;rock(sign,[.07,.07,.03],0xad668c,[Math.sin(a)*.11,Math.cos(a)*.11,.095]);}
 // Chaminés, venezianas e pequenos objetos diferenciam as casas do mesmo bairro.
 if(theme!=='forge'&&index%2===0){block(g,[.49,1.12,.51],0x8c7965,[-1.32,4.28,-.65]);block(g,[.66,.12,.64],trim,[-1.32,4.87,-.65]);}
 if(index%3===0){
  for(let j=0;j<4;j++){const log=block(g,[.65,.19,.22],wood,[-1.40+(j%2)*.28,.41+Math.floor(j/2)*.22,2.54]);log.rotation.y=.08;}
 }else if(index%3===1){
  block(g,[.40,.47,.40],0x9b7351,[-1.65,.48,2.55]);
  for(const side of [-1,1])block(g,[.43,.055,.43],trim,[-1.65,.48+side*.15,2.55]);
 }else{
  block(g,[.42,.32,.38],0xa57856,[-1.65,.41,2.55]);
  for(let j=0;j<3;j++)rock(g,[.19,.27,.19],0x6b9250,[-1.72+j*.09,.69,2.55]);
 }
}

function house(parent,x,z,theme='forest',scale=1,y=2,yaw=0){
 const g=new T.Group();g.position.set(x,y,z);g.rotation.y=yaw;g.scale.setScalar(scale);parent.add(g);
 const roof=theme==='snow'?0xc0d7e3:theme==='water'?0x336d9e:theme==='sakura'?0x4e415f:theme==='forge'?0x5e4d49:0x9b4745;
 block(g,[4.2,3.0,3.8],0x9a6b42,[0,1.5,0]);for(const a of [-1,1])for(const b of [-1,1])block(g,[.27,3.2,.27],trim,[a*1.98,1.5,b*1.8]);
 for(let i=0;i<6;i++)block(g,[4.3,.085,3.95],wood,[0,.3+i*.48,0]);
 g.add(mesh(roofGeometry(5.3,4.9,1.9),roof,[0,3.0,0]));
 for(let i=0;i<5;i++)for(const s of [-1,1]){const m=block(g,[2.95,.09,.14],theme==='snow'?0xe9f4f3:trim,[s*1.27,3.94,-2.3+i*1.1]);m.rotation.z=-s*.62;}
 block(g,[1.0,1.9,.16],0x503d32,[0,1.0,1.98]);block(g,[.12,.12,.12],gold,[.30,1.0,2.1]);
 for(const s of [-1,1]){block(g,[.94,.95,.16],trim,[s*1.38,1.7,1.99]);block(g,[.73,.74,.18],0xffcf67,[s*1.38,1.7,2.01]).material=windowGlass;block(g,[.08,.85,.22],trim,[s*1.38,1.7,2.03]);block(g,[.84,.08,.22],trim,[s*1.38,1.7,2.03]);}
 block(g,[4.6,.23,1.4],wood,[0,.09,2.4]);for(const s of [-1,1])block(g,[.16,2.8,.16],trim,[s*2.2,1.45,3]);
 if(theme==='snow'){block(g,[4.6,.16,1.4],0xeef7f4,[0,.24,2.4]);for(let i=0;i<6;i++)cone(g,.10,.48,0xc8eaf4,[-2+i*.8,3.1,2.6]);}
 if(theme==='forge'){block(g,[.80,3.2,.85],0x6b6260,[1.0,4.5,-.8]);for(let i=0;i<4;i++)rock(g,[.6+i*.2,.5+i*.1,.6+i*.2],0x9c9ea2,[1.0+i*.2,6.4+i*.6,-.8]);}
 decorateHouse(g,theme,homes.length);homes.push({x,z,theme,scale,y,yaw});
 obstacles.push({x,z,r:2.35*scale});return g;
}
function stall(x,z,color,title){
 const g=new T.Group();g.position.set(x,2,z);staticRoot.add(g);block(g,[3.6,1.1,1.6],wood,[0,.55,0]);
 for(const s of [-1,1])block(g,[.17,3.1,.17],trim,[s*1.7,1.55,0]);
 for(let i=0;i<6;i++){const awning=block(g,[.63,.16,2.6],i%2?0xffedc7:color,[-1.57+i*.63,3.05,.1]);awning.rotation.x=.15;}
 for(let i=0;i<9;i++)rock(g,[.19,.17,.20],i%3?0xffae3c:0x82b74a,[-1.2+(i%5)*.57,1.25,Math.floor(i/5)*.38]);
 label(title,S,x,5.7,z,4.3);obstacles.push({x,z,r:2});
}
// Ilha central, cinco bairros e acesso ao mercado.
for(const island of islands){
 const top=island.theme==='snow'?0xe8f3ef:island.theme==='forge'?0x858074:grass;
 cylinder(staticRoot,island.r,island.r*.85,8,stone,[island.x,-2,island.z],12);
 if(island.court){
  // O gramado contorna o piso, sem uma segunda superfície logo abaixo dele.
  // Isso evita cintilação com a projeção em pixels usada nas fases.
  staticRoot.add(mesh(new T.CylinderGeometry(island.r,island.r,.30,12,1,true),top,[island.x,1.945,island.z]));
  const rim=mesh(new T.RingGeometry(island.r*.67,island.r,12),top,[island.x,2.095,island.z]);rim.rotation.x=-Math.PI/2;staticRoot.add(rim);
 }else cylinder(staticRoot,island.r,island.r,.30,top,[island.x,1.91,island.z],12);
 cylinder(staticRoot,island.r*.67,island.r*.67,.075,path,[island.x,2.09,island.z],12);
 for(let j=0;j<13;j++){const a=j/13*Math.PI*2,r=island.r*.94;rock(staticRoot,[1.2,2.2,1.4],j%2?0x848e91:0x687884,[island.x+Math.cos(a)*r,-1.6,island.z+Math.sin(a)*r]);}
 for(let j=0;j<11;j++){const a=range(0,Math.PI*2),r=range(island.r*.78,island.r*.94);flower(staticRoot,island.x+Math.cos(a)*r,island.z+Math.sin(a)*r,island.theme==='sakura'?0xf0a3d6:j%2?0xfce484:0xffa1ae);}
}
for(const area of Campaign.areas){const len=Math.hypot(area.x,area.z),dx=area.x/len,dz=area.z/len;bridge({x:dx*16,z:dz*16},{x:area.x-dx*9.5,z:area.z-dz*9.5});}
for(const court of courts){const area=Campaign.areas[court.area-1],dx=court.x-area.x,dz=court.z-area.z,len=Math.hypot(dx,dz);bridge({x:area.x+dx/len*9.5,z:area.z+dz/len*9.5},{x:court.x-dx/len*5,z:court.z-dz/len*5},2.7);}
bridge({x:-10,z:13.5},{x:-15,z:20});bridge({x:0,z:16},{x:0,z:24},4.2);bridge({x:0,z:34},{x:0,z:44},4.2);
// Água, correntes e cataratas entre as ilhas.
const water=new T.Mesh(new T.PlaneGeometry(600,600),new T.MeshBasicMaterial({color:0x3f90b2}));water.position.set(0,-5.4,0);water.rotation.x=-Math.PI/2;S.add(water);
for(let j=0;j<90;j++)block(staticRoot,[range(.8,2.7),.035,.09],0x8bd9e3,[range(-70,70),-5.3,range(-55,65)]);
for(const [x,z,w] of [[-39,19.5,2.7],[-30,18.9,2.1],[-34,-13.4,2.0],[31,-17.6,2.6],[26,46,1.7],[10,9.2,1.2]]){
 block(staticRoot,[w,7,.20],0x84e2ef,[x,-1.6,z]);block(staticRoot,[w*.55,7,.23],0xd0f5f2,[x+.1,-1.6,z]);
 for(let i=0;i<5;i++){const foam=block(S,[w*.8,.08,.26],0xe5ffff,[x,2-i*1.4,z+.15]);waterfalls.push({mesh:foam,base:i*1.4});}
 rock(staticRoot,[w*.8,.15,.9],0xc4edf0,[x,-5.19,z]);
}
// Estátua central do coelho, jardins, bancos e caminhos de pedra.
cylinder(staticRoot,3.0,3.3,.60,0x9f906b,[0,2.4,0],12);cylinder(staticRoot,2.5,2.8,.50,0xb9a778,[0,2.95,0],10);
const statue=new T.Group();statue.position.set(0,3.2,0);staticRoot.add(statue);
rock(statue,[1.35,1.6,.95],0xcfab63,[0,1.6,0]);block(statue,[2.1,1.8,1.55],0xe0bc73,[0,3.1,0]);block(statue,[1.65,.60,.55],0xe9cc8d,[0,2.85,.85]);
for(const s of [-1,1]){const e=block(statue,[.48,2.4,.45],0xe0bc73,[s*.55,5.1,0]);e.rotation.z=-s*.12;block(statue,[.20,1.83,.07],0xa77e49,[s*.55,5.1,.26]);block(statue,[.15,.24,.06],0x5b4b36,[s*.45,3.2,.81]);rock(statue,[.5,.65,.5],0xe0bc73,[s*1.1,1.6,.3]);block(statue,[.65,.45,.9],0xd8b36c,[s*.56,.25,.3]);}
block(statue,[.20,.16,.12],0x9a7245,[0,2.93,1.16]);label('PRAÇA DO COELHO',S,0,3.0,3.4,5.4);
obstacles.push({x:0,z:0,r:3.4});
for(let i=0;i<24;i++){const a=i/24*Math.PI*2;flower(staticRoot,Math.sin(a)*3.7,Math.cos(a)*3.7,i%2?0xff97c2:0xffeb93,2.2);}
for(const s of [-1,1])for(const z of [-9,9]){block(staticRoot,[3.1,.16,.65],wood,[s*9,2.7,z]);block(staticRoot,[3.1,.60,.13],wood,[s*9,3.1,z-.28]);for(const x of [-1,1])block(staticRoot,[.15,.65,.45],trim,[s*9+x,2.36,z]);}
for(const [x,z] of [[-12,-9],[12,-9],[-12,10],[12,10],[-3,25],[3,25],[-3,35],[3,35],[-14,24],[-24,22]])lamp(staticRoot,x,z);
for(let i=0;i<25;i++)block(staticRoot,[.65,.045,.85],i%3?0xcdb88e:0xe0cba4,[(i%3-1)*1.05,2.12,5+Math.floor(i/3)*3.4]);
// Mercado: toldos, casinhas e uma praça de convívio.
stall(-24,25,0x4b8fcd,'Frutas do Cais');stall(-18,24,0xd65e55,'Quitutes da Vila');house(staticRoot,-24,31,'forest',.72);tree(staticRoot,-28,29,1.2);tree(staticRoot,-18,34,1.0);
label('MERCADO DA VILA',S,-20,7.3,25,8.0);
// Portais: três menores e o arco do chefe em cada bairro.
function portal(area,slot,lx,lz){
 const g=new T.Group();g.position.set(area.x+lx,2.18,area.z+lz);staticRoot.add(g);
 const boss=slot.boss,w=boss?1.10:.75,h=boss?2.70:1.95;
 block(g,[w*2+.48,.18,1.3],0xa79a7c,[0,.05,.1]);
 const frameColors=area.theme==='forest'?[0x916239,0xb58a4c]:area.theme==='snow'?[0x88a8b9,0xc4d9e0]:area.theme==='forge'?[0x645c58,0x887265]:area.theme==='sakura'?[0x65475c,0x987171]:[0x768e98,0x9cabb1];
 for(const s of [-1,1])for(let i=0;i<4;i++)block(g,[.31,h/4+.025,.44],frameColors[i%2],[s*(w+.12),h/8+i*h/4,0],s*.03);
 for(let i=0;i<7;i++){const a=i/6*Math.PI,xx=Math.cos(a)*(w+.12),yy=h+Math.sin(a)*w*.75;const m=block(g,[.43,.36,.46],frameColors[i%2],[xx,yy,0]);m.rotation.z=a-Math.PI/2;}
 for(const s of [-1,1]){block(g,[.17,.30,.17],gold,[s*(w+.42),.29,.4]);block(g,[.10,.30,.10],0xffce58,[s*(w+.42),.59,.4]);}
 const shape=new T.Shape();shape.moveTo(-w,.1);shape.lineTo(w,.1);shape.lineTo(w,h);for(let i=0;i<=12;i++){const a=i/12*Math.PI;shape.lineTo(Math.cos(a)*w,h+Math.sin(a)*w*.76);}shape.lineTo(-w,.1);
 const textureCanvas=document.createElement('canvas');textureCanvas.width=128;textureCanvas.height=256;const tc=textureCanvas.getContext('2d'),gradient=tc.createRadialGradient(64,150,6,64,130,150);
 gradient.addColorStop(0,'#ffffff');gradient.addColorStop(.45,'#b9ffff');gradient.addColorStop(1,'#376a97');tc.fillStyle=gradient;tc.fillRect(0,0,128,256);tc.lineWidth=2;tc.strokeStyle='#e9ffff';
 for(let i=0;i<7;i++){tc.beginPath();tc.ellipse(64,140,11+i*7,20+i*15,i*.14,0,Math.PI*1.65);tc.stroke();}
 const material=new T.MeshBasicMaterial({map:new T.CanvasTexture(textureCanvas),color:area.color,transparent:true,opacity:.66,side:T.DoubleSide,depthWrite:false});portalMaterials.push(material);
 const portalGeometry=new T.ShapeGeometry(shape),uv=portalGeometry.getAttribute('uv'),positions=portalGeometry.getAttribute('position');for(let i=0;i<uv.count;i++)uv.setXY(i,(positions.getX(i)+w)/(2*w),positions.getY(i)/(h+w*.76));uv.needsUpdate=true;
 const surface=new T.Mesh(portalGeometry,material);surface.position.set(area.x+lx,2.25,area.z+lz+.04);S.add(surface);
 const rings=new T.Group();rings.position.copy(surface.position).add(new T.Vector3(0,h*.68,.09));S.add(rings);
 for(let i=0;i<2;i++){const r=new T.Mesh(new T.TorusGeometry(w*(.48+i*.20),.025,3,14,Math.PI*1.6),new T.MeshBasicMaterial({color:0xd2ffff,transparent:true,opacity:.70,depthWrite:false}));r.scale.y=1.45;rings.add(r);}
 const emblem=block(g,[.27,.27,.10],boss?gold:area.color,[0,h+w*.85,.29]);emblem.rotation.z=Math.PI/4;
 const name=label(boss?'CHEFE':String(slot.index),S,area.x+lx,2+h+w*.85+.70,area.z+lz,boss?2.0:1.0);
 const lock=block(S,[.30,.29,.15],0xb8a994,[area.x+lx,2.18+h*.68,.24+area.z+lz]);
 const p={id:slot.id,area,slot,x:area.x+lx,z:area.z+lz,surface,rings,material,lock,label:name,frame:g};portals.push(p);
}
for(const area of Campaign.areas){
 const g=new T.Group();staticRoot.add(g);const theme=area.theme;
 label(area.id+' · '+area.name,S,area.x,10.8,area.z-7,11,'#fff3c8');
 // Clareira lateral: arcos menores deixam as casas e o centro da vilinha livres.
 const court=courts[area.id-1];
 [[-3.9,-1.4],[-1.3,-2.3],[1.35,-2.1],[4.15,-.8]].forEach(([x,z],i)=>portal(area,Campaign.slots[(area.id-1)*4+i],court.x-area.x+x,court.z-area.z+z));
 for(const s of [-1,1]){house(g,area.x+(theme==='sakura'&&s===-1?-9:s*6.8),area.z+(theme==='sakura'&&s===-1?-5:-7.0),theme,.70,theme==='snow'?3.6:2,s*.15);tree(g,area.x+s*10,area.z-5,.85,theme);lamp(g,area.x+s*9,area.z+4);}
 fence(g,area.x-8,area.z+7.5,area.x-4.5,area.z+7.5);fence(g,area.x+4.5,area.z+7.5,area.x+8,area.z+7.5);
 if(theme==='forest'){
  tree(g,area.x-3,area.z-8,1.9);block(g,[7,.22,4],wood,[area.x-3,7.1,area.z-8]);house(g,area.x-3,area.z-8,'forest',.65,7.25);
  for(let i=0;i<10;i++)block(g,[1.3,.15,.55],wood,[area.x-8,2.2+i*.5,area.z-4-i*.38]);
 }else if(theme==='snow'){
  cylinder(g,8,10,2,0xc7dbe1,[area.x,2.4,area.z-7],8);house(g,area.x,area.z-9,'snow',.9,3.6);
  for(let i=0;i<6;i++)block(g,[3.2,.28,.6],0xe3eded,[area.x,2.2+i*.23,area.z-4-i*.45]);
 }else if(theme==='water'){
  const wh=new T.Group();wh.position.set(area.x-10,0,area.z);S.add(wh);wheels.push(wh);
  wh.rotation.y=Math.PI/2;const rim=new T.Mesh(new T.TorusGeometry(2,.19,4,12),mat(wood));wh.add(rim);
  for(let i=0;i<8;i++){const a=i/8*Math.PI*2;const spoke=block(wh,[.13,4,.13],wood,[0,0,0]);spoke.rotation.z=a;const paddle=block(wh,[.7,.45,1.0],wood,[Math.cos(a)*2,Math.sin(a)*2,0]);paddle.rotation.z=a;}
  for(let i=0;i<5;i++)block(g,[3.7,.16,.7],wood,[area.x-4,2.2,area.z+5+i*.8]);
 }else if(theme==='forge'){
  for(const s of [-1,1]){block(g,[.35,7,.35],trim,[area.x+s*8,5.5,area.z-6]);const beam=block(g,[7,.28,.35],wood,[area.x+s*5.7,8.6,area.z-6]);beam.rotation.z=s*.13;block(g,[.09,3,.09],0x554a46,[area.x+s*3.2,7.0,area.z-6]);}
  for(let i=0;i<5;i++)block(g,[.8,.8,.8],i%2?0x6d6461:wood,[area.x-8+i*.65,2.6,area.z+5]);
 }else{
  for(const s of [-1,1])tree(g,area.x+s*8,area.z+5,1.25,'sakura');
  for(const [x,z] of [[-5,7],[-1,9],[5,8]]){rock(g,[1.0,.08,.65],0x82b777,[area.x+x,-5.15,area.z+z]);flower(g,area.x+x,area.z+z,0xffb0dd,-5.05);}
 }
}
// Detalhes de vila nos limites dos bairros: quintais, casas, folhagem e calçamento.
for(const island of islands){
 for(let j=0;j<65;j++){const a=range(0,Math.PI*2),r=range(.8,island.r*.62),x=island.x+Math.cos(a)*r,z=island.z+Math.sin(a)*r;block(staticRoot,[range(.32,.70),.055,range(.38,.66)],j%3?0xc0b198:0x9f998c,[x,2.15,z],range(-.15,.15));}
 for(let j=0;j<15;j++){const a=j/15*Math.PI*2,r=island.r*.89,x=island.x+Math.cos(a)*r,z=island.z+Math.sin(a)*r;
  rock(staticRoot,[.65,.48,.63],island.theme==='snow'?0xd6e8e5:island.theme==='forge'?0x696b64:j%2?0x498047:0x6c9d49,[x,2.25,z]);
  if(j%2)for(let k=0;k<3;k++)flower(staticRoot,x+range(-.5,.5),z+range(-.5,.5),k%2?0xf2a1c8:0xffe994,2.35);
 }
}
for(const area of Campaign.areas){
 for(const s of [-1,1]){
  const outward=s===Math.sign(courts[area.id-1].x-area.x);
  house(staticRoot,area.x+s*(outward?6.6:8.7),area.z+(outward?7:2.6),area.theme,.58,2,-s*.90);
  for(const dz of [-9,6])tree(staticRoot,area.x+s*(dz===6?9.4:8.4),area.z+dz,area.theme==='forest'?1.15:.85,area.theme);
  fence(staticRoot,area.x+s*9.5,area.z+4.5,area.x+s*7.3,area.z+7.5);
 }
 if(area.theme==='forest')for(const [x,z] of [[-4,-10],[3,-9],[0,8]])tree(staticRoot,area.x+x,area.z+z,1.3,'forest');
}
for(const s of [-1,1])tree(staticRoot,s*15,0,.90,'forest');
// Flâmulas sobre o mercado e um pequeno barco junto ao cais.
for(const x of [-26,-14])block(staticRoot,[.18,4.6,.18],trim,[x,4.3,21]);
block(staticRoot,[12,.07,.07],wood,[-20,6.5,21]);for(let i=0;i<13;i++){const pennant=new T.Mesh(new T.ConeGeometry(.25,.55,3),mat([0xc85b52,0xe8bd61,0x52899c][i%3]));pennant.rotation.z=Math.PI;pennant.position.set(-25.5+i*.9,6.15-Math.sin(i/12*Math.PI)*.35,21);staticRoot.add(pennant);}
const boat=new T.Group();boat.position.set(-43,-5.0,23);boat.rotation.y=.35;staticRoot.add(boat);block(boat,[2.0,.45,4.0],wood,[0,0,0]);for(const s of [-1,1])block(boat,[.18,.6,4.2],trim,[s*.95,.2,0]);for(const z of [-1,1])block(boat,[2.0,.16,.45],0xb88752,[0,.4,z]);
// Montanhas assentadas na água; as capas de neve acompanham o mesmo perfil.
for(let i=0;i<15;i++){const x=-105+i*15,z=-148-(i%3)*10,h=range(17,29),r=range(12,20);cone(staticRoot,r,h,i%2?0x718c9a:0x91a7b3,[x,h/2-6,z]);cone(staticRoot,r*8/h,8,0xeaf1ee,[x,h-10,z]);}
// Personagens do jogo, reutilizados sem modificar seus modelos.
const P = new T.Group(), body = new T.Group();
P.add(body);
body.rotation.y = Math.PI;
S.add(P);
const bun = new T.Group();
bun.scale.setScalar(.8);
body.add(bun);
const bx = (w, h, d, c, x, y, z, rz, par) => { const m = mesh(B(w, h, d), c, [x, y, z]); if (rz)
    m.rotation.z = rz; (par || bun).add(m); return m; };
const PU = 0x7a2fe0, PD2 = 0x4f1fa8, WH = 0xf4f4f8, BK = 0x1a1a22, PK = 0xff7aa8;
const mk = (x, y, z) => { const g = new T.Group(); g.position.set(x, y, z); bun.add(g); return g; }, legs = [], arms = [], ears = [];
for (const s of [-1, 1]) {
    const lg = mk(s * .22, .78, 0);
    bx(.42, .12, .64, BK, 0, -.72, .08, 0, lg);
    bx(.4, .2, .58, WH, 0, -.56, .08, 0, lg);
    bx(.3, .45, .3, PD2, 0, -.23, 0, 0, lg);
    legs.push(lg);
    const am = mk(s * .47, 1.28, 0);
    bx(.2, .4, .24, BK, 0, -.23, 0, 0, am);
    bx(.26, .26, .26, WH, s * .07, -.52, .04, 0, am);
    arms.push(am);
    const ear = mk(s * .26, 2.15, 0);
    ear.rotation.z = -s * .1;
    bx(.26, .85, .16, PU, 0, .43, 0, 0, ear);
    bx(.13, .62, .04, PK, 0, .41, .09, 0, ear);
    ears.push(ear);
    bx(.15, .22, .03, BK, s * .2, 1.76, .465);
    bx(.06, .07, .03, WH, s * .2 + .02, 1.82, .485);
    bx(.1, .06, .03, PK, s * .31, 1.58, .465);
}
bx(.74, .62, .44, BK, 0, 1.02, 0);
bx(.26, .6, .02, WH, 0, 1.02, .23);
bx(.7, .18, .42, PD2, 0, .68, 0);
bx(.98, .88, .88, PU, 0, 1.78, 0);
bx(.74, .52, .04, WH, 0, 1.68, .44);
bx(.12, .09, .06, PK, 0, 1.62, .47);
bx(.16, .03, .03, BK, 0, 1.52, .46);
const tail = mk(0, .78, -.3);
bx(.22, .22, .22, WH, 0, 0, 0, 0, tail);
const swoosh = new T.Mesh(new T.RingGeometry(1, 1.7, 28), new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: .45, side: T.DoubleSide }));
swoosh.rotation.x = -Math.PI / 2;
swoosh.visible = false;
S.add(swoosh);

function mkCitizen(opts) {
    const g = new T.Group(), core = new T.Group();
    g.add(core);
    const a = (w, h, d, c, x, y, z, p = core) => { const m = mesh(B(w, h, d), c, [x, y, z]); p.add(m); return m; };
    const fur = opts.fur, face = opts.face, tip = opts.tip || fur, dark = opts.dark || 0x2b2020;
    const legs = [], arms = [];
    for (const sd of [-1, 1]) {
        const leg = new T.Group();
        leg.position.set(sd * .22, .75, 0);
        core.add(leg);
        a(.27, .5, .29, opts.pants || 0x424253, 0, -.27, 0, leg);
        a(.35, .18, .47, opts.boot || 0x58402f, 0, -.58, .08, leg);
        legs.push(leg);
        const arm = new T.Group();
        arm.position.set(sd * .45, 1.5, 0);
        core.add(arm);
        a(.23, .55, .27, fur, 0, -.26, 0, arm);
        a(.25, .18, .29, face, 0, -.57, .03, arm);
        arms.push(arm);
    }
    a(.81, .8, .5, opts.shirt || fur, 0, 1.15, 0);
    a(.56, .4, .055, face, 0, 1.26, .28);
    const head = new T.Group();
    head.position.set(0, 2.04, 0);
    core.add(head);
    a(.83, .67, .64, fur, 0, 0, 0, head);
    a(.63, .28, .18, face, 0, -.18, .36, head);
    for (const sd of [-1, 1]) {
        a(.135, .18, .07, 0xffffff, sd * .22, .06, .338, head);
        a(.075, .13, .045, dark, sd * .22, .045, .38, head);
        a(.25, opts.kind === 'deer' ? .7 : .39, .17, tip, sd * .3, .51, 0, head);
        if (opts.kind === 'cat')
            a(.14, .13, .05, face, sd * .3, .54, .10, head);
    }
    a(.12, .10, .085, dark, 0, -.18, .49, head);
    if (opts.kind === 'deer')
        for (const sd of [-1, 1]) {
            a(.06, .5, .08, 0x805227, sd * .24, .91, 0, head);
            a(.3, .07, .07, 0x805227, sd * .37, 1.03, 0, head);
        }
    if (opts.kind === 'raccoon') {
        for (const sd of [-1, 1])
            a(.28, .18, .035, 0x4c4b54, sd * .2, .07, .355, head);
    }
    if (opts.kind === 'hedgehog') {
        for (let i = -2; i <= 2; i++)
            a(.19, .32, .26, 0x76513a, i * .17, .36, -.27, head);
    }
    if (opts.kind === 'dog')
        a(.14, .3, .21, tip, -.5, .11, 0, head);
    const tail = new T.Group();
    tail.position.set(0, .87, -.35);
    core.add(tail);
    if (opts.kind === 'squirrel' || opts.kind === 'fox') {
        a(.43, .8, .44, fur, 0, .17, -.3, tail);
        a(.36, .36, .4, tip, 0, .53, -.47, tail);
    }
    else if (opts.kind === 'raccoon') {
        a(.35, .48, .35, fur, 0, -.06, -.29, tail);
        a(.36, .15, .36, dark, 0, -.2, -.31, tail);
    }
    else
        a(.27, .27, .38, tip, 0, .03, -.22, tail);
    if (opts.accessory === 'scarf') {
        a(.85, .17, .62, opts.accent, 0, 1.7, 0);
        a(.2, .5, .08, opts.accent, .25, 1.46, .31);
    }
    if (opts.accessory === 'vest')
        a(.86, .64, .54, opts.accent, 0, 1.22, 0);
    if (opts.accessory === 'bag') {
        a(.4, .42, .2, opts.accent, .42, 1.03, .24);
    }
    g.scale.setScalar(opts.scale || .9);
    g.userData = { ...opts, legs, arms, head, tail, core };
    return g;
}

const CITIZENS = [
    { name: 'Nina', kind: 'squirrel', fur: 0xc77930, face: 0xf9e2bb, tip: 0xf9edc9, shirt: 0x68a85b, pants: 0x66533e, accent: 0xecc563, accessory: 'scarf', z: -33, x: -1.8,
        lines: ['Eu só queria juntar nozes em paz, mas os besouros estão empurrando... aquilo!', 'O Bunnyldu passou por aqui! Acho que ele seguiu para o fim do bosque.'] },
    { name: 'Rufus', kind: 'raccoon', fur: 0x827c87, face: 0xe6ded7, tip: 0x56515b, shirt: 0x447d9b, pants: 0x364354, accent: 0xe3a840, accessory: 'bag', z: -78, x: 1.6,
        lines: ['Meu expediente? Catar objetos brilhantes! É uma carreira honesta.', 'Ouvi dizer que os lagartos precisam de dois golpes para cair. Não subestime eles!'] },
    { name: 'Luna', kind: 'cat', fur: 0xc3a5da, face: 0xf8e4ee, tip: 0x8b6bb2, shirt: 0x74438c, pants: 0x55416a, accent: 0xfa92cf, accessory: 'scarf', z: -121, x: -1.8,
        lines: ['Eu venho aqui ver o pôr do sol. Só não gosto das bolas de cocô!', 'Viu o coelhão preto? Passou correndo em direção ao bosque profundo.'] },
    { name: 'Otto', kind: 'deer', fur: 0xa26f46, face: 0xf0cfa3, tip: 0xb48d65, shirt: 0x6a8c4d, pants: 0x695039, accent: 0xd6bb72, accessory: 'vest', z: -166, x: 1.5, scale: .98,
        lines: ['Cuido das trilhas desde pequeno. Agora aparecem buracos da noite pro dia!', 'É melhor pegar impulso antes dos vãos grandes. Segure K e depois pule!'] },
    { name: 'Pip', kind: 'hedgehog', fur: 0xa68557, face: 0xf0d4a6, tip: 0x77533f, shirt: 0xc65750, pants: 0x71533e, accent: 0x5d6938, accessory: 'bag', z: -200, x: -1.7, scale: .77,
        lines: ['Eu vendo cogumelos... quer dizer, eu estudo cogumelos. Muito diferente!', 'Bibibunn anda recrutando criaturas estranhas. Melhor ficar esperto.'] },
    { name: 'Max', kind: 'dog', fur: 0xd6b47d, face: 0xf4e4c7, tip: 0x845c3d, shirt: 0x499eac, pants: 0x555870, accent: 0xb65c3a, accessory: 'scarf', z: -239, x: 1.6,
        lines: ['Eu faço minha corrida da manhã todos os dias. Aposto que ganho de você!', 'Os besouros saíram das árvores. Nem quero imaginar o cheiro!'] },
    { name: 'Fiona', kind: 'fox', fur: 0xe76f32, face: 0xffe4c0, tip: 0xf5e2bd, shirt: 0x7e76c2, pants: 0x664655, accent: 0xf4bc6c, accessory: 'vest', z: -285, x: -1.75,
        lines: ['Meu primo Vixxo vive dando conselhos. Pelo menos desta vez ele acertou.', 'Vi um coelho enorme perto do final do bosque. Parecia preocupado.'] },
    { name: 'Bento', kind: 'raccoon', fur: 0x626b73, face: 0xd7dce0, tip: 0x434751, shirt: 0x6f9a6c, pants: 0x4d474b, accent: 0xe5b35d, accessory: 'bag', z: -329, x: 1.55,
        lines: ['Minha rotina é dormir, comer e fugir dos lagartos. Vida emocionante!', 'Bunnyldu deve estar logo adiante. Você já está chegando!'] },
    { name: 'Mel', kind: 'cat', fur: 0xebcba0, face: 0xffede0, tip: 0xb88b69, shirt: 0xd17c9f, pants: 0x725f71, accent: 0x6e4d7d, accessory: 'scarf', z: -356, x: -1.5,
        lines: ['A Bibibunn? Não confio naquela rockeira nem por um segundo.', 'O grandalhão está no fim do bosque. Tomara que esteja bem.'] }
];

P.position.set(0,worldY,24);body.rotation.y=Math.PI;
const shade=mesh(new T.CircleGeometry(.61,12),0x677c48,[0,worldY+.15,24]);shade.rotation.x=-Math.PI/2;S.add(shade);
const residents=[
 {name:'Lia',kind:'fox',fur:0xd58b45,face:0xffe9bc,shirt:0x5d8e7d,x:-5,z:7,lines:['Bem-vindo à Vila dos Animais! Os cinco bairros partem desta praça.','Siga a ponte até o Bosque das Copas. O primeiro portal está aceso.']},
 {name:'Tito',kind:'raccoon',fur:0x93959a,face:0xf0e8d7,shirt:0x736197,x:5,z:7,lines:['Cada bairro guarda três caminhos e um desafio de chefe.','Ao terminar uma fase, volte para a vila. O próximo portal ficará livre.']},
 {name:'Amora',kind:'squirrel',fur:0xb26e46,face:0xf6d4b2,shirt:0x9474ad,x:-20,z:29,lines:['O mercado está cheio hoje! Veja as barracas de frutas e quitutes.','Ainda estou arrumando a loja. Enquanto isso, fique à vontade para passear.']},
 {name:'Bento',kind:'raccoon',fur:0x66676c,face:0xf0e7d0,shirt:0x6d9d7b,x:-24,z:26.7,lines:['Fruta doce, direto do cais!','Ouvi dizer que o rio da floresta precisa de ajuda...']},
 {name:'Mel',kind:'cat',fur:0xe6bd83,face:0xf6e6cb,shirt:0xb56866,x:-18,z:25.7,lines:['Cheirinho de pão quentinho!','Por enquanto estou preparando a abertura da loja.']},
 {name:'Nina',kind:'squirrel',fur:0xb9804b,face:0xffe9b9,shirt:0x699d62,x:-31,z:-19,lines:['As casas nas copas são ligadas por passarelas.','Bosque Verde e Selva de Pinheiros são os primeiros caminhos desta área.']},
 {name:'Pip',kind:'deer',fur:0xb19170,face:0xf7e9cd,shirt:0x567b9a,x:24,z:-23,lines:['As trilhas geladas ainda estão sendo preparadas.','Depois do chefe do bosque, os portais deste bairro poderão ser liberados.']},
 {name:'Otto',kind:'dog',fur:0x968c7b,face:0xf0e5d6,shirt:0x427d98,x:-32,z:14,lines:['A roda do moinho nunca para!','Aqui os caminhos passam pelas cascatas e pelos cais.']},
 {name:'Brasa',kind:'fox',fur:0xb77a4e,face:0xf5dbb5,shirt:0xa46947,x:31,z:11,lines:['Bem-vindo ao distrito das forjas. Cuidado com as ferramentas!','Estamos preparando novos desafios para os portais daqui.']},
 {name:'Yumi',kind:'cat',fur:0xe9d6d5,face:0xfff1e3,shirt:0xa263a9,x:23,z:40,lines:['As lanternas deixam o jardim bonito mesmo de dia.','Os novos caminhos daqui ainda estão em preparação.']},
 {name:'Rui',kind:'fox',fur:0xb98657,face:0xf3dfbf,shirt:0x688d9d,x:6,z:-6,walk:true,lines:['Uma volta na praça sempre faz bem.']},
 {name:'Luna',kind:'cat',fur:0xc8b9a6,face:0xf6ece2,shirt:0x8d6c9e,x:-6,z:-6,walk:true,lines:['Eu gosto de conversar perto da estátua.']}
];
for(const [i,d] of residents.entries()){
 const original=CITIZENS.find(c=>c.name===d.name),appearance=original||{...d,scale:.79,tip:d.kind==='fox'?0xf7e5ce:d.fur,dark:0x302c34};
 const n=mkCitizen({...appearance,x:d.x,z:d.z,lines:d.lines});n.position.set(d.x,2.1,d.z);n.rotation.y=i%2?.6:-.7;S.add(n);
 // Moradores parados usam uma malha por cor; passantes mantêm articulações.
 prepareCitizen(n);
 npcs.push({model:n,data:d,phase:i*1.7});
 if(i<2||i===3||i===4){const bubble=label(i===0?'Olá!':i===1?'Vamos passear?':i===3?'Frutas fresquinhas!':'Pão quentinho!',S,d.x,5.0,d.z,4.0,'#4a3540','#ffedbd');bubbles.push({sprite:bubble,phase:i,model:n});}
}
// Os cinco irmãos partem do mesmo gato em blocos usado pelos moradores das fases.
for(const spec of MEOWLIN){
 const court=courts[spec.area-1],d={name:spec.name,guardianArea:spec.area,robe:spec.robe,x:court.x-.4,z:court.z+2.2,
  lines:['Sou '+spec.name+'. Eu e meus quatro irmãos guardamos os portais da vila. Escolha um destino; vou confirmar com você antes da viagem.']};
 const n=mkCitizen({name:spec.name,kind:'cat',fur:0xb7aaa1,face:0xf3e9dc,tip:0x86766e,shirt:spec.robe,pants:0x3b3541,dark:0x302731,scale:.84});
 const core=n.userData.core,head=n.userData.head;
 const robe=mesh(new T.CylinderGeometry(.38,.54,.76,4,1),spec.robe,[0,1.00,0]);robe.rotation.y=Math.PI/4;core.add(robe);
 block(core,[.83,.09,.57],0xd9b56c,[0,.65,0]);block(core,[.14,.44,.05],0xe3c17a,[0,1.26,.31]);
 const brim=mesh(new T.CylinderGeometry(.59,.59,.09,6),spec.robe,[0,.40,0]);head.add(brim);
 // As orelhas despontam ao lado do chapéu, preservando a leitura de gato.
 for(const s of [-1,1]){block(head,[.20,.39,.15],0xb7aaa1,[s*.49,.51,.06]);block(head,[.10,.24,.025],0xd899a8,[s*.49,.53,.15]);}
 const hat=mesh(new T.ConeGeometry(.47,1.02,4),spec.robe,[0,.93,-.02]);hat.rotation.z=-.10;head.add(hat);
 const band=mesh(new T.CylinderGeometry(.43,.47,.11,4),0xd9b56c,[0,.49,-.02]);band.rotation.y=Math.PI/4;head.add(band);
 block(head,[.045,.17,.025],0xf1d58a,[0,.88,.28]);block(head,[.16,.045,.025],0xf1d58a,[0,.88,.28]);
 const staff=new T.Group();staff.position.set(.16,-.30,.15);n.userData.arms[1].add(staff);block(staff,[.075,1.90,.075],wood,[0,0,0]);
 staff.add(mesh(new T.OctahedronGeometry(.18),Campaign.areas[spec.area-1].color,[0,1.02,0]));
 n.position.set(d.x,2.1,d.z);n.rotation.y=-.18;S.add(n);mergeMeshes(n);
 const npc={model:n,data:d,phase:spec.area*1.6};npcs.push(npc);guardians.push(npc);
 // O nome aparece na interface ao conversar; a silhueta do gato fica livre de placas.
}
function mergeMeshes(root){
 root.updateMatrixWorld(true);const inverse=new T.Matrix4().copy(root.matrixWorld).invert(),buckets=new Map();
 root.traverse(o=>{if(!o.isMesh)return;const geo=(o.geometry.index?o.geometry.toNonIndexed():o.geometry).clone();geo.applyMatrix4(new T.Matrix4().multiplyMatrices(inverse,o.matrixWorld));const k=o.material;if(!buckets.has(k))buckets.set(k,[]);buckets.get(k).push(geo);});
 root.clear();for(const [material,geos] of buckets){const count=geos.reduce((n,g)=>n+g.getAttribute('position').array.length,0),pos=new Float32Array(count),normal=new Float32Array(count);let offset=0;
  for(const geo of geos){pos.set(geo.getAttribute('position').array,offset);normal.set(geo.getAttribute('normal').array,offset);offset+=geo.getAttribute('position').array.length;geo.dispose();}
  const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.BufferAttribute(pos,3));geometry.setAttribute('normal',new T.BufferAttribute(normal,3));root.add(new T.Mesh(geometry,material));
 }
}
mergeMeshes(staticRoot);
// Caminhos nas ilhas e passarelas; a borda impede caminhar sobre a água.
function onGround(x,z){
 if(islands.some(i=>Math.hypot(x-i.x,z-i.z)<i.r-.65))return true;
 return bridges.some(({a,b,width})=>{const dx=b.x-a.x,dz=b.z-a.z,den=dx*dx+dz*dz,u=Math.max(0,Math.min(1,((x-a.x)*dx+(z-a.z)*dz)/den));return Math.hypot(x-a.x-u*dx,z-a.z-u*dz)<width/2-.45;});
}
function validPosition(x,z){return Number.isFinite(x)&&Number.isFinite(z)&&onGround(x,z)&&!obstacles.some(o=>Math.hypot(x-o.x,z-o.z)<o.r+.40);}
function groundHeight(x,z){const island=islands.find(i=>Math.hypot(x-i.x,z-i.z)<i.r-.65);return island?(Math.hypot(x-island.x,z-island.z)<island.r*.67?2.18:2.07):2.03;}
const spawn=save.villagePosition;if(validPosition(spawn.x,spawn.z))P.position.set(spawn.x,2,spawn.z);
const keys=new Set(),look=new T.Vector3(),cameraEye=new T.Vector3(),focus=new T.Vector3(),clock=new T.Clock();
let overview=true,nearest=null,dialogue=null,dialogIndex=0,phase=0,disposed=false,pendingPortal=null,confirmOrigin=null,entering=false;
// Oito minutos por volta. O horário começa às 9h e só avança dentro da vila.
const villageCycle=(()=>{
 const duration=480,roomClock=window.parent?.BunnyHavocVillageClock;
 let elapsed=roomClock?.read?.()||0,lastSky=-Infinity,lastCaption='',state={};
 // Hora, céu alto/horizonte, neblina, luz ambiente/chão, luz principal, intensidades, noite.
 const keys=[
  [0,0x101c38,0x41536c,0x3c536b,0xa8bce0,0x34465b,0xa5c3ff,.49,.28,1],
  [.20,0x253455,0x7e8195,0x68768c,0xbfc8e2,0x4b5469,0xc1ccf1,.54,.28,.85],
  [.25,0x886787,0xe8ac88,0xb6a4a1,0xf4d7ca,0x65697d,0xffc18c,.62,.46,.35],
  [.32,0x5a9bd3,0xe9e8cb,0xc2dae2,0xfff5e8,0x536f89,0xffecc8,.70,.72,0],
  [.65,0x5a9bd3,0xe9e8cb,0xc2dae2,0xfff5e8,0x536f89,0xffecc8,.70,.72,0],
  [.73,0x736080,0xe5a178,0xad9291,0xf1cfbe,0x5d5871,0xffb16c,.62,.48,.35],
  [.80,0x253455,0x7e8195,0x68768c,0xbfc8e2,0x4b5469,0xc1ccf1,.54,.28,.85],
  [1,0x101c38,0x41536c,0x3c536b,0xa8bce0,0x34465b,0xa5c3ff,.49,.28,1]
 ];
 const colors=Array.from({length:6},()=>new T.Color()),keyColors=keys.map(k=>k.slice(1,7).map(c=>new T.Color(c))),waterDay=new T.Color(0x3f90b2),waterNight=new T.Color(0x25455f);
 const starPositions=Array.from({length:65},(_,i)=>({x:(i*73+19)%256,y:(i*43+7)%145,size:i%9===0?2:1}));
 const glowCanvas=document.createElement('canvas');glowCanvas.width=glowCanvas.height=64;
 const ctx=glowCanvas.getContext('2d'),gradient=ctx.createRadialGradient(32,32,2,32,32,31);
 gradient.addColorStop(0,'rgba(255,188,87,.65)');gradient.addColorStop(.45,'rgba(255,173,65,.3)');gradient.addColorStop(1,'rgba(255,173,65,0)');ctx.fillStyle=gradient;ctx.fillRect(0,0,64,64);
 const glowMaterial=new T.MeshBasicMaterial({map:new T.CanvasTexture(glowCanvas),transparent:true,opacity:0,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1});
 const poolGeometry=new T.PlaneGeometry(4.8,4.8),pools=new T.InstancedMesh(poolGeometry,glowMaterial,lanternSpots.length),poolMatrix=new T.Matrix4();
 for(const [i,spot] of lanternSpots.entries()){poolMatrix.makeRotationX(-Math.PI/2);poolMatrix.setPosition(spot);pools.setMatrixAt(i,poolMatrix);}
 pools.frustumCulled=false;S.add(pools);
 function disk(x,y,r,color){skyCtx.fillStyle=color;skyCtx.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4;const px=x+Math.cos(a)*r,py=y+Math.sin(a)*r;i?skyCtx.lineTo(px,py):skyCtx.moveTo(px,py);}skyCtx.closePath();skyCtx.fill();}
 function paintSky(time,night){
  const g=skyCtx.createLinearGradient(0,0,0,256);g.addColorStop(0,'#'+colors[0].getHexString());g.addColorStop(1,'#'+colors[1].getHexString());skyCtx.fillStyle=g;skyCtx.fillRect(0,0,256,256);
  if(night>.25){skyCtx.globalAlpha=(night-.25)/.75;skyCtx.fillStyle='#dbe5ff';for(const s of starPositions)skyCtx.fillRect(s.x,s.y,s.size,s.size);skyCtx.globalAlpha=1;}
  const day=time>=.25&&time<.75,u=day?(time-.25)/.5:((time+.25)%1)/.5;
  disk(22+u*212,139-Math.sin(u*Math.PI)*105,day?8:6,day?'#ffe9a1':'#dbe6f8');
  S.background.needsUpdate=true;
 }
 function update(dt){
  if(!document.hidden){elapsed=roomClock?.advance?.(dt)??elapsed+Math.max(0,dt);}
  const time=(.375+elapsed/duration)%1;
  let i=0;while(i<keys.length-2&&time>keys[i+1][0])i++;
  const a=keys[i],b=keys[i+1],linear=(time-a[0])/(b[0]-a[0]),u=linear*linear*(3-2*linear);
  for(let c=0;c<6;c++)colors[c].copy(keyColors[i][c]).lerp(keyColors[i+1][c],u);
  const night=T.MathUtils.lerp(a[9],b[9],u);
  hemisphere.color.copy(colors[3]);hemisphere.groundColor.copy(colors[4]);hemisphere.intensity=T.MathUtils.lerp(a[7],b[7],u);
  sun.color.copy(colors[5]);sun.intensity=T.MathUtils.lerp(a[8],b[8],u);
  // Trajetória contínua, inclusive na troca entre o sol e a luz azul da noite.
  sun.position.set(Math.cos(time*Math.PI*2)*65,60+Math.sin(time*Math.PI*2)*12,35);
  S.fog.color.copy(colors[2]);water.material.color.copy(waterDay).lerp(waterNight,night);
  lanternGlass.emissiveIntensity=.08+night*1.1;windowGlass.emissiveIntensity=.06+night*.95;
  glowMaterial.opacity=night*.72;pools.visible=night>.03;
  const caption=time<.22||time>=.80?'☾ Noite':time<.32?'☀ Amanhecer':time<.50?'☀ Manhã':time<.69?'☀ Tarde':time<.80?'☀ Entardecer':'☾ Noite';
  if(caption!==lastCaption){$('timeOfDay').textContent=caption;lastCaption=caption;}
  // O gradiente muda devagar; não é necessário reenviar a textura a cada quadro.
  if(Math.abs(elapsed-lastSky)>=.4){paintSky(time,night);lastSky=elapsed;}
  state={elapsed,duration,time,hour:time*24,night,caption,lanternIntensity:lanternGlass.emissiveIntensity,windowIntensity:windowGlass.emissiveIntensity};
 }
 update(0);
 return {update,get state(){return {...state};}};
})();

// O jogo usa o áudio do launcher; a prévia independente tem sua própria cópia.
const villageAudio=(()=>{
 const owner=window.parent?.BunnyHavocAudio,track=owner?.getAudio('village')||$('villageMusic'),button=$('villageMusicToggle');
 if(!track){button.hidden=true;return {get state(){return {available:false};}};}
 let resume=false;
 if(!owner){track.volume=.22;track.loop=true;}
 function paint(){const audible=!track.paused&&!track.muted&&track.volume>0;
  button.textContent=track.paused?'♫ Ouvir música':track.muted?'♫ Música desligada':'♫ Música ligada';
  button.setAttribute('aria-label',track.paused?'Ouvir Village – Where the sun shines':track.muted?'Ativar música da vila':'Silenciar música da vila');
  button.setAttribute('aria-pressed',String(audible));
 }
 function play(){track.play().then(paint).catch(paint);}
 function toggle(){
  if(track.muted){if(owner)owner.toggleMute();else track.muted=false;play();}
  else if(track.paused)play();
  else if(owner)owner.toggleMute();else track.muted=true;
  paint();
 }
 button.onclick=toggle;
 addEventListener('keydown',e=>{if(e.code==='KeyM'&&!e.repeat){e.preventDefault();toggle();}});
 for(const event of ['play','pause','volumechange','error','loadedmetadata'])track.addEventListener(event,paint);
 addEventListener('pagehide',()=>{for(const event of ['play','pause','volumechange','error','loadedmetadata'])track.removeEventListener(event,paint);if(!owner)track.pause();});
 if(!owner){document.addEventListener('visibilitychange',()=>{if(document.hidden){resume=!track.paused;track.pause();}else if(resume){resume=false;play();}});play();}
 paint();
 return {get state(){return {available:true,playing:!track.paused,muted:track.muted,volume:track.volume,error:track.error?.message||null};}};
})();

// Vida cotidiana da vila: percursos locais, pausas, conversas e fauna em blocos.
function prepareCitizen(n) {
 const u=n.userData,parts=[u.head,...u.arms,...u.legs];
 for(const part of parts){part.parent.remove(part);mergeMeshes(part);}
 mergeMeshes(u.core);for(const part of parts)u.core.add(part);
}
const villageLife=(()=>{
 const routes={
  Lia:[[-5,7],[-6,6],[-5,5]],Tito:[[5,7],[6,5],[8,5],[7,7]],
  Nina:[[-31,-19],[-29,-20],[-27,-19]],Pip:[[24,-23],[26,-22],[27,-24]],
  Otto:[[-32,14],[-34,13],[-34,10],[-31,12]],Brasa:[[31,11],[33,10],[35,11]],
  Yumi:[[23,40],[22,39],[24,39]],Rui:[[6,-6],[7,0],[6,5],[9,5],[10,-3]],
  Luna:[[-6,-6],[-7,0],[-6,5],[-9,6],[-10,-3]]
 };
 const vendors=new Set(['Amora','Bento','Mel']);
 const walkers=npcs.filter(n=>!n.data.guardianArea);
 for(const [i,n] of walkers.entries()){
  n.routine={route:routes[n.data.name]||[[n.data.x,n.data.z]],index:0,wait:2+i*.45,time:0,state:vendors.has(n.data.name)?'atendendo':'observando',travelled:0};
 }
 const props=new T.Group();S.add(props);
 // Jardineiras, regadores, caixas de feira e correspondência nas casas.
 for(const [x,z] of [[-11,-11],[11,-11],[-11,12],[11,12]]){
  block(props,[1.9,.38,.85],wood,[x,2.32,z]);block(props,[1.65,.05,.65],0x594632,[x,2.53,z]);
  for(const s of [-.6,0,.6])flower(props,x+s,z,0xf5afc8,2.56);
 }
 for(const [x,z] of [[-26,23],[-16,27],[-22,32]]){
  block(props,[.78,.56,.72],0x9b6a3d,[x,2.34,z]);
  for(const s of [-1,1])block(props,[.08,.62,.78],trim,[x+s*.39,2.34,z]);
  for(let i=0;i<5;i++)rock(props,[.12,.13,.12],i%2?0xed9b39:0x94b34e,[x-.25+(i%3)*.24,2.68,z-.16+Math.floor(i/3)*.24]);
 }
 for(const a of Campaign.areas){
  const x=a.x+4.5,z=a.z+6;block(props,[.12,.9,.12],wood,[x,2.5,z]);block(props,[.48,.32,.36],0x825548,[x,3.05,z]);block(props,[.43,.035,.03],0xe8c783,[x,3.07,z+.19]);
 }
 // Varal no mercado: retalhos pequenos e facetados, fora dos caminhos.
 for(const x of [-27,-21])block(props,[.12,2.7,.12],wood,[x,3.35,34]);
 block(props,[6,.04,.04],trim,[-24,4.64,34]);
 const laundry=[];for(let i=0;i<5;i++){const cloth=block(S,[.65,.68,.045],[0xd78385,0xe6c779,0x688da8][i%3],[-26.4+i*1.15,4.28,34]);laundry.push(cloth);}
 mergeMeshes(props);
 const smoke=[];
 for(const [x,y,z] of [[-24,7.3,31],[35,8,-4],[27,9.5,-38]])for(let i=0;i<3;i++){
  const puff=mesh(new T.IcosahedronGeometry(.22,0),0xb8b7ac,[x,y+i*.5,z]);S.add(puff);smoke.push({model:puff,x,y,z,phase:i/3});
 }
 const birds=[];
 const perches=[[-9,3.52,9],[9,3.52,-9],[-24,5.7,31],[-33,10.6,-33],[27,8.2,-38],[-41.8,5.6,1],[40.7,8.9,-1],[31.8,5.6,27]];
 function bird(i){
  const g=new T.Group(),color=[0x526f94,0xa9784b,0x648b68,0x765b83][i%4];
  block(g,[.32,.22,.55],color,[0,0,0]);block(g,[.22,.18,.22],color,[0,.12,.22]);block(g,[.09,.08,.18],0xe7b44b,[0,.06,.42]);block(g,[.20,.07,.28],color,[0,.03,-.38]);
  for(const s of [-1,1])block(g,[.04,.055,.055],0x1c2030,[s*.12,.16,.29]);
  mergeMeshes(g);const wings=[];
  for(const s of [-1,1]){const w=new T.Group();w.position.x=s*.12;block(w,[.57,.065,.30],color,[s*.28,0,0]);g.add(w);wings.push(w);}
  const start=perches[i];g.position.set(...start);S.add(g);
  return {model:g,wings,index:i,target:(i+3)%perches.length,elapsed:0,wait:2+i*.9,state:'pousado',start:new T.Vector3(...start)};
 }
 for(let i=0;i<8;i++)birds.push(bird(i));
 const captions=[['Rui','Bom dia, Tito!'],['Luna','Oi, Lia!']].map(([name,text])=>{
  const n=walkers.find(n=>n.data.name===name),sprite=label(text.length>8?'Oi!':text,S,n.data.x,4.9,n.data.z,2.2,'#4a3540','#ffedbd');
  return {npc:n,sprite,text};
 });
 function update(dt,time,night=0){
  const paused=dialogue||pendingPortal||!$('map').hidden;
  for(const n of walkers){
   const r=n.routine,u=n.model.userData,near=P.position.distanceTo(n.model.position)<3.4;
   let walking=false;
   if(!paused&&!near){
    r.time+=dt;
    if(vendors.has(n.data.name)) r.state=['atendendo','arrumando a barraca','acenando'][Math.floor(r.time/6)%3];
    else if(r.wait>0){r.wait-=dt;r.state=r.index%2?'conversando':'descansando';}
    else{
     const [x,z]=r.route[(r.index+1)%r.route.length],dx=x-n.model.position.x,dz=z-n.model.position.z,d=Math.hypot(dx,dz),step=Math.min(d,dt*.8);
     if(d<.06){r.index=(r.index+1)%r.route.length;r.wait=4+(r.index%3)*2;r.state='observando';}
     else{
      const nx=n.model.position.x+dx/d*step,nz=n.model.position.z+dz/d*step;
      if(validPosition(nx,nz)){n.model.position.set(nx,2.1,nz);r.travelled+=step;walking=true;r.state='passeando';n.model.rotation.y=Math.atan2(dx,dz);}
      else{r.index=(r.index+1)%r.route.length;r.wait=1;r.state='observando';}
     }
    }
   }
   if(near)n.model.rotation.y=Math.atan2(P.position.x-n.model.position.x,P.position.z-n.model.position.z);
   else if(r.state==='conversando'){const friend=walkers.find(other=>other!==n&&n.model.position.distanceTo(other.model.position)<4);if(friend)n.model.rotation.y=Math.atan2(friend.model.position.x-n.model.position.x,friend.model.position.z-n.model.position.z);}
   const swing=walking?Math.sin(r.time*7)*.36:0;
   u.legs.forEach((part,i)=>part.rotation.x=swing*(i?1:-1));
   u.arms.forEach((part,i)=>{part.rotation.x=walking?-swing*(i?1:-1):r.state==='arrumando a barraca'?-.45+Math.sin(r.time*3)*.15:0;part.rotation.z=!walking&&(near||r.state==='acenando')&&i===1?-.65+Math.sin(time*4)*.12:0;});
   u.head.rotation.y=near?0:!walking?Math.sin(time*.6+n.phase)*.16:0;
   n.model.position.y=2.1+(walking?Math.abs(Math.sin(r.time*7))*.025:Math.sin(time*2+n.phase)*.012);
  }
  for(const b of birds){
   b.elapsed+=dt;
   if(b.state==='pousado'){
    if(night<.6)b.wait-=dt;b.model.rotation.x=night>=.6?-.15:Math.sin(time*4+b.index)>.7?.25:0;
    b.wings.forEach((w,i)=>w.rotation.z=(i?1:-1)*1.15);
    if(night<.6&&(b.wait<=0||P.position.distanceTo(b.model.position)<3.2)){b.state='voando';b.elapsed=0;b.start.copy(b.model.position);b.target=(b.index+3)%perches.length;}
   }else{
    const end=new T.Vector3(...perches[b.target]),duration=5+b.index%3,u=Math.min(1,b.elapsed/duration),smooth=u*u*(3-2*u);
    b.model.position.lerpVectors(b.start,end,smooth);b.model.position.y+=Math.sin(Math.PI*u)*8;
    b.model.rotation.set(0,Math.atan2(end.x-b.start.x,end.z-b.start.z),Math.sin(time*2)*.08);
    b.wings.forEach((w,i)=>w.rotation.z=(i?1:-1)*Math.sin(time*17+b.index)*.9);
    if(u===1){b.index=b.target;b.state='pousado';b.wait=4+(b.index%4);b.elapsed=0;}
   }
  }
  for(const c of captions){const n=c.npc;c.sprite.position.set(n.model.position.x,5,n.model.position.z);c.sprite.visible=!overview&&!paused&&P.position.distanceTo(n.model.position)<13&&n.routine.state!=='passeando'&&Math.sin(time*.7+n.phase)>.35;}
  laundry.forEach((m,i)=>m.rotation.x=Math.sin(time*1.4+i*.5)*.12);
  for(const p of smoke){const u=(time*.15+p.phase)%1;p.model.position.set(p.x+u*.65,p.y+u*2.4,p.z+Math.sin(time+u)*.12);p.model.scale.setScalar(.55+Math.sin(u*Math.PI)*.8);p.model.visible=u<.95;}
 }
 return {update,birds,walkers,smoke};
})();

// Praça habitada e três brinquedos de cenário. Sem moeda, prêmio ou progresso.
const villageDetails=(()=>{
 const fixed=new T.Group();fixed.name='VillagePlazaDetails';S.add(fixed);const interactables=[];
 const notice=$('villageNotice');let noticeTime=0,audio=null,lastSoundGain=0;
 function solid(x,z,r){obstacles.push({x,z,r});}
 function register(id,title,action,x,z,model){const item={id,title,action,x,z,model,elapsed:0,remaining:0,uses:0};interactables.push(item);return item;}
 function pot(x,z,color){
  block(fixed,[.65,.44,.65],0xa17853,[x,2.36,z]);block(fixed,[.74,.10,.74],wood,[x,2.60,z]);
  for(const dx of [-.19,0,.19])flower(fixed,x+dx,z,color,2.65);solid(x,z,.38);
 }
 // Filete e pequenas rosetas no piso delimitam o passeio circular, sem degraus.
 for(let i=0;i<40;i++){
  const a=i*Math.PI*2/40,r=5.0;
  block(fixed,[.43,.025,.19],i%5===0?0xa58d63:0xd2be94,[Math.sin(a)*r,2.19,Math.cos(a)*r],a);
 }
 // Mesa de conversa junto aos bancos existentes, fora das ligações com as pontes.
 const tx=-11.8,tz=6.1;
 block(fixed,[1.6,.14,1.05],wood,[tx,3.08,tz]);
 for(const dx of [-.58,.58])for(const dz of [-.33,.33])block(fixed,[.13,.94,.13],trim,[tx+dx,2.59,tz+dz]);
 for(const side of [-1,1]){
  block(fixed,[.63,.13,.60],0xa97c4c,[tx,2.66,tz+side*1.0]);
  for(const dx of [-.20,.20])block(fixed,[.11,.50,.38],trim,[tx+dx,2.36,tz+side*1.0]);
 }
 for(const side of [-1,1]){block(fixed,[.14,.20,.14],0xdbcaa2,[tx+side*.43,3.25,tz]);block(fixed,[.21,.035,.21],trim,[tx+side*.43,3.14,tz]);}
 block(fixed,[.43,.04,.34],0xa47562,[tx,3.18,tz]);solid(tx,tz,1.40);pot(-13.5,5.8,0xffcf83);
 // Mural de recados com papel e brasão de cenoura, sem novas missões.
 const bx=-3.8,bz=-11.7;
 for(const side of [-1,1])block(fixed,[.17,2.7,.17],trim,[bx+side*.9,3.37,bz]);
 block(fixed,[2.35,1.5,.19],wood,[bx,4.0,bz]);block(fixed,[2.12,1.26,.06],0x826449,[bx,4.0,bz+.13]);
 block(fixed,[2.65,.14,.60],trim,[bx,4.86,bz]);
 for(let i=0;i<4;i++){
  const x=bx-.73+(i%2)*1.0,z=bz+.18,y=4.25-Math.floor(i/2)*.62;
  block(fixed,[.64,.48,.035],i%2?0xd5c6a3:0xeee0bb,[x,y,z]);block(fixed,[.06,.06,.045],gold,[x,y+.17,z+.025]);
  for(let j=0;j<2;j++)block(fixed,[.32-j*.09,.025,.018],0x9a8b6d,[x,y+.04-j*.10,z+.025]);
 }
 solid(bx,bz,1.12);pot(-5.65,-11.7,0xe59aac);
 // Sino: estrutura baixa de madeira e corpo metálico facetado.
 const x=1.9,z=-11.7;
 for(const side of [-1,1]){block(fixed,[.21,3.15,.21],wood,[x+side*.79,3.62,z]);block(fixed,[.50,.16,.52],stone,[x+side*.79,2.16,z]);}
 block(fixed,[2.0,.19,.44],trim,[x,5.20,z]);
 const bell=new T.Group();bell.position.set(x,4.90,z);S.add(bell);
 block(bell,[.10,.34,.10],trim,[0,-.12,0]);cylinder(bell,.24,.47,.57,0xc9a05b,[0,-.58,0],6);cylinder(bell,.50,.50,.11,gold,[0,-.88,0],6);
 block(bell,[.075,.55,.075],wood,[0,-1.16,0]);rock(bell,[.14,.14,.14],0xa17d43,[0,-1.45,0]);mergeMeshes(bell);
 const bellItem=register('bell','Sino da praça','TOCAR O SINO',x,z,bell);solid(x,z,.96);
 // Cata-vento pequeno no gramado, longe do acesso ao bairro das neves.
 const wx=11.7,wz=-4.7;block(fixed,[.14,2.9,.14],wood,[wx,3.50,wz]);pot(12.6,-4.7,0xf3c781);
 const rotor=new T.Group();rotor.position.set(wx,4.88,wz+.13);S.add(rotor);
 for(let i=0;i<4;i++){
  const blade=new T.Group();blade.rotation.z=i*Math.PI/2;rotor.add(blade);
  block(blade,[.43,.63,.045],[0xa06470,0xe1ba65,0x648da0,0x73965b][i],[.19,.37,0]);
  const crease=block(blade,[.07,.67,.06],0xf0dcb0,[0,.34,.03]);crease.rotation.z=-.30;
 }
 rock(rotor,[.14,.14,.09],gold,[0,0,.06]);mergeMeshes(rotor);
 const windItem=register('pinwheel','Cata-vento','GIRAR',wx,wz,rotor);solid(wx,wz,.43);
 // Canteiro com regador: água e flores animadas em um conjunto fixo de malhas.
 const gx=11.2,gz=7.4;
 block(fixed,[2.3,.29,1.28],wood,[gx,2.26,gz]);block(fixed,[2.10,.035,1.08],0x65513b,[gx,2.42,gz]);
 const blooms=new T.Group();blooms.position.set(gx,2.43,gz);S.add(blooms);
 for(let i=0;i<6;i++){const fx=(i%3-1)*.67,fz=Math.floor(i/3)*.53-.26;
  block(fixed,[.055,.32,.055],0x507e42,[gx+fx,2.60,gz+fz]);
  rock(blooms,[.23,.13,.23],[0xe2a0ba,0xf5d38b,0xb9a0ce][i%3],[fx,.35,fz]);
 }mergeMeshes(blooms);
 const can=new T.Group();can.position.set(gx-1.63,2.65,gz+.33);S.add(can);
 block(can,[.48,.44,.47],0x6b9294,[0,0,0]);block(can,[.22,.14,.18],0x6b9294,[.33,.06,0]);block(can,[.13,.20,.22],0xa3babb,[.47,.14,0]);
 for(const side of [-1,1])block(can,[.07,.38,.07],0x496b72,[-.30,side*.16,0]);block(can,[.07,.07,.35],0x496b72,[-.30,.31,0]);mergeMeshes(can);
 can.name='VillageWateringCan';const drops=new T.Group();drops.name='VillageWaterDrops';S.add(drops);const droplets=[];
 for(let i=0;i<6;i++)droplets.push(block(drops,[.07,.13,.07],0xa9e2e8,[gx-.9,3,gz]));mergeMeshes(fixed);
 const gardenItem=register('garden','Canteiro da praça','REGAR',gx,gz,blooms);solid(gx,gz,1.21);
 solid(gx-1.63,gz+.33,.30);drops.visible=false;
 function message(text){notice.textContent=text;notice.hidden=false;noticeTime=3;}
 function ring(){
  const settings=bhVideo(),track=window.parent?.BunnyHavocAudio?.getAudio('village')||$('villageMusic');
  lastSoundGain=0;if(settings.muted||track?.muted)return;
  const gain=Math.max(0,Math.min(1,settings.sfx??.8))*.12;if(!gain)return;
  const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
  try{audio??=new AC();audio.resume().catch(()=>{});lastSoundGain=gain;
   for(const [frequency,strength] of [[660,1],[990,.28]]){const osc=audio.createOscillator(),volume=audio.createGain(),now=audio.currentTime;
    osc.type='sine';osc.frequency.value=frequency;volume.gain.setValueAtTime(gain*strength,now);volume.gain.exponentialRampToValueAtTime(.0001,now+.8);
    osc.connect(volume);volume.connect(audio.destination);osc.start(now);osc.stop(now+.85);osc.onended=()=>{osc.disconnect();volume.disconnect();};}
  }catch(_error){lastSoundGain=0;}
 }
 function use(item){
  if(!interactables.includes(item)||Math.hypot(P.position.x-item.x,P.position.z-item.z)>2.7)return false;
  if(dialogue||pendingPortal||!$('map').hidden||entering||document.hidden||item.remaining>0)return false;
  item.elapsed=0;item.remaining=item.id==='garden'?2.8:item.id==='bell'?1.8:2.4;item.uses++;
  if(item.id==='bell'){ring();message('O sino ecoa pela praça.');}
  else if(item.id==='pinwheel')message('Uma boa volta para o cata-vento!');
  else message('Um pouco de água para alegrar o canteiro.');
  return true;
 }
 function update(dt){
  const paused=document.hidden||dialogue||pendingPortal||!$('map').hidden||entering;
  if(paused)return;
  if(noticeTime>0){noticeTime=Math.max(0,noticeTime-dt);if(!noticeTime)notice.hidden=true;}
  for(const item of interactables){item.elapsed+=dt;item.remaining=Math.max(0,item.remaining-dt);}
  bell.rotation.z=bellItem.remaining>0?Math.sin(bellItem.elapsed*15)*.35*Math.pow(bellItem.remaining/1.8,2):0;
  rotor.rotation.z+=dt*(.55+(windItem.remaining>0?windItem.remaining*3:0));
  const watering=gardenItem.remaining>0;
  can.rotation.z=watering?-.55*Math.sin(Math.min(1,gardenItem.elapsed/.3)*Math.PI/2):0;
  can.position.y=2.65+(watering?.45:0);drops.visible=watering&&gardenItem.elapsed>.2&&gardenItem.remaining>.3;
  for(let i=0;i<droplets.length;i++){const u=(gardenItem.elapsed*1.7+i/6)%1;droplets[i].position.set(gx-1.08+u*.85,3.11-u*.58,gz+.10+Math.sin(i*3)*.24);}
  const bloom=watering?Math.sin(Math.min(1,gardenItem.elapsed/.45)*Math.PI/2)*Math.min(1,gardenItem.remaining/.5):0;
  blooms.scale.set(1+bloom*.13,1+bloom*.20,1+bloom*.13);
 }
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&audio)audio.suspend().catch(()=>{});});
 addEventListener('pagehide',()=>{if(audio)audio.close().catch(()=>{});});
 return {update,use,interactables,get state(){return {lastSoundGain,notice:notice.hidden?'':notice.textContent};}};
})();

const lockedColor=new T.Color(0x34475a),normalColor=new T.Color();
function status(p){return Campaign.status(save,p.id,trial);}
function portalDescription(p){const s=status(p);return s==='locked'?(p.slot.index===1?'Conclua o chefe da área anterior.':'Conclua o destino anterior para abrir este portal.')+(p.slot.payload?'':' Novo destino em preparação.'):s==='upcoming'?'O caminho foi liberado. Esta fase está em preparação.':s==='complete'?'Concluído · entre para jogar novamente.':'Portal aberto · entre para começar.';}
function updatePortals(){for(const p of portals){const state=status(p),open=state==='open'||state==='complete';p.material.color.set(p.area.color);if(!open)p.material.color.lerp(lockedColor,.55);p.material.opacity=open?.72:state==='upcoming'?.36:.28;p.rings.visible=open;p.lock.visible=!open;p.label.material.opacity=state==='locked'?.75:1;}}
updatePortals();
function setOverview(value){overview=value;$('cameraMode').textContent=overview?'Câmera de perto':'Ver vila inteira';}
$('cameraMode').onclick=()=>setOverview(!overview);
const states={locked:'Bloqueado',upcoming:'Em preparação',complete:'Concluído · rejogar',open:'Entrar na fase'};
function buildMap(){const dest=$('destinations');dest.replaceChildren();for(const area of Campaign.areas){const section=document.createElement('section');section.className='district';const title=document.createElement('h3');title.textContent=area.id+' · '+area.name;section.append(title);const row=document.createElement('div');row.className='destinations';
 for(const p of portals.filter(p=>p.area.id===area.id)){const button=document.createElement('button'),state=status(p);button.dataset.portal=p.id;button.dataset.status=state;button.disabled=state==='locked'||state==='upcoming';button.append(document.createTextNode(p.slot.boss?'Chefe':p.slot.index+' · '+p.slot.name));const small=document.createElement('small');small.textContent=states[state];button.append(small);button.title=portalDescription(p);button.onclick=()=>enterPortal(p);row.append(button);}section.append(row);dest.append(section);}}
function openMap(){keys.clear();buildMap();$('map').hidden=false;$('mapClose').focus();}function closeMap(){$('map').hidden=true;$('mapButton').focus();}
$('mapButton').onclick=openMap;$('mapClose').onclick=closeMap;
function say(n){
 keys.clear();dialogue=n;dialogIndex=0;$('dialogName').textContent=n.data.name;$('dialogText').textContent=n.data.lines[0];$('dialog').hidden=false;
 const choices=$('guardianDestinations');choices.replaceChildren();choices.hidden=!n.data.guardianArea;$('dialogNext').hidden=!!n.data.guardianArea;
 if(n.data.guardianArea){for(const p of portals.filter(p=>p.area.id===n.data.guardianArea)){const button=document.createElement('button'),state=status(p);button.dataset.guardianPortal=p.id;button.disabled=!['open','complete'].includes(state);button.textContent=(p.slot.boss?'Chefe':p.slot.name)+' · '+states[state];button.onclick=()=>enterPortal(p);choices.append(button);}$('dialogClose').focus();}
 else $('dialogNext').focus();
}
function closeDialog(){dialogue=null;$('dialog').hidden=true;$('guardianDestinations').hidden=true;$('dialogNext').hidden=false;$('action').focus();}
$('dialogClose').onclick=closeDialog;$('dialogNext').onclick=()=>{if(!dialogue)return;dialogIndex++;if(dialogIndex>=dialogue.data.lines.length)closeDialog();else $('dialogText').textContent=dialogue.data.lines[dialogIndex];};
function enterPortal(p){
 if(entering||pendingPortal)return;
 const s=status(p);if(!['open','complete'].includes(s)){showInfo(p.slot.name,portalDescription(p));return;}
 const guardian=MEOWLIN[p.area.id-1];keys.clear();pendingPortal=p;confirmOrigin=document.activeElement;
 $('guardianName').textContent=guardian.name;$('portalQuestion').textContent='Tem certeza de que quer entrar em “'+p.slot.name+'”?';
 $('portalConfirm').style.setProperty('--guardian-color','#'+guardian.robe.toString(16).padStart(6,'0'));$('portalConfirm').hidden=false;$('confirmYes').disabled=false;$('confirmCancel').focus();
}
function cancelPortal(){pendingPortal=null;$('portalConfirm').hidden=true;keys.clear();if(confirmOrigin?.isConnected)confirmOrigin.focus();else $('mapButton').focus();confirmOrigin=null;}
$('confirmCancel').onclick=cancelPortal;
$('confirmYes').onclick=()=>{
 const p=pendingPortal;if(!p||entering)return;
 if(!['open','complete'].includes(status(p))){cancelPortal();return;}
 pendingPortal=null;$('portalConfirm').hidden=true;keys.clear();
 if(config.preview){showInfo(MEOWLIN[p.area.id-1].name,'Você está na prévia da vila. Abra o jogo completo para entrar nas fases e guardar seu progresso.');return;}
 entering=true;$('confirmYes').disabled=true;
 keys.clear();const arrival=[[0,3.5],[1.5,3.5],[-1.5,3.5],[0,5]].map(([x,z])=>({x:p.x+x,z:p.z+z})).find(a=>validPosition(a.x,a.z))||{x:P.position.x,z:P.position.z};
 window.parent.postMessage({type:'bunny-havoc-village-enter',token:config.token,id:p.id,guardianArea:p.area.id,confirmed:true,position:arrival},'*');
};
function showInfo(name,text){dialogue={data:{name,lines:[text]}};dialogIndex=0;$('dialogName').textContent=name;$('dialogText').textContent=text;$('guardianDestinations').hidden=true;$('dialogNext').hidden=false;$('dialog').hidden=false;$('dialogClose').focus();}
function interact(){if(pendingPortal||entering||!$('map').hidden)return;if(dialogue){if(!dialogue.data.guardianArea)$('dialogNext').click();return;}if(!nearest)return;if(nearest.kind==='portal')enterPortal(nearest.value);else if(nearest.kind==='prop')villageDetails.use(nearest.value);else say(nearest.value);}
$('action').onclick=interact;
addEventListener('keydown',e=>{if(['Enter','Space'].includes(e.code)&&e.target.closest?.('button'))return;if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','Enter','KeyE'].includes(e.code))e.preventDefault();if(e.repeat&&['Enter','KeyE','KeyV','Escape'].includes(e.code))return;
 if(pendingPortal){if(e.code==='Escape'){e.preventDefault();cancelPortal();}else if(e.code==='Tab'){e.preventDefault();(document.activeElement===$('confirmCancel')?$('confirmYes'):$('confirmCancel')).focus();}return;}
 if(e.code==='Escape'){if(dialogue)closeDialog();else if(!$('map').hidden)closeMap();else openMap();return;}
 if(e.code==='KeyV'){setOverview(!overview);return;}
 if(['KeyE','Enter'].includes(e.code)){interact();return;}if(!dialogue&&$('map').hidden)keys.add(e.code);
});addEventListener('keyup',e=>keys.delete(e.code));addEventListener('blur',()=>keys.clear());
for(const button of document.querySelectorAll('[data-key]')){button.onpointerdown=e=>{e.preventDefault();button.setPointerCapture(e.pointerId);keys.add(button.dataset.key);};button.onpointerup=button.onpointercancel=()=>keys.delete(button.dataset.key);}
function fit(){const video=bhVideo(),height=({low:168,medium:240,high:360})[video.quality]||240,width=Math.max(160,Math.round(height*innerWidth/innerHeight));R.setPixelRatio(video.psx===false?({low:.65,medium:1,high:Math.min(2,devicePixelRatio||1.5)})[video.quality]||1:1);R.setSize(innerWidth,innerHeight);RT.setSize(width,height);qm.uniforms.res.value.set(width,height);C.aspect=innerWidth/innerHeight;C.updateProjectionMatrix();}addEventListener('resize',fit);fit();
function updatePrompt(){let best=Infinity,item=null;for(const p of portals){const d=Math.hypot(P.position.x-p.x,P.position.z-p.z-1);if(d<4.2&&d<best){best=d;item={kind:'portal',value:p};}}
 for(const n of npcs){const d=P.position.distanceTo(n.model.position);if(d<2.9&&d<best){best=d;item={kind:'npc',value:n};}}for(const prop of villageDetails.interactables){const d=Math.hypot(P.position.x-prop.x,P.position.z-prop.z);if(d<2.7&&d<best){best=d;item={kind:'prop',value:prop};}}nearest=item;$('prompt').style.display=item&&!dialogue&&!pendingPortal&&$('map').hidden?'block':'none';
 $('action').disabled=false;
 if(item){const p=item.value,isPortal=item.kind==='portal';if(item.kind==='prop'){$('promptTitle').textContent=p.title;$('promptText').textContent='E / Enter para brincar';$('action').disabled=p.remaining>0;$('action').textContent=p.remaining>0?({bell:'TOCANDO…',pinwheel:'GIRANDO…',garden:'REGANDO…'}[p.id]):p.action;return;}$('promptTitle').textContent=isPortal?(p.slot.boss?'Chefe · '+p.area.name:p.slot.name):p.data.name;$('promptText').textContent=isPortal?portalDescription(p):'E / Enter para conversar';$('action').textContent=isPortal?(['open','complete'].includes(status(p))?'ENTRAR':'VER PORTAL'):'CONVERSAR';}
}
function updateCamera(dt,snap=false){
 if(overview){focus.set(0,4,3);const distance=Math.max(116,150/C.aspect);cameraEye.set(0,4+distance*.61,3+distance*.79);}
 else{focus.copy(P.position).add(new T.Vector3(0,1.1,-3));cameraEye.copy(P.position).add(new T.Vector3(0,12,16));}
 if(snap){look.copy(focus);C.position.copy(cameraEye);}else{look.lerp(focus,1-Math.exp(-5*dt));C.position.lerp(cameraEye,1-Math.exp(-4*dt));}C.lookAt(look);
 // A vista em retrato afasta a câmera: a neblina acompanha a distância para não apagar a vila.
 const distance=C.position.distanceTo(look);S.fog.near=Math.max(100,distance+25);S.fog.far=Math.max(240,distance+160);
 const far=Math.max(350,distance+240);if(Math.abs(C.far-far)>.5){C.far=far;C.updateProjectionMatrix();}
}
function loop(){if(disposed)return;requestAnimationFrame(loop);const dt=Math.min(.05,clock.getDelta());phase+=dt;
 villageCycle.update(document.hidden?0:dt);
 const dx=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0),dz=(keys.has('KeyS')||keys.has('ArrowDown')?1:0)-(keys.has('KeyW')||keys.has('ArrowUp')?1:0),moving=(dx||dz)&&!dialogue&&!pendingPortal&&$('map').hidden;
 if(moving){if(overview)setOverview(false);const length=Math.hypot(dx,dz),speed=(keys.has('ShiftLeft')||keys.has('KeyK')?8:5.8)*dt,nx=P.position.x+dx/length*speed,nz=P.position.z+dz/length*speed;
 if(validPosition(nx,P.position.z))P.position.x=nx;if(validPosition(P.position.x,nz))P.position.z=nz;
 const angle=Math.atan2(dx,dz),delta=Math.atan2(Math.sin(angle-body.rotation.y),Math.cos(angle-body.rotation.y));body.rotation.y+=delta*(1-Math.exp(-14*dt));}
 P.position.y+=(groundHeight(P.position.x,P.position.z)-P.position.y)*(1-Math.exp(-18*dt));
 legs.forEach((l,i)=>l.rotation.x=moving?Math.sin(phase*12+i*Math.PI)*.6:0);arms.forEach((a,i)=>a.rotation.x=moving?Math.sin(phase*12+(i+1)*Math.PI)*.4:0);
 bun.position.y=moving?Math.abs(Math.sin(phase*12))*.07:Math.sin(phase*2)*.012;ears.forEach((e,i)=>e.rotation.x=Math.sin(phase*3+i)*.045);shade.position.set(P.position.x,groundHeight(P.position.x,P.position.z)+.015,P.position.z);
 for(const name of labels)name.visible=!overview&&P.position.distanceTo(name.position)<15;
 for(const p of portals){p.rings.rotation.z=phase*.35;p.material.opacity=(['open','complete'].includes(status(p))?.70:.27)+Math.sin(phase*2+p.id)*.045;p.label.visible=!overview&&P.position.distanceTo(p.surface.position)<15;}
 waterfalls.forEach((w,i)=>w.mesh.position.y=1.9-((phase*1.8+w.base)%6.9));wheels.forEach(w=>w.rotation.z=phase*.25);
 villageLife.update(dt,phase,villageCycle.state.night);
 villageDetails.update(dt);
 guardians.forEach(n=>n.model.position.y=2.1+Math.sin(phase*2.3+n.phase)*.018);
 bubbles.forEach(b=>{b.sprite.position.set(b.model.position.x,5+Math.sin(phase*2+b.phase)*.08,b.model.position.z);b.sprite.visible=!overview&&!dialogue&&!pendingPortal&&$('map').hidden&&P.position.distanceTo(b.sprite.position)<12&&Math.sin(phase*.5+b.phase)>.1;});
 const court=courts.find(c=>Math.hypot(P.position.x-c.x,P.position.z-c.z)<c.r);
 const area=court?Campaign.areas[court.area-1]:Campaign.areas.find(a=>Math.hypot(P.position.x-a.x,P.position.z-a.z)<12);const atMarket=Math.hypot(P.position.x+20,P.position.z-27)<11;
 $('district').textContent=(area?area.name:atMarket?'Mercado da Vila':'Praça do Coelho')+' · '+save.completed.filter(Boolean).length+' / 20 destinos concluídos';
 updatePrompt();updateCamera(dt);
 if(bhVideo().psx!==false){R.setRenderTarget(RT);R.render(S,C);renderStats={...R.info.render};R.setRenderTarget(null);R.render(qs,qc);}else{R.setRenderTarget(null);R.render(S,C);renderStats={...R.info.render};}
}
$('mode').textContent=config.preview?'Prévia da vila · sem salvar':trial?'Exploração em treino · sem salvar':'Arquivo '+((config.slot||0)+1);updateCamera(0,true);
window.BunnyHavocVillage={scene:S,camera:C,renderer:R,get renderStats(){return {...renderStats};},hero:P,portals,npcs,guardians,life:villageLife,details:villageDetails,homes,cycle:villageCycle,audio:villageAudio,courts,islands,bridges,validPosition,get pendingPortal(){return pendingPortal?.id??null;},get overview(){return overview;},get save(){return structuredClone(save);},get state(){return {preview:!!config.preview,trial};}};
window.parent!==window&&window.parent.postMessage({type:'bunny-havoc-village-ready',token:config.token},'*');loop();
addEventListener('pagehide',()=>{disposed=true;RT.dispose();qm.dispose();R.dispose();});
}catch(error){console.error(error);fail('Não foi possível abrir a vila. Volte ao menu e tente novamente.');}
})();
