(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) return;
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) processPreload(link);
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") continue;
      for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
    }
  }).observe(document, {
    childList: true,
    subtree: true
  });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep) return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
function startLauncher() {
  const $ = (id) => document.getElementById(id), mem = {};
  const K = { s: "BunnyHavoc:v8:settings", v: "BunnyHavoc:v8:saves" };
  const rd = (k) => {
    try {
      return localStorage.getItem(k);
    } catch (e) {
      return mem[k] ?? null;
    }
  };
  const wr = (k, v) => {
    mem[k] = v;
    try {
      localStorage.setItem(k, v);
      return true;
    } catch (e) {
      return false;
    }
  };
  const rj = (k, f) => {
    try {
      const v = JSON.parse(rd(k));
      return v ?? f;
    } catch (e) {
      return f;
    }
  };
  const DEF = { psx: true, quality: "medium", music: 0.22, sfx: 0.8, brightness: 100, muted: false };
  const settings = { ...DEF, ...rj(K.s, {}) };
  const Campaign = window.BunnyHavocCampaign;
  const raw = rj(K.v, []);
  const saves = [0, 1, 2].map((i) => Campaign.normalize(Array.isArray(raw) ? raw[i] : null));
  const persist = () => wr(K.v, JSON.stringify(saves)), persistSet = () => wr(K.s, JSON.stringify(settings));
  const tracks = { 1: $("music1"), 2: $("music2"), village: $("villageMusic") }, frame = $("game");
  const NAMES = ["", "BOSQUE VERDE", "SELVA DE PINHEIROS"];
  const STORY = { 1: "Bunnyldu foi capturado! Bibibunn fugiu rumo à Selva de Pinheiros.", 2: "Bunnyck descobriu que a barragem foi sabotada. A Fase 3 ainda está em construção." };
  let level = 0, activeSlot = null, trial = false, pending = null, ready = false, seq = 0, tmo = 0, poll = 0, screen = "title", midx = 0, villageMode = false;
  const villageTimes = /* @__PURE__ */ new Map(), villageClockKey = () => trial || activeSlot === null ? "trial" : activeSlot;
  window.BunnyHavocVillageClock = { read: () => villageTimes.get(villageClockKey()) || 0, advance(dt) {
    const key = villageClockKey(), before = villageTimes.get(key) || 0;
    if (villageMode && ready && !document.hidden && Number.isFinite(dt) && dt > 0) villageTimes.set(key, before + Math.min(0.05, dt));
    return villageTimes.get(key) || 0;
  } };
  let resumeVillageMusic = false;
  function playVillageMusic() {
    if (villageMode && ready && !document.hidden) tracks.village.play().catch(() => {
    });
  }
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      resumeVillageMusic = villageMode && !tracks.village.paused;
      tracks.village.pause();
    } else if (resumeVillageMusic) {
      resumeVillageMusic = false;
      playVillageMusic();
    }
  });
  const toast = (m) => {
    const t = $("toast");
    t.textContent = m;
    t.classList.add("on");
    clearTimeout(toast.t);
    toast.t = setTimeout(() => t.classList.remove("on"), 2200);
  };
  const show = (id) => {
    for (const s of ["title", "menu", "panel", "results", "loading"]) $(s).classList.toggle("hidden", s !== id);
    screen = id || "";
    if (id) {
      try {
        frame.blur();
        window.focus();
      } catch (e) {
      }
    }
  };
  const hideAll = () => show("");
  function refreshVolume() {
    for (const a of Object.values(tracks)) {
      a.volume = Math.min(1, Math.max(0, settings.music));
      a.muted = settings.muted;
    }
    $("bmusic").textContent = settings.muted ? "🔇" : "🔊";
  }
  function toggleMute() {
    settings.muted = !settings.muted;
    persistSet();
    refreshVolume();
    toast(settings.muted ? "Música silenciada" : "Música ativada");
  }
  window.BunnyHavocAudio = { getAudio: (i) => tracks[i], setTrack: () => {
  }, toggleMute, refreshVolume, get current() {
    return villageMode ? "village" : level;
  } };
  window.BunnyHavocSettings = { get: () => ({ ...settings }) };
  const bright = () => {
    frame.style.filter = "brightness(" + settings.brightness + "%)";
  };
  const scenes = window.BunnyHavocScenes;
  function menuHome() {
    villageMode = false;
    clearTimeout(tmo);
    clearInterval(poll);
    level = 0;
    pending = null;
    ready = false;
    trial = false;
    for (const a of Object.values(tracks)) {
      a.pause();
      a.currentTime = 0;
    }
    frame.classList.add("hidden");
    scenes.clear(frame);
    $("bar").classList.add("hidden");
    show("menu");
    selMenu(midx);
  }
  function selMenu(i) {
    const it = [...$("mlist").children];
    midx = (i + it.length) % it.length;
    it.forEach((b, j) => b.classList.toggle("sel", j === midx));
  }
  $("mlist").addEventListener("mouseover", (e) => {
    const b = e.target.closest(".item");
    if (b) selMenu([...$("mlist").children].indexOf(b));
  });
  $("mlist").addEventListener("click", (e) => {
    const b = e.target.closest(".item");
    if (b) act(b.dataset.a);
  });
  function act(a) {
    if (a === "new") slots("new");
    else if (a === "continue") slots("continue");
    else if (a === "saves") slots("manage");
    else if (a === "levels") levels();
    else if (a === "options") options();
    else if (a === "village") slots(saves.some(Boolean) ? "continue" : "new");
  }
  function panel(title, html, hint) {
    $("pt").textContent = title;
    $("pb").innerHTML = html;
    $("ph").textContent = hint || "";
    show("panel");
  }
  $("pback").onclick = () => show("menu");
  const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const slotInfo = (i) => {
    const s = saves[i];
    return s ? `<b>ARQUIVO ${i + 1} · ${escapeHTML(s.name)}</b><small>${s.completed.filter(Boolean).length} / 20 destinos · próxima etapa ${s.unlocked}</small>` : `<b>ARQUIVO ${i + 1} · VAZIO</b><small>Nenhum progresso</small>`;
  };
  function slots(kind) {
    const t = { new: "NOVO JOGO", continue: "CONTINUAR", manage: "ARQUIVOS" }[kind];
    panel(t, [0, 1, 2].map((i) => `<div class="row ${kind === "continue" && !saves[i] ? "lock" : ""}" data-i="${i}"><div>${slotInfo(i)}</div>${kind === "manage" ? saves[i] ? '<button class="btn alt" data-del="' + i + '">APAGAR</button>' : "" : '<button class="btn" data-go="' + i + '">' + (kind === "new" ? "JOGAR" : "ENTRAR") + "</button>"}</div>`).join("") + (kind === "manage" ? '<button class="btn" id="bk">⬇ BACKUP</button>' : ""), kind === "new" ? "Escolha um arquivo para guardar seu progresso." : kind === "continue" && !saves.some(Boolean) ? "Nenhum arquivo salvo ainda. Comece em NOVO JOGO." : "");
    $("pb").querySelectorAll("[data-go]").forEach((b) => b.onclick = () => {
      const i = +b.dataset.go;
      if (kind === "new") {
        if (saves[i] && !confirm("Substituir o arquivo " + (i + 1) + "?")) return;
        saves[i] = Campaign.normalize({ schema: 9, name: "Aventura " + (i + 1), completed: [] });
        villageTimes.delete(i);
        persist();
      }
      activeSlot = i;
      trial = false;
      enterVillage();
    });
    $("pb").querySelectorAll("[data-del]").forEach((b) => b.onclick = () => {
      const i = +b.dataset.del;
      if (confirm("Apagar o arquivo " + (i + 1) + "?")) {
        saves[i] = null;
        if (activeSlot === i) activeSlot = null;
        persist();
        slots("manage");
      }
    });
    const bk = $("bk");
    if (bk) bk.onclick = () => {
      const u = URL.createObjectURL(new Blob([JSON.stringify({ format: "BunnyHavocSaveV9", saves, settings }, null, 2)], { type: "application/json" })), a = document.createElement("a");
      a.href = u;
      a.download = "BunnyHavoc_Backup.json";
      a.click();
      setTimeout(() => URL.revokeObjectURL(u), 2e3);
    };
  }
  function levels() {
    panel("ESCOLHER FASE", [1, 2].map((i) => `<div class="row"><div><b>FASE ${i} · ${NAMES[i]}</b><small>Modo treino: não altera seu save</small></div><button class="btn" data-l="${i}">JOGAR</button></div>`).join(""), "Mais fases em breve.");
    $("pb").querySelectorAll("[data-l]").forEach((b) => b.onclick = () => {
      activeSlot = null;
      start(+b.dataset.l, true);
    });
  }
  function options() {
    panel("OPÇÕES", `<div class="opt"><span>Música</span><input id="o1" type="range" min="0" max="100" value="${Math.round(settings.music * 100)}"></div><div class="opt"><span>Efeitos</span><input id="o2" type="range" min="0" max="100" value="${Math.round(settings.sfx * 100)}"></div><div class="opt"><span>Brilho</span><input id="o3" type="range" min="60" max="140" value="${settings.brightness}"></div><div class="opt"><span>Filtro PS1</span><button class="btn alt" id="o4">${settings.psx ? "LIGADO" : "DESLIGADO"}</button></div><div class="opt"><span>Qualidade</span><button class="btn alt" id="o5">${settings.quality.toUpperCase()}</button></div>`, "O filtro PS1 e a qualidade valem na próxima vez que você iniciar uma fase.");
    $("o1").oninput = (e) => {
      settings.music = e.target.value / 100;
      persistSet();
      refreshVolume();
    };
    $("o2").oninput = (e) => {
      settings.sfx = e.target.value / 100;
      persistSet();
    };
    $("o3").oninput = (e) => {
      settings.brightness = +e.target.value;
      persistSet();
      bright();
    };
    $("o4").onclick = (e) => {
      settings.psx = !settings.psx;
      e.target.textContent = settings.psx ? "LIGADO" : "DESLIGADO";
      persistSet();
    };
    $("o5").onclick = (e) => {
      const q = ["low", "medium", "high"];
      settings.quality = q[(q.indexOf(settings.quality) + 1) % 3];
      e.target.textContent = settings.quality.toUpperCase();
      persistSet();
    };
  }
  function loadFail(msg) {
    if (ready || !level) return;
    clearTimeout(tmo);
    clearInterval(poll);
    if (msg) console.error("Bunny Havoc loading error:", msg);
    $("ls").textContent = "NÃO FOI POSSÍVEL CARREGAR";
    $("le").textContent = "A fase não iniciou. Tente de novo ou volte ao menu.";
    $("lspin").classList.add("hidden");
    $("lfail").classList.remove("hidden");
  }
  function start(id, isTrial) {
    const destination = Campaign.slots[id - 1];
    if (!destination?.payload || !scenes.has(destination.payload)) {
      toast("Este destino ainda está em preparação.");
      return;
    }
    if (!isTrial && !["open", "complete"].includes(Campaign.status(saves[activeSlot], id))) {
      toast("Conclua o destino anterior primeiro.");
      return;
    }
    villageMode = false;
    $("bvillage").classList.remove("hidden");
    for (const a of Object.values(tracks)) {
      a.pause();
      a.currentTime = 0;
    }
    level = id;
    trial = isTrial;
    pending = null;
    ready = false;
    const token = ++seq;
    clearTimeout(tmo);
    clearInterval(poll);
    $("lt").textContent = "FASE " + id + " · " + NAMES[id];
    $("ls").textContent = "CARREGANDO";
    $("le").textContent = "";
    $("lspin").classList.remove("hidden");
    $("lready").classList.add("hidden");
    $("lfail").classList.add("hidden");
    show("loading");
    frame.classList.remove("hidden");
    $("bar").classList.remove("hidden");
    refreshVolume();
    bright();
    try {
      scenes.loadPhase(frame, destination.payload, String(token), isTrial);
    } catch (e) {
      loadFail(e);
      return;
    }
    poll = setInterval(inspect, 400);
    tmo = setTimeout(() => {
      if (level === id && seq === token && !ready) loadFail("timeout");
    }, 3e4);
  }
  function inspect() {
    if (!level || ready || !scenes.isCurrent(frame)) return;
    try {
      const d = frame.contentDocument;
      if (!d) return;
      const b = d.getElementById("ov");
      if (d.querySelector("canvas") && typeof b?.onclick === "function" && frame.contentWindow?.THREE?.WebGLRenderer) stageReady();
    } catch (e) {
    }
  }
  function stageReady() {
    if (!level || ready) return;
    ready = true;
    clearTimeout(tmo);
    clearInterval(poll);
    $("ls").textContent = "PRONTO!";
    $("lspin").classList.add("hidden");
    $("lready").classList.remove("hidden");
  }
  function go() {
    if (!ready) return;
    try {
      const d = frame.contentDocument, b = d?.getElementById("ov");
      if (typeof b?.onclick !== "function") {
        toast("Os controles ainda não estão prontos.");
        return;
      }
      b.onclick(new MouseEvent("click"));
      hideAll();
      frame.contentWindow?.focus();
    } catch (e) {
      toast("Falha iniciando a fase.");
    }
  }
  $("lready").onclick = go;
  $("lretry").onclick = () => villageMode ? enterVillage() : start(level, trial);
  $("lback").onclick = menuHome;
  $("bmenu").onclick = () => {
    if (screen === "results" || confirm("Voltar ao menu principal? O progresso desta tentativa será perdido.")) menuHome();
  };
  $("bmusic").onclick = toggleMute;
  function result(i, d) {
    if (pending?.level === i) return;
    for (const a of Object.values(tracks)) a.pause();
    const sc = { carrots: Math.max(0, +d.carrots || 0), hearts: Math.max(0, +d.hearts || 0), boxes: Math.max(0, +d.boxes || 0) };
    pending = { level: i, score: sc };
    $("rt").textContent = "FASE " + i + " COMPLETA!";
    $("rs").textContent = STORY[i];
    $("rst").innerHTML = `<span>🥕 ${sc.carrots}</span><span>❤️ ${sc.hearts}</span><span>📦 ${sc.boxes}</span>`;
    let fb = "Modo treino: nada foi salvo.";
    if (!trial && activeSlot !== null && saves[activeSlot]) {
      saves[activeSlot] = Campaign.complete(saves[activeSlot], i, sc);
      fb = persist() ? "💾 Progresso salvo no arquivo " + (activeSlot + 1) + "." : "⚠ O navegador bloqueou o salvamento.";
    }
    $("rf").textContent = fb;
    $("rnext").textContent = trial ? "PRÓXIMA FASE ▶" : "VOLTAR À VILA";
    $("rnext").classList.toggle("hidden", trial && i >= 2);
    show("results");
    $("bar").classList.add("hidden");
  }
  $("rnext").onclick = () => {
    const i = pending?.level;
    if (!trial) enterVillage();
    else if (i && i < 2) start(i + 1, true);
  };
  $("rmenu").onclick = menuHome;
  function enterVillage() {
    clearTimeout(tmo);
    clearInterval(poll);
    for (const a of Object.values(tracks)) {
      a.pause();
      a.currentTime = 0;
    }
    level = 0;
    pending = null;
    ready = false;
    villageMode = true;
    const token = String(++seq);
    const hubTrial = trial || activeSlot === null;
    $("lt").textContent = "VILA DOS ANIMAIS";
    $("ls").textContent = "CARREGANDO";
    $("le").textContent = "";
    $("lspin").classList.remove("hidden");
    $("lready").classList.add("hidden");
    $("lfail").classList.add("hidden");
    show("loading");
    frame.classList.remove("hidden");
    $("bar").classList.add("hidden");
    $("bvillage").classList.add("hidden");
    bright();
    const state = { token, save: hubTrial ? null : saves[activeSlot], slot: activeSlot, trial: hubTrial, preview: false };
    scenes.loadVillage(frame, state);
    tmo = setTimeout(() => {
      if (villageMode && !ready) {
        $("ls").textContent = "NÃO FOI POSSÍVEL ABRIR A VILA";
        $("le").textContent = "Confira sua conexão e tente novamente.";
        $("lspin").classList.add("hidden");
        $("lfail").classList.remove("hidden");
      }
    }, 3e4);
  }
  $("bvillage").onclick = enterVillage;
  window.addEventListener("message", (ev) => {
    if (ev.source !== frame.contentWindow || !scenes.isCurrent(frame) || !ev.data || typeof ev.data !== "object") return;
    const t = ev.data.type, ok = !ev.data.token || String(ev.data.token) === String(seq);
    if (!ok) return;
    if (t === "bunny-havoc-village-ready") {
      if (villageMode && ev.data.token === String(seq)) {
        clearTimeout(tmo);
        ready = true;
        hideAll();
        screen = "village";
        $("bar").classList.remove("hidden");
        refreshVolume();
        playVillageMusic();
        frame.contentWindow?.focus();
      }
      return;
    }
    if (t === "bunny-havoc-village-enter") {
      if (!villageMode || !ready || ev.data.token !== String(seq) || ev.data.confirmed !== true) return;
      const id = Number(ev.data.id), isTrial = trial || activeSlot === null;
      if (Campaign.slots[id - 1]?.area !== ev.data.guardianArea) return;
      if (!["open", "complete"].includes(Campaign.status(isTrial ? null : saves[activeSlot], id, isTrial))) return;
      if (!isTrial) {
        const position = ev.data.position;
        saves[activeSlot] = Campaign.normalize({ ...saves[activeSlot], villagePosition: position, lastLevel: id });
        persist();
      }
      start(id, isTrial);
      return;
    }
    if (t === "bunny-havoc-stage-ready") {
      if (level === +ev.data.level && ok) stageReady();
    } else if (t === "bunny-havoc-stage-error") {
      if (level === +ev.data.level && ok) console.error("Erro da fase:", ev.data.detail || "desconhecido");
      loadFail();
    } else if (t === "bunny-havoc-open-menu") {
      $("bmenu").onclick();
    } else if (t === "bunny-havoc-fase1-concluida" && level === 1) result(1, ev.data);
    else if (t === "bunny-havoc-fase2-concluida" && level === 2) result(2, ev.data);
  });
  const toMenu = () => {
    if (screen === "title") {
      show("menu");
      selMenu(0);
    }
  };
  $("title").onclick = toMenu;
  addEventListener("keydown", (e) => {
    if (screen === "title" && (e.code === "Enter" || e.code === "Space")) {
      e.preventDefault();
      toMenu();
    } else if (screen === "menu") {
      if (e.code === "ArrowDown" || e.code === "KeyS") {
        e.preventDefault();
        selMenu(midx + 1);
      } else if (e.code === "ArrowUp" || e.code === "KeyW") {
        e.preventDefault();
        selMenu(midx - 1);
      } else if (e.code === "Enter" || e.code === "Space") {
        e.preventDefault();
        $("mlist").children[midx].click();
      }
    } else if (screen === "loading" && ready && e.code === "Enter") {
      e.preventDefault();
      go();
    } else if (screen === "results" && e.code === "Enter") {
      e.preventDefault();
      ($("rnext").classList.contains("hidden") ? $("rmenu") : $("rnext")).click();
    } else if (screen === "panel" && e.code === "Escape") {
      show("menu");
    }
    if (e.code === "KeyM" && screen !== "") toggleMute();
  });
  refreshVolume();
  bright();
  show("title");
}
const scenePaths = {
  phase1: "scenes/phase1.html",
  phase2: "scenes/phase2.html",
  village: "scenes/village.html"
};
function createSceneLoader(base) {
  const sessions = /* @__PURE__ */ new WeakMap();
  function navigate(frame, session) {
    const snapshot = structuredClone(session);
    sessions.set(frame, snapshot);
    frame.dataset.loadToken = snapshot.token;
    frame.dataset.bhScene = snapshot.scene;
    frame.removeAttribute("srcdoc");
    const url = new URL(scenePaths[snapshot.scene], base);
    url.searchParams.set("bh-session", snapshot.token);
    frame.src = url.href;
  }
  function isCurrent(frame) {
    const session = sessions.get(frame);
    if (!session) return false;
    try {
      const actual = new URL(frame.contentWindow.location.href);
      const expected = new URL(scenePaths[session.scene], base);
      return actual.origin === expected.origin && actual.pathname === expected.pathname && actual.searchParams.get("bh-session") === session.token;
    } catch {
      return false;
    }
  }
  return Object.freeze({
    has(key) {
      return Object.hasOwn(scenePaths, key);
    },
    loadPhase(frame, scene, token, trial) {
      navigate(frame, { scene, token, trial });
    },
    loadVillage(frame, state) {
      navigate(frame, { scene: "village", token: state.token, state });
    },
    readSession(frame, scene, token) {
      const session = sessions.get(frame);
      if (!session || !isCurrent(frame) || session.scene !== scene || session.token !== token) return void 0;
      return structuredClone(session);
    },
    isCurrent,
    clear(frame) {
      sessions.delete(frame);
      delete frame.dataset.loadToken;
      delete frame.dataset.bhScene;
      frame.removeAttribute("srcdoc");
      frame.src = "about:blank";
    }
  });
}
window.BunnyHavocScenes = createSceneLoader(new URL("./", location.href));
startLauncher();
//# sourceMappingURL=index-BLnZsLZB.js.map
