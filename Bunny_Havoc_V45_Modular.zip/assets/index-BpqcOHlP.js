(function polyfill() {
  const relList = document.createElement("link").relList;
  if (relList && relList.supports && relList.supports("modulepreload")) return;
  for (const link of document.querySelectorAll('link[rel="modulepreload"]')) processPreload(link);
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type !== "childList") continue;
      for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
    }
  }).observe(document, {
    childList: true,
    subtree: true
  });
  function getFetchOpts(link) {
    const fetchOpts = {};
    if (link.integrity) fetchOpts.integrity = link.integrity;
    if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
    if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
    else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
    else fetchOpts.credentials = "same-origin";
    return fetchOpts;
  }
  function processPreload(link) {
    if (link.ep) return;
    link.ep = true;
    const fetchOpts = getFetchOpts(link);
    fetch(link.href, fetchOpts);
  }
})();
const definitions = [
  { id: 1, name: "Bosque das Copas", theme: "forest", color: 6544240, x: -30, z: -25 },
  { id: 2, name: "Vila das Neves", theme: "snow", color: 6015743, x: 27, z: -29 },
  { id: 3, name: "Cais das Cascatas", theme: "water", color: 3528419, x: -35, z: 8 },
  { id: 4, name: "Distrito das Forjas", theme: "forge", color: 16751410, x: 35, z: 5 },
  { id: 5, name: "Jardins da Lua", theme: "sakura", color: 15235071, x: 25, z: 34 }
];
const areas = Object.freeze(definitions.map((area) => Object.freeze(area)));
const slots = Object.freeze(areas.flatMap((area) => Array.from({ length: 4 }, (_, i) => Object.freeze({
  id: (area.id - 1) * 4 + i + 1,
  area: area.id,
  index: i + 1,
  boss: i === 3,
  name: area.id === 1 && i === 0 ? "Bosque Verde" : area.id === 1 && i === 1 ? "Selva de Pinheiros" : i === 3 ? "Chefe da área " + area.id : "Fase " + ((area.id - 1) * 3 + i + 1),
  payload: area.id === 1 && i < 2 ? i === 0 ? "phase1" : "phase2" : null
}))));
function normalize(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const source = input;
  const previous = source.completed;
  const completed = Array.from({ length: 20 }, (_, i) => previous?.[i] === true);
  if (source.schema !== 9 && Number(source.unlocked) === 2) completed[0] = true;
  let unlocked = 1;
  while (unlocked <= 20 && completed[unlocked - 1]) unlocked++;
  unlocked = Math.min(20, unlocked);
  const p = source.villagePosition;
  const valid = p && Number.isFinite(p.x) && Number.isFinite(p.z) && Math.abs(p.x) < 80 && Math.abs(p.z) < 80;
  const storedStats = source.stats;
  const stats = {};
  for (let i = 1; i <= 20; i++) {
    const value = storedStats?.[i];
    if (value && typeof value === "object") {
      const fields = value;
      const numeric = (key) => Math.min(999999, Math.max(0, Number(fields[key]) || 0));
      stats[i] = { carrots: numeric("carrots"), hearts: numeric("hearts"), boxes: numeric("boxes") };
    }
  }
  return {
    schema: 9,
    name: String(source.name || "Aventura").slice(0, 40),
    completed,
    unlocked,
    lastLevel: Math.min(unlocked, Math.max(1, Number(source.lastLevel) | 0)),
    stats,
    villagePosition: valid ? { x: p.x, z: p.z } : { x: 0, z: 24 }
  };
}
function status(save, id, trial = false) {
  const slot = slots[id - 1];
  if (!slot) return "locked";
  const s = normalize(save);
  if (!trial && (!s || id > s.unlocked)) return "locked";
  if (!slot.payload) return "upcoming";
  return s?.completed[id - 1] ? "complete" : "open";
}
function complete(save, id, score) {
  const s = normalize(save);
  if (!s || !slots[id - 1]?.payload || !["open", "complete"].includes(status(s, id))) return s;
  s.completed[id - 1] = true;
  s.stats[id] = score;
  s.lastLevel = Math.min(20, id + 1);
  return normalize(s);
}
const Campaign = Object.freeze({ areas, slots, normalize, status, complete });
function createStorage(resolve) {
  const memory = {};
  const read = (key) => {
    try {
      return resolve().getItem(key);
    } catch {
      return memory[key] ?? null;
    }
  };
  const write = (key, value) => {
    memory[key] = value;
    try {
      resolve().setItem(key, value);
      return true;
    } catch {
      return false;
    }
  };
  return {
    read,
    write,
    readJSON(key, fallback) {
      try {
        return JSON.parse(read(key) ?? "null") ?? fallback;
      } catch {
        return fallback;
      }
    }
  };
}
const SAVE_KEY = "BunnyHavoc:v8:saves";
const BACKUP_FORMAT = "BunnyHavocSaveV9";
function createSaveRepository(storage) {
  return {
    load() {
      const raw = storage.readJSON(SAVE_KEY, []);
      const slot = (i) => normalize(Array.isArray(raw) ? raw[i] : null);
      return [slot(0), slot(1), slot(2)];
    },
    write(saves) {
      return storage.write(SAVE_KEY, JSON.stringify(saves));
    },
    backup(saves, settings) {
      return JSON.stringify({ format: BACKUP_FORMAT, saves, settings }, null, 2);
    }
  };
}
const SETTINGS_KEY = "BunnyHavoc:v8:settings";
const DEFAULT_SETTINGS = {
  psx: true,
  quality: "medium",
  music: 0.22,
  sfx: 0.8,
  brightness: 100,
  muted: false
};
function createSettingsStore(storage) {
  const value = { ...DEFAULT_SETTINGS, ...storage.readJSON(SETTINGS_KEY, {}) };
  return {
    value,
    persist: () => storage.write(SETTINGS_KEY, JSON.stringify(value)),
    snapshot: () => ({ ...value })
  };
}
function createMusicController(tracks, settings, context) {
  let resumeVillageMusic = false;
  function playVillageMusic() {
    const scene = context.readScene();
    if (scene.villageMode && scene.ready && !context.document.hidden) tracks.village.play().catch(() => {
    });
  }
  function visibilityChanged() {
    if (context.document.hidden) {
      resumeVillageMusic = context.readScene().villageMode && !tracks.village.paused;
      tracks.village.pause();
    } else if (resumeVillageMusic) {
      resumeVillageMusic = false;
      playVillageMusic();
    }
  }
  context.document.addEventListener("visibilitychange", visibilityChanged);
  function refreshVolume() {
    for (const track of Object.values(tracks)) {
      track.volume = Math.min(1, Math.max(0, settings.value.music));
      track.muted = settings.value.muted;
    }
    context.onVolumeChange(settings.value.muted);
  }
  function toggleMute() {
    settings.value.muted = !settings.value.muted;
    settings.persist();
    refreshVolume();
    context.onMuteChange(settings.value.muted);
  }
  function pauseAll(reset = false) {
    for (const track of Object.values(tracks)) {
      track.pause();
      if (reset) track.currentTime = 0;
    }
  }
  const bridge = {
    getAudio: (id) => tracks[id],
    // Compatibilidade: esse método já era vazio. A fase inicia seu próprio play.
    setTrack: () => {
    },
    toggleMute,
    refreshVolume,
    get current() {
      const scene = context.readScene();
      return scene.villageMode ? "village" : scene.level;
    }
  };
  return {
    bridge,
    refreshVolume,
    toggleMute,
    playVillageMusic,
    pauseAll,
    dispose: () => context.document.removeEventListener("visibilitychange", visibilityChanged)
  };
}
function createLauncherView(document2, window2, frame) {
  let screen = "title", toastTimer;
  const element = (id) => document2.getElementById(id);
  function show(id) {
    for (const name of ["title", "menu", "panel", "results", "loading"]) element(name).classList.toggle("hidden", name !== id);
    screen = id || "";
    if (id) {
      try {
        frame.blur();
        window2.focus();
      } catch {
      }
    }
  }
  return {
    get screen() {
      return screen;
    },
    set screen(value) {
      screen = value;
    },
    show,
    hideAll: () => show(""),
    panel(title, html, hint) {
      element("pt").textContent = title;
      element("pb").innerHTML = html;
      element("ph").textContent = hint || "";
      show("panel");
    },
    toast(message) {
      const node = element("toast");
      node.textContent = message;
      node.classList.add("on");
      window2.clearTimeout(toastTimer);
      toastTimer = window2.setTimeout(() => node.classList.remove("on"), 2200);
    },
    brightness: (value) => {
      frame.style.filter = "brightness(" + value + "%)";
    }
  };
}
function createLauncherPanels(document2, window2, view, actions) {
  const element = (id) => document2.getElementById(id);
  const slotsList = [0, 1, 2];
  const { saves, settings } = actions;
  const escapeHTML = (value) => String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const slotInfo = (i) => {
    const save = saves[i];
    return save ? `<b>ARQUIVO ${i + 1} · ${escapeHTML(save.name)}</b><small>${save.completed.filter(Boolean).length} / 20 destinos · próxima etapa ${save.unlocked}</small>` : `<b>ARQUIVO ${i + 1} · VAZIO</b><small>Nenhum progresso</small>`;
  };
  function slots2(kind) {
    const title = { new: "NOVO JOGO", continue: "CONTINUAR", manage: "ARQUIVOS" }[kind];
    view.panel(title, slotsList.map((i) => `<div class="row ${kind === "continue" && !saves[i] ? "lock" : ""}" data-i="${i}"><div>${slotInfo(i)}</div>${kind === "manage" ? saves[i] ? '<button class="btn alt" data-del="' + i + '">APAGAR</button>' : "" : '<button class="btn" data-go="' + i + '">' + (kind === "new" ? "JOGAR" : "ENTRAR") + "</button>"}</div>`).join("") + (kind === "manage" ? '<button class="btn" id="bk">⬇ BACKUP</button>' : ""), kind === "new" ? "Escolha um arquivo para guardar seu progresso." : kind === "continue" && !saves.some(Boolean) ? "Nenhum arquivo salvo ainda. Comece em NOVO JOGO." : "");
    element("pb").querySelectorAll("[data-go]").forEach((button) => button.onclick = () => {
      const i = +button.dataset.go;
      if (kind === "new") {
        if (saves[i] && !window2.confirm("Substituir o arquivo " + (i + 1) + "?")) return;
        actions.createGame(i);
      }
      actions.enterSave(i);
    });
    element("pb").querySelectorAll("[data-del]").forEach((button) => button.onclick = () => {
      const i = +button.dataset.del;
      if (window2.confirm("Apagar o arquivo " + (i + 1) + "?")) {
        actions.deleteGame(i);
        slots2("manage");
      }
    });
    const backup = document2.getElementById("bk");
    if (backup) backup.onclick = () => {
      const url = URL.createObjectURL(new Blob([actions.backup()], { type: "application/json" })), anchor = document2.createElement("a");
      anchor.href = url;
      anchor.download = "BunnyHavoc_Backup.json";
      anchor.click();
      window2.setTimeout(() => URL.revokeObjectURL(url), 2e3);
    };
  }
  function levels() {
    view.panel("ESCOLHER FASE", [1, 2].map((i) => `<div class="row"><div><b>FASE ${i} · ${actions.names[i]}</b><small>Modo treino: não altera seu save</small></div><button class="btn" data-l="${i}">JOGAR</button></div>`).join(""), "Mais fases em breve.");
    element("pb").querySelectorAll("[data-l]").forEach((button) => button.onclick = () => actions.startTrial(+button.dataset.l));
  }
  function options() {
    view.panel("OPÇÕES", `<div class="opt"><span>Música</span><input id="o1" type="range" min="0" max="100" value="${Math.round(settings.music * 100)}"></div><div class="opt"><span>Efeitos</span><input id="o2" type="range" min="0" max="100" value="${Math.round(settings.sfx * 100)}"></div><div class="opt"><span>Brilho</span><input id="o3" type="range" min="60" max="140" value="${settings.brightness}"></div><div class="opt"><span>Filtro PS1</span><button class="btn alt" id="o4">${settings.psx ? "LIGADO" : "DESLIGADO"}</button></div><div class="opt"><span>Qualidade</span><button class="btn alt" id="o5">${settings.quality.toUpperCase()}</button></div>`, "O filtro PS1 e a qualidade valem na próxima vez que você iniciar uma fase.");
    element("o1").oninput = (event) => {
      settings.music = Number(event.target.value) / 100;
      actions.persistSettings();
      actions.refreshVolume();
    };
    element("o2").oninput = (event) => {
      settings.sfx = Number(event.target.value) / 100;
      actions.persistSettings();
    };
    element("o3").oninput = (event) => {
      settings.brightness = +event.target.value;
      actions.persistSettings();
      actions.bright();
    };
    element("o4").onclick = (event) => {
      settings.psx = !settings.psx;
      event.target.textContent = settings.psx ? "LIGADO" : "DESLIGADO";
      actions.persistSettings();
    };
    element("o5").onclick = (event) => {
      const qualities = ["low", "medium", "high"];
      settings.quality = qualities[(qualities.indexOf(settings.quality) + 1) % 3];
      event.target.textContent = settings.quality.toUpperCase();
      actions.persistSettings();
    };
  }
  function act(action) {
    if (action === "new") slots2("new");
    else if (action === "continue") slots2("continue");
    else if (action === "saves") slots2("manage");
    else if (action === "levels") levels();
    else if (action === "options") options();
    else if (action === "village") slots2(saves.some(Boolean) ? "continue" : "new");
  }
  element("pback").onclick = () => view.show("menu");
  return { act, slots: slots2, levels, options };
}
function createLauncherNavigation(document2, window2, view, actions) {
  const menu = document2.getElementById("mlist");
  let index = 0;
  function select(i) {
    const items = [...menu.children];
    index = (i + items.length) % items.length;
    items.forEach((button, j) => button.classList.toggle("sel", j === index));
  }
  menu.addEventListener("mouseover", (event) => {
    const button = event.target.closest(".item");
    if (button) select([...menu.children].indexOf(button));
  });
  menu.addEventListener("click", (event) => {
    const button = event.target.closest(".item");
    if (button) actions.act(button.dataset.a);
  });
  function toMenu() {
    if (view.screen === "title") {
      view.show("menu");
      select(0);
    }
  }
  document2.getElementById("title").onclick = toMenu;
  window2.addEventListener("keydown", (event) => {
    if (view.screen === "title" && (event.code === "Enter" || event.code === "Space")) {
      event.preventDefault();
      toMenu();
    } else if (view.screen === "menu") {
      if (event.code === "ArrowDown" || event.code === "KeyS") {
        event.preventDefault();
        select(index + 1);
      } else if (event.code === "ArrowUp" || event.code === "KeyW") {
        event.preventDefault();
        select(index - 1);
      } else if (event.code === "Enter" || event.code === "Space") {
        event.preventDefault();
        menu.children[index].click();
      }
    } else if (view.screen === "loading" && actions.ready() && event.code === "Enter") {
      event.preventDefault();
      actions.go();
    } else if (view.screen === "results" && event.code === "Enter") {
      event.preventDefault();
      document2.getElementById(document2.getElementById("rnext").classList.contains("hidden") ? "rmenu" : "rnext").click();
    } else if (view.screen === "panel" && event.code === "Escape") view.show("menu");
    if (event.code === "KeyM" && view.screen !== "") actions.toggleMute();
  });
  return { select, get index() {
    return index;
  } };
}
function createVillageClock(readSession, isHidden) {
  const times = /* @__PURE__ */ new Map();
  function key() {
    const session = readSession();
    return session.trial || session.slot === null ? "trial" : session.slot;
  }
  const bridge = {
    read: () => times.get(key()) || 0,
    advance(dt) {
      const id = key(), before = times.get(id) || 0, session = readSession();
      if (session.villageMode && session.ready && !isHidden() && Number.isFinite(dt) && dt > 0) times.set(id, before + Math.min(0.05, dt));
      return times.get(id) || 0;
    }
  };
  return { bridge, reset: (slot) => times.delete(slot) };
}
function createSceneFlowState() {
  return { level: 0, trial: false, ready: false, seq: 0, villageMode: false };
}
function createSceneFlow(context) {
  const { document: document2, window: window2, frame, scenes, view, state, audio } = context;
  const element = (id) => document2.getElementById(id);
  let timeout, poll;
  function stopWaiting() {
    window2.clearTimeout(timeout);
    window2.clearInterval(poll);
  }
  function menuHome() {
    state.villageMode = false;
    stopWaiting();
    state.level = 0;
    context.resetAttempt();
    state.ready = false;
    state.trial = false;
    audio.pauseAll(true);
    frame.classList.add("hidden");
    scenes.clear(frame);
    element("bar").classList.add("hidden");
    view.show("menu");
    context.selectMenu();
  }
  function loadFail(message) {
    if (state.ready || !state.level) return;
    stopWaiting();
    if (message) console.error("Bunny Havoc loading error:", message);
    element("ls").textContent = "NÃO FOI POSSÍVEL CARREGAR";
    element("le").textContent = "A fase não iniciou. Tente de novo ou volte ao menu.";
    element("lspin").classList.add("hidden");
    element("lfail").classList.remove("hidden");
  }
  function start(id, isTrial) {
    const destination = Campaign.slots[id - 1];
    if (!destination?.payload || !scenes.has(destination.payload)) {
      view.toast("Este destino ainda está em preparação.");
      return;
    }
    if (!isTrial && !["open", "complete"].includes(Campaign.status(context.readSave().save, id))) {
      view.toast("Conclua o destino anterior primeiro.");
      return;
    }
    state.villageMode = false;
    element("bvillage").classList.remove("hidden");
    audio.pauseAll(true);
    state.level = id;
    state.trial = isTrial;
    context.resetAttempt();
    state.ready = false;
    const token = ++state.seq;
    stopWaiting();
    element("lt").textContent = "FASE " + id + " · " + context.names[id];
    loading();
    view.show("loading");
    frame.classList.remove("hidden");
    element("bar").classList.remove("hidden");
    audio.refreshVolume();
    context.bright();
    try {
      scenes.loadPhase(frame, destination.payload, String(token), isTrial);
    } catch (error) {
      loadFail(error);
      return;
    }
    poll = window2.setInterval(inspect, 400);
    timeout = window2.setTimeout(() => {
      if (state.level === id && state.seq === token && !state.ready) loadFail("timeout");
    }, 3e4);
  }
  function loading() {
    element("ls").textContent = "CARREGANDO";
    element("le").textContent = "";
    element("lspin").classList.remove("hidden");
    element("lready").classList.add("hidden");
    element("lfail").classList.add("hidden");
  }
  function inspect() {
    if (!state.level || state.ready || !scenes.isCurrent(frame)) return;
    try {
      const document22 = frame.contentDocument;
      if (!document22) return;
      const button = document22.getElementById("ov");
      const child = frame.contentWindow;
      if (document22.querySelector("canvas") && typeof button?.onclick === "function" && child?.THREE?.WebGLRenderer) stageReady();
    } catch {
    }
  }
  function stageReady() {
    if (!state.level || state.ready) return;
    state.ready = true;
    stopWaiting();
    element("ls").textContent = "PRONTO!";
    element("lspin").classList.add("hidden");
    element("lready").classList.remove("hidden");
  }
  function go() {
    if (!state.ready) return;
    try {
      const button = frame.contentDocument?.getElementById("ov");
      if (typeof button?.onclick !== "function") {
        view.toast("Os controles ainda não estão prontos.");
        return;
      }
      button.onclick(new MouseEvent("click"));
      view.hideAll();
      frame.contentWindow?.focus();
    } catch {
      view.toast("Falha iniciando a fase.");
    }
  }
  function enterVillage() {
    stopWaiting();
    audio.pauseAll(true);
    state.level = 0;
    context.resetAttempt();
    state.ready = false;
    state.villageMode = true;
    const token = String(++state.seq), save = context.readSave();
    const hubTrial = state.trial || save.slot === null;
    element("lt").textContent = "VILA DOS ANIMAIS";
    loading();
    view.show("loading");
    frame.classList.remove("hidden");
    element("bar").classList.add("hidden");
    element("bvillage").classList.add("hidden");
    context.bright();
    scenes.loadVillage(frame, { token, save: hubTrial ? null : save.save, slot: save.slot, trial: hubTrial, preview: false });
    timeout = window2.setTimeout(() => {
      if (state.villageMode && !state.ready) {
        element("ls").textContent = "NÃO FOI POSSÍVEL ABRIR A VILA";
        element("le").textContent = "Confira sua conexão e tente novamente.";
        element("lspin").classList.add("hidden");
        element("lfail").classList.remove("hidden");
      }
    }, 3e4);
  }
  function requestMenu() {
    if (view.screen === "results" || window2.confirm("Voltar ao menu principal? O progresso desta tentativa será perdido.")) menuHome();
  }
  function receive(event) {
    if (event.source !== frame.contentWindow || !scenes.isCurrent(frame) || !event.data || typeof event.data !== "object") return;
    const data = event.data;
    const type = data.type, ok = !data.token || String(data.token) === String(state.seq);
    if (!ok) return;
    if (type === "bunny-havoc-village-ready") {
      if (state.villageMode && data.token === String(state.seq)) {
        window2.clearTimeout(timeout);
        state.ready = true;
        view.hideAll();
        view.screen = "village";
        element("bar").classList.remove("hidden");
        audio.refreshVolume();
        audio.playVillageMusic();
        frame.contentWindow?.focus();
      }
      return;
    }
    if (type === "bunny-havoc-village-enter") {
      if (!state.villageMode || !state.ready || data.token !== String(state.seq) || data.confirmed !== true) return;
      const save = context.readSave();
      const id = Number(data.id), isTrial = state.trial || save.slot === null;
      if (Campaign.slots[id - 1]?.area !== data.guardianArea) return;
      if (!["open", "complete"].includes(Campaign.status(isTrial ? null : save.save, id, isTrial))) return;
      if (!isTrial) context.rememberPortal(id, data.position);
      start(id, isTrial);
      return;
    }
    if (type === "bunny-havoc-stage-ready") {
      if (state.level === +data.level && ok) stageReady();
    } else if (type === "bunny-havoc-stage-error") {
      if (state.level === +data.level && ok) console.error("Erro da fase:", data.detail || "desconhecido");
      loadFail();
    } else if (type === "bunny-havoc-open-menu") requestMenu();
    else if (type === "bunny-havoc-fase1-concluida" && state.level === 1) context.complete(1, data);
    else if (type === "bunny-havoc-fase2-concluida" && state.level === 2) context.complete(2, data);
  }
  element("lready").onclick = go;
  element("lretry").onclick = () => state.villageMode ? enterVillage() : start(state.level, state.trial);
  element("lback").onclick = menuHome;
  element("bmenu").onclick = requestMenu;
  element("bvillage").onclick = enterVillage;
  window2.addEventListener("message", receive);
  return { start, go, enterVillage, menuHome };
}
function startLauncher() {
  const $ = (id) => document.getElementById(id), storage = createStorage(() => localStorage), repository = createSaveRepository(storage);
  const settingsStore = createSettingsStore(storage), settings = settingsStore.value;
  const saves = repository.load();
  const persist = () => repository.write(saves), persistSet = settingsStore.persist;
  const tracks = { 1: $("music1"), 2: $("music2"), village: $("villageMusic") }, frame = $("game");
  const NAMES = ["", "BOSQUE VERDE", "SELVA DE PINHEIROS"];
  const STORY = { 1: "Bunnyldu foi capturado! Bibibunn fugiu rumo à Selva de Pinheiros.", 2: "Bunnyck descobriu que a barragem foi sabotada. A Fase 3 ainda está em construção." };
  let activeSlot = null, pending = null;
  const session = createSceneFlowState();
  const clock = createVillageClock(() => ({ slot: activeSlot, trial: session.trial, villageMode: session.villageMode, ready: session.ready }), () => document.hidden);
  window.BunnyHavocVillageClock = clock.bridge;
  const view = createLauncherView(document, window, frame), { toast, show } = view;
  const audio = createMusicController(tracks, settingsStore, {
    document,
    readScene: () => session,
    onVolumeChange: (muted) => {
      $("bmusic").textContent = muted ? "🔇" : "🔊";
    },
    onMuteChange: (muted) => toast(muted ? "Música silenciada" : "Música ativada")
  });
  const { refreshVolume, toggleMute } = audio;
  window.BunnyHavocAudio = audio.bridge;
  window.BunnyHavocSettings = { get: settingsStore.snapshot };
  const bright = () => view.brightness(settings.brightness);
  const scenes = window.BunnyHavocScenes;
  const panels = createLauncherPanels(document, window, view, {
    saves,
    settings,
    names: NAMES,
    createGame: (i) => {
      saves[i] = Campaign.normalize({ schema: 9, name: "Aventura " + (i + 1), completed: [] });
      clock.reset(i);
      persist();
    },
    enterSave: (i) => {
      activeSlot = i;
      session.trial = false;
      flow.enterVillage();
    },
    deleteGame: (i) => {
      saves[i] = null;
      if (activeSlot === i) activeSlot = null;
      persist();
    },
    startTrial: (i) => {
      activeSlot = null;
      flow.start(i, true);
    },
    backup: () => repository.backup(saves, settings),
    persistSettings: persistSet,
    refreshVolume,
    bright
  });
  const navigation = createLauncherNavigation(document, window, view, { act: panels.act, ready: () => session.ready, go: () => flow.go(), toggleMute });
  const flow = createSceneFlow({
    document,
    window,
    frame,
    scenes,
    view,
    state: session,
    names: NAMES,
    audio,
    bright,
    readSave: () => ({ slot: activeSlot, save: saves[activeSlot] ?? null }),
    resetAttempt: () => {
      pending = null;
    },
    selectMenu: () => navigation.select(navigation.index),
    rememberPortal: (id, position) => {
      saves[activeSlot] = Campaign.normalize({ ...saves[activeSlot], villagePosition: position, lastLevel: id });
      persist();
    },
    complete: result
  });
  $("bmusic").onclick = toggleMute;
  function result(i, d) {
    if (pending?.level === i) return;
    audio.pauseAll();
    const sc = { carrots: Math.max(0, +d.carrots || 0), hearts: Math.max(0, +d.hearts || 0), boxes: Math.max(0, +d.boxes || 0) };
    pending = { level: i, score: sc };
    $("rt").textContent = "FASE " + i + " COMPLETA!";
    $("rs").textContent = STORY[i];
    $("rst").innerHTML = `<span>🥕 ${sc.carrots}</span><span>❤️ ${sc.hearts}</span><span>📦 ${sc.boxes}</span>`;
    let fb = "Modo treino: nada foi salvo.";
    if (!session.trial && activeSlot !== null && saves[activeSlot]) {
      saves[activeSlot] = Campaign.complete(saves[activeSlot], i, sc);
      fb = persist() ? "💾 Progresso salvo no arquivo " + (activeSlot + 1) + "." : "⚠ O navegador bloqueou o salvamento.";
    }
    $("rf").textContent = fb;
    $("rnext").textContent = session.trial ? "PRÓXIMA FASE ▶" : "VOLTAR À VILA";
    $("rnext").classList.toggle("hidden", session.trial && i >= 2);
    show("results");
    $("bar").classList.add("hidden");
  }
  $("rnext").onclick = () => {
    const i = pending?.level;
    if (!session.trial) flow.enterVillage();
    else if (i && i < 2) flow.start(i + 1, true);
  };
  $("rmenu").onclick = flow.menuHome;
  refreshVolume();
  bright();
  show("title");
}
const scenePaths = {
  phase1: "scenes/phase1.html",
  phase2: "scenes/phase2.html",
  village: "scenes/village.html"
};
function createSceneLoader(base) {
  const sessions = /* @__PURE__ */ new WeakMap();
  function navigate(frame, session) {
    const snapshot = structuredClone(session);
    sessions.set(frame, snapshot);
    frame.dataset.loadToken = snapshot.token;
    frame.dataset.bhScene = snapshot.scene;
    frame.removeAttribute("srcdoc");
    const url = new URL(scenePaths[snapshot.scene], base);
    url.searchParams.set("bh-session", snapshot.token);
    frame.src = url.href;
  }
  function isCurrent(frame) {
    const session = sessions.get(frame);
    if (!session) return false;
    try {
      const actual = new URL(frame.contentWindow.location.href);
      const expected = new URL(scenePaths[session.scene], base);
      return actual.origin === expected.origin && actual.pathname === expected.pathname && actual.searchParams.get("bh-session") === session.token;
    } catch {
      return false;
    }
  }
  return Object.freeze({
    has(key) {
      return Object.hasOwn(scenePaths, key);
    },
    loadPhase(frame, scene, token, trial) {
      navigate(frame, { scene, token, trial });
    },
    loadVillage(frame, state) {
      navigate(frame, { scene: "village", token: state.token, state });
    },
    readSession(frame, scene, token) {
      const session = sessions.get(frame);
      if (!session || !isCurrent(frame) || session.scene !== scene || session.token !== token) return void 0;
      return structuredClone(session);
    },
    isCurrent,
    clear(frame) {
      sessions.delete(frame);
      delete frame.dataset.loadToken;
      delete frame.dataset.bhScene;
      frame.removeAttribute("srcdoc");
      frame.src = "about:blank";
    }
  });
}
window.BunnyHavocScenes = createSceneLoader(new URL("./", location.href));
startLauncher();
//# sourceMappingURL=index-BpqcOHlP.js.map
