# Bunny Havoc — projeto completo atual para Godot 4.7

Extraia em uma pasta nova e importe `project.godot` pelo Godot 4.7.
**F5 joga. Para assistir direto: `PreviaFinal.tscn` + F6; R repete.**
A pasta inclui todas as atualizações anteriores. Validação no Godot 4.7.2,
renderer Compatibility. Instruções e controles em `LEIA-ME.txt`.

A cutscene de Bunnyldu e Bibibunn agora usa poses por situação, olhares entre
os personagens, gestos com preparação e repouso, reações pontuais à magia e
à jaula, recuperação após o golpe e passada baseada no deslocamento da fuga.
Piscadas e movimento de boca reutilizam as peças do modelo. A boca acompanha
o envelope do áudio original; não é captura facial nem sincronização fonética.
As transições locais são amostradas e misturadas de forma determinística.
Nenhuma malha ou áudio foi reexportado. Raízes dos atores, trajetória da jaula
e braço de sustentação da Bibi continuam com a coreografia original.

A importação 4.7.2 pode deixar o uso de COLOR_0 desativado nos materiais.
`Fase1/cores_vertices.gd` reativa as cores existentes nas cenas de cenário,
inclusive na vegetação instanciada, no editor e em execução. A geometria não muda.

A base da cena permanece em `Fase1/Completa/final.json.gz`, `Final.glb` e
`final.wav`. A direção fica em `Fase1/Completa/Cinema`: atuação, transições,
rig, envelope da fala, planos, luzes e áudio complementar. Enter revela e
avança as falas; luzes, volume, aves e controle são restaurados ao sair.

O Bosque Verde inclui o percurso completo, sete vãos grandes/checkpoints/
plataformas, 19 inimigos da fonte mais o urso aprovado, 14 NPCs, 13 caixas e
três segredos. Há saúde de três corações, combo, dano/arremesso, coleta e save.
Câmera e janela de salto da atualização 005 foram mantidas. Céu: energia 1.5.
As cenas reutilizáveis e exemplos continuam disponíveis para criar fases.
A Vila e a Fase 2 ainda não fazem parte da migração nativa. As tocas bônus
permanecem desativadas como na fonte. O jogo web original é preservado no repo.

F2 alterna o pacote PSX enviado pelo usuário com o visual original; começa
ligado. Shaders originais CC0 de Francisco Cidade em `addons/psx_shader`.
O adaptador conserva cores/texturas e restaura os materiais ao desligar.
Ajustes em `Fase1Trecho.tscn` > `FiltroPS1`: Ativado, Tamanho Pixel (3 padrão,
2 mais definido), Materiais 3d e Dithering. As mudanças valem ao reiniciar.
HUD e legendas ficam acima do filtro; materiais PSX não recebem sombras,
conforme o shader fornecido. A renderização 3D continua na resolução normal.

`export_presets.cfg` prepara Windows e Web. Instale os templates da mesma
versão do editor. Nesta entrega foram validados importação e execução Linux;
as exportações Windows/Web não foram executadas nem é teste na GPU do usuário.

Geradores no repositório: `tools/export_godot_phase1.cjs --rig-only` extrai os
nomes de pivôs sem reexportar geometria. O envelope vem do RMS de `final.wav`.
`tools/package_godot.py --cinema47` inclui fontes versionadas e manifesto SHA256,
sem caches de importação. `tools/test_godot_full.py` testa o ZIP independente.
