# Atualização 008 — habitantes e bosque vivos

Aplicar sobre o projeto completo Godot 4.7 entregue anteriormente, na pasta
de `project.godot`, com o editor fechado. Reabrir e jogar com F5.

Os 14 NPCs mantêm a orientação de descanso e suas atividades. A cabeça segue
o jogador suavemente dentro de 8 m, com giro limitado, inclusive no diálogo;
quando ele se afasta, volta à pose da atividade. O Vixxo recebeu um pivô de
pescoço montado com as próprias peças do GLB, sem mudar suas malhas.

Besouros: passada ligada ao deslocamento, bola rolando pela distância e antenas
atentas. Lagartos: respiração/farejo, passada diagonal, mandíbula, preparação
do bote e recuperação. Urso: atenção com a cabeça e farejo em quatro patas.
IA, velocidades, tempos de ataque, dano, HP, colisores e mortes foram mantidos.

Vento discreto na vegetação existente, sem desmontar o instancing. Atualiza
plantas próximas em 20 Hz, com pivô na base; árvores quase não inclinam,
folhas/flores/samambaias respondem mais. Pássaros fazem curvas e planeiam.
68 detalhes em 17 composições nas margens: samambaias com folhas dobradas,
troncos facetados com anéis e casca, raízes e folhas caídas, junto a cogumelos.
São cenas reutilizáveis em `Cenas/Natureza/Detalhes`, com malhas compartilhadas.
Os apoios seguem a inclinação original do terreno. Oito borboletas aparecem
perto do jogador e ficam ocultas na cutscene. Nenhum detalhe novo tem colisão.
A trilha, plataformas, itens, cutscene, céu 1.5 e shader PSX foram preservados.

Para editar: `Fase1/Vida/VidaBosque.tscn` contém as composições. `Vento Ativo`
em cada Vegetacao liga/desliga a animação das plantas. Testado no Godot 4.7.2.

# Referência do projeto completo Godot 4.7

Extraia em uma pasta nova e importe `project.godot` pelo Godot 4.7.
**F5 joga. Para assistir direto: `PreviaFinal.tscn` + F6; R repete.**
A pasta inclui todas as atualizações anteriores. Validação no Godot 4.7.2,
renderer Compatibility. Instruções e controles em `LEIA-ME.txt`.

A cutscene de Bunnyldu e Bibibunn agora usa poses por situação, olhares entre
os personagens, gestos com preparação e repouso, reações pontuais à magia e
à jaula, recuperação após o golpe e passada baseada no deslocamento da fuga.
Piscadas e movimento de boca reutilizam as peças do modelo. A boca acompanha
o envelope do áudio original; não é captura facial nem sincronização fonética.
As transições locais são amostradas e misturadas de forma determinística.
Nenhuma malha ou áudio foi reexportado. Raízes dos atores, trajetória da jaula
e braço de sustentação da Bibi continuam com a coreografia original.

A importação 4.7.2 pode deixar o uso de COLOR_0 desativado nos materiais.
`Fase1/cores_vertices.gd` reativa as cores existentes nas cenas de cenário,
inclusive na vegetação instanciada, no editor e em execução. A geometria não muda.

A base da cena permanece em `Fase1/Completa/final.json.gz`, `Final.glb` e
`final.wav`. A direção fica em `Fase1/Completa/Cinema`: atuação, transições,
rig, envelope da fala, planos, luzes e áudio complementar. Enter revela e
avança as falas; luzes, volume, aves e controle são restaurados ao sair.

O Bosque Verde inclui o percurso completo, sete vãos grandes/checkpoints/
plataformas, 19 inimigos da fonte mais o urso aprovado, 14 NPCs, 13 caixas e
três segredos. Há saúde de três corações, combo, dano/arremesso, coleta e save.
Câmera e janela de salto da atualização 005 foram mantidas. Céu: energia 1.5.
As cenas reutilizáveis e exemplos continuam disponíveis para criar fases.
A Vila e a Fase 2 ainda não fazem parte da migração nativa. As tocas bônus
permanecem desativadas como na fonte. O jogo web original é preservado no repo.

F2 alterna o pacote PSX enviado pelo usuário com o visual original; começa
ligado. Shaders originais CC0 de Francisco Cidade em `addons/psx_shader`.
O adaptador conserva cores/texturas e restaura os materiais ao desligar.
Ajustes em `Fase1Trecho.tscn` > `FiltroPS1`: Ativado, Tamanho Pixel (3 padrão,
2 mais definido), Materiais 3d e Dithering. As mudanças valem ao reiniciar.
HUD e legendas ficam acima do filtro; materiais PSX não recebem sombras,
conforme o shader fornecido. A renderização 3D continua na resolução normal.

`export_presets.cfg` prepara Windows e Web. Instale os templates da mesma
versão do editor. Nesta entrega foram validados importação e execução Linux;
as exportações Windows/Web não foram executadas nem é teste na GPU do usuário.

Geradores no repositório: `tools/export_godot_phase1.cjs --rig-only` extrai os
nomes de pivôs sem reexportar geometria. O envelope vem do RMS de `final.wav`.
`tools/package_godot.py --cinema47` inclui fontes versionadas e manifesto SHA256,
sem caches de importação. `tools/test_godot_full.py` testa o ZIP independente.
