extends Node3D
## Instancing preservado; vento por planta, pivotado na base, só perto da câmera.
@export var otimizar_em_execucao: bool=true
@export var vento_ativo: bool=true
var lotes: int=0
var pecas: int=0
var vento: Array[Dictionary]=[]
var _tempo: float=0
var _acumulado: float=0
var _jogador: Node3D
func _amplitude(planta: Node3D) -> float:
	var nome: String=planta.scene_file_path.get_file()
	if nome=="ArvoreCopaRedonda.tscn":return 0.007
	if nome=="Pinheiro.tscn":return 0.005
	if nome=="Arbusto.tscn":return 0.025
	if nome=="Samambaia.tscn":return 0.085
	if nome.begins_with("Flor") or nome=="TufoGrama.tscn":return 0.10
	return 0
func _ready() -> void:
	if not otimizar_em_execucao:return
	var grupos: Dictionary={}
	for node: MeshInstance3D in $Instancias.find_children("*","MeshInstance3D",true,false):
		if not node.is_visible_in_tree() or node.mesh==null:continue
		var material: Material=node.get_active_material(0)
		var chave: String=str(node.mesh.get_rid())+":"+str(material.get_rid())
		if not grupos.has(chave):grupos[chave]={"mesh":node.mesh,"material":material,"transforms":[],"movimentos":[]}
		var grupo: Dictionary=grupos[chave]
		var base: Transform3D=global_transform.affine_inverse()*node.global_transform
		var planta: Node3D=node
		while planta.get_parent()!=null and planta.get_parent()!=$Instancias:
			if planta.scene_file_path.ends_with(".tscn"):break
			planta=planta.get_parent()
		var amp: float=_amplitude(planta)
		if vento_ativo and amp>0:
			grupo.movimentos.append({"i":grupo.transforms.size(),"base":base,"pivot":to_local(planta.global_position),"z":planta.global_position.z,"fase":planta.global_position.x*0.71+planta.global_position.z*0.23,"amp":amp})
		grupo.transforms.append(base);pecas+=1
	for grupo: Dictionary in grupos.values():
		var multi:=MultiMesh.new();multi.transform_format=MultiMesh.TRANSFORM_3D;multi.mesh=grupo.mesh
		multi.instance_count=grupo.transforms.size()
		for i in multi.instance_count:multi.set_instance_transform(i,grupo.transforms[i])
		var node:=MultiMeshInstance3D.new();node.multimesh=multi;node.material_override=grupo.material
		node.extra_cull_margin=0.30
		add_child(node);lotes+=1
		if not grupo.movimentos.is_empty():vento.append({"node":node,"items":grupo.movimentos})
	$Instancias.visible=false
	set_process(vento_ativo and not vento.is_empty())
func _process(dt: float) -> void:
	_tempo+=dt;_acumulado+=dt
	if _acumulado<0.05:return
	_acumulado=0
	if _jogador==null:
		var cena: Node=get_tree().current_scene
		if cena!=null:_jogador=cena.get_node_or_null("Jogador")
	for grupo: Dictionary in vento:
		for item: Dictionary in grupo.items:
			if _jogador!=null and absf(item.z-_jogador.global_position.z)>55:continue
			(grupo.node as MultiMeshInstance3D).multimesh.set_instance_transform(int(item.i),pose_vento(item))
func pose_vento(item: Dictionary) -> Transform3D:
	var onda: float=sin(_tempo*1.35+item.fase)*0.65+sin(_tempo*0.47+item.fase*0.21)*0.35
	var b:=Basis(Vector3(0.8,0,0.6),onda*float(item.amp))
	var original: Transform3D=item.base
	return Transform3D(b*original.basis,item.pivot+b*(original.origin-item.pivot))
