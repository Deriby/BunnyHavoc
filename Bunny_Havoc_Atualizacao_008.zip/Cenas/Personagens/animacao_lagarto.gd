extends RefCounted
## Respiração, farejo, apoio diagonal e poses de bote; não altera a IA/colisão.
var corpo: Node3D
var cabeca: Node3D
var cauda: Node3D
var boca: Node3D
var pernas: Array[Node3D]
var _origens: Dictionary={}
var _ultimo: Vector3
var _passada: float=0
var _atividade: float=0
func configurar(c: Node3D,h: Node3D,t: Node3D,p: Array[Node3D],pos: Vector3) -> void:
	corpo=c;cabeca=h;cauda=t;pernas=p;boca=h.find_child("Mandibula",true,false)
	for n in [corpo,cabeca,cauda,boca]+pernas:
		if n!=null:_origens[n]=n.transform
	_ultimo=pos
func _restaurar_membros() -> void:
	for n in [cabeca,cauda,boca]+pernas:
		if n!=null:n.transform=_origens[n]
func atualizar(dt: float,pos: Vector3,estado: String,idade: float,tempo: float,perseguindo: bool) -> void:
	var dist: float=Vector2(pos.x-_ultimo.x,pos.z-_ultimo.z).length();_ultimo=pos
	_passada+=minf(dist,0.3)*8.0
	_atividade=move_toward(_atividade,clampf(dist/maxf(dt,0.001),0,1),dt*8)
	corpo.transform=_origens[corpo];_restaurar_membros()
	var sniff: float=sin(PI*clampf((fposmod(tempo,6.4)-1.0)/0.8,0,1)) if not perseguindo else 0
	corpo.position.y=sin(tempo*2.6)*0.012+absf(sin(_passada))*0.04*_atividade
	corpo.rotation.z=sin(_passada)*0.028*_atividade
	cabeca.rotation.x=-0.09 if perseguindo else sniff*0.14
	cabeca.rotation.y=sin(tempo*1.5)*0.08*(1.0 if not perseguindo else 0.25)
	cauda.rotation.y=sin(_passada*0.7+tempo*1.4)*0.25
	cauda.rotation.x=sin(tempo*2.2)*0.045
	if boca!=null:boca.rotation.x=0.025+maxf(0,sin(tempo*2.6))*0.035
	for i in pernas.size():
		var ph: float=_passada+([0.0,PI,PI,0.0][i])
		pernas[i].rotation.x=sin(ph)*(0.54 if perseguindo else 0.34)*_atividade
		pernas[i].position.y+=maxf(0,cos(ph))*0.035*_atividade
	if estado=="windup":
		var u: float=smoothstep(0,0.32,idade)
		corpo.position.y-=0.10*u;corpo.rotation.x=-0.10*u
		corpo.scale=Vector3(1+0.025*u,1-0.07*u,1+0.025*u)
		cabeca.rotation.x=0.18*u
		for i in pernas.size():pernas[i].rotation.x=(0.27 if i%2 else -0.27)*u
		if boca!=null:boca.rotation.x=0.06+0.25*u
	elif estado=="lunge":
		corpo.rotation.x=-0.13
		cabeca.rotation.x=-0.15
		cauda.rotation.y*=0.35
		if boca!=null:boca.rotation.x=0.35
	elif estado=="recover":
		var fim: float=1.0-smoothstep(0,0.50,idade)
		corpo.position.y-=0.07*fim
		cabeca.rotation.x=0.14*fim
		if boca!=null:boca.rotation.x=0.025+0.18*fim
func dano(u: float) -> void:
	_restaurar_membros()
	var arco: float=sin(u*PI)
	for i in pernas.size():pernas[i].rotation.x=(0.50 if i%2 else -0.45)*arco
	cabeca.rotation.x=-0.24*arco
	cauda.rotation.y=0.30*arco
	if boca!=null:boca.rotation.x=0.25*arco
func reiniciar(pos: Vector3) -> void:
	_ultimo=pos;_passada=0;_atividade=0
	for n in _origens:n.transform=_origens[n]
