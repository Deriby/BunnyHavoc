extends CanvasLayer
## Pacote PSX enviado pelo usuário: shader de tela e materiais 3D originais.
const Materiais=preload("materiais_psx.gd")
var materiais: RefCounted=Materiais.new()
@export var ativado: bool = true:
	set(value):
		if ativado==value:return
		ativado=value
		if is_node_ready():_aplicar()
@export_range(1.0,8.0,0.5) var tamanho_pixel: float=3.0
@export var materiais_3d: bool=true
@export_range(0.0,1.0,0.05) var dithering: float=1.0

func _ready() -> void:
	var material: ShaderMaterial=$Tela.material.duplicate()
	material.set_shader_parameter("screen_pixel_size",tamanho_pixel)
	material.set_shader_parameter("screen_dither",dithering)
	$Tela.material=material
	materiais.pixel_size=tamanho_pixel
	get_tree().node_added.connect(_novo_no)
	_aplicar()

func _aplicar() -> void:
	$Tela.visible=ativado
	if ativado and materiais_3d:
		materiais.iniciar(get_parent())
	else:
		materiais.parar()

func _novo_no(node: Node) -> void:
	if ativado and materiais_3d and (node is MeshInstance3D or node is MultiMeshInstance3D):
		_adicionar.call_deferred(node)
func _adicionar(node: Node) -> void:
	if is_instance_valid(node) and ativado and get_parent().is_ancestor_of(node):
		materiais.adicionar(node)
func _process(dt: float) -> void:
	if ativado and materiais_3d:materiais.atualizar(dt)
func _exit_tree() -> void:
	materiais.parar()
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F2 or event.keycode==KEY_F2):
		ativado=not ativado
		get_viewport().set_input_as_handled()
