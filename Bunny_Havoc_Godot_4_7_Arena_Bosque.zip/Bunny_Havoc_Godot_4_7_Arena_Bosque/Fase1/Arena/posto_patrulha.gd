extends RefCounted
## Ponto de vigia com sino e insígnia: explica a presença da patrulha.
static func montar(arena: Node3D) -> void:
	var raiz:=Node3D.new();raiz.name="PostoDaPatrulha";arena.add_child(raiz)
	var st:=SurfaceTool.new();st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var mat:=StandardMaterial3D.new();mat.vertex_color_use_as_albedo=true
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_PER_VERTEX;mat.specular_mode=BaseMaterial3D.SPECULAR_DISABLED;st.set_material(mat)
	for d in [
		[Vector3(6.9,1.7,-6.7),Vector3(.22,3.4,.22),Color("725334"),0],
		[Vector3(6.2,3.25,-6.7),Vector3(1.6,.2,.25),Color("725334"),0],
		[Vector3(6.0,2.9,-6.7),Vector3(.07,.55,.07),Color("c4a476"),0],
		[Vector3(6.0,2.52,-6.7),Vector3(.63,.48,.50),Color("d5ae54"),0],
		[Vector3(6.0,2.30,-6.7),Vector3(.76,.12,.59),Color("b88b3c"),0],
		[Vector3(-6.8,1.7,-8.5),Vector3(.20,3.4,.20),Color("725334"),0],
		[Vector3(-6.2,2.72,-8.5),Vector3(1.2,1.0,.08),Color("6d2557"),0],
		[Vector3(-6.2,2.80,-8.43),Vector3(.36,.36,.05),Color("f177b8"),PI/4],
		[Vector3(-6.8,.2,-8.5),Vector3(.7,.40,.6),Color("695f50"),0],
		[Vector3(6.9,.2,-6.7),Vector3(.7,.40,.6),Color("695f50"),0]]:
		var box:=BoxMesh.new();box.size=d[1]
		var arrays: Array=box.surface_get_arrays(0);var vertices: PackedVector3Array=arrays[Mesh.ARRAY_VERTEX]
		var indices: PackedInt32Array=arrays[Mesh.ARRAY_INDEX]
		var b:=Basis(Vector3.FORWARD,d[3])
		for index in indices:
			st.set_color(d[2]);st.set_normal(b*arrays[Mesh.ARRAY_NORMAL][index]);st.add_vertex(b*vertices[index]+d[0])
	st.index();var visual:=MeshInstance3D.new();visual.mesh=st.commit();visual.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF;raiz.add_child(visual)
