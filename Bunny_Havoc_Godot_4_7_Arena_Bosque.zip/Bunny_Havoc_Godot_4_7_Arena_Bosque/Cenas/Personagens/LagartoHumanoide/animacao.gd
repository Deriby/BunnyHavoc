extends RefCounted
## Passada bípede, guarda, preparação e soco; compartilha o contrato da fauna.
var corpo: Node3D
var cabeca: Node3D
var cauda: Node3D
var boca: Node3D
var membros: Array[Node3D]
var bases: Dictionary={}
var ultimo: Vector3
var passada: float=0
func configurar(c: Node3D,h: Node3D,t: Node3D,p: Array[Node3D],pos: Vector3) -> void:
	corpo=c;cabeca=h;cauda=t;boca=h.get_node("Mandibula");membros=p;ultimo=pos
	for n in [corpo,cabeca,cauda,boca]+membros:bases[n]=n.transform
func restaurar() -> void:
	for n in bases:n.transform=bases[n]
func atualizar(dt: float,pos: Vector3,estado: String,idade: float,tempo: float,perseguindo: bool) -> void:
	var dist: float=Vector2(pos.x-ultimo.x,pos.z-ultimo.z).length();ultimo=pos
	passada+=minf(dist,.25)*7
	var andando: float=clampf(dist/maxf(.001,dt),0,1)
	restaurar()
	corpo.position.y+=absf(sin(passada))*andando*.045+sin(tempo*3)*.012
	corpo.rotation.z=sin(passada)*andando*.035
	for i in 2:
		membros[i].rotation.x=sin(passada+i*PI)*.6*andando
		membros[i+2].rotation.x=-.25-sin(passada+i*PI)*.35*andando
		membros[i+2].rotation.z=(.08 if i==0 else -.08)
	cauda.rotation.y=sin(passada*.5+tempo)*.17
	cabeca.rotation.y=sin(tempo*1.4)*(.025 if perseguindo else .10)
	if estado=="stalk":
		corpo.rotation.x=-.09;membros[2].rotation.x=-.85;membros[3].rotation.x=-.65
	elif estado=="windup":
		var u: float=smoothstep(0,.32,idade)
		corpo.rotation.y=-.35*u;corpo.position.y-=.09*u
		membros[2].rotation.x=-.8;membros[3].rotation.x=.75*u;membros[3].rotation.z=-.5*u
		cabeca.rotation.y=.25*u;boca.rotation.x=.12*u
	elif estado=="lunge":
		var u: float=sin(clampf(idade/.40,0,1)*PI)
		corpo.rotation.y=.28*u;corpo.rotation.x=-.15
		membros[3].rotation.x=-1.7*u;membros[3].position.z+=.20*u
		membros[2].rotation.x=-.8;membros[0].rotation.x=-.5;membros[1].rotation.x=.5
	elif estado=="recover":
		membros[2].rotation.x=-.35;membros[3].rotation.x=-.5*(1-smoothstep(0,.5,idade))
func dano(u: float) -> void:
	restaurar()
	var a: float=sin(u*PI)
	cabeca.rotation.x=-.3*a;boca.rotation.x=.25*a;cauda.rotation.y=.4*a
	for i in 4:membros[i].rotation.x=(.7 if i%2 else -.7)*a
func reiniciar(pos: Vector3) -> void:
	ultimo=pos;passada=0;restaurar()
