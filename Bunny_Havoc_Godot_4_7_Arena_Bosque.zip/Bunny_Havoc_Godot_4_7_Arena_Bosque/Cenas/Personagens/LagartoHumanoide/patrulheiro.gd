extends "res://Cenas/Personagens/lagarto.gd"
## Variante da patrulha. Reutiliza dano, recuo, golpes e colisões já aprovados.
signal caiu(inimigo: CharacterBody3D)
var arena: Node3D
func _ready() -> void:
	animacao=preload("animacao.gd").new()
	super._ready()
func _patrulhar(dt: float) -> void:
	if is_instance_valid(arena):
		_casa=arena.global_position
		if estado=="stalk" and not arena.pedir_ataque(self):
			estado="patrol";_cool=maxf(_cool,.35)
	super._patrulhar(dt)
func _mover(passo: Vector3) -> void:
	if is_instance_valid(arena):
		var destino: Vector3=global_position+passo-arena.global_position
		destino.y=0
		if destino.length()>arena.raio-1.0:
			var permitido: Vector3=arena.global_position+destino.limit_length(arena.raio-1.0)
			passo=Vector3(permitido.x-global_position.x,0,permitido.z-global_position.z)
	super._mover(passo)
func _contato(vida: Node) -> void:
	# Patrulheiros ferem no ataque anunciado, não por encostar enquanto cercam.
	var guardando: bool=estado=="patrol"
	if guardando:estado="guard"
	super._contato(vida)
	if guardando and estado=="guard":estado="patrol"
func receber_golpe(dano: int,heading: float,finalizador: bool,premiar: bool=true) -> bool:
	var vivo: bool=not derrotado_agora
	var acertou: bool=super.receber_golpe(dano,heading,finalizador,premiar)
	if acertou and vivo and derrotado_agora:caiu.emit(self)
	return acertou
