extends AudioStreamPlayer
## Toca Jump1, Jump2 e Jump3 em sequência quando um salto realmente começa.

signal pulo_tocado

@export var amostras: Array[AudioStream] = []

var _jogador: CharacterBody3D
var _estava_subindo: bool = false
var _proximo_som: int = 0

func _ready() -> void:
	# Também aceita um filho intermediário, como CollisionShape3D.
	var ancestral: Node = get_parent()
	while ancestral != null and not ancestral is CharacterBody3D:
		ancestral = ancestral.get_parent()
	_jogador = ancestral as CharacterBody3D
	if _jogador == null:
		push_warning("Pulos: coloque Pulos.tscn dentro do Jogador (CharacterBody3D).")
		set_physics_process(false)
		return
	if amostras.is_empty():
		var pasta: String = (get_script() as Script).resource_path.get_base_dir()
		for nome in ["Jump1.mp3", "Jump2.mp3", "Jump3.mp3"]:
			var caminho: String = pasta.path_join("audio").path_join(nome)
			if ResourceLoader.exists(caminho):
				var audio := load(caminho) as AudioStream
				if audio != null:
					amostras.append(audio)
	if amostras.is_empty():
		push_warning("Pulos: copie também a pasta audio com Jump1.mp3, Jump2.mp3 e Jump3.mp3.")
		set_physics_process(false)
		return
	_estava_subindo = not _jogador.is_on_floor() and _jogador.velocity.y > 0.1

func _physics_process(_delta: float) -> void:
	var subindo: bool = not _jogador.is_on_floor() and _jogador.velocity.y > 0.1
	var comecou: bool = subindo and not _estava_subindo
	_estava_subindo = subindo
	if not comecou:
		return
	stream = amostras[_proximo_som]
	_proximo_som = (_proximo_som + 1) % amostras.size()
	play()
	pulo_tocado.emit()
