extends RefCounted
## Malhas fixas do player_combat.js original: punho curto, fitas e impacto.

var raiz: Node3D
var punho: Node3D
var luva: Node3D
var fitas: Node3D
var halo: Node3D
var impacto: Node3D
var _mangas: Array[MeshInstance3D] = []
var _riscos: Array[MeshInstance3D] = []
var _cubo := BoxMesh.new()

func _grupo(nome: String, pai: Node3D) -> Node3D:
	var grupo := Node3D.new()
	grupo.name = nome
	grupo.rotation_order = EULER_ORDER_XYZ
	pai.add_child(grupo)
	return grupo

func _peca(pai: Node3D, tamanho: Vector3, material: Material, posicao: Vector3) -> MeshInstance3D:
	var malha := MeshInstance3D.new()
	malha.rotation_order = EULER_ORDER_XYZ
	malha.mesh = _cubo
	malha.material_override = material
	malha.scale = tamanho
	malha.position = posicao
	pai.add_child(malha)
	return malha

func _material(cor: Color, opacidade: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	material.cull_mode = BaseMaterial3D.CULL_DISABLED
	material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	material.albedo_color = Color(cor, opacidade)
	return material

func _anel(pai: Node3D, interno: float, externo: float, segmentos: int, inicio: float, arco: float, material: Material) -> MeshInstance3D:
	var vertices := PackedVector3Array()
	var normais := PackedVector3Array()
	var indices := PackedInt32Array()
	for i in segmentos + 1:
		var angulo: float = inicio + arco * float(i) / segmentos
		for raio in [interno, externo]:
			vertices.append(Vector3(cos(angulo) * raio, sin(angulo) * raio, 0))
			normais.append(Vector3(0, 0, 1))
	for i in segmentos:
		var a: int = i * 2
		indices.append_array(PackedInt32Array([a, a + 2, a + 1, a + 2, a + 3, a + 1]))
	var dados: Array = []
	dados.resize(Mesh.ARRAY_MAX)
	dados[Mesh.ARRAY_VERTEX] = vertices
	dados[Mesh.ARRAY_NORMAL] = normais
	dados[Mesh.ARRAY_INDEX] = indices
	var geometria := ArrayMesh.new()
	geometria.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, dados)
	var malha := MeshInstance3D.new()
	malha.rotation_order = EULER_ORDER_XYZ
	malha.mesh = geometria
	malha.material_override = material
	pai.add_child(malha)
	return malha

func configurar(jogador: Node3D, visual: Node3D) -> void:
	raiz = _grupo("EfeitosCombo", jogador)
	punho = _grupo("Punho", raiz)
	luva = _grupo("Luva", punho)
	impacto = _grupo("Impacto", punho)
	fitas = _grupo("FitasGiro", raiz)
	var preto: Material = (visual.find_child("Peca_01", true, false) as MeshInstance3D).get_active_material(0)
	var branco: Material = (visual.find_child("Peca_02", true, false) as MeshInstance3D).get_active_material(0)
	var roxo: Material = (visual.find_child("Peca_03", true, false) as MeshInstance3D).get_active_material(0)
	for i in 2:
		_mangas.append(_peca(punho, Vector3(0.19, 0.20, 1), preto, Vector3.ZERO))
	_peca(luva, Vector3(0.67, 0.59, 0.65), branco, Vector3.ZERO)
	for i in 3:
		_peca(luva, Vector3(0.22, 0.24, 0.22), branco, Vector3(-0.23 + i * 0.23, 0.16, 0.33))
	_peca(luva, Vector3(0.26, 0.32, 0.34), branco, Vector3(0.37, -0.13, -0.02))
	_peca(luva, Vector3(0.43, 0.40, 0.18), roxo, Vector3(0, -0.02, -0.37))
	var luz_branca: Material = _material(Color("f4f4ff"), 0.75)
	var luz_roxa: Material = _material(Color("933dff"), 0.80)
	var luz_rosa: Material = _material(Color("ff80c8"), 0.75)
	var luz_dourada: Material = _material(Color("ffdf70"), 0.9)
	for i in 3:
		var anel: MeshInstance3D = _anel(fitas, 1.10 + i * 0.06, 1.20 + i * 0.06, 24, i * 0.9, PI * 1.45, luz_roxa if i == 1 else luz_branca)
		anel.position.y = 0.48 + i * 0.37
		anel.rotation.x = -PI / 2.0 + (i - 1) * 0.12
	halo = _grupo("Halo", punho)
	for i in 2:
		_anel(halo, 0.35 + i * 0.09, 0.41 + i * 0.09, 18, i * 0.7, PI * 1.65, luz_branca if i == 1 else luz_roxa)
	for i in 6:
		_riscos.append(_peca(punho, Vector3(0.035, 0.045, 0.65), luz_branca if i % 2 else luz_roxa, Vector3.ZERO))
	for i in 8:
		var angulo: float = i * PI / 4.0
		var raio: MeshInstance3D = _peca(impacto, Vector3(0.055, 0.28 if i % 2 else 0.38, 0.04), luz_branca if i % 3 else luz_dourada, Vector3(sin(angulo) * 0.49, cos(angulo) * 0.49, 0))
		raio.rotation.z = -angulo
	for i in 4:
		var angulo: float = i * PI / 2.0
		var raio: MeshInstance3D = _peca(impacto, Vector3(0.07, 0.30, 0.04), luz_rosa, Vector3(sin(angulo) * 0.24, cos(angulo) * 0.24, 0.025))
		raio.rotation.z = -angulo
	ocultar()

func ocultar() -> void:
	raiz.visible = false
	punho.visible = false
	fitas.visible = false

func giro(progresso: float, direcao: float) -> void:
	raiz.visible = true
	raiz.rotation.y = direcao
	fitas.visible = true
	fitas.rotation.y = progresso * TAU

func soco(etapa: int, progresso: float, forma: Dictionary, corpo_y: float, impacto_restante: float) -> void:
	var drive: float = forma.amount
	var lado: float = forma.side
	raiz.visible = true
	punho.visible = forma.limit > 0.23
	punho.position = Vector3(0, 1.02 + corpo_y, 0)
	var tamanho: float = 0.43 + drive * (0.16 if etapa == 2 else 0.22)
	var alcance_punho: float = minf(0.36 + drive * (0.62 if etapa == 2 else 0.79), maxf(0.02, forma.limit - 0.18))
	luva.position = Vector3(lado * (0.38 - 0.10 * drive), 0.04 * drive, alcance_punho)
	luva.scale = Vector3(lado * tamanho * (1.0 + 0.08 * drive), tamanho * (1.0 - 0.08 * drive), tamanho * (1.0 + 0.14 * drive))
	luva.rotation.z = -lado * 0.12 * drive
	var inicio := Vector3(lado * 0.37, 0, 0)
	var cotovelo := Vector3(lado * (0.44 - 0.13 * drive), -0.12 + 0.13 * drive, alcance_punho * 0.43)
	var fim: Vector3 = luva.position - Vector3(0, 0, 0.12)
	for i in 2:
		var a: Vector3 = cotovelo if i == 1 else inicio
		var b: Vector3 = fim if i == 1 else cotovelo
		var segmento: Vector3 = b - a
		_mangas[i].position = (a + b) * 0.5
		_mangas[i].scale = Vector3(0.19, 0.20, maxf(0.03, segmento.length() + 0.04))
		_mangas[i].quaternion = Quaternion(Vector3(0, 0, 1), segmento.normalized())
	halo.visible = drive > 0.20
	halo.position = Vector3(lado * 0.24, 0.08, forma.reach)
	halo.rotation.z = lado * progresso * PI * 0.8
	halo.scale = Vector3.ONE * (1.28 if etapa == 3 else 0.82) * (0.65 + 0.35 * drive)
	for i in 6:
		_riscos[i].visible = drive > 0.25
		var abertura: float = (1.0 if i % 2 else -1.0) * (0.20 + floori(i / 2.0) * 0.13)
		_riscos[i].position = Vector3(abertura, ((i % 3) - 1) * 0.13, forma.reach * 0.48)
		_riscos[i].scale.z = forma.reach * 0.9 * drive
	impacto.visible = impacto_restante > 0.0
	impacto.position = halo.position
	impacto.scale = Vector3.ONE * (1.12 if etapa == 3 else 0.68)
	impacto.rotation.z = lado * 0.18
