extends RefCounted
## Combo da fonte compartilhada player_combat.js, adaptado à física nativa.
## Dano/arremesso em inimigos serão ligados quando os inimigos forem migrados.

const Efeitos = preload("bunnyck_efeitos_combo.gd")
const DURACOES: Array[float] = [0.30, 0.26, 0.32]
const ALCANCES: Array[float] = [0.0, 1.0, 1.30]
const PASSOS: Array[float] = [0.0, 0.22, 0.28]
const SONS: Array[AudioStream] = [preload("audio/giro.wav"), preload("audio/soco.wav"), preload("audio/soco_final.wav")]
const IMPACTOS: Array[AudioStream] = [preload("audio/impacto.wav"), preload("audio/impacto_final.wav")]

var atacando: bool:
	get:
		return _etapa > 0 and _idade < DURACOES[_etapa - 1]
var girando: bool:
	get:
		return _etapa == 1 and atacando
var estado: Dictionary:
	get:
		var forma: Dictionary = _forma_golpe()
		return {"step": _etapa, "age": _idade, "queued": _fila, "grace": _tolerancia, "serial": _serial, "heading": _direcao, "activeHit": _ativo(), "reach": forma.get("reach", 0.0), "reachLimit": forma.get("limit", 0.0), "travelled": _percorrido, "hitStop": _pausa_impacto}

var _jogador: CharacterBody3D
var _visual: Node3D
var _efeitos: RefCounted = Efeitos.new()
var _bracos: Array[Node3D] = []
var _pernas: Array[Node3D] = []
var _orelhas: Array[Node3D] = []
var _base_posicao: Vector3
var _base_escala: Vector3
var _etapa: int = 0
var _idade: float = 0.0
var _idade_anterior: float = 0.0
var _fila: int = 0
var _tolerancia: float = 0.0
var _direcao: float = 0.0
var _serial: int = 0
var _acertados: Dictionary = {}
var _impacto: float = 0.0
var _pausa_impacto: float = 0.0
var _usou_impacto: bool = false
var _percorrido: float = 0.0
var _possui_pose: bool = false
var _chave_forma: Array = []
var _cache_forma: Dictionary = {}
var _volume_parede := BoxShape3D.new()
var _pronto: bool = false
var _som_golpe: AudioStreamPlayer
var _som_impacto: AudioStreamPlayer

func configurar(jogador: CharacterBody3D, visual: Node3D) -> void:
	if visual == null:
		return
	_jogador = jogador
	_visual = visual
	_bracos = [visual.find_child("Braco_E", true, false) as Node3D, visual.find_child("Braco_D", true, false) as Node3D]
	_pernas = [visual.find_child("Perna_E", true, false) as Node3D, visual.find_child("Perna_D", true, false) as Node3D]
	_orelhas = [visual.find_child("Orelha_E", true, false) as Node3D, visual.find_child("Orelha_D", true, false) as Node3D]
	for pivo in _bracos + _pernas + _orelhas:
		if pivo == null:
			push_warning("Combo do Bunnyck: use o modelo original com pivôs nomeados.")
			return
	_base_posicao = visual.position
	_base_escala = visual.scale
	_direcao = visual.rotation.y
	_volume_parede.size = Vector3(1.16, 0.04, 1.16)
	_efeitos.configurar(jogador, visual)
	_som_golpe = AudioStreamPlayer.new()
	_som_golpe.name = "SomCombo"
	jogador.add_child(_som_golpe)
	_som_impacto = AudioStreamPlayer.new()
	_som_impacto.name = "SomImpactoCombo"
	jogador.add_child(_som_impacto)
	_pronto = true

func _ocultar() -> void:
	_efeitos.ocultar()
	for braco in _bracos:
		braco.visible = true

func _liberar_pose() -> void:
	if not _possui_pose:
		return
	_visual.scale = _base_escala
	_visual.position = _base_posicao
	_visual.rotation.x = 0.0
	_visual.rotation.z = 0.0
	for pivo in _bracos + _pernas:
		pivo.rotation = Vector3.ZERO
	for i in 2:
		_orelhas[i].rotation = Vector3(0, 0, -0.1 if i else 0.1)
	_possui_pose = false

func limpar() -> void:
	if not _pronto:
		return
	_ocultar()
	_liberar_pose()
	if _etapa > 0:
		_visual.rotation.y = _direcao
	_etapa = 0
	_idade = 0.0
	_idade_anterior = 0.0
	_fila = 0
	_tolerancia = 0.0
	_impacto = 0.0
	_pausa_impacto = 0.0
	_chave_forma.clear()
	_acertados.clear()

func _iniciar(etapa: int, eixo: Vector2) -> void:
	_ocultar()
	_liberar_pose()
	_etapa = etapa
	_idade = 0.0
	_idade_anterior = 0.0
	_tolerancia = 0.0
	_impacto = 0.0
	_pausa_impacto = 0.0
	_usou_impacto = false
	_chave_forma.clear()
	_acertados.clear()
	_serial += 1
	if etapa == 1:
		_percorrido = 0.0
		var velocidade: Vector2 = Vector2(_jogador.velocity.x, _jogador.velocity.z)
		_direcao = atan2(velocidade.x, velocidade.y) if velocidade.length() > 0.5 else _visual.rotation.y
	else:
		if eixo.length() > 0.2:
			_direcao = atan2(eixo.x, eixo.y)
		_visual.rotation.y = _direcao
	_som_golpe.stream = SONS[etapa - 1]
	_som_golpe.play()

func pressionar(eixo: Vector2) -> bool:
	if not _pronto:
		return false
	if _etapa == 0:
		_iniciar(1, eixo)
	elif _idade >= DURACOES[_etapa - 1]:
		if _etapa < 3 and _tolerancia > 0.0:
			_iniciar(_etapa + 1, eixo)
	else:
		_fila = mini(3 - _etapa, _fila + 1)
	return true

func atualizar(dt: float, eixo: Vector2) -> void:
	if not _pronto:
		return
	_impacto = maxf(0.0, _impacto - dt)
	_chave_forma.clear()
	if _etapa == 0:
		return
	var duracao: float = DURACOES[_etapa - 1]
	if _idade < duracao:
		_idade_anterior = _idade
		var pausa: float = minf(dt, _pausa_impacto)
		_pausa_impacto -= pausa
		_idade = minf(duracao, _idade + dt - pausa)
		if _etapa > 1:
			_avancar(PASSOS[_etapa - 1] * (_progresso_passo(_idade / duracao) - _progresso_passo(_idade_anterior / duracao)))
		if _etapa == 1:
			_visual.rotation.y = _direcao + _idade / duracao * TAU
		if _idade >= duracao:
			_visual.rotation.y = _direcao
			if _fila > 0 and _etapa < 3:
				_fila -= 1
				_iniciar(_etapa + 1, eixo)
			else:
				_tolerancia = 0.38 if _etapa < 3 else 0.14
	else:
		_tolerancia -= dt
		if _tolerancia <= 0.0:
			limpar()

func _smooth(x: float) -> float:
	var valor: float = clampf(x, 0.0, 1.0)
	return valor * valor * (3.0 - 2.0 * valor)

func _progresso_passo(u: float) -> float:
	return _smooth((u - 0.22) / 0.36)

func _avancar(distancia: float) -> void:
	if distancia <= 0.0 or not _jogador.is_on_floor():
		return
	var espaco: PhysicsDirectSpaceState3D = _jogador.get_world_3d().direct_space_state
	var frente := Vector3(sin(_direcao), 0, cos(_direcao))
	var quantidade: int = ceili(distancia / 0.035)
	var passo: Vector3 = frente * distancia / quantidade
	for i in quantidade:
		var seguinte: Vector3 = _jogador.global_position + passo
		var raio := PhysicsRayQueryParameters3D.create(seguinte + Vector3.UP * 0.30, seguinte - Vector3.UP * 0.30, _jogador.collision_mask, [_jogador.get_rid()])
		var piso: Dictionary = espaco.intersect_ray(raio)
		if piso.is_empty() or absf(piso.position.y - _jogador.global_position.y) > 0.18 or piso.normal.y < cos(_jogador.floor_max_angle):
			break
		if _jogador.test_move(_jogador.global_transform, passo):
			break
		_jogador.global_position = seguinte
		_percorrido += passo.length()

func _extensao(u: float) -> float:
	var preparo: float = 0.25 if _etapa == 3 else 0.18
	if u < preparo:
		return 0.0
	if u < 0.52:
		return 1.0 - pow(1.0 - (u - preparo) / (0.52 - preparo), 3)
	if u < 0.64:
		return 1.0
	return 1.0 - _smooth((u - 0.64) / 0.36)

func _alcance_livre(maximo: float) -> float:
	var consulta := PhysicsShapeQueryParameters3D.new()
	consulta.shape = _volume_parede
	consulta.transform = Transform3D(Basis.IDENTITY, _jogador.global_position + Vector3.UP * 1.05)
	consulta.collision_mask = _jogador.collision_mask
	consulta.exclude = [_jogador.get_rid()]
	var espaco: PhysicsDirectSpaceState3D = _jogador.get_world_3d().direct_space_state
	if not espaco.intersect_shape(consulta, 1).is_empty():
		return 0.0
	consulta.motion = Vector3(sin(_direcao), 0, cos(_direcao)) * maximo
	var resultado: PackedFloat32Array = espaco.cast_motion(consulta)
	return maximo * resultado[0]

func _forma_golpe() -> Dictionary:
	if _etapa < 2 or _idade >= DURACOES[_etapa - 1]:
		return {}
	var chave: Array = [_jogador.global_position, _etapa, _idade, _idade_anterior, _direcao]
	if _chave_forma == chave:
		return _cache_forma
	var quantidade: float = _extensao(_idade / DURACOES[_etapa - 1])
	var anterior: float = _extensao(_idade_anterior / DURACOES[_etapa - 1])
	var limite: float = _alcance_livre(0.60 + ALCANCES[_etapa - 1])
	var alcance: float = minf(limite, 0.60 + ALCANCES[_etapa - 1] * quantidade)
	_cache_forma = {"reach": alcance, "sweep": minf(limite, maxf(alcance, 0.60 + ALCANCES[_etapa - 1] * anterior)), "limit": limite, "amount": quantidade, "width": 0.66 if _etapa == 2 else 0.82, "side": 1.0 if _etapa == 2 else -1.0}
	_chave_forma = chave
	return _cache_forma

func _ativo() -> bool:
	if _etapa == 0:
		return false
	var inicio: float = 0.0 if _etapa == 1 else DURACOES[_etapa - 1] * (0.25 if _etapa == 2 else 0.31)
	var fim: float = 0.26 if _etapa == 1 else DURACOES[_etapa - 1] * 0.84
	return _idade >= inicio and _idade < fim

# Interface para os futuros inimigos: o chamador confere a faixa vertical.
func pode_atingir(alvo: Node3D, raio: float = 1.65) -> bool:
	if not _ativo() or not is_instance_valid(alvo) or _acertados.has(alvo.get_instance_id()):
		return false
	var deslocamento: Vector3 = alvo.global_position - _jogador.global_position
	if _etapa == 1:
		return Vector2(deslocamento.x, deslocamento.z).length() <= raio
	var forma: Dictionary = _forma_golpe()
	if forma.is_empty():
		return false
	var frente: float = deslocamento.x * sin(_direcao) + deslocamento.z * cos(_direcao)
	var lado: float = deslocamento.x * cos(_direcao) - deslocamento.z * sin(_direcao)
	return frente >= -0.15 and frente <= forma.sweep + 0.40 and frente <= forma.limit + 0.40 and absf(lado) <= forma.width

func registrar_acerto(alvo: Node3D) -> void:
	if not _ativo() or not is_instance_valid(alvo) or _acertados.has(alvo.get_instance_id()):
		return
	_acertados[alvo.get_instance_id()] = true
	if _etapa > 1:
		_impacto = 0.12 if _etapa == 3 else 0.08
		if not _usou_impacto:
			_pausa_impacto = 0.032 if _etapa == 3 else 0.012
			_usou_impacto = true
			_som_impacto.stream = IMPACTOS[1 if _etapa == 3 else 0]
			_som_impacto.play()

func golpe_para(alvo: Node3D) -> Dictionary:
	var acertou: bool = _ativo() and is_instance_valid(alvo) and _acertados.has(alvo.get_instance_id())
	var final: bool = _etapa == 3 and acertou
	return {"damage": 2 if final else 1, "finisher": final, "opening": _etapa > 0 and _etapa < 3 and acertou, "heading": _direcao}

func aplicar_pose() -> void:
	if not _pronto:
		return
	_ocultar()
	if not atacando:
		_liberar_pose()
		return
	_possui_pose = true
	var u: float = _idade / DURACOES[_etapa - 1]
	var onda: float = sin(u * PI)
	if _etapa == 1:
		_efeitos.giro(u, _direcao)
		_visual.rotation = Vector3(0.10 * onda, _direcao + u * TAU, sin(u * TAU) * 0.10)
		_visual.position.y = _base_posicao.y + 0.07 * onda
		_visual.scale = _base_escala * Vector3(1.0 + 0.04 * onda, 1.0 - 0.07 * onda, 1.0 + 0.04 * onda)
		for i in 2:
			_bracos[i].rotation = Vector3(-0.25, 0, (1.0 if i else -1.0) * 1.30)
			_pernas[i].rotation = Vector3((-0.40 if i else 0.52) * onda, 0, (0.18 if i else -0.18) * onda)
			_orelhas[i].rotation.x = -0.18 * onda
			_orelhas[i].rotation.z = (-0.1 if i else 0.1) + sin(u * TAU + (1.0 if i else 0.0)) * 0.12
		return
	var forma: Dictionary = _forma_golpe()
	var drive: float = forma.amount
	var lado: float = forma.side
	var braco: int = 1 if _etapa == 2 else 0
	var carga: float = sin(minf(1.0, u / (0.25 if _etapa == 3 else 0.18)) * PI) * (1.0 - drive)
	var forca: float = 1.0 if _etapa == 3 else 0.75
	_visual.rotation = Vector3(0.08 * carga - 0.18 * drive * forca, _direcao + lado * (0.24 * carga - 0.24 * drive) * forca, -lado * 0.09 * drive)
	var corpo_y: float = -0.07 * carga + 0.035 * drive if _jogador.is_on_floor() else 0.0
	_visual.position.y = _base_posicao.y + corpo_y
	_visual.scale = _base_escala * Vector3(1.0 + 0.045 * carga, 1.0 - 0.07 * carga + 0.035 * drive, 1.0 + 0.025 * carga)
	_efeitos.raiz.rotation.y = _direcao
	_efeitos.soco(_etapa, u, forma, corpo_y, _impacto)
	_bracos[braco].visible = not _efeitos.punho.visible
	_bracos[braco].rotation = Vector3(-0.45 - drive * 1.2, 0, lado * 0.06)
	_bracos[1 - braco].rotation = Vector3(-1.1 - 0.20 * carga, lado * 0.15, -lado * 0.25)
	if _jogador.is_on_floor():
		_pernas[braco].rotation = Vector3(-0.46 * drive + 0.18 * carga, 0, lado * 0.14)
		_pernas[1 - braco].rotation = Vector3(0.36 * drive - 0.15 * carga, 0, -lado * 0.14)
	for i in 2:
		_orelhas[i].rotation.x = 0.15 * carga - 0.28 * drive
		_orelhas[i].rotation.z = (-0.1 if i else 0.1) + lado * 0.06 * drive
