extends RefCounted
## Trilho original da Fase 1: enquadramento antecipado do vão e salto/corrida.
var camera: Camera3D
var jogador: CharacterBody3D
var pontos: Array
var olho := Vector3.ZERO
var olhar := Vector3.ZERO
var pronto: bool = false
var ultimo := Vector3.ZERO
var tempo: float = 0.0

func configurar(c: Camera3D, p: CharacterBody3D, anchors: Array) -> void:
	camera = c
	jogador = p
	pontos = anchors

func altura(z: float) -> float:
	if z >= -40.0:
		return 0.0
	return 5.0 * smoothstep(0.0, 1.0, (-40.0 - z) / 40.0)

func amostrar(z: float) -> Dictionary:
	var i: int = 0
	while i < pontos.size() - 2 and z < float(pontos[i + 1].z):
		i += 1
	var a: Dictionary = pontos[i]
	var b: Dictionary = pontos[i + 1]
	var u: float = smoothstep(0.0, 1.0, (float(a.z) - z) / (float(a.z) - float(b.z)))
	var resultado: Dictionary = {}
	for chave in ["h", "dist", "lead", "fov", "side"]:
		resultado[chave] = lerpf(float(a[chave]), float(b[chave]), u)
	return resultado

func atualizar(dt: float) -> void:
	tempo += dt
	var p: Vector3 = jogador.global_position
	var z: float = clampf(p.z, -56.0, 12.0)
	var s: Dictionary = amostrar(z)
	var dz: float = z + 48.0
	var perigo: float = 1.0 - smoothstep(0.0, 1.0, (dz - 2.0) / 18.0 if dz >= 0.0 else (-dz - 2.0) / 11.0)
	var voo: float = clampf(p.y - altura(z), 0.0, 8.0)
	var correndo: bool = Vector2(jogador.velocity.x, jogador.velocity.z).length() > 8.03
	var cy: float = p.y if p.y >= altura(z) - 1.5 else (altura(z) + maxf(p.y, altura(z) - 9.0)) / 2.0
	var base: float = maxf(altura(z), cy - voo * 0.45)
	var alvo_olho := Vector3(p.x * 0.60 + clampf(jogador.velocity.x * 0.075, -0.65, 0.65) + float(s.side), base + float(s.h) + perigo * 1.85 + voo * 0.15, z + float(s.dist) + perigo * 2.35 + (0.60 if correndo else 0.0))
	var alvo_olhar := Vector3(p.x * 0.78 + clampf(jogador.velocity.x * 0.10, -0.65, 0.65), maxf(altura(z) + 0.90, cy + 1.50 + voo * 0.12) + perigo * 0.18, z - float(s.lead) - perigo * 1.8 - (0.75 if correndo else 0.0))
	if not pronto or Vector2(p.x - ultimo.x, p.z - ultimo.z).length() > 24.0:
		olho = alvo_olho
		olhar = alvo_olhar
		camera.fov = float(s.fov)
		pronto = true
	else:
		olho = olho.lerp(alvo_olho, 1.0 - exp(-(3.8 if perigo > 0.3 else 4.3) * dt))
		olhar = olhar.lerp(alvo_olhar, 1.0 - exp(-(5.0 if perigo > 0.3 else 5.7) * dt))
		camera.fov = lerpf(camera.fov, float(s.fov) + perigo * 2.25 + (0.6 if correndo else 0.0), 1.0 - exp(-2.6 * dt))
	ultimo = p
	camera.global_position = olho
	camera.look_at(olhar)
