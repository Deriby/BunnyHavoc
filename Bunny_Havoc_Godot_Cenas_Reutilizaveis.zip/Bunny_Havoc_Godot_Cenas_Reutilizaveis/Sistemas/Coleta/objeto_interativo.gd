extends Node3D
## Ligação opcional: cenas funcionam sem depender de um script específico de fase.
@export var caminho_jogador: NodePath
var _jogador: CharacterBody3D

func configurar_jogador(jogador: CharacterBody3D) -> void:
	_jogador = jogador

func localizar_jogador() -> CharacterBody3D:
	if is_instance_valid(_jogador):
		return _jogador
	if not caminho_jogador.is_empty():
		_jogador = get_node_or_null(caminho_jogador) as CharacterBody3D
	if _jogador == null and get_tree().current_scene != null:
		_jogador = get_tree().current_scene.find_child("Jogador", true, false) as CharacterBody3D
	return _jogador

func pode_interagir() -> bool:
	if localizar_jogador() == null or not _jogador.is_physics_processing():
		return false
	var saude: Node = _jogador.get_node_or_null("Saude")
	return saude == null or (not bool(saude.get("morto")) and not bool(saude.get("encerrado")))
