extends AudioStreamPlayer
## Componente opcional: acompanha a fase das pernas sem editar o controlador.

signal passo_tocado

@export var amostras: Array[AudioStream] = []

var _jogador: CharacterBody3D
var _animacao: RefCounted
var _tem_combo: bool = false
var _ultimo_contato: int = 0
var _ultima_posicao: Vector3
var _proximo_som: int = 0

func _ready() -> void:
	_jogador = get_parent() as CharacterBody3D
	if _jogador == null:
		push_warning("Arraste Passos.tscn sobre o nó Jogador (CharacterBody3D).")
		set_physics_process(false)
		return
	for propriedade in _jogador.get_property_list():
		if propriedade.name == "_animacao":
			_animacao = _jogador.get("_animacao") as RefCounted
		elif propriedade.name == "_combate":
			_tem_combo = true
	if _animacao == null:
		push_warning("Passos: use o controlador com as animações de locomoção do Bunnyck.")
		set_physics_process(false)
		return
	_ultima_posicao = _jogador.global_position
	_ultimo_contato = floori(float(_animacao.get("_passada")) / PI)

func _physics_process(_delta: float) -> void:
	var contato: int = floori(float(_animacao.get("_passada")) / PI)
	var posicao: Vector3 = _jogador.global_position
	var deslocamento: float = Vector2(posicao.x - _ultima_posicao.x, posicao.z - _ultima_posicao.z).length()
	var mudou: bool = contato != _ultimo_contato
	_ultimo_contato = contato
	_ultima_posicao = posicao
	if not mudou or not _jogador.is_on_floor() or deslocamento < 0.0001:
		return
	var estado: String = str(_animacao.get("estado"))
	if estado != "run" and estado != "sprint":
		return
	if _tem_combo:
		var combate: RefCounted = _jogador.get("_combate") as RefCounted
		if combate != null and combate.get("atacando"):
			return
	if amostras.is_empty():
		return
	stream = amostras[_proximo_som]
	_proximo_som = (_proximo_som + 1) % amostras.size()
	play()
	passo_tocado.emit()
