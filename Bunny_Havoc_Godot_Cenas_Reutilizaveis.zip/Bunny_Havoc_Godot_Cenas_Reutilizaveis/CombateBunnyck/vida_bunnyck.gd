extends Node
## Saúde da tentativa: três corações, imunidade 1,25 s e reação 0,22 s da fonte.

signal mudou
signal renasceu
signal fim_de_jogo

const SONS: Array[AudioStream] = [preload("audio/bunnyck_dano.wav"), preload("audio/bunnyck_morte.wav"), preload("audio/bunnyck_pouso.wav")]

var coracoes: int = 3
var vidas: int = 3
var imunidade: float = 0.0
var reacao: float = 0.0
var morto: bool = false
var encerrado: bool = false
var jogador: CharacterBody3D
var _visual: Node3D
var _combo: RefCounted
var _animacao: RefCounted
var _tempo_morte: float = 0.0
var _morte_vy: float = 0.0
var _morte_vx: float = 0.0
var _morte_chao: float = 0.0
var _pouso_morte: float = -1.0
var _tipo: String = "hit"
var _rotacao_original: Basis
var _escala_original: Vector3
var _angulo_morte: float = 0.0
var _som: AudioStreamPlayer

func _ready() -> void:
	process_physics_priority = 5
	jogador = get_parent() as CharacterBody3D
	_visual = jogador.get_node("Visual") as Node3D
	_combo = jogador.get("_combate") as RefCounted
	_animacao = jogador.get("_animacao") as RefCounted
	_escala_original = _visual.scale
	_som = AudioStreamPlayer.new()
	_som.name = "SomDanoBunnyck"
	add_child(_som)

func receber_dano(quantidade: int = 1, fonte: Node3D = null, tipo: String = "hit") -> bool:
	if morto or encerrado or (tipo != "pit" and imunidade > 0.0):
		return false
	coracoes = 0 if tipo == "pit" else maxi(0, coracoes - maxi(1, quantidade))
	_combo.limpar()
	_visual.visible = true
	mudou.emit()
	if coracoes > 0:
		_som.stream = SONS[0]
		_som.play()
		imunidade = 1.25
		reacao = 0.22
		jogador.velocity.x *= -0.25
		jogador.velocity.z *= -0.25
		jogador.set_process_unhandled_key_input(false)
		return true
	morto = true
	_som.stream = SONS[1]
	_som.play()
	_tipo = tipo
	_tempo_morte = 0.0
	_morte_vy = 9.0 if tipo == "hit" else 0.0
	_morte_vx = (4.0 if jogador.global_position.x >= fonte.global_position.x else -4.0) if fonte != null else 0.0
	_morte_chao = jogador.global_position.y
	_pouso_morte = -1.0
	_angulo_morte = 0.0
	_rotacao_original = _visual.basis
	jogador.velocity = Vector3.ZERO
	jogador.set_physics_process(false)
	jogador.set_process_unhandled_key_input(false)
	return true

func _physics_process(dt: float) -> void:
	if encerrado:
		return
	if morto:
		_animar_morte(dt)
		return
	imunidade = maxf(0.0, imunidade - dt)
	reacao = maxf(0.0, reacao - dt)
	_visual.visible = imunidade <= 0.0 or int(floor(imunidade * 18.0)) % 2 == 0
	if reacao <= 0.0:
		jogador.set_process_unhandled_key_input(true)

func _animar_morte(dt: float) -> void:
	_tempo_morte += dt
	if _tipo == "pit":
		if _tempo_morte < 0.55:
			_visual.basis = Basis(Vector3(0, 0, 1), sin(_tempo_morte * 45.0) * 0.18) * _rotacao_original
			for lado in ["E", "D"]:
				(_visual.find_child("Braco_" + lado, true, false) as Node3D).rotation.x = -2.5 + sin(_tempo_morte * 40.0) * 0.7
		else:
			_morte_vy -= 45.0 * dt
			jogador.global_position.y += _morte_vy * dt
			_visual.scale = _escala_original * Vector3(0.8, 1.25, 0.8)
		if _tempo_morte > 1.55:
			_terminar_morte()
	else:
		if _pouso_morte < 0.0:
			_morte_vy -= 24.0 * dt
			jogador.global_position += Vector3(_morte_vx, _morte_vy, 2.5) * dt
			_angulo_morte += dt * 14.0
			_visual.basis = Basis(Vector3(0, 0, 1), _angulo_morte) * _rotacao_original
			if jogador.global_position.y <= _morte_chao and _tempo_morte > 0.1:
				jogador.global_position.y = _morte_chao + 0.25
				_pouso_morte = _tempo_morte
				_som.stream = SONS[2]
				_som.play()
				_visual.basis = Basis(Vector3(0, 0, 1), PI / 2.0) * _rotacao_original
		else:
			_visual.visible = _tempo_morte - _pouso_morte < 0.6 or int(floor(_tempo_morte * 14.0)) % 2 == 0
			if _tempo_morte - _pouso_morte > 1.0:
				_terminar_morte()
		if _tempo_morte > 3.0 and morto:
			_terminar_morte()
	jogador.call("_atualizar_camera")

func _terminar_morte() -> void:
	vidas -= 1
	mudou.emit()
	if vidas <= 0:
		encerrado = true
		_visual.visible = false
		fim_de_jogo.emit()
		return
	_restaurar()
	renasceu.emit()

func _restaurar() -> void:
	morto = false
	imunidade = 0.0
	reacao = 0.0
	coracoes = 3
	_visual.basis = _rotacao_original if _rotacao_original.determinant() != 0.0 else _visual.basis
	_visual.scale = _escala_original
	_visual.visible = true
	jogador.call("voltar_ao_inicio")
	jogador.set_physics_process(true)
	jogador.set_process_unhandled_key_input(true)
	mudou.emit()

func reiniciar() -> void:
	vidas = 3
	encerrado = false
	_restaurar()
