extends RefCounted
## Queda pesada de lado: pose contínua, pausa de impacto, ressalto e poeira baixa.

var duracao_voo: float = 0.62
var duracao_total: float = 1.82
var impacto: bool = false
var menor_y: float = 0.0
var _animacao: RefCounted
var _inimigo: CharacterBody3D
var _meshes: Array[Node] = []
var _poeira: Node3D
var _puffs: Array[MeshInstance3D] = []
var _material: StandardMaterial3D
var _onda: MeshInstance3D
var _onda_material: StandardMaterial3D
var _pose_inicial: Dictionary = {}
var pausa_impacto: float = 0.065
var ressalto_maximo: float = 0.12
const TEMPO_IMPACTO: float = 0.12

func configurar(inimigo: CharacterBody3D, visual: Node3D, animacao: RefCounted) -> void:
	_inimigo = inimigo
	_animacao = animacao
	_meshes = visual.find_children("UrsoPeca_*", "MeshInstance3D", true, false)
	_poeira = Node3D.new()
	_poeira.name = "PoeiraImpacto"
	_poeira.top_level = true
	inimigo.add_child(_poeira)
	var gradient := Gradient.new()
	gradient.set_color(0, Color(0.8, 0.71, 0.53, 0.55))
	gradient.set_color(1, Color(0.8, 0.71, 0.53, 0.0))
	var texture := GradientTexture2D.new()
	texture.gradient = gradient
	texture.fill = GradientTexture2D.FILL_RADIAL
	texture.fill_from = Vector2(0.5, 0.5)
	texture.fill_to = Vector2(1.0, 0.5)
	_material = StandardMaterial3D.new()
	_material.albedo_texture = texture
	_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_material.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	_material.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	var quad := QuadMesh.new()
	quad.size = Vector2.ONE
	for i in 6:
		var puff := MeshInstance3D.new()
		puff.mesh = quad
		puff.material_override = _material
		_poeira.add_child(puff)
		_puffs.append(puff)
	_onda = MeshInstance3D.new()
	var anel := TorusMesh.new()
	anel.inner_radius = 0.66
	anel.outer_radius = 0.71
	anel.rings = 20
	anel.ring_segments = 4
	_onda.mesh = anel
	_onda_material = StandardMaterial3D.new()
	_onda_material.albedo_color = Color(0.95, 0.83, 0.64, 0.0)
	_onda_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_onda_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_onda.material_override = _onda_material
	_poeira.add_child(_onda)
	_poeira.visible = false

func iniciar(finalizador: bool) -> void:
	duracao_voo = 0.62 if finalizador else 0.30
	duracao_total = duracao_voo + 1.20
	impacto = false
	_poeira.visible = false
	_pose_inicial.clear()
	for node: Node3D in [_animacao.corpo, _animacao.torso, _animacao.cabeca, _animacao.mandibula] + _animacao.bracos + _animacao.antebracos + _animacao.pernas:
		_pose_inicial[node] = node.transform
	_assentar(0.0)

func _assentar(peso: float) -> void:
	menor_y = INF
	for node: MeshInstance3D in _meshes:
		var aabb: AABB = node.get_aabb()
		for i in 8:
			menor_y = minf(menor_y, (node.global_transform * aabb.get_endpoint(i)).y)
	var piso: float = _inimigo.chao_y + 0.025
	var ajuste: float = piso - menor_y
	if ajuste > 0.0 or peso > 0.0:
		_animacao.corpo.position.y += ajuste * (1.0 if ajuste > 0.0 else peso) / 1.15
		menor_y += ajuste * (1.0 if ajuste > 0.0 else peso)

func atualizar(idade: float) -> bool:
	var voo: float = clampf(idade / duracao_voo, 0.0, 1.0)
	var depois: float = maxf(0.0, idade - duracao_voo)
	var acomodacao: float = maxf(0.0, depois - TEMPO_IMPACTO - pausa_impacto)
	var queda: float = smoothstep(0.0, TEMPO_IMPACTO, depois)
	_animacao.aplicar_quadrupede()
	var corpo: Node3D = _animacao.corpo
	# Um giro de lado, sem colocar o urso em pé ou acumular cambalhotas.
	var angulo: float = -0.10 - 0.65 * smoothstep(0.0, 1.0, voo) - 0.80 * queda
	if acomodacao > 0.0:
		angulo += sin(acomodacao * 23.0) * 0.11 * exp(-acomodacao * 10.0)
	corpo.rotation = Vector3(-0.12 * voo, 0, angulo)
	var aperto: float = 0.0
	if depois >= TEMPO_IMPACTO and depois < TEMPO_IMPACTO + pausa_impacto:
		aperto = 0.15
	elif acomodacao > 0.0:
		aperto = 0.15 * exp(-acomodacao * 22.0)
	corpo.scale = Vector3(1.0 - aperto, 1.0 + aperto * 0.35, 1.0 + aperto * 0.25)
	var pivo := Vector3(0, 1.0, 0)
	corpo.position += pivo - corpo.basis * pivo
	for i in 2:
		_animacao.bracos[i].rotation.x -= 0.35 + queda * 0.25
		_animacao.bracos[i].rotation.z = (-0.40 if i == 0 else 0.40) * (1.0 - queda * 0.4)
		_animacao.antebracos[i].rotation.x = -0.5 - 0.2 * voo
		_animacao.pernas[i].rotation.x = 0.2 + (0.22 if i else -0.16) * sin(voo * PI)
	_animacao.cabeca.rotation.x -= 0.14 * (1.0 - queda)
	_animacao.mandibula.rotation.x = 0.25 * (1.0 - queda * 0.45)
	# O primeiro quadro parte da pose que estava na tela, inclusive no ataque.
	var mistura: float = smoothstep(0.0, 0.20, idade)
	for node: Node3D in _pose_inicial:
		node.transform = (_pose_inicial[node] as Transform3D).interpolate_with(node.transform, mistura)
	_assentar(queda)
	if acomodacao > 0.0:
		var pulo: float = sin(minf(acomodacao / 0.20, 1.0) * PI) * ressalto_maximo
		corpo.position.y += pulo / 1.15
		menor_y += pulo
	if depois >= TEMPO_IMPACTO:
		impacto = true
		var poeira_t: float = clampf((depois - TEMPO_IMPACTO) / 0.48, 0.0, 1.0)
		_poeira.visible = poeira_t < 1.0
		_poeira.global_position = Vector3(_inimigo.global_position.x, _inimigo.chao_y + 0.055, _inimigo.global_position.z)
		_material.albedo_color.a = 1.0 - poeira_t
		_onda_material.albedo_color.a = (1.0 - smoothstep(0.0, 0.65, poeira_t)) * 0.60
		_onda.scale = Vector3(1.0 + poeira_t * 2.0, 0.22, 1.0 + poeira_t * 2.0)
		for i in 6:
			var a: float = i * TAU / 6.0
			var largura: float = 0.50 + poeira_t * 1.15
			_puffs[i].position = Vector3(sin(a) * largura, 0.10 + sin(poeira_t * PI) * 0.16, cos(a) * largura)
			_puffs[i].scale = Vector3(0.62 + poeira_t * 0.45, 0.32 + poeira_t * 0.26, 1.0)
	var sumindo: float = clampf((depois - 0.98) / 0.22, 0.0, 1.0)
	corpo.visible = sumindo < 1.0
	if sumindo > 0.0:
		corpo.scale *= 1.0 - 0.30 * sumindo
		_assentar(1.0)
	return idade >= duracao_total

func reiniciar() -> void:
	impacto = false
	_poeira.visible = false
	_animacao.reiniciar()
