extends Node3D
## Editor: cenas individuais. Jogo: MultiMesh por recurso, sem alterar a composição.
@export var otimizar_em_execucao: bool = true
var lotes: int = 0
var pecas: int = 0

func _ready() -> void:
	if not otimizar_em_execucao:
		return
	var grupos: Dictionary = {}
	for node: MeshInstance3D in $Instancias.find_children("*", "MeshInstance3D", true, false):
		if not node.is_visible_in_tree() or node.mesh == null:
			continue
		var material: Material = node.get_active_material(0)
		var chave: String = str(node.mesh.get_rid()) + ":" + str(material.get_rid())
		if not grupos.has(chave):
			grupos[chave] = {"mesh": node.mesh, "material": material, "transforms": []}
		grupos[chave].transforms.append(global_transform.affine_inverse() * node.global_transform)
		pecas += 1
	for grupo: Dictionary in grupos.values():
		var multi := MultiMesh.new()
		multi.transform_format = MultiMesh.TRANSFORM_3D
		multi.mesh = grupo.mesh
		multi.instance_count = grupo.transforms.size()
		for i in multi.instance_count:
			multi.set_instance_transform(i, grupo.transforms[i])
		var node := MultiMeshInstance3D.new()
		node.multimesh = multi
		node.material_override = grupo.material
		add_child(node)
		lotes += 1
	$Instancias.visible = false
