@tool
extends Node3D
## Pequenas diferenças do modelo original por instância; não duplica geometrias.
@export_storage var ocultar_pecas: PackedInt32Array = PackedInt32Array()
@export_storage var ajustes_pecas: Array[Transform3D] = []:
	set(value):
		ajustes_pecas = value
		if is_inside_tree():
			_aplicar()

func _ready() -> void:
	_aplicar()

func _aplicar() -> void:
	for i in ajustes_pecas.size():
		var node := find_child("Parte_%02d" % (i + 1), true, false) as Node3D
		if node != null:
			node.transform = ajustes_pecas[i]

	for indice in ocultar_pecas:
		var node := find_child("Parte_%02d" % (indice + 1), true, false) as Node3D
		if node != null:
			node.visible = false
