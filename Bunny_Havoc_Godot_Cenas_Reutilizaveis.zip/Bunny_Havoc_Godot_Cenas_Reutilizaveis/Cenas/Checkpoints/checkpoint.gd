extends "res://Sistemas/Coleta/objeto_interativo.gd"
signal ativado(posicao: Vector3)
var ativo: bool = false
var _materiais: Array[Dictionary] = []

func _ready() -> void:
	process_physics_priority = 18
	add_to_group("bh_checkpoints")
	for mesh: MeshInstance3D in $Visual.find_children("*", "MeshInstance3D", true, false):
		var material := mesh.get_active_material(0).duplicate() as StandardMaterial3D
		mesh.material_override = material
		_materiais.append({"material": material, "color": material.albedo_color})

func _physics_process(_dt: float) -> void:
	if ativo or not pode_interagir() or not _jogador.is_on_floor():
		return
	var caixa := $Gatilho/CollisionShape3D as CollisionShape3D
	var metade: Vector3 = (caixa.shape as BoxShape3D).size * 0.5
	var local: Vector3 = caixa.to_local(_jogador.global_position)
	if absf(local.x) < metade.x and absf(local.y) < metade.y and absf(local.z) < metade.z:
		ativar()

func ativar() -> void:
	if ativo or localizar_jogador() == null:
		return
	ativo = true
	_jogador.set("_inicio", $Reaparecimento.global_position)
	for item: Dictionary in _materiais:
		(item.material as StandardMaterial3D).albedo_color = Color("9b5cff")
	$Som.play()
	ativado.emit($Reaparecimento.global_position)

func reiniciar() -> void:
	ativo = false
	for item: Dictionary in _materiais:
		(item.material as StandardMaterial3D).albedo_color = item.color
