extends "res://Sistemas/Coleta/objeto_interativo.gd"
signal coletada(valor: int, origem: Node3D)
@export var valor: int = 1
@export var som_local: bool = true
var _base_y: float
var _tempo: float = 0.0

func _ready() -> void:
	process_physics_priority = 15
	_base_y = position.y
	add_to_group("bh_cenouras")

func _physics_process(dt: float) -> void:
	_tempo += dt
	if not visible:
		return
	rotation.y += dt * 3.0
	position.y = _base_y + sin(_tempo * 3.0 + position.z) * 0.12
	if not pode_interagir():
		return
	var distancia: Vector3 = global_position - _jogador.global_position
	if absf(distancia.x) < 0.8 and absf(distancia.z) < 0.8 and absf(distancia.y - 0.8) < 1.2:
		coletar()

func coletar() -> void:
	if not visible:
		return
	visible = false
	if som_local:
		$Som.play()
	coletada.emit(valor, self)

func reiniciar() -> void:
	visible = true
