extends AnimatableBody3D
## Mesma trajetória da fonte: seno de 1,1 rad/s; transporte pelo piso nativo.
@export var amplitude: float = 2.1
@export var fase: float = -48.0
@export var velocidade: float = 1.1
var tempo: float = 0.0
var _centro_x: float

func _ready() -> void:
	process_physics_priority = -10
	sync_to_physics = false
	_centro_x = position.x
	add_to_group("bh_plataformas")

func _physics_process(dt: float) -> void:
	tempo += dt
	position.x = _centro_x + sin(tempo * velocidade + fase) * amplitude
