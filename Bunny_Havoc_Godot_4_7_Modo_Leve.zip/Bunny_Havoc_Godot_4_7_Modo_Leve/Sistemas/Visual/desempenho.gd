extends CanvasLayer
## Escala apenas o 3D; HUD, diálogos e entrada permanecem no viewport original.
const MODOS: Array[String]=["Leve","Mínimo","Original"]
const ESCALAS: Array[float]=[0.5,1.0/3.0,1.0]
var modo: int=0
var _aviso: Label
var _restante: float=0
var _psx: Node
var _viewport: Viewport
func _ready() -> void:
	layer=80
	_viewport=get_viewport()
	_psx=get_parent().get_node_or_null("FiltroPS1")
	_aviso=Label.new();_aviso.position=Vector2(20,178)
	_aviso.mouse_filter=Control.MOUSE_FILTER_IGNORE
	_aviso.add_theme_font_size_override("font_size",16)
	_aviso.add_theme_color_override("font_color",Color("fff0dc"))
	_aviso.add_theme_color_override("font_outline_color",Color("241335"))
	_aviso.add_theme_constant_override("outline_size",4)
	add_child(_aviso);_aviso.visible=false
	aplicar(0,false)
	_limitar_objetos.call_deferred()
func _limitar_objetos() -> void:
	# A névoa aprovada já está completa a 120 m. Não desenhar personagens e
	# itens ainda mais distantes; IA, gatilhos e colisões continuam funcionando.
	var fase: Node=get_parent()
	var raizes: Array=[]
	var objetos: Node=fase.get_node_or_null("Objetos")
	if objetos!=null:raizes.append(objetos)
	var final: Node=fase.get_node_or_null("FinalOriginal")
	if final!=null and final.get("espera")!=null:raizes.append(final.espera)
	for raiz: Node in raizes:
		for geometry: GeometryInstance3D in raiz.find_children("*","GeometryInstance3D",true,false):
			if geometry.visibility_range_end==0:geometry.visibility_range_end=145.0
func aplicar(indice: int,avisar: bool=true) -> void:
	modo=clampi(indice,0,MODOS.size()-1)
	_viewport.scaling_3d_mode=Viewport.SCALING_3D_MODE_NEAREST
	_viewport.scaling_3d_scale=ESCALAS[modo]
	if _psx!=null:_psx.definir_escala_3d(ESCALAS[modo])
	if avisar:
		_aviso.text="Gráficos: "+MODOS[modo]+" — F3 para trocar"
		_restante=3;_aviso.visible=true
func _process(dt: float) -> void:
	if _restante<=0:return
	_restante=maxf(0,_restante-dt)
	_aviso.visible=_restante>0
func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and (event.physical_keycode==KEY_F3 or event.keycode==KEY_F3):
		aplicar((modo+1)%MODOS.size());get_viewport().set_input_as_handled()
