# Atualização 007 — pacote PSX enviado pelo usuário

Aplicar sobre 006, com o Godot fechado. F5 joga com o efeito já ligado;
**F2 alterna com os materiais e a imagem originais**.
O filtro anterior foi substituído pelo PSX de Francisco Cidade: shader de tela,
vertex snapping, texturas afins e iluminação por vértice. Os cinco shaders
estão intactos em `addons/psx_shader/shaders/`, com licença CC0 e README original.
As texturas e modelos de exemplo do pacote não foram importados para a fase.

O adaptador usa as cores e texturas do próprio Bunny Havoc. Só aplica overrides
em execução; os arquivos GLB e as malhas continuam iguais. Restaura os recursos
originais ao desligar e acompanha os fades da cutscene e objetos criados depois.
HUD e legendas ficam acima do shader de tela. O céu continua com energia 1.5.
O shader de materiais do pacote não recebe sombras, conforme seu render_mode.

Em `Fase1Trecho.tscn`, selecione `FiltroPS1`. Inspetor:
- `Ativado`: iniciar com/sem o pacote; padrão ligado.
- `Tamanho Pixel`: 3 padrão do pacote, 2 para uma imagem mais definida.
- `Materiais 3d`: inclui o shader dos modelos; desligar deixa só o efeito de tela.
- `Dithering`: intensidade do pontilhado na tela, de 0 a 1.
Salve e reinicie a execução após mudar os parâmetros. Para reutilizar em outra
fase, arraste `Sistemas/Visual/FiltroPS1.tscn` para a raiz; uma instância por cena.
O efeito não reduz a resolução real de renderização do 3D.

# Atualização anterior 006 — filtro PS1 opcional

Aplicar sobre a atualização 005. F5 inicia o jogo; **F2 liga/desliga o filtro**.
Ele começa desligado. Reduz a imagem do mundo para cerca de 320×180 em 16:9,
com 32 níveis por canal e dithering discreto. HUD e legendas continuam nítidos.
Funciona também na cutscene. O filtro não altera modelos, luzes ou gameplay.

Para começar ligado, selecione `FiltroPS1` em `Fase1Trecho.tscn` e marque
`Ativado` no Inspetor. No mesmo lugar: `Altura Virtual` 180 = pixelado,
240 = mais definido; `Niveis Cor` 32; `Dithering` 0 a 1.
Para usar em outra fase, arraste `Sistemas/Visual/FiltroPS1.tscn` para a cena.
Use somente uma instância por viewport. Mantenha a camada 0; HUD/legendas >0.
Este é um filtro de pós-processamento: o 3D continua renderizado na resolução
normal. Ele não reduz o custo da geometria e não simula todas as limitações
do hardware PS1. Compatível com o renderer Compatibility do Godot 4.4.

# Atualização anterior 005 — câmera e saltos

Aplicar sobre a atualização 004, com o Godot fechado, na pasta de
`project.godot`. F5 joga normalmente. A câmera mostra melhor a margem de
chegada dos vãos e acompanha menos a subida do salto. A tolerância ao sair
da borda e a antecipação de um toque antes de aterrissar são de 0,12 s.
Segurar Espaço não repete o salto; um toque muito cedo no ar expira.
Velocidades, gravidade, força dos saltos, caixas-mola e cutscene preservados.

# Atualização anterior 004 — direção cinematográfica

Aplicar este patch **sobre a atualização 003**, na pasta de `project.godot`.
Feche o Godot antes de extrair e substituir. F5 continua iniciando o jogo.
Para assistir direto, abra **`PreviaFinal.tscn` e aperte F6**. R repete a prévia;
Enter revela a fala e, no próximo toque, avança o diálogo.

A cena de Bunnyldu e Bibibunn recebeu planos e contraplanos, reações, atuação
mais contida, luz de recorte, luz da magia, legendas e faixas cinematográficas.
Foley e uma trilha instrumental discreta acompanham a jaula e os impactos.
Uma câmera lenta breve destaca o arremesso. Os modelos, falas, acontecimentos,
trajetórias da jaula e animações de base foram preservados. Ao sair da cena,
a luz, a música e as aves do cenário voltam ao estado anterior.
O céu continua com energia 1.5. Nenhuma geometria foi reexportada.

# Base anterior — Fase 1 completa no Godot

O Bosque Verde agora vai do início até a cutscene original do resgate:
sete vãos grandes, sete checkpoints, sete plataformas, 19 inimigos originais
mais o urso aprovado, 14 NPCs, 13 caixas e três segredos. Os prefabs anteriores
continuam no lugar; `Fase1/Completa` acrescenta cenário, colisão e objetos.

Aplicar **atualização 003** sobre o projeto Lagarto ou atualizações 001/002,
na pasta de `project.godot`, com Godot
fechado. F5 joga. Controles e instalação em `LEIA-ME.txt`. Não é uma recriação:
as malhas e posições vêm dos construtores Three.js preservados. O Bunnyck,
os modelos aprovados e o céu nativo com energia 1.5 foram mantidos.

A cutscene tem as 18 etapas originais. Poses, câmera, escalas e visibilidade
foram amostradas do diretor original a 20 Hz e são interpoladas no Godot.
Não depende de navegador ou Three.js em execução. A voz sintetizada foi
extraída para `final.wav`; animação em `final.json.gz`, modelo em `Final.glb`.
Enter avança o diálogo; o final exibe resultados e salva o progresso local.

As caixas reforçada, mola e Nitro têm cenas e scripts próprios. A coleta
concede uma vida a cada 100 cenouras; segredos valem 25. O pisão usa a altura
do colisor nativo. A regra de queda da antiga arena foi desativada nesta fase,
que já usa a altura real do terreno. Os cidadãos escolhem o interlocutor mais
próximo e reutilizam diálogo, com rotinas e modelos individuais.

A Vila e a Fase 2 ainda não foram migradas. A entrada das tocas bônus permanece
desativada como na fonte atual. O HTML/TypeScript original continua preservado.

`export_presets.cfg` prepara Windows e Web, incluindo os JSON/GZIP. Instalar
os templates da mesma versão local do Godot antes de exportar. Foram testados
o editor/runtime Godot 4.4 e renderização Compatibility Linux; exports de
Windows/Web não foram executados nesta entrega.

Gerar: `node tools/export_godot_phase1.cjs`, depois
`python3 tools/build_godot_phase1.py`. Os geradores nunca reexportam os GLBs
já aprovados. As entregas são patches, não pastas completas.
