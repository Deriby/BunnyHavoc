# Bunny Havoc — cenário estático unificado

Godot 4.7.2 Compatibility. Extraia em pasta nova, importe project.godot e F5.
F3 alterna Leve 240 linhas, Mínimo 180 e Nítido. F4 exibe FPS. Sem PS1,
sem névoa e sem corte radial; céu 1,5. Fase 1 completa, Vila/Fase 2 ainda não
migradas. Colisões e pulinho de dano mantidos.

## Cenário

Fase1/Estatico/CenarioEstatico.tscn contém 152 blocos de 32 x 32 m com terreno,
árvores, montanhas, pedras, flores, matos e cogumelos combinados por material.
Os 539.452 triângulos originais e as 2.791 peças de vegetação são preservados
no nível de detalhe completo. LODs nativos já estão gravados; a engine pode
reduzir detalhes pequenos na tela. Textura e materiais são recursos comuns.
A colisão de chão, limites e plataformas continua independente da malha visual.
Faixas distantes usam agrupamentos HLOD pré-calculados de 64 m, com seleção de
LOD nativa. Perto do jogador voltam os blocos completos. Nenhuma faixa some;
a troca usa apenas camadas de desenho e não altera a física.

O jogo não instancia o bosque de autoria nem cria lotes de plantas. Vegetação
fica estática e não dobra ao passar; não há rotinas de vento por planta.
Pássaros, borboletas, poeira e folhas levantadas por golpes continuam ativos.
Os pontos das folhas são metadados do cenário, sem exigir objetos decorativos.
NPCs, inimigos, caixas, cenouras, checkpoints, plataformas e atores da cutscene
continuam separados. HLOD de atores distantes e animações próximas mantidos.

## Edição e geração

Sistemas/Visual/fontes_cenario.gd mostra as quatro cenas originais do bosque
no editor e oculta o bake, evitando desenho duplicado. No jogo faz o inverso,
sem carregar os milhares de nós de decoração. Abra Fase1/Cenario.tscn,
Trecho2/Cenario.tscn, Trecho4/Cenario.tscn e Completa/Cenario.tscn para editar
as fontes. Os modelos e arquivos originais não são alterados pelo gerador.

Depois de editar, execute tools/build_static_world.gd no Godot 4.7.2, copiando
o script para a raiz de uma cópia de importação do projeto. O script ativa
BH_BUILD_STATIC_WORLD=1, carrega as fontes, une os triângulos por setor/material,
cria textura/materiais compartilhados e grava os LODs fora do jogo. Copie a
pasta Fase1/Estatico resultante para o projeto. tools/build_visual_cache.gd
atualiza os recursos otimizados dos objetos dinâmicos separadamente.

Recursos/Otimizados contém apenas o cache de objetos ainda usados pelo jogo;
os antigos recursos de vegetação e terreno gerados em execução foram retirados.
O exemplo independente e os modelos reutilizáveis continuam disponíveis;
se faltarem LODs de um recurso editado, o fallback usa a geometria completa.

Esta arquitetura visa PCs com vídeo integrado e pouca RAM. A capacidade de
6 GB não determina sozinha o FPS; CPU, driver e GPU integrada também contam.
